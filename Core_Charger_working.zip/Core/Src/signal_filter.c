/**
 * @file    signal_filter.c
 * @brief   Implementation: Kalman+MA+Median+Rate-limiter+Validation
 *          Why: Rejects balancer glitches (sudden cellV jumps), noise, outliers
 *          Ensures fault_detector/SOC use only automotive-grade clean signals
 *
 * @fix     Removed false OV trigger: minCellmV >= maxCellmV - 0.01f check
 *          was using a 0.01 mV threshold in a millivolt-domain comparison,
 *          effectively rejecting all well-balanced packs. Cell OV/UV fault
 *          detection is handled downstream by fault_detector using
 *          filtered_min/max_cellV (already converted to Volts).
 */

#include "signal_filter.h"
#include "daly_bms.h"
#include <math.h>
#include <string.h>

/* ---- Private helpers ----------------------------------------------------- */
static float kalman_update(float x, float P, float z, float dt);
static float moving_average(float *buf, uint8_t *head, uint8_t size, float new_val);
static float median3(float *buf, uint8_t *head, float new_val);
static bool  rate_limited(float prev, float now, float limit_per_100ms);

/* ---- Public API ---------------------------------------------------------- */

/**
 * @brief  Initialise all filter state to safe defaults.
 * @param  hfilter  Pointer to filter handle (must not be NULL).
 */
void SignalFilter_Init(SignalFilter_Handle_t *hfilter)
{
    memset(hfilter, 0, sizeof(*hfilter));

    hfilter->kalman_x     = KALMAN_INIT_X;
    hfilter->kalman_P     = 1.0f;
    hfilter->kalman_prevV = KALMAN_INIT_X;

    /* Pre-fill MA buffers with plausible resting voltages so the
     * first few real samples are not diluted by zeros.             */
    for (uint8_t i = 0; i < FILTER_MA_WINDOW; i++) {
        hfilter->ma_packV[i] = KALMAN_INIT_X;
        hfilter->ma_minV[i]  = 3.3f;
        hfilter->ma_maxV[i]  = 4.2f;
    }
}

/**
 * @brief  Run one filter cycle (call every 100 ms).
 *
 * Pipeline:
 *   Raw validation → mV-to-V conversion → Kalman (packV) →
 *   Rate limiter → Moving average → Median → Output
 *
 * @param  hfilter    Filter state handle.
 * @param  pdaly      Latest raw BMS frame.
 * @param  current_a  Pack current in Amperes (signed).
 * @param  tick_ms    Current system tick (reserved for future dt calc).
 * @return FilteredData_t with .valid = true on success, false on rejection.
 */
FilteredData_t SignalFilter_Update(SignalFilter_Handle_t *hfilter,
                                   const DalyBMS_Data_t  *pdaly,
                                   float                  current_a,
                                   uint32_t               tick_ms)
{
    FilteredData_t out = {0};
    hfilter->total_samples++;

    /* ------------------------------------------------------------------ */
    /* 1. Raw validation (physical implausibility)                         */
    /* ------------------------------------------------------------------ */
    if (!SignalFilter_ValidateRaw(pdaly, current_a)) {
        return out; /* .valid remains false */
    }

    /* NOTE: Balancer glitch rejection REMOVED here.
     * The Double-Kalman EKF in daly_bms.c handles outlier rejection via
     * 100-sample median + cascaded Kalman filters.  Removing this block
     * prevents the "voltages freeze when balancer active" deadlock.        */

    /* ------------------------------------------------------------------ */
    /* 2. Unit conversion: cellVmV (millivolts) → Volts                   */
    /*                                                                      */
    /* cellVmV[] stores values like 3700 (= 3.700 V).                      */
    /* filtered_min/max_cellV must be in VOLTS to match FaultThresholds_t  */
    /* (cellMax_V = 4.25 V, cellMin_V = 3.00 V).                           */
    /* Old bug: raw mV values (~3700) were compared directly against V      */
    /* thresholds (~4.25), always triggering a false Cell OV fault.         */
    /* ------------------------------------------------------------------ */
    float raw_packV = pdaly->packVoltage;
    float raw_minV  = 99.0f;
    float raw_maxV  =  0.0f;

    for (uint8_t i = 0; i < pdaly->numberOfCells && i < DALY_MAX_CELLS; i++) {
        float cell_v = pdaly->cellVmV[i] / 1000.0f; /* mV → V */

        /* Sanity: accept only values inside the valid LiX range */
        if (cell_v > 0.5f && cell_v < 5.0f) {
            if (cell_v < raw_minV) raw_minV = cell_v;
            if (cell_v > raw_maxV) raw_maxV = cell_v;
        }
    }

    if (raw_minV >= 99.0f) {
        return out; /* No valid cell readings — reject frame */
    }

    /* ------------------------------------------------------------------ */
    /* 3. Kalman filter (pack voltage only)                                */
    /* ------------------------------------------------------------------ */
    float dt         = 0.1f; /* Fixed 100 ms cycle */
    float kalman_packV = kalman_update(hfilter->kalman_x,
                                       hfilter->kalman_P,
                                       raw_packV,
                                       dt);

    /* ------------------------------------------------------------------ */
    /* 4. Rate limiter — rejects step-changes beyond physical plausibility */
    /* ------------------------------------------------------------------ */
    if (!rate_limited(hfilter->kalman_prevV, kalman_packV,
                      FILTER_RATE_LIMIT_V_100MS)) {
        hfilter->rejected_rate++;
        return out;
    }
    hfilter->kalman_prevV = kalman_packV;

    /* ------------------------------------------------------------------ */
    /* 5. Moving average (smooths high-frequency noise)                    */
    /* ------------------------------------------------------------------ */
    float ma_packV = moving_average(hfilter->ma_packV, &hfilter->ma_head_packV,
                                    FILTER_MA_WINDOW, kalman_packV);
    float ma_minV  = moving_average(hfilter->ma_minV,  &hfilter->ma_head_minV,
                                    FILTER_MA_WINDOW, raw_minV);
    float ma_maxV  = moving_average(hfilter->ma_maxV,  &hfilter->ma_head_maxV,
                                    FILTER_MA_WINDOW, raw_maxV);

    /* ------------------------------------------------------------------ */
    /* 6. Median filter (window = 3, odd → no ambiguity)                  */
    /*    Rejects any remaining single-sample spikes after averaging.      */
    /* ------------------------------------------------------------------ */
    hfilter->median_head = (hfilter->median_head + 1) % FILTER_MEDIAN_WINDOW;
    hfilter->median_packV[hfilter->median_head] = ma_packV;
    hfilter->median_minV [hfilter->median_head] = ma_minV;
    hfilter->median_maxV [hfilter->median_head] = ma_maxV;

    /* head pointer not used by median3 — full 3-element buf is always valid */
    float med_packV = median3(hfilter->median_packV, NULL, 0.0f);
    float med_minV  = median3(hfilter->median_minV,  NULL, 0.0f);
    float med_maxV  = median3(hfilter->median_maxV,  NULL, 0.0f);

    /* ------------------------------------------------------------------ */
    /* 7. Populate output (values are in VOLTS, ready for fault_detector)  */
    /* ------------------------------------------------------------------ */
    out.filtered_packV     = med_packV;
    out.filtered_min_cellV = med_minV;   /* Volts — compared vs cellMin_V  */
    out.filtered_max_cellV = med_maxV;   /* Volts — compared vs cellMax_V  */
    out.valid              = true;

    return out;
}

/**
 * @brief  Validate raw BMS frame for physical plausibility.
 *
 * Checks performed:
 *   - Pack voltage within 1–60 V (covers 2S–14S LiX packs)
 *   - Current magnitude below 50 A (application-specific ceiling)
 *   - Cell count within expected range for this hardware (6–24 cells)
 *
 * NOT checked here (handled downstream by fault_detector):
 *   - Individual cell over/under voltage
 *   - Pack over/under voltage
 *   - Temperature limits
 *
 * @note   The former check `minCellmV >= maxCellmV - 0.01f` has been REMOVED.
 *         Reason 1: 0.01 mV threshold is meaningless in the mV domain —
 *                   it fires for any pack with cells balanced within 0.01 mV,
 *                   i.e. a perfectly healthy balanced pack.
 *         Reason 2: The intent (catching corrupt min > max data) is served
 *                   correctly by the cell-voltage sanity range check
 *                   (0.5 V < cell_v < 5.0 V) in SignalFilter_Update, which
 *                   already discards nonsensical readings before min/max are
 *                   computed.
 *
 * @param  pdaly      Raw BMS data frame.
 * @param  current_a  Pack current in Amperes (signed).
 * @return true if frame is plausible, false if it should be discarded.
 */
bool SignalFilter_ValidateRaw(const DalyBMS_Data_t *pdaly, float current_a)
{
    /* Pack voltage: must be within physical LiX multi-cell range */
    if (pdaly->packVoltage < 1.0f || pdaly->packVoltage > 60.0f) {
        return false;
    }

    /* Current: reject absurdly large values (sensor fault / CAN corruption) */
    if (fabsf(current_a) > 50.0f) {
        return false;
    }

    /* Cell count: must match hardware configuration */
    if (pdaly->numberOfCells < 6 || pdaly->numberOfCells > 24) {
        return false;
    }

    /* REMOVED: if (pdaly->minCellmV >= pdaly->maxCellmV - 0.01f)
     *
     * This check caused FALSE OVER-VOLTAGE rejections:
     *   - Threshold 0.01 (mV) is effectively zero; any balanced pack
     *     triggers it and gets silently dropped.
     *   - Cell OV/UV is correctly detected by fault_detector using
     *     filtered_min/max_cellV which arrive in Volts after the
     *     mV→V conversion in SignalFilter_Update.                    */

    return true;
}

/* ---- Private implementations -------------------------------------------- */

/**
 * @brief  1-D scalar Kalman filter (constant-velocity model).
 *
 * State  x : estimated voltage
 * Covar  P : estimation uncertainty
 * Q      : process noise (KALMAN_Q — tuned for slow voltage drift)
 * R      : measurement noise (KALMAN_R — tuned for ADC/CAN noise floor)
 *
 * @param  x   Previous state estimate.
 * @param  P   Previous covariance.
 * @param  z   New measurement.
 * @param  dt  Time step (seconds) — reserved; model is currently static.
 * @return     Updated state estimate.
 *
 * @note   P and x are passed by value here; the caller (SignalFilter_Update)
 *         owns the persistent copies inside the handle struct.
 */
static float kalman_update(float x, float P, float z, float dt)
{
    /* -- Predict -------------------------------------------------------- */
    float x_pred = x;               /* Static model: no motion assumed    */
    float P_pred = P + KALMAN_Q;    /* Uncertainty grows with time         */

    /* -- Update --------------------------------------------------------- */
    float K = P_pred / (P_pred + KALMAN_R); /* Kalman gain                */
    x = x_pred + K * (z - x_pred);          /* Fuse prediction + measurement */
    P = (1.0f - K) * P_pred;                /* Reduce uncertainty          */

    (void)dt; /* dt retained in signature for future constant-velocity model */
    return x;
}

/**
 * @brief  Circular-buffer moving average.
 *
 * @param  buf      Circular sample buffer (length = size).
 * @param  head     Write index (updated in-place).
 * @param  size     Buffer / window length.
 * @param  new_val  New sample to insert.
 * @return          Arithmetic mean of all samples in the window.
 */
static float moving_average(float *buf, uint8_t *head, uint8_t size,
                             float new_val)
{
    buf[*head] = new_val;
    *head = (*head + 1) % size;

    float sum = 0.0f;
    for (uint8_t i = 0; i < size; i++) {
        sum += buf[i];
    }
    return sum / (float)size;
}

/**
 * @brief  Median of a fixed 3-element buffer (insertion-sort approach).
 *
 * The head/dummy parameters are present only for API uniformity with the
 * moving_average helper; they are not used because the full 3-element
 * buffer is always valid after initialisation.
 *
 * @param  buf    Buffer of exactly 3 floats.
 * @param  head   Unused (pass NULL).
 * @param  dummy  Unused (pass 0.0f).
 * @return        Median value (middle of sorted triple).
 */
static float median3(float *buf, uint8_t *head, float dummy)
{
    float a = buf[0], b = buf[1], c = buf[2];

    /* Sorting network for 3 elements (3 comparisons, optimal) */
    if (a > b) { float t = a; a = b; b = t; }
    if (a > c) { float t = a; a = c; c = t; }
    if (b > c) { float t = b; b = c; c = t; }

    (void)head;
    (void)dummy;
    return b; /* Middle element = median */
}

/**
 * @brief  Rate limiter — accepts a new value only if the step from the
 *         previous value is within the allowed slew rate.
 *
 * @param  prev             Last accepted value.
 * @param  now              Candidate new value.
 * @param  limit_per_100ms  Maximum allowed change per 100 ms cycle.
 * @return true  if the step is within limit (value accepted),
 *         false if the step exceeds limit (value rejected).
 */
static bool rate_limited(float prev, float now, float limit_per_100ms)
{
    return fabsf(now - prev) <= limit_per_100ms;
}
