/**
 * @file    soc_extended.c
 * @brief   Verified SOC persistence impl: CRC16 buffer[3], stable-only updates
 */

#include "soc_extended.h"
#include "calib_store.h"  /* For flash save */
#include "main.h"        /* SaveSystemStateToFlash() prototype */
#include <string.h>

/* CRC16 CCITT table-free impl */
static uint16_t crc16_byte(uint16_t crc, uint8_t data) {
  crc ^= (uint16_t)data << 8;
  for (uint8_t i = 0; i < 8; i++) {
    if (crc & 0x8000U) {
      crc = (crc << 1) ^ SOC_CRC16_POLY;
    } else {
      crc <<= 1;
    }
  }
  return crc;
}

uint16_t SOC_Extended_CRC16(const VerifiedSOC_t *psoc) {
  uint16_t crc = 0U;
  const uint8_t *p = (const uint8_t*)psoc;
  for (uint8_t i = 0; i < sizeof(VerifiedSOC_t) - sizeof(uint16_t); i++) {
    crc = crc16_byte(crc, p[i]);
  }
  return crc;
}

bool SOC_Extended_VerifyCRC(const VerifiedSOC_t *psoc) {
  return (SOC_Extended_CRC16(psoc) == psoc->crc16);
}

/* ---- Public API ---------------------------------------------------------- */

bool SOC_Extended_Init(SOC_Extended_Handle_t *se, const SOC_Config_t *config, uint32_t time_ms) {
  /* Base init w/ 50% default */
  SOC_Init(&se->base, config, 50.0f, time_ms);
  
  se->latest_idx = 0;
  se->last_save_tick = time_ms;
  se->save_interval_ms = 5U * 60U * 1000U;  /* 5 min */
  se->last_soc_percent = 50.0f;
  
  /* Try restore latest verified from flash (via CalibStore_Load) */
  CalibStore_Data_t cal;
  if (CalibStore_Load(&cal) && cal.soc_verified_valid) {
    /* Check buffer for valid CRC */
    for (uint8_t i = 0; i < SOC_VERIFIED_BUFFER_SIZE; i++) {
      VerifiedSOC_t *p = (VerifiedSOC_t*)&cal.soc_verified_buffer[i];
      if (SOC_Extended_VerifyCRC(p)) {
        se->base.soc_percent = p->verified_soc_percent;
        se->base.remaining_ah = p->verified_remaining_ah;
        se->latest_idx = i;
        return true;  /* Restored valid, no default used */
      }
    }
  }
  /* No valid verified → stick w/ default */
  return false;
}

void SOC_Extended_Update(SOC_Extended_Handle_t *se, float current_a, bool filter_valid, bool no_fault, uint32_t time_ms) {
  /* Base coulomb counting */
  SOC_Update(&se->base, current_a, time_ms);
  
  /* Stable condition for verified update? */
  se->soc_stable = (filter_valid && no_fault && fabsf(current_a) < 0.2f);  /* Idle <0.2A */
}

void SOC_Extended_SaveIfNeeded(SOC_Extended_Handle_t *se) {
  float now_soc = se->base.soc_percent;
  uint32_t now = HAL_GetTick();
  
  /* Throttle: 1% change OR 5min */
  bool percent_changed = fabsf(now_soc - se->last_soc_percent) >= 1.0f;
  bool interval_passed = (now - se->last_save_tick) >= se->save_interval_ms;
  
  if (se->soc_stable && (percent_changed || interval_passed)) {
    /* Rotate buffer */
    se->latest_idx = (se->latest_idx + 1) % SOC_VERIFIED_BUFFER_SIZE;
    
    /* Write newest */
    VerifiedSOC_t *pnew = (VerifiedSOC_t*)&se->buffer[se->latest_idx];
    pnew->verified_soc_percent = now_soc;
    pnew->verified_remaining_ah = se->base.remaining_ah;
    pnew->crc16 = SOC_Extended_CRC16(pnew);
    
    se->last_soc_percent = now_soc;
    se->last_save_tick = now;
    
    /* Trigger flash save via calib_store (adds to CalibStore_Data_t) */
    SaveSystemStateToFlash();  /* External call */
  }
}

float SOC_Extended_GetVerifiedPercent(const SOC_Extended_Handle_t *se) {
  VerifiedSOC_t *platest = (VerifiedSOC_t*)&se->buffer[se->latest_idx];
  return SOC_Extended_VerifyCRC(platest) ? platest->verified_soc_percent : 50.0f;
}
