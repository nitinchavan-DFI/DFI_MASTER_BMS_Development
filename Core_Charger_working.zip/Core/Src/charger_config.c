/**
 * @file    charger_config.c
 * @brief   Solterra charger: ISR-safe RX latch, main-loop decode,
 *          CC/CV state machine, and CV cutoff termination.
 */
#include "charger_config.h"
#include "fault_detector.h"
#include <string.h>

/**
 * Fault conditions that trigger immediate STOP command:
 *   FAULT_BIT_OV  — Over-Voltage (pack or cell)
 *   FAULT_BIT_OT  — Over-Temperature (NTC1)
 *   FAULT_BIT_OT2 — Over-Temperature (NTC2)
 * These are the safety-critical faults that must stop charging
 * regardless of CC/CV phase. Other faults (UV, OC, cell diff)
 * are monitored but do NOT gate charging — they are handled by
 * the Daly BMS hardware protection.
 */
/**
 * Fault conditions that trigger immediate STOP command.
 *
 * CORRECTED — the mask was (OV | OT | OT2) while the PATH A comment in
 * Charger_ComputeCommand() below claimed cell over-voltage was covered. It
 * was not, and neither was charge over-current:
 *
 *   FAULT_BIT_CELL_OV — a single cell over cellMax_V (4.26 V by default)
 *     did not stop charging. With the charger targeting 4.20 V/cell, one
 *     high cell in an imbalanced pack is precisely the case that needs to
 *     halt the session; pack OV at 58.8 V will not see it, because 13 sag-
 *     ging cells hide one climbing cell in the pack total.
 *   FAULT_BIT_CHARGE_OC — omitting this is the same defect that previously
 *     allowed uncontrolled charge current and the cascading FDCAN EMI hang.
 *
 * Still deliberately excluded (Daly hardware protection handles them, and
 * they are not charge-direction faults): pack UV, discharge OC, cell UV,
 * cell imbalance, under-temperature.
 *
 * If you need the old behaviour back for a bench test, drop the two added
 * bits — but do not ship it that way.
 */
#define CHARGER_GATING_FAULT_MASK  (FAULT_BIT_OV | FAULT_BIT_OT | \
                                    FAULT_BIT_OT2 | FAULT_BIT_CELL_OV | \
                                    FAULT_BIT_CHARGE_OC)
#define CHARGER_RX_V_MAX_V         70.0f
#define CHARGER_RX_I_MAX_A         60.0f

/* CV phase: charger-reported V must reach this fraction of the setpoint
 * before we consider it in CV mode (0.995 = within 0.5% of target). */
#define CV_ENTRY_RATIO  0.995f

ChargerRxStage_t g_chargerRxStage;

/**
 * @brief  CHARGER-SIDE Temp1 start/continue gate — completely independent
 *         of the pack-level safety fault system.
 *
 *         This function does NOT read faultBitmask, does NOT read
 *         fault_detector's otTemp_C threshold (FAULT_OT_DEFAULT = 55.0°C,
 *         FAULT_HYST_OT_C = 3.0°C — pack safety, last-resort trip that
 *         stops charge AND discharge), and does NOT touch FaultFlags_t.
 *         It only compares the raw Temp1 (NTC1) reading against its own
 *         charger-only thresholds (CHARGER_TEMP_START_BLOCK_C /
 *         CHARGER_TEMP_START_HYST_C / CHARGER_TEMP_START_RESUME_C, all
 *         defined in charger_config.h, unrelated to fault_detector.h's
 *         values). The two systems happen to look at the same physical
 *         sensor, but the thresholds, the state they latch, and the code
 *         path are entirely separate — this gate can change without
 *         touching pack fault behaviour, and vice versa.
 *
 *         Sticky/latched so it can't chatter right on a boundary:
 *           BLOCK  @ temp >= CHARGER_TEMP_START_BLOCK_C             (50.0°C)
 *           RESUME @ temp <= CHARGER_TEMP_START_RESUME_C             (47.0°C)
 *           Holds previous state in between (the 3.0°C hysteresis band).
 *
 * @param  rt       Runtime handle — the tempStartBlocked latch lives here.
 * @param  temp1_C  Current Temp1 reading (°C). 0.0f = "ADC not ready yet"
 *                  sentinel, sits below the resume point so it never
 *                  spuriously blocks charging before the first sample.
 * @return true  if this gate is currently BLOCKING charger start/continue.
 */
static bool Charger_TempStartGate_Update(ChargerRuntime_t *rt, float temp1_C) {
  if (temp1_C >= CHARGER_TEMP_START_BLOCK_C) {
    rt->tempStartBlocked = 1U;
  } else if (temp1_C <= CHARGER_TEMP_START_RESUME_C) {
    rt->tempStartBlocked = 0U;
  }
  /* else: temp is inside the 47.0-50.0°C hold band — leave the latch as-is.
   * RESUME_C is now derived from BLOCK_C minus the single hysteresis
   * constant, so this comparison is the whole gate; there is no second
   * tolerance term silently shifting the resume point down to 46.2°C. */
  return (rt->tempStartBlocked != 0U);
}

void ChargerConfig_LoadDefaults(CLI_ChargerConfig_t *cfg) {
  cfg->cellVoltageSetpoint_V = CHARGER_CONFIG_DEFAULT_CELL_V;
  cfg->chargeCurrentFull_A   = CHARGER_CONFIG_DEFAULT_ICHG_A;
  cfg->cvCutoffCurrent_A     = CHARGER_CONFIG_DEFAULT_ITAPER_A;
  cfg->socTaperStart_pct     = CHARGER_CONFIG_DEFAULT_SOC_TAPER;
  cfg->cellCount             = CHARGER_CONFIG_DEFAULT_CELLS;
  cfg->chargeEnable          = 1U;
  cfg->reserved[0]           = 0U;
  cfg->reserved[1]           = 0U;
}

void Charger_RuntimeInit(ChargerRuntime_t *rt) {
  memset(rt, 0, sizeof(*rt));
  rt->state = CHARGER_STATE_DISCONNECTED;
}

void Charger_LatchRawFrame(ChargerRxStage_t *stage, const uint8_t *data, uint8_t len) {
  /* ISR context — O(1), no math, no branches on content. */
  if (stage->pending) {
    stage->overrun_count++;
  }
  uint8_t n = (len > 8U) ? 8U : len;
  for (uint8_t i = 0U; i < 8U; i++) {
    stage->raw[i] = (i < n) ? data[i] : 0U;
  }
  stage->len = n;
  /* Write pending LAST so main loop never sees partial data. */
  __DMB();  /* data memory barrier: ensure raw[] written before pending=1 */
  stage->pending = 1U;
}

void Charger_ProcessStatusFrame(ChargerRuntime_t *rt, ChargerRxStage_t *stage,
                                 uint32_t tick_ms) {
  /* ── Fast-path: nothing to do ─────────────────────────────────────────────
   * Check pending with a single volatile read BEFORE the timeout check.
   * If neither pending nor timeout window elapsed, return immediately with
   * zero overhead — this is the common case on every main-loop iteration
   * that doesn't have a new charger frame. */
  bool timeout_due = rt->everConnected && rt->comm_ok &&
                     ((tick_ms - rt->last_valid_rx_tick) > CHARGER_COMM_TIMEOUT_MS);
  if (!stage->pending && !timeout_due) {
    return;
  }

  /* Comm-timeout watchdog */
  if (timeout_due) {
    rt->state   = CHARGER_STATE_TIMEOUT;
    rt->comm_ok = 0U;
  }

  /* Atomic 8-byte copy from ISR staging buffer.
   * __disable_irq/__enable_irq is the minimal critical section on Cortex-M4
   * (a few cycles); the ISR side never blocks so this never stalls. */
  uint8_t raw[8];
  uint8_t len = 0U;
  uint8_t havePending;

  __disable_irq();
  havePending = stage->pending;
  if (havePending) {
    memcpy(raw, stage->raw, 8U);
    len            = stage->len;
    stage->pending = 0U;
  }
  __enable_irq();

  if (!havePending) return;
  if (len < 5U)     return; /* malformed */

  /* Big-endian per the Solterra packet map */
  uint16_t v_x10 = ((uint16_t)raw[0] << 8) | raw[1];
  uint16_t i_x10 = ((uint16_t)raw[2] << 8) | raw[3];
  uint8_t  flags = raw[4];

  float v = (float)v_x10 * 0.1f;
  float i = (float)i_x10 * 0.1f;

  /* Hard physical bounds — discard garbage silently */
  if ((v > CHARGER_RX_V_MAX_V) || (i > CHARGER_RX_I_MAX_A)) return;

  rt->actual_V           = v;
  rt->actual_I           = i;
  rt->last_valid_flags   = flags;
  rt->last_valid_rx_tick = tick_ms;
  rt->everConnected      = 1U;
  rt->comm_ok            = 1U;

  /* State machine: FAULT > INHIBITED > CHARGING > READY */
  if ((flags & CHARGER_FLAG_FAULT_MASK) != 0U) {
    rt->state = CHARGER_STATE_FAULT;
  } else if ((flags & CHARGER_FLAG_INHIBITED) != 0U) {
    rt->state = CHARGER_STATE_INHIBITED;
  } else if ((v > 0.0f) && (i > 0.0f)) {
    rt->state = CHARGER_STATE_CHARGING;
  } else {
    rt->state = CHARGER_STATE_READY;
  }
}

void Charger_ComputeCommand(ChargerRuntime_t *rt, const CLI_ChargerConfig_t *cfg,
                             float soc_percent, uint16_t faultBitmask,
                             float temp1_C,
                             float *out_v_setpoint, float *out_i_setpoint,
                             uint8_t *out_enabled) {
  float pack_target_v = (float)cfg->cellCount * cfg->cellVoltageSetpoint_V;
  float i;

  /* ════════════════════════════════════════════════════════════════════════
   * PATH T — CHARGER-SIDE TEMP1 GATE (fully independent of pack safety)
   *
   * Deliberately kept OUT of the pack-level fault path below (PATH A).
   * Charger_TempStartGate_Update() never looks at faultBitmask or
   * fault_detector's otTemp_C (55.0°C pack safety trip) — it is a
   * standalone charger-only concern with its own thresholds (50.0°C block
   * / 47.0°C resume), evaluated purely on the raw temperature reading. It exists
   * to stop a Solterra charge session — or refuse a new one — well before
   * Temp1 ever approaches the real 55°C pack fault. */
  if (Charger_TempStartGate_Update(rt, temp1_C)) {
    /* Reset only the CC/CV *phase* so voltage phase is re-detected when the
     * gate releases.  charge_done is deliberately NOT cleared here: it means
     * "this pack is full", which a heat excursion does not undo.  Clearing
     * it let a hot-then-cool cycle at 100% SOC start a whole new CC session,
     * and it also bypassed main.c's "restart only below 98% SOC" hysteresis
     * — the same stop/restart chatter that the OV-threshold vs CV-target
     * collision used to cause.  charge_done is cleared where it belongs: on
     * charger disconnect/timeout, or by that SOC hysteresis in main.c. */
    rt->cv_phase = 0U;
    i = 0.0f;
    goto done;
  }

  /* ════════════════════════════════════════════════════════════════════════
   * PATH A — FAULT STOP: OV or OT fault detected (PACK-LEVEL safety, fully
   * separate from PATH T above — this one reads faultBitmask, which is
   * driven by fault_detector.c's own otTemp_C threshold, not by anything
   * in PATH T).
   *
   * Immediate STOP command regardless of CC/CV phase. Reset CC/CV state
   * so the next plug-in or fault-cleared event starts fresh from CC.
   *
   * This covers:
   *   - Pack over-voltage (FAULT_BIT_OV)
   *   - Cell over-voltage (FAULT_BIT_CELL_OV)
   *   - Over-temperature NTC1 (FAULT_BIT_OT)
   *   - Over-temperature NTC2 (FAULT_BIT_OT2)
   *   - Charger self-reported fault (rt->state == CHARGER_STATE_FAULT)
   *
   * NOTE: soc_percent >= 100% alone does NOT trigger this path — the
   * normal CV taper termination (PATH B) handles reaching full capacity.
   * ════════════════════════════════════════════════════════════════════════ */
  if (((faultBitmask & CHARGER_GATING_FAULT_MASK) != 0U) ||
      (rt->state == CHARGER_STATE_FAULT)) {
    /* Reset the CC/CV phase only — see the note in PATH T above for why
     * charge_done must survive a transient fault. */
    rt->cv_phase = 0U;
    i = 0.0f;
    goto done;
  }

  /* ════════════════════════════════════════════════════════════════════════
   * PATH B — NORMAL TERMINATION: CV taper current reached
   *
   * Once charge_done is set (by a previous iteration detecting taper
   * completion), keep sending STOP until the charger disconnects or
   * the hysteresis in main.c allows restart (SOC drops below 98%).
   *
   * The taper threshold is a FIXED 2.0A (CHARGER_TAPER_CURRENT_A),
   * NOT the configurable cvCutoffCurrent_A. The configurable value
   * is retained for GUI display / telemetry only.
   * ════════════════════════════════════════════════════════════════════════ */
  if (rt->charge_done) {
    i = 0.0f;
    goto done;
  }

  /* ════════════════════════════════════════════════════════════════════════
   * CC/CV PHASE DETECTION
   *
   * CC phase: charger supplies full current, pack voltage rises.
   * CV phase: pack voltage reaches target, charger self-limits,
   *           current begins to taper exponentially.
   *
   * Transition CC → CV when charger-reported voltage reaches
   * 99.5% of the pack target voltage (CV_ENTRY_RATIO).
   * ════════════════════════════════════════════════════════════════════════ */
  if (!rt->cv_phase) {
    /* Enter CV when charger-reported V reaches the pack target */
    if (rt->actual_V >= (pack_target_v * CV_ENTRY_RATIO) && rt->actual_V > 0.0f) {
      rt->cv_phase = 1U;
    }
  }

  /* ════════════════════════════════════════════════════════════════════════
   * CV TAPER MONITORING
   *
   * In CV phase, the charger's actual current naturally decays.
   * When it drops to CHARGER_TAPER_CURRENT_A (2.0A), the BMS considers
   * the battery full and sends STOP.
   *
   * This is the IDEAL termination condition — the battery has reached
   * full capacity through the normal CC/CV profile.
   *
   * The configurable cvCutoffCurrent_A from the GUI is NOT used here.
   * It is retained in the config struct for display/telemetry only.
   * ════════════════════════════════════════════════════════════════════════ */
  if (rt->cv_phase) {
    /* CV phase: check for taper current termination using FIXED 2.0A */
    if ((rt->actual_I > 0.0f) && (rt->actual_I <= CHARGER_TAPER_CURRENT_A)) {
      rt->charge_done = 1U;
      i = 0.0f;
      goto done;
    }
  }

  /* ════════════════════════════════════════════════════════════════════════
   * NORMAL CC/CV: send full current ceiling
   *
   * No fault, not yet done, still in CC or early CV — send the
   * configured charge current. The charger will either:
   *   - CC: deliver this current until voltage target reached
   *   - CV: self-limit voltage, current tapers naturally
   * ════════════════════════════════════════════════════════════════════════ */
  i = cfg->chargeCurrentFull_A;

done:
  *out_v_setpoint    = pack_target_v;
  *out_i_setpoint    = i;
  *out_enabled       = (i > 0.0f) ? 1U : 0U;
  rt->cmd_V_setpoint = pack_target_v;
  rt->cmd_I_setpoint = i;
}
