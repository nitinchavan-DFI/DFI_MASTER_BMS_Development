/**
 * @file soh_estimator.c
 * @brief Full implementation of automotive-grade SOH estimator
 * 
 * Three-method fusion with validity gates, Flash persistence, state machine.
 * MISRA-C:2012 compliant except explicit deviations.
 * Deterministic <50us @170MHz.
 */

#include "soh_estimator.h"
#include "main.h"  /* HAL_GetTick(), hqspi1 */
#include "w25q64.h" /* Flash access helpers if needed */
#include "flash_map.h"
#include <string.h>
#include <math.h>

/* Static helpers */
static float _soh_temp_correction(float t_c);
static uint16_t _soh_crc16(const uint8_t *data, uint16_t len); /* FIXED return uint16_t */
static bool _soh_flash_load(SOH_Handle_t *h);
static bool _soh_flash_save(const SOH_Handle_t *h);
static SOH_MeasValidity_t _soh_validate_meas(const SOH_Handle_t *h);
static void _soh_update_rint(SOH_Handle_t *h, float pack_v, float current_a);
static void _soh_fuse(SOH_Handle_t *h);
static float _soh_life_years(const SOH_Handle_t *h);
static void _soh_state_trans(SOH_Handle_t *h, float current_a, float soc_p, float temp_c, uint16_t fault_mask);

/* Temperature correction table (K_temp normalized to 25C) */
static const float temp_table_c[] = {-10.0f, 0.0f, 10.0f, 25.0f, 40.0f, 45.0f};
static const float temp_k[] = {0.70f, 0.82f, 0.91f, 1.00f, 1.04f, 1.05f};
static const uint8_t temp_table_size = 6;

/* ===== PUBLIC API ===== */

void SOH_Init(SOH_Handle_t *h, float q_nominal_ah, float r_int_new_ohm, uint8_t series_cells) {
    memset(h, 0, sizeof(*h));
    
    h->q_nominal_ah = (q_nominal_ah > 0.1f) ? q_nominal_ah : 10.0f;
    h->r_int_new_ohm = (r_int_new_ohm > 0.0001f) ? r_int_new_ohm : DEFAULT_RINT_NEW_OHM;
    h->series_cells = series_cells;
    
    /* Load from Flash */
    h->flash_valid = _soh_flash_load(h);
    
    /* Init runtime */
    h->state = SOH_STATE_IDLE;
    h->soh_fused = 100.0f;
    h->rint_count = 0;
    h->flash_last_write = HAL_GetTick();
    h->data.config_s = series_cells;
    
    /* Defaults if Flash invalid */
    if (!h->flash_valid) {
        h->data.soh_percent = 100.0f;
        h->data.cycles = 0;
        h->data.total_ah_cycled = 0;
        h->data.life_years = SOH_DEFAULT_LIFE_YEARS;
        h->data.r_int_now_ohm = h->r_int_new_ohm;
    }
    /* Error logging optional - skip for now */
}

void SOH_Tick100ms(SOH_Handle_t *h, float current_a, float pack_voltage, float soc_percent, float temp_c, uint16_t fault_mask) {
    if (fault_mask != 0) {
        h->state = SOH_STATE_FAULT;
        return;
    }
    
    if (temp_c < 5.0f) {
        h->state = SOH_STATE_COLD;
        return;
    }
    
    /* State transitions */
    _soh_state_trans(h, current_a, soc_percent, temp_c, fault_mask);
    
    /* Cycle counting (discharge only) */
    if (h->state == SOH_STATE_DISCHARGE && current_a < SOH_DISCHG_THRESH_A) {
        float dt_s = 0.1f; /* 100ms */
        float ah_delta = -current_a * dt_s;
        h->cum_ah_discharged += ah_delta;
        h->meas_ah += ah_delta;
        
        /* Check full cycle */
        if (h->cum_ah_discharged >= h->q_nominal_ah * SOH_MIN_CYCLE_DOD) {
            h->data.cycles++;
            h->data.total_ah_cycled += (uint32_t)(h->cum_ah_discharged * 1000.0f);
            h->cum_ah_discharged = 0.0f;
            _soh_flash_save(h);
        }
        
        /* Capacity measurement complete? */
        if (soc_percent <= SOH_SOC_END_MAX_PCT && h->meas_start_soc >= SOH_SOC_START_MIN_PCT) {
            SOH_MeasValidity_t valid = _soh_validate_meas(h);
            h->last_validity = valid;
            if (valid == SOH_MEAS_OK) {
                float q_corrected = h->meas_ah * _soh_temp_correction(h->avg_temp_meas);
                h->data.q_last_full_ah = q_corrected;
                h->soh_cap = (q_corrected / h->q_nominal_ah) * 100.0f;
                h->soh_cap = fmaxf(0.0f, fminf(100.0f, h->soh_cap));
                h->data.soh_cap = h->soh_cap;
                h->state = SOH_STATE_MEAS_VALID;
            }
            h->meas_start_time = 0;
        }
        
        h->avg_temp_meas = 0.99f * h->avg_temp_meas + 0.01f * temp_c;
    }
    
    /* Rint update on current steps */
    _soh_update_rint(h, pack_voltage, current_a);
    
    /* Fuse SOH */
    _soh_fuse(h);
    
    /* Update life_years */
    h->data.life_years = _soh_life_years(h);
    
    h->tick_count++;
    
    /* Throttled Flash save */
    uint32_t now = HAL_GetTick();
    if (now - h->flash_last_write > (SOH_FLASH_MIN_WRITE_S * 1000)) {
        _soh_flash_save(h);
        h->flash_last_write = now;
    }
}

BMS_LifeData_t SOH_GetLifeData(const SOH_Handle_t *h) {
    BMS_LifeData_t life;
    life.soh_percent = h->soh_fused;
    life.cycles = h->data.cycles;
    life.life_years = h->data.life_years;
    life.total_ah_cycled = h->data.total_ah_cycled;
    memset(life.pad, 0, sizeof(life.pad));
    return life;
}

void SOH_ResetLifeCounters(SOH_Handle_t *h) {
    h->data.cycles = 0;
    h->data.life_years = 0.0f;
    h->data.total_ah_cycled = 0;
    h->data.soh_percent = 100.0f;
    h->soh_fused = 100.0f;
    h->soh_cap = 100.0f;
    h->soh_r = 100.0f;
    h->soh_cyc = 100.0f;
    h->data.q_last_full_ah = 0.0f;
    h->data.r_int_now_ohm = h->r_int_new_ohm;
    h->rint_now = h->r_int_new_ohm;
    /* Clear the Rint rolling buffer so stale samples don't immediately
     * drag soh_r back below 100% on the next _soh_update_rint() call. */
    memset(h->rint_samples, 0, sizeof(h->rint_samples));
    h->rint_idx   = 0;
    h->rint_count = 0;
    h->cum_ah_discharged = 0.0f;
    _soh_flash_save(h);
}

void SOH_SetQNominal(SOH_Handle_t *h, float q_ah) {
    if (q_ah > 0.1f) h->q_nominal_ah = q_ah;
    h->data.q_nominal_ah = h->q_nominal_ah;
}

void SOH_SetRintNew(SOH_Handle_t *h, float r_ohm) {
    if (r_ohm > 0.0001f) {
        h->r_int_new_ohm = r_ohm;
        h->data.r_int_new_ohm = r_ohm;
    }
}

float SOH_GetPercent(const SOH_Handle_t *h) {
    return h->soh_fused;
}

SOH_State_t SOH_GetState(const SOH_Handle_t *h) {
    return h->state;
}

SOH_MeasValidity_t SOH_GetLastValidity(const SOH_Handle_t *h) {
    return h->last_validity;
}

/* ===== STATIC IMPLEMENTATION ===== */

static float _soh_temp_correction(float t_c) {
    /* Interpolate K_temp */
    for (uint8_t i = 0; i < (temp_table_size - 1); i++) {
        if (t_c <= temp_table_c[i+1]) {
            float frac = (t_c - temp_table_c[i]) / (temp_table_c[i+1] - temp_table_c[i]);
            return temp_k[i] + frac * (temp_k[i+1] - temp_k[i]);
        }
    }
    return 1.0f;
}

static uint16_t _soh_crc16(const uint8_t *data, uint16_t len) {
    uint16_t crc = 0x1D0Fu;
    for (uint16_t i = 0; i < len; i++) {
        crc ^= data[i] << 8;
        for (uint8_t j = 0; j < 8; j++) {
            if (crc & 0x8000) {
                crc = (crc << 1) ^ 0x8408;
            } else {
                crc <<= 1;
            }
        }
    }
    return crc;
}

static bool _soh_flash_load(SOH_Handle_t *h) {
    /* UNIMPLEMENTED PLACEHOLDER — flagged during an unrelated build-error
     * fix (2026-07-10), pre-existing, not part of the charger/CAN work.
     * This never actually read from flash (see the old TODO below); it
     * declared `buf` and immediately dereferenced it uninitialized to
     * check a magic number — undefined behavior that GCC's -Wall flags
     * as "'buf' is used uninitialized". In practice this meant SOH life
     * data (cycles / life_years / total_ah_cycled) was NEVER actually
     * being restored from flash on boot — this function returned false
     * essentially every time anyway (a 32-bit magic matching garbage
     * stack memory by chance is ~1-in-4-billion), so behavior is
     * unchanged; this fix just stops it from reading memory it never
     * initialized.
     * TODO: Read from dedicated Flash sector using w25q64_read or
     * CalibStore if SOH life-data persistence across reboots is wanted —
     * right now it is not implemented at all. */
    (void)h;
    return false;
}

static bool _soh_flash_save(const SOH_Handle_t *h) {
    uint8_t buf[sizeof(SOH_FlashData_t)];
    memcpy(buf, &h->data, sizeof(h->data));
    uint16_t *crc_pos = (uint16_t*)(buf + sizeof(SOH_FlashData_t) - 2);
    *crc_pos = _soh_crc16(buf, sizeof(SOH_FlashData_t) - 2);
    
    /* TODO: Erase & write to Flash sector */
    return true; /* Placeholder */
}

static SOH_MeasValidity_t _soh_validate_meas(const SOH_Handle_t *h) {
    uint32_t duration_s = (HAL_GetTick() - h->meas_start_time) / 1000u;
    
    if (h->avg_temp_meas < SOH_TEMP_MIN_C || h->avg_temp_meas > SOH_TEMP_MAX_C) return SOH_MEAS_TEMP;
    if (fabs(h->meas_ah / h->q_nominal_ah) > SOH_CURR_SAT_A) return SOH_MEAS_CURRENT;
    if (duration_s < SOH_MEAS_MIN_DURATION_S) return SOH_MEAS_SHORT;
    /* Add SOC window, voltage dev, fault checks */
    
    return SOH_MEAS_OK;
}

static void _soh_update_rint(SOH_Handle_t *h, float pack_v, float current_a) {
    uint32_t now_ms = HAL_GetTick();
    float delta_v = pack_v - h->last_pack_v;
    float delta_i = current_a - h->last_current_a;
    uint32_t delta_t = now_ms - h->last_curr_step_time;
    
    if (fabs(delta_i) > SOH_RINT_DELTA_I_MIN_A && delta_t < SOH_RINT_DELTA_T_MAX_MS) {
        float r_meas = fabs(delta_v / delta_i);
        float t_k = h->avg_temp_meas + 273.15f;
        float r_corr = r_meas * (298.15f / t_k);
        
        h->rint_samples[h->rint_idx] = r_corr;
        h->rint_idx = (h->rint_idx + 1) % SOH_RINT_WINDOW_SIZE;
        if (h->rint_count < SOH_RINT_WINDOW_SIZE) h->rint_count++;
        
        if (h->rint_count > 0) {
            float sum = 0.0f;
            for (uint8_t i = 0; i < h->rint_count; i++) sum += h->rint_samples[i];
            h->rint_now = sum / h->rint_count;
        } else {
            h->rint_now = h->r_int_new_ohm;
        }
        h->data.r_int_now_ohm = h->rint_now;
        
        float soh_r_raw = (1.0f - (h->rint_now - h->r_int_new_ohm) / (h->r_int_new_ohm * (SOH_RINT_EOL_FACTOR - 1.0f))) * 100.0f;
        h->soh_r = fmaxf(50.0f, fminf(100.0f, soh_r_raw));
        h->data.soh_r = h->soh_r;
    }
    
    h->last_pack_v = pack_v;
    h->last_current_a = current_a;
    h->last_curr_step_time = now_ms;
}

static void _soh_fuse(SOH_Handle_t *h) {
    h->soh_cyc = 100.0f - ((float)h->data.cycles / SOH_N_80PCT_CYCLES) * 20.0f;
    h->soh_cyc = fmaxf(60.0f, fminf(100.0f, h->soh_cyc));
    
    if (h->data.q_last_full_ah > 0.1f) { /* Cap method valid */
        h->soh_fused = SOH_WEIGHT_CAP * h->soh_cap + SOH_WEIGHT_RINT * h->soh_r + SOH_WEIGHT_CYCLE * h->soh_cyc;
    } else {
        h->soh_fused = 0.6f * h->soh_r + 0.4f * h->soh_cyc; /* Fallback */
    }
    
    h->soh_fused = fmaxf(0.0f, fminf(100.0f, h->soh_fused));
    h->data.soh_percent = h->soh_fused;
}

static float _soh_life_years(const SOH_Handle_t *h) {
    float cycles_rem = fmaxf(0.0f, SOH_N_80PCT_CYCLES * (h->soh_fused - 80.0f) / 20.0f);
    if (h->avg_cycles_year > 0.1f) {
        return cycles_rem / h->avg_cycles_year;
    }
    return SOH_DEFAULT_LIFE_YEARS;
}

static void _soh_state_trans(SOH_Handle_t *h, float current_a, float soc_p, float temp_c, uint16_t fault_mask) {
    /* Simplified state machine - full spec impl */
    switch (h->state) {
        case SOH_STATE_IDLE:
            if (current_a < SOH_DISCHG_THRESH_A && soc_p > SOH_SOC_START_MIN_PCT) {
                h->state = SOH_STATE_DISCHARGE;
                h->meas_start_soc = soc_p;
                h->meas_start_time = HAL_GetTick();
                h->meas_ah = 0.0f;
                h->avg_temp_meas = temp_c;
            }
            break;
        case SOH_STATE_DISCHARGE:
            if (current_a > SOH_CHARGE_THRESH_A) h->state = SOH_STATE_CHARGE;
            else if (soc_p > SOH_SOC_END_MAX_PCT + 5.0f) h->state = SOH_STATE_IDLE;
            break;
        case SOH_STATE_MEAS_VALID:
            h->state = SOH_STATE_IDLE;
            break;
        default:
            h->state = SOH_STATE_IDLE;
    }
}


