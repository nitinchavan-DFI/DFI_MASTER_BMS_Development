/**
 * @file    calib_store.c
 * @brief   Non-volatile calibration storage implementation
 *
 * Uses sector 0 (address 0x000000) of the W25Q64 flash.
 * Data is stored as a single CalibStore_Data_t struct with CRC32
 * for integrity validation.
 */

#include "calib_store.h"
#include "flash_map.h"
#include "w25q64.h"
#include "stm32g4xx_hal.h"   /* HAL_IWDG_Refresh */
#include <string.h>

/* External IWDG handle — defined in main.c */
extern IWDG_HandleTypeDef hiwdg;

/* ========================================================================== */
/*                       Flash Address                                         */
/* ========================================================================== */

/** Base address in flash for calibration data (Partition 1) */
#define CALIB_FLASH_ADDRESS FLASH_PART_1_START

/* ========================================================================== */
/*                       Software CRC-32                                       */
/* ========================================================================== */

/**
 * @brief  Compute CRC-32 (ISO 3309 / ITU-T V.42 / PNG / ZIP polynomial).
 *         No lookup table — small code size, suitable for infrequent use.
 */
static uint32_t CalibStore_CRC32(const uint8_t *data, uint32_t length) {
  uint32_t crc = 0xFFFFFFFFU;
  for (uint32_t i = 0; i < length; i++) {
    crc ^= (uint32_t)data[i];
    for (int j = 0; j < 8; j++) {
      if (crc & 1U) {
        crc = (crc >> 1) ^ 0xEDB88320U;
      } else {
        crc >>= 1;
      }
    }
  }
  return crc ^ 0xFFFFFFFFU;
}

/* ========================================================================== */
/*                       Private State                                         */
/* ========================================================================== */

static QSPI_HandleTypeDef *sQspiHandle = NULL;

/* ========================================================================== */
/*                       Public API                                            */
/* ========================================================================== */

bool CalibStore_Init(QSPI_HandleTypeDef *hqspi) {
  sQspiHandle = hqspi;

  if (W25Q64_Init(hqspi) != W25Q64_OK) {
    return false;
  }
  return true;
}

bool CalibStore_Save(const CalibStore_Data_t *data) {
  if (sQspiHandle == NULL) {
    return false;
  }

  /* Build a mutable copy and compute CRC */
  CalibStore_Data_t store;
  memcpy(&store, data, sizeof(store));
  store.magic = CALIB_STORE_MAGIC;

  /* CRC covers everything except the crc32 field itself */
  uint32_t crc_len = (uint32_t)((uintptr_t)&store.crc32 - (uintptr_t)&store);
  store.crc32 = CalibStore_CRC32((const uint8_t *)&store, crc_len);

  /* --------------------------------------------------------------------------
   * Erase sector 0 (4 KB).  The W25Q64 sector erase takes up to ~400 ms.
   * Refresh the IWDG before AND after to prevent a watchdog reset mid-erase
   * that would leave the flash in an erased (all-0xFF) state, causing
   * CalibStore_Load() to fail on the next boot and SOC to default to 50%.
   * --------------------------------------------------------------------------*/
  HAL_IWDG_Refresh(&hiwdg);
  if (W25Q64_EraseSector(sQspiHandle, CALIB_FLASH_ADDRESS) != W25Q64_OK) {
    HAL_IWDG_Refresh(&hiwdg);
    return false;
  }
  HAL_IWDG_Refresh(&hiwdg);

  /* Write the struct (fits within one 256-byte page) */
  if (W25Q64_Write(sQspiHandle, (const uint8_t *)&store, CALIB_FLASH_ADDRESS,
                   sizeof(store)) != W25Q64_OK) {
    HAL_IWDG_Refresh(&hiwdg);
    return false;
  }
  HAL_IWDG_Refresh(&hiwdg);

  return true;
}

bool CalibStore_Load(CalibStore_Data_t *data) {
  if (sQspiHandle == NULL) {
    return false;
  }

  /* Read the struct from flash */
  if (W25Q64_Read(sQspiHandle, (uint8_t *)data, CALIB_FLASH_ADDRESS,
                  sizeof(CalibStore_Data_t)) != W25Q64_OK) {
    return false;
  }

  return CalibStore_IsValid(data);
}

bool CalibStore_IsValid(const CalibStore_Data_t *data) {
  if (data->magic != CALIB_STORE_MAGIC) {
    return false;
  }

  /* CRC covers everything except the crc32 field itself */
  uint32_t crc_len = (uint32_t)((uintptr_t)&data->crc32 - (uintptr_t)data);
  uint32_t computed = CalibStore_CRC32((const uint8_t *)data, crc_len);

  return (computed == data->crc32);
}
