/**
 * @file    can_gui_cmds.c
 * @brief   GUI -> BMS config-write commands over CAN: ISR-safe staging
 *          array + atomic main-loop consume. See can_gui_cmds.h for the
 *          protocol/payload description.
 *
 * Decode, validation (ValidateFaultThresholds()), and dispatch into
 * Fault_SetThresholds() / CurrentSensor_Start*Calibration() live in
 * main.c, not here -- same split as the charger RX path: this file only
 * ever touches raw bytes.
 */
#include "can_gui_cmds.h"
#include "main.h" /* __disable_irq/__enable_irq/__DMB (CMSIS) */
#include <string.h>

GuiCmdStage_t g_guiCmdStage[GUI_CMD_COUNT];

void GuiCmd_LatchRawFrame(GuiCmdIndex_t idx, const uint8_t *data, uint8_t len) {
  if ((uint32_t)idx >= (uint32_t)GUI_CMD_COUNT) {
    return; /* defensive -- should never happen, see header note */
  }

  GuiCmdStage_t *stage = &g_guiCmdStage[idx];

  if (stage->pending) {
    stage->overrun_count++;
  }
  uint8_t n = (len > 8U) ? 8U : len;
  for (uint8_t i = 0U; i < 8U; i++) {
    stage->raw[i] = (i < n) ? data[i] : 0U;
  }
  stage->len = n;
  /* Write pending LAST so main loop never sees partial data. */
  __DMB();
  stage->pending = 1U;
}

bool GuiCmd_TryConsume(GuiCmdIndex_t idx, uint8_t *out_raw, uint8_t *out_len) {
  if ((uint32_t)idx >= (uint32_t)GUI_CMD_COUNT) {
    return false;
  }

  GuiCmdStage_t *stage = &g_guiCmdStage[idx];
  uint8_t havePending;

  __disable_irq();
  havePending = stage->pending;
  if (havePending) {
    memcpy(out_raw, stage->raw, 8U);
    *out_len       = stage->len;
    stage->pending = 0U;
  }
  __enable_irq();

  return (havePending != 0U);
}
