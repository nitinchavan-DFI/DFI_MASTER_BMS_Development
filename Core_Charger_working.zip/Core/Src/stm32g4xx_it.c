/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file    stm32g4xx_it.c
 * @brief   Interrupt Service Routines.
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2026 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32g4xx_it.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "NTC10K.h"
#include "cli_frame.h"
#include "current_sensor.h"
#include "daly_bms.h"
#include "led_status.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/
extern ADC_HandleTypeDef hadc1;
extern ADC_HandleTypeDef hadc2;
extern FDCAN_HandleTypeDef hfdcan1;
extern TIM_HandleTypeDef htim1;
extern TIM_HandleTypeDef htim5;
extern TIM_HandleTypeDef htim6;
extern TIM_HandleTypeDef htim15;
extern UART_HandleTypeDef huart5;
extern UART_HandleTypeDef huart2;
/* USER CODE BEGIN EV */
extern ADC_HandleTypeDef hadc2;
extern TIM_HandleTypeDef htim6;
extern DalyBMS_Handle_t hDaly;
/* USER CODE END EV */

/******************************************************************************/
/*           Cortex-M4 Processor Interruption and Exception Handlers          */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */
  while (1) {
  }
  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Memory management fault.
  */
void MemManage_Handler(void)
{
  /* USER CODE BEGIN MemoryManagement_IRQn 0 */

  /* USER CODE END MemoryManagement_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_MemoryManagement_IRQn 0 */
    /* USER CODE END W1_MemoryManagement_IRQn 0 */
  }
}

/**
  * @brief This function handles Prefetch fault, memory access fault.
  */
void BusFault_Handler(void)
{
  /* USER CODE BEGIN BusFault_IRQn 0 */

  /* USER CODE END BusFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_BusFault_IRQn 0 */
    /* USER CODE END W1_BusFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Undefined instruction or illegal state.
  */
void UsageFault_Handler(void)
{
  /* USER CODE BEGIN UsageFault_IRQn 0 */

  /* USER CODE END UsageFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_UsageFault_IRQn 0 */
    /* USER CODE END W1_UsageFault_IRQn 0 */
  }
}

/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
  /* USER CODE BEGIN SVCall_IRQn 0 */

  /* USER CODE END SVCall_IRQn 0 */
  /* USER CODE BEGIN SVCall_IRQn 1 */

  /* USER CODE END SVCall_IRQn 1 */
}

/**
  * @brief This function handles Debug monitor.
  */
void DebugMon_Handler(void)
{
  /* USER CODE BEGIN DebugMonitor_IRQn 0 */

  /* USER CODE END DebugMonitor_IRQn 0 */
  /* USER CODE BEGIN DebugMonitor_IRQn 1 */

  /* USER CODE END DebugMonitor_IRQn 1 */
}

/**
  * @brief This function handles Pendable request for system service.
  */
void PendSV_Handler(void)
{
  /* USER CODE BEGIN PendSV_IRQn 0 */

  /* USER CODE END PendSV_IRQn 0 */
  /* USER CODE BEGIN PendSV_IRQn 1 */

  /* USER CODE END PendSV_IRQn 1 */
}

/**
  * @brief This function handles System tick timer.
  */
void SysTick_Handler(void)
{
  /* USER CODE BEGIN SysTick_IRQn 0 */

  /* USER CODE END SysTick_IRQn 0 */
  HAL_IncTick();
  /* USER CODE BEGIN SysTick_IRQn 1 */

  /* USER CODE END SysTick_IRQn 1 */
}

/******************************************************************************/
/* STM32G4xx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32g4xx.s).                    */
/******************************************************************************/

/**
  * @brief This function handles ADC1 and ADC2 global interrupt.
  */
void ADC1_2_IRQHandler(void)
{
  /* USER CODE BEGIN ADC1_2_IRQn 0 */

  /* USER CODE END ADC1_2_IRQn 0 */
  HAL_ADC_IRQHandler(&hadc1);
  HAL_ADC_IRQHandler(&hadc2);
  /* USER CODE BEGIN ADC1_2_IRQn 1 */

  /* USER CODE END ADC1_2_IRQn 1 */
}

/**
  * @brief This function handles FDCAN1 interrupt 0.
  */
void FDCAN1_IT0_IRQHandler(void)
{
  /* USER CODE BEGIN FDCAN1_IT0_IRQn 0 */

  /* USER CODE END FDCAN1_IT0_IRQn 0 */
  HAL_FDCAN_IRQHandler(&hfdcan1);
  /* USER CODE BEGIN FDCAN1_IT0_IRQn 1 */

  /* USER CODE END FDCAN1_IT0_IRQn 1 */
}

/**
  * @brief This function handles EXTI line[9:5] interrupts.
  */
void EXTI9_5_IRQHandler(void)
{
  /* USER CODE BEGIN EXTI9_5_IRQn 0 */

  /* USER CODE END EXTI9_5_IRQn 0 */
  HAL_GPIO_EXTI_IRQHandler(wakeButton_Pin);
  /* USER CODE BEGIN EXTI9_5_IRQn 1 */

  /* USER CODE END EXTI9_5_IRQn 1 */
}

/**
  * @brief This function handles TIM1 break interrupt and TIM15 global interrupt.
  */
void TIM1_BRK_TIM15_IRQHandler(void)
{
  /* USER CODE BEGIN TIM1_BRK_TIM15_IRQn 0 */

  /* USER CODE END TIM1_BRK_TIM15_IRQn 0 */
  HAL_TIM_IRQHandler(&htim1);
  HAL_TIM_IRQHandler(&htim15);
  /* USER CODE BEGIN TIM1_BRK_TIM15_IRQn 1 */

  /* USER CODE END TIM1_BRK_TIM15_IRQn 1 */
}

/**
  * @brief This function handles USART2 global interrupt / USART2 wake-up interrupt through EXTI line 26.
  */
void USART2_IRQHandler(void)
{
  /* USER CODE BEGIN USART2_IRQn 0 */

  /* USER CODE END USART2_IRQn 0 */
  HAL_UART_IRQHandler(&huart2);
  /* USER CODE BEGIN USART2_IRQn 1 */

  /* USER CODE END USART2_IRQn 1 */
}

/**
  * @brief This function handles TIM5 global interrupt.
  */
void TIM5_IRQHandler(void)
{
  /* USER CODE BEGIN TIM5_IRQn 0 */

  /* USER CODE END TIM5_IRQn 0 */
  HAL_TIM_IRQHandler(&htim5);
  /* USER CODE BEGIN TIM5_IRQn 1 */

  /* USER CODE END TIM5_IRQn 1 */
}

/**
  * @brief This function handles UART5 global interrupt / UART5 wake-up interrupt through EXTI line 35.
  */
void UART5_IRQHandler(void)
{
  /* USER CODE BEGIN UART5_IRQn 0 */

  /* USER CODE END UART5_IRQn 0 */
  HAL_UART_IRQHandler(&huart5);
  /* USER CODE BEGIN UART5_IRQn 1 */

  /* USER CODE END UART5_IRQn 1 */
}

/**
  * @brief This function handles TIM6 global interrupt, DAC1 and DAC3 channel underrun error interrupts.
  */
void TIM6_DAC_IRQHandler(void)
{
  /* USER CODE BEGIN TIM6_DAC_IRQn 0 */

  /* USER CODE END TIM6_DAC_IRQn 0 */
  HAL_TIM_IRQHandler(&htim6);
  /* USER CODE BEGIN TIM6_DAC_IRQn 1 */

  /* USER CODE END TIM6_DAC_IRQn 1 */
}

/* USER CODE BEGIN 1 */

/* ADC conversion complete → dispatch to current sensor and NTC10K */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc) {
  CurrentSensor_ADC_Callback(hadc);
  NTC10K_ADC_Callback(hadc);
}

/* TIM period elapsed → dispatch to NTC10K (TIM6 triggers ADC2) and TIM5 for
 * DroneCAN */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
  if (htim->Instance == TIM5) {
    extern volatile uint8_t tim5_flag;
    tim5_flag = 1;
  }
  NTC10K_TIM_Callback(htim);
  LedStatus_TIM_Callback(htim);
}

/* UART TX complete → Daly BMS driver */
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart) {
  DalyBMS_TxCpltCallback(&hDaly, huart);
}

/* UART RX complete → dispatch to CLI (USART2) or Daly (UART5) */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
  CLI_Frame_RxCallback(huart);
  DalyBMS_RxCpltCallback(&hDaly, huart);
}

/* UART error → Daly BMS driver + full UART error recovery.
 *
 * BUG FIXED (Root cause of "cells stuck after cell-diff fault"):
 *
 *   The original code only re-armed the CLI byte receiver (USART2).
 *   UART5 (Daly BMS) error flags were left SET after the error callback.
 *
 *   Sequence that caused the deadlock:
 *     1. cellDiffError latches → FET cutoff fires.
 *     2. Blocking UART ops on huart5 (2000 ms total) corrupted the
 *        IT-driven 0x95 receive in progress.
 *     3. The blocking calls land in the middle of an IT-driven 0x95 receive,
 *        generating framing / overrun errors on huart5.
 *     4. HAL_UART_ErrorCallback fires for huart5.
 *     5. OLD CODE: UART5 error flags NOT cleared, huart5.RxState left as
 *        HAL_UART_STATE_BUSY_RX → every subsequent HAL_UART_Receive_IT()
 *        returns HAL_BUSY/HAL_ERROR silently.
 *     6. DalyBMS_StartRxIT() does not check the return value → rxComplete
 *        never fires → timeout → ERROR → retry loops forever.
 *     7. dataReady never becomes true → g_snap_cellDiff frozen at the
 *        imbalance value → Fault_Update never called → fault never clears.
 *     8. Cells displayed on GUI permanently frozen.
 *
 *   FIX: Apply identical flag-clear + state-reset to ALL UARTs, not only
 *   USART2. Then re-arm each peripheral's normal receive path:
 *     - USART2: re-arm CLI single-byte receiver.
 *     - UART5:  let DalyBMS_ErrorCallback set rxError=true so the Daly
 *               state machine naturally transitions to DALY_STATE_ERROR
 *               and calls HAL_UART_AbortReceive + DalyBMS_StartRxIT on the
 *               next DalyBMS_Process() tick — which now succeeds because
 *               the error flags are already cleared here.
 */
void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart) {
  /* Notify Daly driver first so rxError flag is set before we reset state */
  DalyBMS_ErrorCallback(&hDaly, huart);

  /* ── Universal UART error recovery (applies to ALL UART instances) ──── */
  if (huart->ErrorCode != HAL_UART_ERROR_NONE) {
    /* Clear all hardware error flags: parity, framing, noise, overrun */
    __HAL_UART_CLEAR_FLAG(huart, UART_CLEAR_PEF | UART_CLEAR_FEF |
                                     UART_CLEAR_NEF | UART_CLEAR_OREF);
    huart->ErrorCode = HAL_UART_ERROR_NONE;
    huart->gState    = HAL_UART_STATE_READY;  /* Allow new TX             */
    huart->RxState   = HAL_UART_STATE_READY;  /* Allow new RX — KEY FIX  */
  }

  /* ── Per-peripheral re-arm ──────────────────────────────────────────── */
  extern UART_HandleTypeDef huart2;
  extern UART_HandleTypeDef huart5;

  if (huart->Instance == huart2.Instance) {
    /* CLI: re-arm the single-byte interrupt receiver */
    CLI_Frame_Init(&huart2);
  }
  /* UART5 (Daly): do NOT call DalyBMS_StartRxIT here — the Daly state
   * machine handles re-arm itself in DALY_STATE_ERROR → DALY_STATE_SENDING.
   * Calling StartRxIT here would race with the SM's own re-arm.
   * The rxError flag set above causes DalyBMS_Process() to enter ERROR
   * state and issue HAL_UART_AbortReceive() + StartRxIT on the next tick,
   * which now succeeds because RxState is READY. */
}

/* PB9 wake button EXTI → wake LEDs from rest mode */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
  if (GPIO_Pin == wakeButton_Pin) {
    LedStatus_Wake();
  }
}

/* USER CODE END 1 */
