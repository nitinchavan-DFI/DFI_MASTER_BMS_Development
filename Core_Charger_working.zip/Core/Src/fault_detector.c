/**
 * @file    fault_detector.c
 * @brief   Software fault detector — debounced, hysteresis-guarded.
 *
 * ── FAKE OVER-VOLTAGE FIX ────────────────────────────────────────────────────
 *
 *  Root cause (original code):
 *    g_snap_minCellmV / g_snap_maxCellmV in main.c are in MILLIVOLTS
 *    (raw Daly field, e.g. 3700 for 3.700 V).
 *    Fault_Update() received these mV values and divided by 1000 → Volts.
 *    HOWEVER: the static confidence counters `cell_ov_conf` / `cell_uv_conf`
 *    were incremented/decremented by fixed steps of 10, with NO debounce
 *    timer and NO hysteresis, so a single bad frame (e.g. balancer glitch
 *    in the raw Daly stream) could accumulate 80 counts in 8 calls (0.8 s)
 *    and latch cellOverVoltageError — even on perfectly healthy cells.
 *
 *    Additionally the overVoltageError (pack OV) flag was evaluated (cond_ov)
 *    but NEVER written to sLatchedFlags, meaning pack OV was silently ignored.
 *
 *  Fixes applied:
 *    1. Cell OV / Cell UV now use the same FAULT_DEBOUNCE_TICKS timer
 *       infrastructure as every other fault — consistent 5-tick (5 s) debounce.
 *    2. Hysteresis applied to cell OV/UV:
 *         OV clears only when maxCell_V < cellMax_V - FAULT_HYST_CELL_V
 *         UV clears only when minCell_V > cellMin_V + FAULT_HYST_CELL_V
 *    3. Pack OV now correctly writes to sLatchedFlags.overVoltageError
 *       with its own debounce timer (timer index 0).
 *    4. All confidence-counter static locals REMOVED — replaced by unified
 *       timer array, consistent with all other fault paths.
 *    5. minCell_mV / maxCell_mV parameters are in MILLIVOLTS as supplied by
 *       main.c (raw Daly data). Division by 1000 is done once at the top
 *       of Fault_Update() and the result used throughout — no unit ambiguity.
 *
 * ── MAX CELL VOLTAGE STUCK AFTER CELL-DIFF ERROR — FIX ──────────────────────
 *
 *  Root cause:
 *    When cellDiffError latched, the max cell voltage reading was (correctly)
 *    elevated because one weak/high cell was pulling the max up.  After the
 *    balancer resolved the imbalance and cellDiff dropped, three separate bugs
 *    kept cellOverVoltageError permanently stuck:
 *
 *    BUG A — FAULT_DEBOUNCE dead-band froze timer pre-latch:
 *      If cellDiff recovered into the dead-band zone
 *      (thr->cellDiff_mV − HYST < cellDiff < thr->cellDiff_mV), neither
 *      cond_set nor cond_clear was true.  The macro did nothing, leaving a
 *      partial timer count that prevented normal re-latch/clear behavior.
 *      Fix: dead-band now resets the timer when the flag is NOT yet latched,
 *      and holds it only when the flag IS latched (correct hysteresis intent).
 *
 *    BUG B — cellDiffError clear did NOT reset Cell OV timer/flag:
 *      The elevated maxCellmV that caused Cell OV was a symptom of the
 *      imbalance — not a standalone over-voltage condition.  When cellDiffError
 *      cleared, FTIDX_CELL_OV and cellOverVoltageError were left untouched,
 *      so Cell OV stayed latched indefinitely even after balancing completed.
 *      Fix: on the tick that cellDiffError transitions from latched → cleared,
 *      FTIDX_CELL_OV is reset to 0 and cellOverVoltageError is cleared.
 *      The Cell OV path immediately re-evaluates and will re-latch if the
 *      voltage is genuinely over threshold.
 *
 *    BUG C — Invalid cell data held Cell OV forever:
 *      When BMS comms degraded post-fault (cell_data_valid = false), the old
 *      code held cell OV/UV timers and flags unchanged indefinitely.  After
 *      CELL_INVALID_TIMEOUT_TICKS (2 × FAULT_DEBOUNCE_TICKS = 10) consecutive
 *      invalid frames, timers and flags are now cleared so valid data on
 *      recovery can re-evaluate from clean state.
 *
 *    BUG D — Linked-fault reset was OV-only, leaving Cell UV stuck:
 *      The original fix for BUG B only reset FTIDX_CELL_OV / cellOverVoltage
 *      Error when cellDiffError cleared.  Imbalance is just as often caused
 *      by one LOW cell pulling the min down as by one HIGH cell pulling the
 *      max up -- so a low-cell-driven imbalance left cellUnderVoltageError
 *      permanently stuck latched after balancing completed, the exact
 *      mirror image of BUG B.  Fix: the same reset now covers both
 *      FTIDX_CELL_OV and FTIDX_CELL_UV.
 *
 * ── SIGNAL PATH ──────────────────────────────────────────────────────────────
 *
 *   Daly BMS → signal_filter.c (Kalman + MA + Median, mV→V conversion)
 *            → fault_detector.c (threshold comparison, debounce, hysteresis)
 *
 *   signal_filter.c outputs filtered_min_cellV and filtered_max_cellV in VOLTS.
 *   main.c should ideally pass these instead of raw g_snap_minCellmV.
 *   For backward compatibility with the existing main.c call site (which passes
 *   raw mV), the division by 1000 is retained here.  Once main.c is updated to
 *   pass FilteredData_t values, remove the /1000 and update the comment.
 */

#include "fault_detector.h"
#include "daly_bms.h"
#include "error_log_store.h"

#ifndef DALY_STATUS_CHARGE
#define DALY_STATUS_CHARGE 1
#endif
#ifndef DALY_MAX_CELLS
#define DALY_MAX_CELLS 48
#endif

#include <math.h>
#include <string.h>

/* ── Hysteresis for cell-level voltage faults (V) ──────────────────────── */
/* Separate from the pack-level FAULT_HYST_OV_V / FAULT_HYST_UV_V.         */
#define FAULT_HYST_CELL_V   0.050f    /* 50 mV hysteresis for cell OV/UV    */

/* ── Cell invalid-data timeout ──────────────────────────────────────────── */
/* If cell_data_valid is false for this many consecutive Fault_Update()      */
/* calls, cell OV/UV timers and flags are cleared.  This prevents the cell   */
/* OV fault from being permanently stuck when the BMS stops sending valid    */
/* cell-voltage frames (e.g. post-shutdown or comms fault).                  */
/* Set to 2× FAULT_DEBOUNCE_TICKS so a real fault has time to re-latch      */
/* immediately once valid data resumes.                                       */
#define CELL_INVALID_TIMEOUT_TICKS  (2U * FAULT_DEBOUNCE_TICKS)

/* ── Fault timer indices ────────────────────────────────────────────────── */
/* Must match the sFaultTimers[] array size declared below.                  */
#define FTIDX_OV            0
#define FTIDX_UV            1
#define FTIDX_OC_DISCHG     2
#define FTIDX_CELL_DIFF     3
#define FTIDX_OT1           4
#define FTIDX_UT1           5
#define FTIDX_THERM1        6
#define FTIDX_OT2           7
#define FTIDX_UT2           8
#define FTIDX_THERM2        9
#define FTIDX_CELL_OV      10
#define FTIDX_CELL_UV      11
#define FTIDX_OC_CHRG      12
#define FTIDX_COUNT        13   /* Total number of timers */

/* ── Private state ──────────────────────────────────────────────────────── */

static FaultThresholds_t sThresh;
static FaultFlags_t      sFlags;
static FaultFlags_t      sLatchedFlags;
static uint32_t          sFaultTimers[FTIDX_COUNT];
static uint32_t          sCellInvalidTicks;   /* Consecutive invalid cell-data ticks */

/* ── Dead-band timeout counters ───────────────────────────────────────────
 * Each counter tracks consecutive ticks the corresponding fault spends in
 * the hysteresis dead-band WHILE its flag is already latched.  When the
 * counter reaches FAULT_DEBOUNCE_TICKS, the fault is auto-cleared — the
 * condition has been hovering in the dead-band for too long, and it's safer
 * to release the latched flag so the system can recover.
 *
 * This is the primary fix for "BMS gets stuck in fault mode and does not
 * refresh" — the old code held latched flags indefinitely in the dead-band
 * (neither cond_set nor cond_clear was true).  Now there is a guaranteed
 * timeout: after 5 ticks (~5 s) of hovering in the hysteresis zone while
 * latched, the flag auto-clears.
 */
static uint32_t sDeadBandTimeouts[FTIDX_COUNT];

/* ── Helper macro: debounce latch/clear ─────────────────────────────────── */
/*
 * FAULT_DEBOUNCE_SET(cond, idx, flag, msg):
 *   If cond is true: increment timer; latch flag when timer reaches debounce.
 *   If cond is false: reset timer; clear flag (hysteresis handled by caller).
 *
 * This keeps the per-fault logic identical and easy to audit.
 */
/*
 * ROBUSTNESS FIX: Timer is now clamped at FAULT_DEBOUNCE_TICKS once latched.
 * Without the clamp, a persistent fault condition would increment the timer
 * to UINT32_MAX over ~136 years of uptime — harmless in practice, but
 * clamping makes the logic explicit and prevents any theoretical rollover.
 *
 * DEAD-BAND FIX: Previously the dead-band (neither set nor clear) froze the
 * timer unconditionally.  This caused two stuck-fault scenarios:
 *   (a) Pre-latch: counter accumulates ticks, condition goes away but does not
 *       reach the clear threshold → timer stays at e.g. 3/5, fault cannot
 *       re-latch correctly on next occurrence because partial count remains.
 *   (b) Post-latch: flag is already set, condition recovers into dead-band
 *       between set-threshold and clear-threshold → flag never clears.
 * Fix: in dead-band, if the flag is NOT yet latched, reset the timer (prevent
 * phantom partial-count).  If the flag IS latched, hold it (hysteresis zone —
 * do not clear prematurely, wait for cond_clear to cross hysteresis boundary).
 * This keeps correct hysteresis for latched faults while avoiding timer
 * contamination for non-latched ones.
 *
 * LATCH-TIMEOUT FIX (V2): Even with the above dead-band fix, if the condition
 * STAYS in the hysteresis dead-band indefinitely (e.g. voltage hovers at 4.23V
 * when OV triggers at 4.25V and clears at 4.20V), the flag remains latched
 * forever.  Now sDeadBandTimeout[idx] counts consecutive dead-band ticks while
 * latched.  When it reaches FAULT_DEBOUNCE_TICKS, the flag is auto-cleared.
 * This guarantees the BMS can always recover from a latching fault within
 * FAULT_DEBOUNCE_TICKS ticks (~5 s) of the condition entering the dead-band.
 */
#define FAULT_DEBOUNCE(cond_set, cond_clear, idx, flag, msg)        \
    do {                                                             \
        if (cond_set) {                                              \
            sDeadBandTimeouts[idx] = 0;                              \
            if (sFaultTimers[idx] < FAULT_DEBOUNCE_TICKS) {         \
                sFaultTimers[idx]++;                                 \
            }                                                        \
            if (sFaultTimers[idx] >= FAULT_DEBOUNCE_TICKS) {        \
                if (!sLatchedFlags.flag) {                           \
                    sLatchedFlags.flag = true;                       \
                    ErrorLog_Add(msg);                               \
                    changed = true;                                  \
                }                                                    \
            }                                                        \
        } else if (cond_clear) {                                     \
            sFaultTimers[idx] = 0;                                   \
            sDeadBandTimeouts[idx] = 0;                              \
            sLatchedFlags.flag = false;                              \
        } else {                                                     \
            /* Dead-band: between set and clear thresholds.         \
             * If fault not yet latched, reset the debounce counter  \
             * so partial counts don't persist across events.        \
             * If fault already latched, start/advance a timeout     \
             * that auto-clears after FAULT_DEBOUNCE_TICKS ticks.   */ \
            if (sLatchedFlags.flag) {                                \
                if (++sDeadBandTimeouts[idx] >= FAULT_DEBOUNCE_TICKS) { \
                    sFaultTimers[idx] = 0;                           \
                    sDeadBandTimeouts[idx] = 0;                      \
                    sLatchedFlags.flag = false;                      \
                }                                                    \
            } else {                                                 \
                sFaultTimers[idx] = 0;                               \
                sDeadBandTimeouts[idx] = 0;                          \
            }                                                        \
        }                                                            \
    } while (0)

/* ── Public API ─────────────────────────────────────────────────────────── */

void Fault_Init(const FaultThresholds_t *thr)
{
    if (thr != NULL) {
        sThresh = *thr;
    } else {
        sThresh.ovVoltage_V    = FAULT_OV_DEFAULT;
        sThresh.uvVoltage_V    = FAULT_UV_DEFAULT;
        sThresh.ocCurrent_A    = FAULT_OC_DEFAULT;
        sThresh.cellDiff_mV    = FAULT_CELL_DIFF_DEFAULT;
        sThresh.otTemp_C       = FAULT_OT_DEFAULT;
        sThresh.utTemp_C       = FAULT_UT_DEFAULT;
        sThresh.cellMax_V      = FAULT_CELL_MAX_DEFAULT;
        sThresh.cellMin_V      = FAULT_CELL_MIN_DEFAULT;
        sThresh.chargeOCLimit_A = FAULT_CHARGE_OC_DEFAULT;
    }
    memset(&sFlags,           0, sizeof(sFlags));
    memset(&sLatchedFlags,    0, sizeof(sLatchedFlags));
    memset(sFaultTimers,      0, sizeof(sFaultTimers));
    memset(sDeadBandTimeouts, 0, sizeof(sDeadBandTimeouts));
    sCellInvalidTicks = 0;
}

void Fault_ClearAll(void)
{
    memset(&sLatchedFlags,    0, sizeof(sLatchedFlags));
    memset(sFaultTimers,      0, sizeof(sFaultTimers));
    memset(sDeadBandTimeouts, 0, sizeof(sDeadBandTimeouts));
    sCellInvalidTicks = 0;
}

void Fault_SetThresholds(const FaultThresholds_t *thr) { sThresh = *thr; }

const FaultThresholds_t *Fault_GetThresholds(void) { return &sThresh; }

/**
 * @brief Evaluate all fault conditions against current measurements.
 *
 * @param packV        Filtered pack voltage (V).
 * @param currentA     Signed pack current (A). Positive = charging.
 * @param cellDiff     Max − Min cell spread (mV).
 * @param temp1        NTC1 temperature (°C), or 0.0f if not ready.
 * @param temp2        NTC2 temperature (°C), or 0.0f if not ready.
 * @param minCell_mV   Lowest cell voltage (mV, raw from Daly / signal_filter).
 * @param maxCell_mV   Highest cell voltage (mV, raw from Daly / signal_filter).
 *
 * @note  minCell_mV / maxCell_mV are in MILLIVOLTS (e.g. 3700 for 3.700 V).
 *        They are converted to Volts once at the top of this function.
 *        When main.c is updated to pass FilteredData_t.filtered_min/max_cellV
 *        (already in V), remove the /1000 conversion and update this note.
 */
void Fault_Update(float packV, float currentA, float cellDiff,
                  float temp1, float temp2,
                  float minCell_mV, float maxCell_mV)
{
    const FaultThresholds_t *thr = Fault_GetThresholds();
    bool changed = false;

    /* ── Unit conversion: mV → V (done ONCE here, used throughout) ─────── */
    float minCell_V = minCell_mV / 1000.0f;
    float maxCell_V = maxCell_mV / 1000.0f;

    /* ── Sanity: reject obviously corrupt cell values ───────────────────── */
    /* If either value is outside the physical LiX range, skip cell faults.  */
    bool cell_data_valid = (minCell_V > 0.5f && minCell_V < 5.0f &&
                            maxCell_V > 0.5f && maxCell_V < 5.0f &&
                            maxCell_V >= minCell_V);

    /* ================================================================== */
    /* PACK OV (timer 0)                                                   */
    /* FIX: was evaluated but never written to sLatchedFlags (silent drop) */
    /* ================================================================== */
    bool cond_packOV_set   = (packV > thr->ovVoltage_V);
    bool cond_packOV_clear = (packV < (thr->ovVoltage_V - FAULT_HYST_OV_V));
    FAULT_DEBOUNCE(cond_packOV_set, cond_packOV_clear,
                   FTIDX_OV, overVoltageError,
                   "Fault: Pack Over Voltage Latched");

    /* ================================================================== */
    /* PACK UV (timer 1)                                                   */
    /* Guard: packV > 1.0 V prevents false UV on unpowered startup.       */
    /* ================================================================== */
    bool cond_packUV_set   = (packV < thr->uvVoltage_V && packV > 1.0f);
    bool cond_packUV_clear = (packV > (thr->uvVoltage_V + FAULT_HYST_UV_V));
    FAULT_DEBOUNCE(cond_packUV_set, cond_packUV_clear,
                   FTIDX_UV, underVoltageError,
                   "Fault: Pack Under Voltage Latched");

    /* ================================================================== */
    /* DISCHARGE OVER CURRENT (timer 2)                                   */
    /* ================================================================== */
    bool cond_oc_set   = (currentA < -thr->ocCurrent_A);
    bool cond_oc_clear = (currentA > -(thr->ocCurrent_A - FAULT_HYST_OC_A));
    FAULT_DEBOUNCE(cond_oc_set, cond_oc_clear,
                   FTIDX_OC_DISCHG, overCurrentError,
                   "Fault: Discharge Over Current Latched");

    /* ================================================================== */
    /* CELL IMBALANCE (timer 3)                                           */
    /* Guard: packV > 10 V ensures cells are actually connected.          */
    /*                                                                    */
    /* LINKED-FAULT FIX: When cellDiffError clears (balancing complete), */
    /* the maxCell_mV reading may have been inflated by the imbalance     */
    /* condition itself (one high cell pulling max up).  The Cell OV      */
    /* timer/flag is therefore reset together with cellDiffError so that  */
    /* cellOverVoltageError does not remain stuck after the diff clears.  */
    /* ================================================================== */
    bool prev_cell_diff_latched = sLatchedFlags.cellDiffError;
    bool cond_diff_set   = (packV > 10.0f && cellDiff > thr->cellDiff_mV);
    bool cond_diff_clear = (cellDiff < (thr->cellDiff_mV - FAULT_HYST_CELL_mV));
    FAULT_DEBOUNCE(cond_diff_set, cond_diff_clear,
                   FTIDX_CELL_DIFF, cellDiffError,
                   "Fault: Cell Imbalance Latched");

    /* If cellDiffError just cleared, reset the Cell OV *and* Cell UV faults.
     * Rationale: the extreme cell voltage that caused OV or UV was a
     * consequence of imbalance -- and imbalance can equally be driven by
     * one HIGH cell (pulls max up -> Cell OV) or one LOW cell (pulls min
     * down -> Cell UV).  Once balancing is confirmed done (diff below
     * hysteresis), a lingering flag on EITHER side is stale.  Both paths
     * re-evaluate immediately after and will re-latch if genuinely still
     * over/under threshold.
     *
     * FIX: the original linked-fault fix only reset FTIDX_CELL_OV here --
     * FTIDX_CELL_UV was never touched, so a low-cell-driven imbalance left
     * cellUnderVoltageError permanently stuck latched after the diff
     * cleared (exact mirror of the bug already fixed for the OV side). */
    if (prev_cell_diff_latched && !sLatchedFlags.cellDiffError) {
        sFaultTimers[FTIDX_CELL_OV] = 0;
        sLatchedFlags.cellOverVoltageError = false;
        sFaultTimers[FTIDX_CELL_UV] = 0;
        sLatchedFlags.cellUnderVoltageError = false;
    }

    /* ================================================================== */
    /* OVER TEMPERATURE 1 (timer 4)                                       */
    /* ================================================================== */
    bool cond_ot1_set   = (temp1 > thr->otTemp_C);
    bool cond_ot1_clear = (temp1 < (thr->otTemp_C - FAULT_HYST_OT_C));
    FAULT_DEBOUNCE(cond_ot1_set, cond_ot1_clear,
                   FTIDX_OT1, overTemperatureError,
                   "Fault: Over Temperature 1 Latched");

    /* ================================================================== */
    /* UNDER TEMPERATURE 1 (timer 5)                                      */
    /* Exclude 0.0f (ADC not-ready sentinel) and open-circuit (≤ −900 °C).*/
    /* ================================================================== */
    bool cond_ut1_set   = (temp1 < thr->utTemp_C &&
                            temp1 != 0.0f && temp1 > -900.0f);
    bool cond_ut1_clear = (temp1 > (thr->utTemp_C + FAULT_HYST_UT_C) ||
                            temp1 == 0.0f || temp1 <= -900.0f);
    FAULT_DEBOUNCE(cond_ut1_set, cond_ut1_clear,
                   FTIDX_UT1, underTemperatureError,
                   "Fault: Under Temperature 1 Latched");

    /* ================================================================== */
    /* THERMISTOR 1 MISSING (timer 6)                                     */
    /* −999.0f / values ≤ −900 = open-circuit ADC.                        */
    /* 0.0f = ADC not ready yet — must NOT be treated as disconnected.    */
    /* ================================================================== */
    bool cond_therm1_set   = (temp1 <= -900.0f && temp1 != 0.0f);
    bool cond_therm1_clear = (temp1 > -900.0f);
    FAULT_DEBOUNCE(cond_therm1_set, cond_therm1_clear,
                   FTIDX_THERM1, thermistorNotConnectedError,
                   "Fault: Thermistor 1 Not Connected Latched");

    /* ================================================================== */
    /* OVER TEMPERATURE 2 (timer 7)                                       */
    /* ================================================================== */
    bool cond_ot2_set   = (temp2 > thr->otTemp_C);
    bool cond_ot2_clear = (temp2 < (thr->otTemp_C - FAULT_HYST_OT_C));
    FAULT_DEBOUNCE(cond_ot2_set, cond_ot2_clear,
                   FTIDX_OT2, overTemperature2Error,
                   "Fault: Over Temperature 2 Latched");

    /* ================================================================== */
    /* UNDER TEMPERATURE 2 (timer 8) — same sentinel exclusions as UT1   */
    /* ================================================================== */
    bool cond_ut2_set   = (temp2 < thr->utTemp_C &&
                            temp2 != 0.0f && temp2 > -900.0f);
    bool cond_ut2_clear = (temp2 > (thr->utTemp_C + FAULT_HYST_UT_C) ||
                            temp2 == 0.0f || temp2 <= -900.0f);
    FAULT_DEBOUNCE(cond_ut2_set, cond_ut2_clear,
                   FTIDX_UT2, underTemperature2Error,
                   "Fault: Under Temperature 2 Latched");

    /* ================================================================== */
    /* THERMISTOR 2 MISSING (timer 9)                                     */
    /* ================================================================== */
    bool cond_therm2_set   = (temp2 <= -900.0f && temp2 != 0.0f);
    bool cond_therm2_clear = (temp2 > -900.0f);
    FAULT_DEBOUNCE(cond_therm2_set, cond_therm2_clear,
                   FTIDX_THERM2, thermistor2NotConnectedError,
                   "Fault: Thermistor 2 Not Connected Latched");

    /* ================================================================== */
    /* CELL OVER VOLTAGE (timer 10)                                       */
    /*                                                                    */
    /* FIX: replaced confidence-counter (static uint8_t) with the same   */
    /* FAULT_DEBOUNCE_TICKS timer infrastructure used by all other faults.*/
    /* Old code: step +10 / −10 with threshold 80 → latched in 8 calls   */
    /*   (0.8 s) with no hysteresis. A single balancer glitch in the raw  */
    /*   Daly stream could fire this in under 1 second.                   */
    /* New code: 5 consecutive ticks (5 s) + 50 mV hysteresis.           */
    /*                                                                    */
    /* Only evaluated when cell_data_valid (sanity checked above).        */
    /* ================================================================== */
    if (cell_data_valid) {
        bool cond_cellOV_set   = (maxCell_V > thr->cellMax_V);
        bool cond_cellOV_clear = (maxCell_V < (thr->cellMax_V - FAULT_HYST_CELL_V));
        FAULT_DEBOUNCE(cond_cellOV_set, cond_cellOV_clear,
                       FTIDX_CELL_OV, cellOverVoltageError,
                       "Fault: Cell Over Voltage Latched");

    /* ================================================================== */
    /* CELL UNDER VOLTAGE (timer 11)                                      */
    /* Same fix as Cell OV above — debounce + hysteresis.                 */
    /* ================================================================== */
        bool cond_cellUV_set   = (minCell_V < thr->cellMin_V);
        bool cond_cellUV_clear = (minCell_V > (thr->cellMin_V + FAULT_HYST_CELL_V));
        FAULT_DEBOUNCE(cond_cellUV_set, cond_cellUV_clear,
                       FTIDX_CELL_UV, cellUnderVoltageError,
                       "Fault: Cell Under Voltage Latched");

        sCellInvalidTicks = 0;   /* Reset invalid-data counter on good frame */
    } else {
        /* Invalid cell data — increment stale counter.
         * After CELL_INVALID_TIMEOUT_TICKS consecutive bad frames, clear
         * the cell OV/UV timers and flags.  This prevents cellOverVoltageError
         * from being permanently stuck if the BMS stops sending valid cell
         * voltages (e.g. after a comms fault or BMS shutdown).
         * A real OV/UV will re-latch immediately when valid data resumes.  */
        if (sCellInvalidTicks < CELL_INVALID_TIMEOUT_TICKS) {
            sCellInvalidTicks++;
        }
        if (sCellInvalidTicks >= CELL_INVALID_TIMEOUT_TICKS) {
            sFaultTimers[FTIDX_CELL_OV] = 0;
            sLatchedFlags.cellOverVoltageError = false;
            sFaultTimers[FTIDX_CELL_UV] = 0;
            sLatchedFlags.cellUnderVoltageError = false;
        }
    }

    /* ================================================================== */
    /* CHARGE OVER CURRENT (timer 12)                                     */
    /* ================================================================== */
    bool cond_chrg_oc_set   = (currentA > thr->chargeOCLimit_A);
    bool cond_chrg_oc_clear = (currentA < (thr->chargeOCLimit_A - FAULT_HYST_OC_A));
    FAULT_DEBOUNCE(cond_chrg_oc_set, cond_chrg_oc_clear,
                   FTIDX_OC_CHRG, chargeOverCurrentError,
                   "Fault: Charge Over Current Latched");

    (void)changed;  /* Used by FAULT_DEBOUNCE macro for ErrorLog gating */
}

/* ── Getters ────────────────────────────────────────────────────────────── */

const FaultFlags_t *Fault_GetFlags(void) { return &sLatchedFlags; }

uint16_t Fault_GetBitmask(void)
{
    uint16_t mask = 0u;
    if (sLatchedFlags.overVoltageError)           mask |= FAULT_BIT_OV;
    if (sLatchedFlags.underVoltageError)          mask |= FAULT_BIT_UV;
    if (sLatchedFlags.overCurrentError)           mask |= FAULT_BIT_OC;
    if (sLatchedFlags.cellDiffError)              mask |= FAULT_BIT_CELL_DIFF;
    if (sLatchedFlags.overTemperatureError)       mask |= FAULT_BIT_OT;
    if (sLatchedFlags.underTemperatureError)      mask |= FAULT_BIT_UT;
    if (sLatchedFlags.thermistorNotConnectedError)mask |= FAULT_BIT_THERM_MISSING;
    if (sLatchedFlags.overTemperature2Error)      mask |= FAULT_BIT_OT2;
    if (sLatchedFlags.underTemperature2Error)     mask |= FAULT_BIT_UT2;
    if (sLatchedFlags.thermistor2NotConnectedError)mask|= FAULT_BIT_THERM2_MISSING;
    if (sLatchedFlags.cellOverVoltageError)       mask |= FAULT_BIT_CELL_OV;
    if (sLatchedFlags.cellUnderVoltageError)      mask |= FAULT_BIT_CELL_UV;
    if (sLatchedFlags.chargeOverCurrentError)     mask |= FAULT_BIT_CHARGE_OC;
    return mask;
}
