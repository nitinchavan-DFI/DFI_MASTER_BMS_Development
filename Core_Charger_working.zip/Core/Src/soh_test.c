/**
 * soh_test.c - Standalone unit test sketch for SOH estimator
 * Compile: gcc soh_test.c soh_estimator.c -lm -o soh_test && ./soh_test
 */

#include "soh_estimator.h"
#include <stdio.h>
#include <unistd.h> /* usleep */

int main() {
    SOH_Handle_t h;
    float q_nom = 20.0f; /* 20Ah */
    
    SOH_Init(&h, q_nom, 0.001f, 14);
    
    printf("SOH Test - Initial: %.1f%% cycles=%u life=%.1fy totalAh=%u\\n", 
           SOH_GetPercent(&h), h.data.cycles, h.data.life_years, h.data.total_ah_cycled);
    
    /* Simulate 1000 100ms ticks: discharge 20Ah */
    for (int tick = 0; tick < 1000; tick++) {
        float curr_a = -20.0f; /* 20A discharge */
        float soc_p = 100.0f - (tick * 0.09f); /* ~90% DoD */
        SOH_Tick100ms(&h, curr_a, 50.0f, soc_p, 25.0f, 0);
        if (tick % 100 == 0) {
            printf("Tick %d: SOH=%.1f%% cycles=%u state=%d\\n", tick, SOH_GetPercent(&h), h.data.cycles, SOH_GetState(&h));
        }
    }
    
    printf("\\nSOH Test Complete: %.1f%% cycles=%u life=%.1fy totalAh=%u\\n", 
           SOH_GetPercent(&h), h.data.cycles, h.data.life_years, h.data.total_ah_cycled);
    
    /* Reset test */
    SOH_ResetLifeCounters(&h);
    printf("\\nAfter RESET_LIFE: cycles=%u life=%.1fy\\n", h.data.cycles, h.data.life_years);
    
    return 0;
}
