/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2026 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "NTC10K.h"
#include "bmsNode.h"
#include "calib_store.h"
#include "canard.h"
#include "charger_config.h"
#include "cli_frame.h"
#include "current_sensor.h"
#include "daly_bms.h"
#include "daly_ekf.h"
#include "error_log_store.h"
#include "fault_detector.h"
#include "fdcan.h"
#include "led_status.h"
#include "soc.h"
#include "soc_extended.h"
#include "signal_filter.h"
#include "soh_estimator.h"

#include "fault_confidence.h"
#include "lc_estimator.h" /* NEW */
#include "w25q64.h"

#include <assert.h>

#include <math.h>
#include <string.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
ADC_HandleTypeDef hadc2;

/* hfdcan1 now defined in fdcan.c */

IWDG_HandleTypeDef hiwdg;

QSPI_HandleTypeDef hqspi1;

RTC_HandleTypeDef hrtc;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim5;
TIM_HandleTypeDef htim6;
TIM_HandleTypeDef htim15;

UART_HandleTypeDef huart5;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
/* TxHeader/RxHeader/TxData/RxData removed — TX now goes through the
   Transmit_*_Msg() helpers in fdcan.c, and RX header/data are local to
   HAL_FDCAN_RxFifo0Callback() below. */

volatile uint8_t tim5_flag = 0;
static uint32_t ms_100_counter = 0;
volatile uint64_t _1secCounter = 0;

SOC_Handle_t hSoc;
SOC_Config_t g_soc_config;
CLI_ChargerConfig_t g_charger_config; /**< Solterra charge profile, see charger_config.h */
ChargerRuntime_t hChgRt; /**< Charger RX filter + state machine + last command,
                              see charger_config.h. NOT persisted -- re-derives
                              from live data every boot ("plug and play"). */
DalyBMS_Handle_t hDaly;
SignalFilter_Handle_t hFilter;
FaultConfidence_Handle_t hFaultConf;
LC_Handle_t hLC; /* NEW LC estimator */
SOH_Handle_t hSOH;

/* hrtc is declared in the HAL-generated block above — do not re-declare */


static CLI_Frame_t rxFrame;
static uint32_t lastSendTick = 0;
float temp_celsius = -999.0f;
float temp2_celsius = -999.0f;
static int last_saved_soc_percent = -1;
#define CLI_SEND_INTERVAL_MS 100U
#define CLI_CMD_READ_RESET_COUNTS   0x30
#define CLI_CMD_RESET_RESET_COUNTS  0x31

uint8_t temp1Ready = 0;
uint8_t temp2Ready = 0;
/* ---- CAN RX deferred processing queue ---- */
#define CAN_RX_QUEUE_SIZE 8 /* keep small to avoid bloating stack/ROM; not related to UART */
typedef struct {
  CanardCANFrame frame;
  uint64_t timestamp_usec;
} CAN_RxItem_t;

static volatile CAN_RxItem_t can_rx_queue[CAN_RX_QUEUE_SIZE];
static volatile uint8_t can_rx_head = 0;
static volatile uint8_t can_rx_tail = 0;

/* ---- Flash auto-save throttle ---- */
static uint32_t last_auto_save_tick = 0;
#define AUTO_SAVE_MIN_INTERVAL_MS (5U * 60U * 1000U) /* 5 minutes */

/* ---- Reset counters ---- */
static uint32_t total_reset_count = 0;
static uint32_t max_false_reset_count = 0;
static uint8_t consecutive_fault_ticks = 0;

/* ---- Daly BMS disconnect detection ---- */
static uint32_t last_bms_valid_tick = 0;

/* ---- System state machine (DRIVE/CHARGE/IDLE) with dead-band timeout ----
 * Moved to file scope so CLI_CMD_RESET_STATE (case 0x55) can access them.
 * Previously static inside a nested block in main() — invisible to switch(). */
static SystemState_t lastDriveState = SYS_STATE_IDLE;
static uint8_t spike_persist_cnt = 0;
static uint16_t state_deadband_ticks = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM1_Init(void);
static void MX_UART5_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_QUADSPI1_Init(void);
static void MX_ADC2_Init(void);
static void MX_TIM6_Init(void);
static void MX_RTC_Init(void);
/* MX_FDCAN1_Init prototype now comes from fdcan.h */
static void MX_TIM5_Init(void);
static void MX_TIM15_Init(void);
static void MX_IWDG_Init(void);
/* USER CODE BEGIN PFP */
void Process_CAN_Tx(void);
/* Local forward declaration — belt-and-suspenders alongside the one in
 * fdcan.h. If fdcan.h on disk is ever out of sync, this keeps main.c
 * compiling; the linker still resolves the symbol from fdcan.c either way. */
bool FDCAN1_HealthCheck(void);
/* Same belt-and-suspenders reasoning for the two new CAN-health getters
 * (added alongside the sustained-Error_Passive recovery fix) — confirmed
 * necessary by a real build: fdcan.h on disk was out of sync and main.c
 * failed with "implicit declaration" for both, including the pre-existing
 * FDCAN1_GetBusOffRecoveryCount(). Declaring them here too means main.c
 * compiles even if Core/Inc/fdcan.h isn't the exact copy shipped alongside
 * this main.c/fdcan.c pair. */
uint32_t FDCAN1_GetBusOffRecoveryCount(void);
uint32_t FDCAN1_GetErrorPassiveSeconds(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* ── CLI config-write input validation ───────────────────────────────────
 * Every SET_* command below used to memcpy the incoming payload straight
 * into the live config with zero bounds checking (only cellCount had a
 * check). A single dropped/garbled UART byte that still happens to pass
 * the frame checksum (1-in-256 by construction), or simply a fat-fingered
 * value typed into the GUI, could set e.g. battery_capacity_ah = 0 or
 * cellMax_V < cellMin_V. SOC_Update() already has its own NaN/Inf guard
 * (soc.c) so a bad capacity can't propagate into a divide-by-zero crash,
 * but "silently falls back to 50% SOC" and "silently accepts a physically
 * impossible fault threshold" are both still exactly the kind of thing an
 * automotive-grade input boundary should reject outright rather than
 * paper over. Each validator below rejects the WHOLE write (old config is
 * kept unchanged) rather than partially applying — same "reject, don't
 * half-apply" convention already used for charger cellCount.
 */
static bool AllFinite(const float *arr, uint32_t n) {
  for (uint32_t i = 0; i < n; i++) {
    if (!isfinite(arr[i])) {
      return false;
    }
  }
  return true;
}

/**
 * @brief  Return a stored threshold if it is finite and strictly inside
 *         (lo, hi), otherwise the compiled-in default.
 *
 *         Used when restoring from flash so one bad field cannot poison the
 *         whole threshold set, and so a record written by an older firmware
 *         (or a field that never existed in that record) degrades to the
 *         current default instead of to zero.
 */
static float ThrOrDefault(float stored, float lo, float hi, float dflt) {
  if (isfinite(stored) && (stored > lo) && (stored < hi)) {
    return stored;
  }
  return dflt;
}

static bool ValidateFaultThresholds(const FaultThresholds_t *t) {
  if (!AllFinite((const float *)t, (uint32_t)(sizeof(*t) / sizeof(float)))) {
    return false;
  }
  /* Envelope comes from fault_detector.h so the accepted range and the
   * defaults can't drift apart. The old bands (ov < 100, cellDiff < 5000,
   * utTemp > -50, oc < 1000) were sized for physically-plausible trip points
   * only, so the commissioning set — which uses cellDiff_mV = 15000 and
   * utTemp_C = -10000 to switch those two faults OFF — was rejected in full,
   * taking the seven perfectly good values with it. Ordering constraints are
   * kept: the detector's hysteresis arithmetic depends on them. */
  if (!(t->ovVoltage_V > 0.0f && t->ovVoltage_V < FAULT_ACCEPT_V_MAX)) {
    return false;
  }
  if (!(t->uvVoltage_V > 0.0f && t->uvVoltage_V < t->ovVoltage_V)) return false;
  if (!(t->ocCurrent_A > 0.0f && t->ocCurrent_A < FAULT_ACCEPT_I_MAX)) {
    return false;
  }
  if (!(t->cellDiff_mV >= 0.0f &&
        t->cellDiff_mV < FAULT_ACCEPT_CELLDIFF_MAX)) {
    return false;
  }
  if (!(t->otTemp_C > t->utTemp_C && t->otTemp_C < FAULT_ACCEPT_TEMP_MAX &&
        t->utTemp_C > FAULT_ACCEPT_TEMP_MIN)) {
    return false;
  }
  if (!(t->cellMax_V > t->cellMin_V && t->cellMin_V > 0.0f &&
        t->cellMax_V < FAULT_ACCEPT_CELL_V_MAX)) {
    return false;
  }
  if (!(t->chargeOCLimit_A > 0.0f &&
        t->chargeOCLimit_A < FAULT_ACCEPT_I_MAX)) {
    return false;
  }
  return true;
}

/**
 * @brief  Warn when the pack OV trip sits at or below the charger's CV
 *         target — the OV fault then preempts the CV taper and you get the
 *         stop/restart chatter ("BMS dancing") that an identical 50.4 V
 *         threshold/target pair caused before.
 *
 *         With the commissioning defaults this fires: FAULT_OV_DEFAULT is
 *         58.8 V and 14 cells x 4.20 V/cell is also exactly 58.8 V. Logged,
 *         not enforced — it is a configuration smell, not an invalid value.
 */
static void Fault_WarnIfOvBelowCvTarget(void) {
  const FaultThresholds_t *t = Fault_GetThresholds();
  float cv_target = (float)g_charger_config.cellCount *
                    g_charger_config.cellVoltageSetpoint_V;

  if ((cv_target > 1.0f) &&
      (t->ovVoltage_V <= (cv_target + FAULT_HYST_OV_V))) {
    ErrorLog_Add("WARN: pack OV trip <= charger CV target +1V");
  }
}

static bool ValidateSocConfig(const CLI_SOC_Config_Payload_t *p) {
  if (!AllFinite((const float *)p, (uint32_t)(sizeof(*p) / sizeof(float)))) {
    return false;
  }
  if (!(p->pack_uv_limit > 0.0f && p->pack_uv_limit < 200.0f)) return false;
  if (!(p->pack_full_voltage > p->pack_uv_limit &&
        p->pack_full_voltage < 200.0f)) return false;
  /* 1C reference for the charger's temperature-derate table -- 0 or
   * negative would silently zero every derated current (safe direction,
   * SOC_Update() falls back to 50% too) but is still a config mistake
   * worth rejecting outright rather than accepting quietly. */
  if (!(p->battery_capacity_ah > 0.01f && p->battery_capacity_ah < 1000.0f)) {
    return false;
  }
  for (int i = 0; i < SOC_OCV_POINTS; i++) {
    if (!(p->pack_ocv[i] > 0.0f && p->pack_ocv[i] < 200.0f)) return false;
    if (!(p->soc_ref[i] >= 0.0f && p->soc_ref[i] <= 100.0f)) return false;
  }
  return true;
}

static bool ValidateChargerConfig(const CLI_ChargerConfig_t *c) {
  if (!isfinite(c->cellVoltageSetpoint_V) || !isfinite(c->chargeCurrentFull_A) ||
      !isfinite(c->cvCutoffCurrent_A) || !isfinite(c->socTaperStart_pct)) {
    return false;
  }
  if (!(c->cellCount > 0U && c->cellCount <= 32U)) return false;
  if (!(c->cellVoltageSetpoint_V > 0.0f && c->cellVoltageSetpoint_V < 10.0f)) {
    return false;
  }
  if (!(c->chargeCurrentFull_A >= 0.0f && c->chargeCurrentFull_A < 1000.0f)) {
    return false;
  }
  if (!(c->cvCutoffCurrent_A >= 0.0f && c->cvCutoffCurrent_A <= c->chargeCurrentFull_A)) {
    return false;
  }
  if (!(c->socTaperStart_pct >= 0.0f && c->socTaperStart_pct <= 100.0f)) {
    return false;
  }
  return true;
}

/* ──────────────────────────────────────────────────────────────────────────
 * Charger thermal gate — temperature source selection (main.c side)
 *
 * Charger_ComputeCommand() owns the sticky 50.0 °C block / 47.0 °C resume
 * latch; this function owns deciding WHICH number to hand it, which is the
 * part that was missing.  Passing `temp1Ready ? temp_celsius : 0.0f` looks
 * right but has a hole: NTC_ADC_To_Celsius() returns -999.0f on an open
 * circuit, temp1Ready is still 1, and -999 °C is *below* the resume point.
 * So a thermistor whose wire falls off does not block the gate — it
 * permanently RELEASES it, and the BMS will happily command a 15 A charge
 * with no working temperature sensor.  Nothing else catches this either:
 * CHARGER_GATING_FAULT_MASK is (OV | OT | OT2) and does not include
 * FAULT_BIT_THERM_MISSING.
 *
 * Rules, in order:
 *   1. No sample from either NTC yet  -> CHARGER_TEMP_NOT_READY_C (permit).
 *      Only true for the first few hundred ms after boot.
 *   2. At least one plausible reading -> the HOTTEST plausible reading.
 *   3. Samples arrived but none plausible (open circuit / short / NaN /
 *      out of range) -> CHARGER_TEMP_SENSOR_FAIL_C, which is above the
 *      block threshold, so the gate blocks and latches.
 *
 * Rule 2 uses the hottest of NTC1/NTC2 rather than NTC1 alone. The pack has
 * two thermistors and the charger gate only watched one, so a hot spot on
 * NTC2 was ignored until the pack-wide 55 °C OT2 fault tripped — which
 * stops discharge too, i.e. exactly the last-resort trip this gate exists
 * to stay ahead of. Set CHARGER_TEMP_GATE_USE_BOTH_NTC to 0 to go back to
 * NTC1-only behaviour.
 * ────────────────────────────────────────────────────────────────────────*/
#define CHARGER_TEMP_GATE_USE_BOTH_NTC 1

/**
 * @brief  Append a signed decimal integer to a NUL-terminated string,
 *         bounded by cap. Avoids dragging newlib's printf family into the
 *         image just to log one number (this project has never included
 *         <stdio.h> — see the boot reset-flags message for the same idiom).
 */
static void AppendIntStr(char *dst, size_t cap, int32_t value) {
  char digits[12];
  size_t len = strlen(dst);
  uint8_t n = 0U;
  uint32_t mag;

  if (value < 0) {
    if ((len + 1U) < cap) {
      dst[len++] = '-';
      dst[len] = '\0';
    }
    mag = (uint32_t)(-(int64_t)value);
  } else {
    mag = (uint32_t)value;
  }

  do {
    digits[n++] = (char)('0' + (mag % 10U));
    mag /= 10U;
  } while ((mag != 0U) && (n < sizeof(digits)));

  while ((n > 0U) && ((len + 1U) < cap)) {
    dst[len++] = digits[--n];
  }
  dst[len] = '\0';
}

static bool ChargerTemp_IsPlausible(uint8_t ready, float t_C) {
  return (ready != 0U) && isfinite(t_C) &&
         (t_C > CHARGER_TEMP_PLAUSIBLE_MIN_C) &&
         (t_C < CHARGER_TEMP_PLAUSIBLE_MAX_C);
}

static float Charger_GetGateTemperature(void) {
  bool have = false;
  float hottest = CHARGER_TEMP_PLAUSIBLE_MIN_C;

  if (ChargerTemp_IsPlausible(temp1Ready, temp_celsius)) {
    hottest = temp_celsius;
    have = true;
  }
#if CHARGER_TEMP_GATE_USE_BOTH_NTC
  if (ChargerTemp_IsPlausible(temp2Ready, temp2_celsius)) {
    if (!have || (temp2_celsius > hottest)) {
      hottest = temp2_celsius;
    }
    have = true;
  }
#endif

  if (have) {
    return hottest;
  }

  /* Nothing plausible. Distinguish "not sampled yet" from "sampled and
   * broken" — the first must permit charging, the second must block it. */
  if ((temp1Ready == 0U) && (temp2Ready == 0U)) {
    return CHARGER_TEMP_NOT_READY_C;
  }
  return CHARGER_TEMP_SENSOR_FAIL_C;
}

/**
 * @brief  Persist calibration, SOC state, fault thresholds, DroneCAN and
 *         charger config to external flash.
 * @retval true  Record written AND read back successfully.
 * @retval false Erase, program or verify failed -- the stored record is NOT
 *               the state currently in RAM.
 */
bool SaveSystemStateToFlash(void) {
  const CurrentSensor_Data_t *csData = CurrentSensor_GetData();
  const FaultThresholds_t *ft = Fault_GetThresholds();
  CalibStore_Data_t calData;
  memset(&calData, 0, sizeof(calData));

  calData.zeroOffset_Q16 = csData->zeroOffset_Q16;
  calData.couplingFactor = csData->couplingFactor;
  calData.ntc_calib_b = g_calib_b;
  calData.ntc2_calib_b = g_calib2_b;

  calData.soc_config = g_soc_config;
  calData.soc_percent = SOC_GetPercent(&hSoc);
  calData.remaining_ah = SOC_GetRemainingAh(&hSoc);

  /* Save all 9 fault thresholds (3 new ones added for cell OV/UV/charge OC) */
  calData.fault_ov_v          = ft->ovVoltage_V;
  calData.fault_uv_v          = ft->uvVoltage_V;
  calData.fault_oc_a          = ft->ocCurrent_A;
  calData.fault_cell_diff_mv  = ft->cellDiff_mV;
  calData.fault_ot_c          = ft->otTemp_C;
  calData.fault_ut_c          = ft->utTemp_C;
  calData.fault_cell_max_v    = ft->cellMax_V;
  calData.fault_cell_min_v    = ft->cellMin_V;
  calData.fault_charge_oc_a   = ft->chargeOCLimit_A;

  /* DroneCAN Settings */
  calData.dronecan_settings = settings;

  /* Solterra charger charge profile */
  calData.charger_config = g_charger_config;

  /* Save reset counters */
  ((uint32_t*)calData.reserved)[0] = total_reset_count;
  ((uint32_t*)calData.reserved)[1] = max_false_reset_count;

  /* CalibStore_Save internally refreshes the IWDG around the flash erase.
   * Do NOT call HAL_IWDG_Refresh here — it is handled inside CalibStore. */
  if (!CalibStore_Save(&calData)) {
    return false;
  }

  /* VERIFY-AFTER-WRITE. CalibStore_Save()'s return value used to be
   * discarded, so an erase or page-program that never landed reported
   * nothing at all -- the config silently reverted on the next boot and the
   * only symptom was "save to flash doesn't work". */
  CalibStore_Data_t verify;
  if (!CalibStore_Load(&verify)) {
    return false;
  }
  return (verify.fault_ov_v == calData.fault_ov_v) &&
         (verify.fault_uv_v == calData.fault_uv_v) &&
         (verify.fault_charge_oc_a == calData.fault_charge_oc_a) &&
         (verify.zeroOffset_Q16 == calData.zeroOffset_Q16);
}
/* USER CODE END 0 */

/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void) {

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick.
   */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_TIM1_Init();
  MX_UART5_Init();
  MX_USART2_UART_Init();
  MX_QUADSPI1_Init();
  MX_ADC2_Init();
  MX_TIM6_Init();
  MX_RTC_Init();
  MX_FDCAN1_Init();
  MX_TIM5_Init();
  MX_TIM15_Init();
  MX_IWDG_Init();
  /* USER CODE BEGIN 2 */

  /* --- Current sensor: init --- */
  CurrentSensor_Init(&hadc1, &htim1);

  /* --- External flash + calibration restore --- */
  CalibStore_Data_t savedCal;
  bool calValid = false;

  if (CalibStore_Init(&hqspi1)) {
    calValid = CalibStore_Load(&savedCal);
  }

  /* Initialize the Error Log partition in Flash */
  ErrorLog_Init(&hqspi1);

  /* ── Reset-cause diagnostics — logged on EVERY boot ─────────────────────
   * Reuses the existing error-log ring buffer (already exposed via the
   * GUI's "Error Logs" tab / CLI_CMD_READ_ERROR_LOGS) — no new protocol,
   * no GUI change needed.
   *
   * This directly targets the open "BMS hangs under sustained ~45-48A
   * charge current" question: was that actually a firmware freeze
   * (IWDG bit set -- main loop stopped feeding the watchdog), or a power-
   * rail event (BOR bit set -- voltage sag under load, which a fresh
   * ~45-48A pull through wiring/connectors/decoupling can absolutely
   * cause, and which looks identical to a "hang" from the outside: the
   * board just silently reboots and comes back a couple seconds later)?
   * Those are two completely different root-cause categories -- one is a
   * code bug, the other is a hardware/power-integrity issue -- and no
   * amount of reading the source can tell them apart. This can, the very
   * next time it happens.
   *
   * Note BOR also fires on every normal cold power-up on this series (BOR
   * covers POR detection too) -- a BOR-only entry right after you power
   * the board on is expected, not evidence of anything. What matters is
   * IWDG appearing at all, or BOR appearing on a boot that was NOT a
   * deliberate power cycle. */
  {
    char resetMsg[ERROR_LOG_MSG_MAX_LEN];
    strcpy(resetMsg, "Boot reset flags: ");
    if (__HAL_RCC_GET_FLAG(RCC_FLAG_IWDGRST)) strcat(resetMsg, "IWDG ");
    if (__HAL_RCC_GET_FLAG(RCC_FLAG_WWDGRST)) strcat(resetMsg, "WWDG ");
    if (__HAL_RCC_GET_FLAG(RCC_FLAG_BORRST))  strcat(resetMsg, "BOR ");
    if (__HAL_RCC_GET_FLAG(RCC_FLAG_PINRST))  strcat(resetMsg, "PIN ");
    if (__HAL_RCC_GET_FLAG(RCC_FLAG_SFTRST))  strcat(resetMsg, "SFT ");
    if (__HAL_RCC_GET_FLAG(RCC_FLAG_LPWRRST)) strcat(resetMsg, "LPWR ");
    if (__HAL_RCC_GET_FLAG(RCC_FLAG_OBLRST))  strcat(resetMsg, "OBL ");
    ErrorLog_Add(resetMsg);
    __HAL_RCC_CLEAR_RESET_FLAGS();
  }

  if (calValid) {
    /* Restore saved calibration — skip zero-cal */
    CurrentSensor_SetCalibration(savedCal.zeroOffset_Q16,
                                 savedCal.couplingFactor);
    if (savedCal.ntc_calib_b > 1000.0f) {
      g_calib_b = savedCal.ntc_calib_b;
    }
    if (savedCal.ntc2_calib_b > 1000.0f) {
      g_calib2_b = savedCal.ntc2_calib_b;
    }

    /* Restore DroneCAN Settings if valid */
    if (savedCal.dronecan_settings.magic == SETTINGS_MAGIC) {
      settings = savedCal.dronecan_settings;
    }

    /* Load reset counters if valid */
    total_reset_count++;
    if (calValid) {
      max_false_reset_count = ((uint32_t*)savedCal.reserved)[0];
    }

    /* Restore Solterra charger charge profile if it looks sane (non-zero
     * cell count) — guards against a struct-layout mismatch reading back
     * as all-zero/garbage before this field existed. */
    if (savedCal.charger_config.cellCount > 0U &&
        savedCal.charger_config.cellCount <= 32U) {
      g_charger_config = savedCal.charger_config;
    } else {
      ChargerConfig_LoadDefaults(&g_charger_config);
    }
  } else {
    /* No valid data — run zero calibration */
    CurrentSensor_StartZeroCalibration();
    ChargerConfig_LoadDefaults(&g_charger_config);
  }

  /* Charger runtime state (RX filter, state machine, derate hysteresis) is
   * never persisted -- always starts fresh at DISCONNECTED/INHIBIT and
   * re-derives from live status frames + live temperature within a few
   * seconds of boot. That is the "plug and play" behavior: nothing to
   * restore, nothing to arm. */
  Charger_RuntimeInit(&hChgRt);

  /* ---- DronCAN Settings ---- */
  load_settings();

  /* ---- Libcanard Init ---- */
  canardInit(&canard, memory_pool, sizeof(memory_pool), onTransferReceived,
             shouldAcceptTransfer, NULL);

  if (settings.can_node > 0) {
    canardSetLocalNodeID(&canard, (uint8_t)settings.can_node);
  }

  /* ---- FDCAN Filter & Start ----
     Filters (Charger exact-match, Display reject, DroneCAN catch-all),
     global filter, RX/TX-empty notifications, and HAL_FDCAN_Start now live
     in fdcan.c. Called here — AFTER canard init and node ID assignment
     above — so the bus does not go live before canardHandleRxFrame()'s
     target object exists, same ordering as before. */
  FDCAN1_ConfigFiltersAndStart();

  /* ---- Start TIM5 in interrupt mode (100 ms tick) ---- */
  HAL_TIM_Base_Start_IT(&htim5);

  /* ---- Start TIM15 directly for LED Status (100 ms tick) ---- */
  LedStatus_Init();
  HAL_TIM_Base_Start_IT(&htim15);

  /* LC init — deferred: called after SOC_Init so we can pass real SOC% */
  
  /* NEW SOH init */
  SOH_Init(&hSOH, g_soc_config.battery_capacity_ah, DEFAULT_RINT_NEW_OHM, CELL_COUNT);


  /* --- Daly BMS driver --- */
  DalyBMS_Init(&hDaly, &huart5);
  DalyBMS_SetCellCount(&hDaly, 16); /* <-- change to your pack size (12/14/16) */
  DalyBMS_StartUpdate(&hDaly);

  g_soc_config.ocv_min_pack_volt = g_soc_config.pack_ocv[1];

  /* --- Signal Filter Init --- */

  
  /* --- Extended SOC Init (restores verified or defaults) --- */
  if (calValid) {
    g_soc_config = savedCal.soc_config;
  } else {
    /* Defaults */
    g_soc_config.pack_uv_limit = SOC_DEFAULT_PACK_UV_LIMIT;
    g_soc_config.battery_capacity_ah = SOC_DEFAULT_BATTERY_CAPACITY_AH;
    g_soc_config.pack_full_voltage = SOC_DEFAULT_PACK_FULL_VOLTAGE;
    g_soc_config.taper_current = SOC_DEFAULT_TAPER_CURRENT;
    g_soc_config.idle_current_a = SOC_DEFAULT_IDLE_CURRENT_A;
    g_soc_config.max_dt_sec = SOC_DEFAULT_MAX_DT_SEC;
    g_soc_config.ocv_min_pack_volt = SOC_DEFAULT_OCV_MIN_PACK_VOLT;
    g_soc_config.ocv_min_soc_percent = SOC_DEFAULT_OCV_MIN_SOC_PERCENT;
    g_soc_config.charge_efficiency = SOC_DEFAULT_CHARGE_EFFICIENCY;

    const float def_soc_ref[SOC_OCV_POINTS] = SOC_DEFAULT_SOC_REF_ARRAY;
    const float def_pack_ocv[SOC_OCV_POINTS] = SOC_DEFAULT_PACK_OCV_ARRAY;
    memcpy(g_soc_config.soc_ref, def_soc_ref, sizeof(def_soc_ref));
    memcpy(g_soc_config.pack_ocv, def_pack_ocv, sizeof(def_pack_ocv));
  }
  /* ROOT CAUSE FIX: Use persisted soc_percent (no 50% default reset) */
  float init_soc_pct = calValid ? savedCal.soc_percent : hDaly.data.packSOC;
  SOC_Init(&hSoc, &g_soc_config, init_soc_pct, HAL_GetTick());

  /* LC init: open at actual persisted SOC so first display is correct.
   * Uses runtime pack config (pack_full_voltage, battery_capacity_ah, cellCount)
   * instead of hardcoded defaults — ensures Wh estimates and voltage anchors
   * match the actual battery pack. */
  LC_InitWithConfig(&hLC,
                    100.0f,
                    SOC_GetPercent(&hSoc),
                    g_soc_config.pack_full_voltage,
                    g_soc_config.battery_capacity_ah,
                    g_charger_config.cellCount);

  last_saved_soc_percent = (int)SOC_GetPercent(&hSoc);

  /* --- CLI frame protocol on USART2 --- */
  CLI_Frame_Init(&huart2);

  /* --- Fault detector: legacy + confidence (thresholds only) ---
   * A stored record is now sanity-checked before it is installed. The old
   * code took ov/uv/oc/cellDiff/ot/ut from flash unconditionally and only
   * guarded the three newer fields with ad-hoc literals (> 0.5f, > 0.1f), so
   * a record written by an older firmware — or one field of a partially
   * written record — could install a nonsense threshold that then looked
   * like a phantom fault. Each field falls back to its FAULT_*_DEFAULT
   * individually, and the assembled set is validated as a whole. */
  if (calValid) {
    FaultThresholds_t ft;
    ft.ovVoltage_V     = ThrOrDefault(savedCal.fault_ov_v,   0.0f,  FAULT_ACCEPT_V_MAX,        FAULT_OV_DEFAULT);
    ft.uvVoltage_V     = ThrOrDefault(savedCal.fault_uv_v,   0.0f,  FAULT_ACCEPT_V_MAX,        FAULT_UV_DEFAULT);
    ft.ocCurrent_A     = ThrOrDefault(savedCal.fault_oc_a,   0.0f,  FAULT_ACCEPT_I_MAX,        FAULT_OC_DEFAULT);
    ft.cellDiff_mV     = ThrOrDefault(savedCal.fault_cell_diff_mv, -0.001f, FAULT_ACCEPT_CELLDIFF_MAX, FAULT_CELL_DIFF_DEFAULT);
    ft.otTemp_C        = ThrOrDefault(savedCal.fault_ot_c,   FAULT_ACCEPT_TEMP_MIN, FAULT_ACCEPT_TEMP_MAX, FAULT_OT_DEFAULT);
    ft.utTemp_C        = ThrOrDefault(savedCal.fault_ut_c,   FAULT_ACCEPT_TEMP_MIN, FAULT_ACCEPT_TEMP_MAX, FAULT_UT_DEFAULT);
    ft.cellMax_V       = ThrOrDefault(savedCal.fault_cell_max_v,  0.5f, FAULT_ACCEPT_CELL_V_MAX, FAULT_CELL_MAX_DEFAULT);
    ft.cellMin_V       = ThrOrDefault(savedCal.fault_cell_min_v,  0.5f, FAULT_ACCEPT_CELL_V_MAX, FAULT_CELL_MIN_DEFAULT);
    ft.chargeOCLimit_A = ThrOrDefault(savedCal.fault_charge_oc_a, 0.1f, FAULT_ACCEPT_I_MAX,      FAULT_CHARGE_OC_DEFAULT);

    if (ValidateFaultThresholds(&ft)) {
      Fault_Init(&ft);
    } else {
      /* Ordering broken (e.g. stored uv >= ov) — take the whole default set
       * rather than run the detector on an inconsistent pair. */
      Fault_Init(NULL);
      ErrorLog_Add("Stored fault thresholds invalid - defaults loaded");
    }
  } else {
    Fault_Init(NULL);
  }
  Fault_WarnIfOvBelowCvTarget();

  /* --- NTC10K thermistor: ADC2 self-cal then start TIM1-triggered sampling --- */
  HAL_ADCEx_Calibration_Start(&hadc2, ADC_SINGLE_ENDED);
  HAL_ADC_Start_IT(&hadc2);        /* Arm ADC2 for external trigger         */
  HAL_TIM_Base_Start(&htim1);      /* TIM1 TRGO triggers ADC2 conversions   */
  HAL_TIM_Base_Start_IT(&htim6);   /* TIM6 still needed for other purposes  */

  /* ---- Initialise BMS disconnect timer ---- */
  last_bms_valid_tick = HAL_GetTick();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1) {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

    /* ---- Feed the watchdog every loop iteration ---- */
    HAL_IWDG_Refresh(&hiwdg);

    /* ---- Drain the charger RX staging buffer every iteration ----
     * Charger_LatchRawFrame() (ISR, in can_frame_handlers.c) only ever
     * copies raw bytes; ALL decode/filter/state-machine work for the
     * Solterra status broadcast happens here, at main-loop priority, so a
     * noisy or flooding charger can never add unbounded work at IRQ
     * priority. Unconditional + cheap (O(1) when nothing pending) — also
     * runs the 5 s comm-timeout watchdog every call regardless of new
     * data, so a charger going silent is detected promptly. */
    Charger_ProcessStatusFrame(&hChgRt, &g_chargerRxStage, HAL_GetTick());

    /* ---- Fast CAN bus-error recovery (EMI burst protection) -----------
     * FDCAN1_HealthCheck() is also called in the 1Hz block, but charger
     * high-current switching can cause a burst of hundreds of CAN errors
     * in <100ms — well within one IWDG period (~4s). Calling it here on
     * a 500ms throttle ensures the peripheral is reset within 500ms of
     * an EMI burst, long before the IWDG fires. */
    {
      static uint32_t last_can_health_ms = 0;
      uint32_t now_ms = HAL_GetTick();
      if ((now_ms - last_can_health_ms) >= 500U) {
        last_can_health_ms = now_ms;
        if (FDCAN1_HealthCheck()) {
          Process_CAN_Tx();
        }
      }
    }

    /* ---- Non-blocking 100 ms tick processing ---- */
    if (tim5_flag) {
      tim5_flag = 0;
      ms_100_counter++;

      /* -- DNA allocation if node ID not yet assigned -- */
      if (canardGetLocalNodeID(&canard) == CANARD_BROADCAST_NODE_ID) {
        uint32_t now = ms_100_counter * 100;
        if (now > DNA.send_next_node_id_allocation_request_at_ms) {
          request_DNA();
        }
      }

      /* -- Send BatteryInfo every 100 ms (rate limited by telem_rate) -- */
      send_BatteryInfo();

      /* -- Send NodeStatus heartbeat every 1 s (10 × 100 ms) -- */
      if (ms_100_counter >= 10) {
        process1HzTasks(_1secCounter * 1000000ULL);
        _1secCounter++;
        ms_100_counter = 0;

        /* -- CAN bus health check / bus-off auto-recovery --
         * Peripheral-only recovery: never resets the MCU, never touches
         * canard state. If it just recovered, flush anything canard
         * queued up while the bus was down rather than waiting on a
         * TX-FIFO-empty interrupt that a dead bus won't generate on its
         * own.
         *
         * Now also recovers from SUSTAINED Error_Passive, not just formal
         * Bus_Off (see fdcan.c FDCAN1_HealthCheck comment) — that gap was
         * the most likely explanation for "CAN hangs, only a manual BMS
         * reset fixes it": Error_Passive can persist indefinitely without
         * ever latching the hardware BOFF bit that the old code waited
         * for. Every recovery (either cause) is logged here so it's
         * visible in the Error Logs tab without needing a bus analyzer
         * attached. */
        if (FDCAN1_HealthCheck()) {
          Process_CAN_Tx();
          /* Each entry is already RTC-timestamped by ErrorLog_Add, so
           * recovery frequency is visible from the log itself without
           * needing an embedded counter here. */
          ErrorLog_Add("CAN auto-recovered (BusOff or sustained ErrorPassive)");
        }

        /* -- Solterra charger command, 1 Hz (ID 0x1806E5F4) --
         * Profile (g_charger_config) is set via CLI_CMD_SET_CHARGER_CONFIG
         * and persisted via CLI_CMD_SAVE_CAL.
         *
         * Charging hysteresis for “idle/stop-chatter near full”:
         * - If Battery SOC >= 100%: cap current down to 2A gradually,
         *   keep charging inhibited for 5 seconds, then send STOP.
         * - Wait until Battery SOC <= 90% to allow charging again.
         */
        {
          float chg_v = 0.0f, chg_i = 0.0f;
          uint8_t chg_enabled = 0U;
          /* Reset CC/CV state when charger is not present */
          if (hChgRt.state == CHARGER_STATE_DISCONNECTED ||
              hChgRt.state == CHARGER_STATE_TIMEOUT) {
            hChgRt.cv_phase    = 0U;
            hChgRt.charge_done = 0U;
          }
          /* Charging hysteresis: CC → CV → Taper-termination.
           *
           * SOC >= 100% no longer forces a hard STOP — the CV phase
           * continues naturally until the charger's actual current drops
           * below cvCutoffCurrent_A (set via GUI as "Taper Current").
           * This ensures the battery reaches full capacity before
           * termination instead of stopping prematurely at CC->100% pivot.
           *
           * Termination flow:
           *   1. Charger_ComputeCommand() runs CC/CV state machine:
           *      - CC: sends chargeCurrentFull_A until pack voltage target
           *      - CV: charger self-limits voltage, current tapers
           *      - When actual_I <= cvCutoffCurrent_A: sets charge_done=1
           *        and returns enabled=0 / i=0
           *   2. Hysteresis: once charge_done, inhibit restart until
           *      SOC drops below 90% (prevents oscillation at 99-100%).
           *   3. On charger disconnect/timeout: charge_done reset by
           *      the block above (cv_phase=0, charge_done=0).
           */
          {
            float soc_now = SOC_GetPercent(&hSoc);

            float chg_temp1 = Charger_GetGateTemperature();

            /* Let the CC/CV state machine compute the command. This is what
             * advances the sticky thermal latch (rt->tempStartBlocked). */
            Charger_ComputeCommand(&hChgRt, &g_charger_config, soc_now,
                                   Fault_GetBitmask(), chg_temp1,
                                   &chg_v, &chg_i, &chg_enabled);

            /* Log every gate transition, with the temperature that caused
             * it. Evaluated AFTER ComputeCommand so it reports the latch as
             * it is now, not as it was a second ago. Without this a
             * thermally-blocked session is invisible: the BMS just commands
             * STOP at 1 Hz and the charger sits at output-OFF with no
             * indication of why. */
            {
              static uint8_t prev_temp_blocked = 0xFFU; /* 0xFF = first pass */
              uint8_t now_blocked = hChgRt.tempStartBlocked;
              if (now_blocked != prev_temp_blocked) {
                if (prev_temp_blocked != 0xFFU) {
                  /* Built with strcpy/strcat + AppendIntStr rather than
                   * snprintf on purpose — this project never pulls in
                   * <stdio.h> (see the boot reset-flags message), and
                   * newlib's printf family costs several KB of flash plus
                   * -u _printf_float for the %f forms. */
                  char tmsg[ERROR_LOG_MSG_MAX_LEN];
                  strcpy(tmsg, "Charger temp gate ");
                  strcat(tmsg, now_blocked ? "BLOCK" : "RESUME");
                  if (chg_temp1 >= CHARGER_TEMP_SENSOR_FAIL_C) {
                    strcat(tmsg, ": NTC invalid/missing");
                  } else {
                    strcat(tmsg, " at ");
                    AppendIntStr(tmsg, sizeof(tmsg), (int32_t)chg_temp1);
                    strcat(tmsg, " C");
                  }
                  ErrorLog_Add(tmsg);
                }
                prev_temp_blocked = now_blocked;
              }
            }

            /* Hysteresis: once charge_done (CV taper current reached),
             * keep charging STOPped until SOC drops well below full
             * to prevent on/off oscillation at 99-100% SOC. */
            if (hChgRt.charge_done) {
              /* Force STOP while in hysteresis window */
              chg_enabled = 0U;
              chg_i = 0.0f;

              /* Allow restart when SOC drops below 98% */
              if (soc_now <= 98.0f) {
                hChgRt.charge_done = 0U;
                hChgRt.cv_phase    = 0U; /* restart fresh in CC */
              }
            }
          }


          uint16_t v_raw = (uint16_t)(chg_v * 10.0f + 0.5f);
          uint16_t i_raw = (uint16_t)(chg_i * 10.0f + 0.5f);
          uint8_t chgFrame[8] = {
              (uint8_t)(v_raw >> 8), (uint8_t)(v_raw & 0xFF),
              (uint8_t)(i_raw >> 8), (uint8_t)(i_raw & 0xFF),
              /* Control byte polarity — RESOLVED (see charger_config.h):
               * confirmed against real hardware that 0x00 = enabled/START,
               * 0x01 = disabled/STOP is correct; CHARGER_CTRL_*_VALUE now
               * reflects that. */
              (uint8_t)(chg_enabled ? CHARGER_CTRL_ENABLED_VALUE
                                     : CHARGER_CTRL_DISABLED_VALUE),
              0x00U, 0x00U, 0x00U};
          Transmit_Charger_Msg(CHARGER_TX_ID_CMD, chgFrame, sizeof(chgFrame));
        }
      }
    }

    /* -- Drain the CAN RX queue (deferred from ISR) -- */
    while (can_rx_tail != can_rx_head) {
      CAN_RxItem_t item;
      memcpy(&item, (const void *)&can_rx_queue[can_rx_tail], sizeof(item));
      can_rx_tail = (can_rx_tail + 1) % CAN_RX_QUEUE_SIZE;
      canardHandleRxFrame(&canard, &item.frame, item.timestamp_usec);
    }

    /* -- Drain the libcanard TX queue -- */
    Process_CAN_Tx();

    /* ---- 1. Process current sensor calibration flags ---- */
    CurrentSensor_ProcessFlags();

    /* ---- 1b. Consume NTC averaged sample if ready ---- */
    if (g_adc_ready) {
      float t1_raw = NTC_ADC_To_Celsius(g_adc_raw);
      /* EMA smoothing for temp1 */
      static float t1_ema = 0.0f;
      static uint8_t t1_init = 0;
      const float alpha_t1 = 0.08f; /* smaller => smoother */

      if (!t1_init) {
        t1_ema = t1_raw;
        t1_init = 1;
      } else {
        t1_ema = t1_ema + alpha_t1 * (t1_raw - t1_ema);
      }

      temp_celsius = t1_ema;
      g_adc_ready = 0u;
      temp1Ready = 1;
    }

    /* ---- 1c. Consume NTC2 averaged sample if ready ---- */
    if (g_adc2_ready) {
      float t2_raw = NTC2_ADC_To_Celsius(g_adc2_raw);
      /* EMA smoothing for temp2 */
      static float t2_ema = 0.0f;
      static uint8_t t2_init = 0;
      const float alpha_t2 = 0.08f;

      if (!t2_init) {
        t2_ema = t2_raw;
        t2_init = 1;
      } else {
        t2_ema = t2_ema + alpha_t2 * (t2_raw - t2_ema);
      }

      temp2_celsius = t2_ema;
      g_adc2_ready = 0u;
      temp2Ready = 1;
    }

    /* ---- 2. Drive Daly BMS state machine ---- */
    DalyBMS_Process(&hDaly);

    /* ---- 3. Get current reading (mA → A) ----
     * NOTE: current_sensor.c already runs its own full filtering pipeline
     * (RC filter -> ADC oversampling -> spike detector -> 2-state Kalman ->
     * temperature comp -> offset comp -> deadband). Do NOT add a second
     * main-loop EMA/filter on top of this value — a prior version did
     * (~1s extra time-constant), which double-filtered the reading, lagged
     * real current changes, and risked delaying OC fault detection /
     * destabilizing charger CC-CV transitions. Use the sensor's output
     * directly, as validated in the known-working build. */
    float current_a = CurrentSensor_GetCurrent_mA() / 1000.0f;


    /* ---- 3b. Update fault detector with balancer-safe voltage snapshot ----
     *
     * TWO PROBLEMS FIXED HERE:
     *
     * PROBLEM 1 — False RED LED at boot (thermistor fault):
     *   temp_celsius starts at -999.0f before the ADC fires its first
     *   conversion.  Passing -999.0f to Fault_Update() immediately sets
     *   cond_therm1 = (tempC <= -900.0f) = true, and after 50 debounce
     *   ticks (~5 s) the thermistor-not-connected fault latches and the
     *   RED LED turns on even though no thermistor is missing.
     *   FIX: Use 0.0f as the "ADC not ready yet" sentinel.  0.0f is
     *   outside every fault window (OT > 55, UT < -10, therm <= -900)
     *   so no spurious flag is latched.
     *
     * PROBLEM 2 — Voltage stuck on GUI:
     *   hDaly.data.packVoltage is the raw live value which during a Daly
     *   active-balancer switching event reports wrong voltages.  We use a
     *   snapshot (g_snap_packV) that is only refreshed when the balancer
     *   is idle, freezing the last known-good reading during glitches.
     *   The same snapshot is sent to the GUI so it never sees glitch data.
     * -------------------------------------------------------------------- */

    /* Snapshot variables (static = zero-initialized, persistent across calls) */
    static float    g_snap_packV     = 0.0f;
    static float    g_snap_cellDiff  = 0.0f;
    static float    g_snap_minCellmV = 0.0f;
    static uint8_t  g_snap_minIdx    = 0U;
    static float    g_snap_maxCellmV = 0.0f;
    static uint8_t  g_snap_maxIdx    = 0U;

    /* ── BMS data snapshot + fault evaluation ──────────────────────────────
     *
     * Snapshot update (fresh data only) is decoupled from fault evaluation
     * (runs every loop on last-known-good snapshots).
     * A staleness guard (BMS_SNAP_STALE_MS) stops fault evaluation if no
     * Daly data has arrived for > 3 s, preventing stale snapshots from
     * holding the debounce timers in a meaningless state.
     * ─────────────────────────────────────────────────────────────────── */
#define BMS_SNAP_STALE_MS  3000U   /* Stop fault eval if BMS silent > 3 s */

    if (DalyBMS_IsDataReady(&hDaly)) {
      /* Fresh frame: update all snapshots */
      g_snap_packV     = hDaly.data.packVoltage;
      g_snap_cellDiff  = hDaly.data.cellDiff;
      g_snap_minCellmV = hDaly.data.minCellmV;
      g_snap_minIdx    = hDaly.data.minCellVNum;
      g_snap_maxCellmV = hDaly.data.maxCellmV;
      g_snap_maxIdx    = hDaly.data.maxCellVNum;

      last_bms_valid_tick = HAL_GetTick();
      SOC_InitFromOCV(&hSoc, g_snap_packV, current_a);

      DalyBMS_ClearDataReady(&hDaly);  /* Consume */
    }

    /* Fault evaluation runs every loop on last-known-good snapshots.
     * Only skipped when: no valid voltage yet, OR BMS data is stale.
     * This means the fault CLEAR path is evaluated even if Daly is
     * temporarily unresponsive — so imbalance recovery is not blocked
     * by a huart5 error that previously occurred after FET cutoff calls. */
    float safe_temp1 = temp1Ready ? temp_celsius  : 0.0f;
    float safe_temp2 = temp2Ready ? temp2_celsius : 0.0f;
    bool bms_data_fresh = (HAL_GetTick() - last_bms_valid_tick) < BMS_SNAP_STALE_MS;

    if (g_snap_packV > 1.0f && bms_data_fresh) {
      Fault_Update(g_snap_packV, current_a, g_snap_cellDiff,
                   safe_temp1, safe_temp2, g_snap_minCellmV, g_snap_maxCellmV);
    }

    /* -- Display telemetry (BMS_VIT / BMS_OvrView / Cell_DeltaV), ~200 ms --
     * These frames were never being built or sent anywhere in this
     * codebase — Transmit_Display_Msg() existed as a TX helper but nothing
     * called it with real data, which is why BUSMASTER never showed them.
     * Placed here (not the 100 ms tim5_flag block) because it needs
     * g_snap_packV / safe_temp1 / safe_temp2 / g_snap_min/maxCellmV, which
     * only exist in this part of the loop. */
    {
      static uint32_t lastDisplayTxMs = 0;
      if ((HAL_GetTick() - lastDisplayTxMs) >= 200U) {
        lastDisplayTxMs = HAL_GetTick();

        /* BMS_VIT (0x1FF820): pack_voltage u16LE x0.001V, pack_current
         * s16LE x0.01A, temp1/temp2 s16LE x0.01 degC each. */
        uint16_t v_raw = (uint16_t)(g_snap_packV * 1000.0f + 0.5f);
        int16_t i_raw = (current_a >= 0.0f) ? (int16_t)(current_a * 100.0f + 0.5f)
                                             : (int16_t)(current_a * 100.0f - 0.5f);
        int16_t t1_raw = (safe_temp1 >= 0.0f) ? (int16_t)(safe_temp1 * 100.0f + 0.5f)
                                               : (int16_t)(safe_temp1 * 100.0f - 0.5f);
        int16_t t2_raw = (safe_temp2 >= 0.0f) ? (int16_t)(safe_temp2 * 100.0f + 0.5f)
                                               : (int16_t)(safe_temp2 * 100.0f - 0.5f);
        uint8_t vitFrame[8] = {
            (uint8_t)(v_raw & 0xFFU), (uint8_t)(v_raw >> 8),
            (uint8_t)((uint16_t)i_raw & 0xFFU), (uint8_t)((uint16_t)i_raw >> 8),
            (uint8_t)((uint16_t)t1_raw & 0xFFU), (uint8_t)((uint16_t)t1_raw >> 8),
            (uint8_t)((uint16_t)t2_raw & 0xFFU), (uint8_t)((uint16_t)t2_raw >> 8)};
        Transmit_Display_Msg(DISPLAY_ID_VIT, vitFrame, sizeof(vitFrame));

        /* BMS_OvrView (0x1FF810): soc u8%, soh u8%, cycle_count u16LE,
         * remaining_cap u16LE x0.001Ah, charging_status u8, charging_cmd u8.
         *
         * Reads hChgRt.cmd_V_setpoint/cmd_I_setpoint (last value the 1 Hz
         * TX block actually put on the wire) rather than calling
         * Charger_ComputeCommand() again here. That function now advances
         * a soft-start slew-rate ramp every time it's called (see
         * CHARGER_CMD_I_SLEW_A_PER_S) — calling it a second time per
         * iteration at this block's ~200 ms cadence would advance that
         * ramp ~6x faster than the intended "N amps per second", silently
         * defeating the inrush mitigation it exists for. Display-only
         * consumers must read the state, never recompute it. */
        float soc_now = SOC_GetPercent(&hSoc);
        BMS_LifeData_t life = SOH_GetLifeData(&hSOH);
        uint16_t faultBits = Fault_GetBitmask();
        float dispI = hChgRt.cmd_I_setpoint;

        /* charging_cmd (byte 7) and charging_status (byte 6) must not diverge.
         * Add hysteresis + persistence so they don't bounce around the
         * near-full / near-zero boundary.
         *
         * - Enter CHARGING only when SOC is not full and the commanded
         *   current indicates charging.
         * - Exit CHARGING only when commanded current is clearly low for
         *   multiple 1Hz ticks (persistence), using a small hysteresis band.
         *
         * This is display-only (does not change charger control / fault logic). */
        static uint8_t chg_disp_state = 0U;        /* 0=idle,1=charging */
        static uint8_t chg_disp_persist_cnt = 0U; /* consecutive samples */

        const float I_enter = 2.0f; /* >= ~2A => charging */
        const float I_exit  = 1.0f; /* <= 1A  => idle (hysteresis) */

        /* PERSISTENCE TIMEOUT FIX: If current oscillates around the boundary
         * (e.g. 1.5A-1.8A on a floating signal), the persistence counter
         * churns but never reaches 3 consecutive samples in either direction,
         * leaving the display state stuck. A total elapsed timeout
         * (chg_disp_total_ticks) ensures the display state resets to idle
         * after 100 ticks (~10s) of indecision. */
        static uint16_t chg_disp_total_ticks = 0U; /* total timeout counter */

        if (faultBits != 0U) {
          /* fault overrides display state */
          chg_disp_state = 0U;
          chg_disp_persist_cnt = 0U;
          chg_disp_total_ticks = 0U;
        } else if (soc_now >= 100.0f) {
          /* full overrides display state */
          chg_disp_state = 0U;
          chg_disp_persist_cnt = 0U;
          chg_disp_total_ticks = 0U;
        } else {
          /* SOC < 100: run hysteresis state machine */
          if (chg_disp_state == 0U) {
            /* idle -> charging requires sustained indication */
            if (dispI >= I_enter) {
              if (++chg_disp_persist_cnt >= 3U) { /* 3 consecutive samples */
                chg_disp_state = 1U;
                chg_disp_persist_cnt = 0U;
                chg_disp_total_ticks = 0U;
              }
            } else {
              chg_disp_persist_cnt = 0U;
            }
          } else {
            /* charging -> idle requires commanded current to go low */
            if (dispI <= I_exit) {
              if (++chg_disp_persist_cnt >= 3U) {
                chg_disp_state = 0U;
                chg_disp_persist_cnt = 0U;
                chg_disp_total_ticks = 0U;
              }
            } else {
              chg_disp_persist_cnt = 0U;
            }
          }
          /* Total-indecision timeout: force to idle after ~10s of oscillation */
          if (chg_disp_state != 0U) {
            if (++chg_disp_total_ticks >= 100U) {
              chg_disp_state = 0U;
              chg_disp_persist_cnt = 0U;
              chg_disp_total_ticks = 0U;
            }
          }
        }

        uint8_t charging_status;
        if (faultBits != 0U) {
          charging_status = 2U; /* fault */
        } else if (soc_now >= 100.0f) {
          charging_status = 3U; /* full */
        } else {
          /* normal display state */
          charging_status = (chg_disp_state == 1U) ? 1U : 0U;
          /* Additional gate: in ideal mode measured pack current hovers near 0,
           * so suppress "charging_status" too. */
          if (charging_status == 1U && fabsf(current_a) <= 2.0f) {
            charging_status = 0U;
          }
        }

        /* display payload byte 7 (charging_cmd) must match charging_status.
         * Apply the same “ideal current near zero” gate to both so they
         * never diverge. */
        uint8_t dispEnabled = 0U;
        if (charging_status == 1U) {
          if (fabsf(current_a) <= 2.0f) {
            dispEnabled = 0U;
            charging_status = 0U;
          } else {
            dispEnabled = 1U;
          }
        }

        float soc_clamped = (soc_now > 100.0f) ? 100.0f : ((soc_now < 0.0f) ? 0.0f : soc_now);
        float soh_clamped = (life.soh_percent > 100.0f) ? 100.0f
                             : ((life.soh_percent < 0.0f) ? 0.0f : life.soh_percent);
        uint16_t remcap_raw = (uint16_t)(SOC_GetRemainingAh(&hSoc) * 1000.0f + 0.5f);

        uint8_t ovrFrame[8] = {
            (uint8_t)soc_clamped,
            (uint8_t)soh_clamped,
            (uint8_t)(life.cycles & 0xFFU), (uint8_t)(life.cycles >> 8),
            (uint8_t)(remcap_raw & 0xFFU), (uint8_t)(remcap_raw >> 8),
            charging_status,
            dispEnabled};
        Transmit_Display_Msg(DISPLAY_ID_OVRVIEW, ovrFrame, sizeof(ovrFrame));

        /* Cell_DeltaV (0x1FF710): delta_v/min_cell_v/max_cell_v, all u16LE
         * x0.001V. g_snap_*CellmV are already in millivolts, i.e. already
         * the raw integer count this scale expects (1 LSB = 1 mV). */
        uint16_t delta_raw = (uint16_t)(g_snap_cellDiff + 0.5f);
        uint16_t min_raw = (uint16_t)(g_snap_minCellmV + 0.5f);
        uint16_t max_raw = (uint16_t)(g_snap_maxCellmV + 0.5f);
        uint8_t cellFrame[6] = {
            (uint8_t)(delta_raw & 0xFFU), (uint8_t)(delta_raw >> 8),
            (uint8_t)(min_raw & 0xFFU), (uint8_t)(min_raw >> 8),
            (uint8_t)(max_raw & 0xFFU), (uint8_t)(max_raw >> 8)};
        Transmit_Display_Msg(DISPLAY_ID_CELL_DELTAV, cellFrame, sizeof(cellFrame));
      }
    }

    /* FET cutoff removed — application does not use software FET control.
     * Fault flags are still evaluated and latched for LED / GUI / telemetry;
     * hardware protection is handled externally by the Daly BMS module. */

    /* ---- 3c. Update LED Error State ---- */
    const FaultFlags_t *flags = Fault_GetFlags();
    LedError_t led_err = LED_ERR_NONE;

    /* Priority: thermistor faults first (hardware), then cell-level, then pack */
    if (flags->thermistorNotConnectedError || flags->thermistor2NotConnectedError) {
      led_err = LED_ERR_THERMISTOR_NOT_CONNECTED;
    } else if (flags->cellOverVoltageError || flags->overVoltageError) {
      led_err = LED_ERR_OVERVOLTAGE;
    } else if (flags->cellUnderVoltageError || flags->underVoltageError) {
      led_err = LED_ERR_UNDERVOLTAGE;
    } else if (flags->chargeOverCurrentError || flags->overCurrentError) {
      led_err = LED_ERR_OVERCURRENT;
    } else if (flags->cellDiffError) {
      led_err = LED_ERR_SEVERE_CELL_DISBALANCE;
    } else if (flags->overTemperatureError || flags->overTemperature2Error) {
      led_err = LED_ERR_OVERTEMPERATURE;
    } else if (flags->underTemperatureError || flags->underTemperature2Error) {
      led_err = LED_ERR_UNDERTEMPERATURE;
    }

    LedStatus_SetError(led_err);

    /* "Generic fault" -> toggling RED if led_err is one of the above */
    LedStatus_SetGenericFault(led_err != LED_ERR_NONE);

    /* False-reset debounce: count fault episodes >500ms when BMS connected */
    if (led_err != LED_ERR_NONE) {
      if (++consecutive_fault_ticks >= 5) {  /* 500 ms @ 100 ms ticks */
        if (max_false_reset_count < UINT32_MAX) {
          max_false_reset_count++;
        }
        consecutive_fault_ticks = 0;
      }
    } else {
      consecutive_fault_ticks = 0;
    }

    /* Check for static FAULT (hardware disconnects) */
    static bool hardware_disconnect = false;
    if ((HAL_GetTick() - last_bms_valid_tick) > 10000) {  /* 10s tolerance */
      hardware_disconnect = true; /* Daly BMS disconnected */
    } else {
      hardware_disconnect = false; /* BMS comms restored — exit FAULT state */
    }

    // float cs_mv = CurrentSensor_GetVoltage_mV();
    // if (cs_mv < 100.0f || cs_mv > 3200.0f) {
    //   hardware_disconnect =
    //       true; /* Current sensor disconnected out of bounds */
    // }

    if (hardware_disconnect) {
      LedStatus_SetSystemState(SYS_STATE_FAULT);
    } else {
      /* Determine IDLE / CHARGE / DRIVE with ±0.3A hysteresis
       * + 3-tick persistence counter to suppress idle noise spikes
       * + 50-tick (~5s) dead-band timeout to prevent permanent latching.
       *
       * STUCK-STATE FIX: Previously, if current sat in the dead-band
       * (1.2A-1.5A), the state machine maintained whatever state it was
       * in indefinitely — no timeout, no exit.  Now a cumulative counter
       * (state_deadband_ticks) counts consecutive dead-band ticks and
       * forces the state to IDLE after 50 ticks (~5 s).  This guarantees
       * the BMS can never be permanently stuck in CHARGE or DRIVE on a
       * floating current reading. */
      /* lastDriveState, spike_persist_cnt, state_deadband_ticks now at file scope
       * (declared in the PV section above) so CLI_CMD_RESET_STATE can access them. */
const float hyst = 0.3f; /* Hysteresis band (A) */
const float idle_thresh = 1.5f; /* Updated idle threshold for sleep wake (within 1A idle -> 1.5A threshold) */


      if (lastDriveState == SYS_STATE_IDLE) {
        /* Currently IDLE — require 3 consecutive ticks above threshold
         * before leaving IDLE (suppresses single-tick noise spikes) */
        state_deadband_ticks = 0; /* Reset on any decision */
        if (current_a > idle_thresh) {
          if (++spike_persist_cnt >= 3) {
            lastDriveState = SYS_STATE_CHARGE;
            spike_persist_cnt = 0;
          }
        } else if (current_a < -idle_thresh) {
          if (++spike_persist_cnt >= 3) {
            lastDriveState = SYS_STATE_DRIVE;
            spike_persist_cnt = 0;
          }
        } else {
          spike_persist_cnt = 0;
        }
      } else {
        /* Currently CHARGE or DRIVE — return to IDLE only below (threshold −
         * hyst) */
        if (current_a > idle_thresh) {
          state_deadband_ticks = 0;
          lastDriveState = SYS_STATE_CHARGE;
        } else if (current_a < -idle_thresh) {
          state_deadband_ticks = 0;
          lastDriveState = SYS_STATE_DRIVE;
        } else if (fabsf(current_a) < (idle_thresh - hyst)) {
          state_deadband_ticks = 0;
          lastDriveState = SYS_STATE_IDLE;
        } else {
          /* Dead-band: between 1.2A-1.5A (CHARGE side) or
           * -1.2A to -1.5A (DRIVE side).  Count consecutive ticks;
           * force IDLE after 50 ticks (~5 s) to prevent permanent latching. */
          if (++state_deadband_ticks >= 50U) {
            state_deadband_ticks = 0;
            lastDriveState = SYS_STATE_IDLE;
          }
        }
        spike_persist_cnt = 0;
      }


      LedStatus_SetSystemState(lastDriveState);
    }

    /* Also update SOC for LED */
    LedStatus_SetSoc((uint8_t)SOC_GetPercent(&hSoc));

    /* ---- 4. (Merged into step 3b above) ---- */
    /* last_bms_valid_tick and SOC_InitFromOCV are now called in step 3b
     * immediately before DalyBMS_ClearDataReady() so they are never missed. */

    /* ---- 5. SOC coulomb counting update (with voltage correction) ---- */
    SOC_Update(&hSoc, current_a, g_snap_packV, HAL_GetTick());

    /* ---- 6. Hard calibration anchors ---- */
    if (hDaly.data.packVoltage >= g_soc_config.pack_full_voltage &&
        fabsf(current_a) < (g_soc_config.taper_current)) {
      SOC_SetFull(&hSoc);
      LC_SetFull(&hLC); /* Mirror: LC snaps to 100% on confirmed full */
    }
    /* Robust UV empty: current-aware debounce with KF-smoothed voltage.
     * Low current: 30 ticks (~3s) � high current: 100 ticks (~10s).
     * Uses g_snap_packV (EKF-smoothed) to ignore balancer glitches. */
    /* ROBUSTNESS FIX: was uint8_t — overflows at 255 when thresh=100, wraps
     * to 0 and never triggers. Changed to uint16_t (max 65535, safe). */
    static uint16_t uv_debounce_cnt = 0;
    float v_check = (g_snap_packV > 1.0f) ? g_snap_packV : hDaly.data.packVoltage;
    if (v_check <= g_soc_config.pack_uv_limit && v_check > 1.0f) {
      uint16_t thresh = (fabsf(current_a) < 1.0f) ? 30U : 100U;
      if (++uv_debounce_cnt >= thresh) {
        SOC_SetEmpty(&hSoc);
        LC_SetZero(&hLC); /* Mirror: LC drops to 1% on confirmed empty */
        uv_debounce_cnt = 0;
      }
    } else {
      uv_debounce_cnt = 0;
    }


    /* ---- 6b. Auto-save state to flash if SOC percentage changed ---- */
    int current_soc_int = (int)SOC_GetPercent(&hSoc);
    /* CRITICAL FIX BUG4: Prevent auto-save SOC <1% */
    if (current_soc_int >= 1 && current_soc_int != last_saved_soc_percent && current_soc_int <= 100 &&
        (HAL_GetTick() - last_auto_save_tick) >= AUTO_SAVE_MIN_INTERVAL_MS) {
      last_saved_soc_percent = current_soc_int;
      last_auto_save_tick = HAL_GetTick();
      SaveSystemStateToFlash();
    }

    /* ---- 7. Periodic CLI frame send (SOC data) ---- */
    uint32_t now = HAL_GetTick();
    if ((now - lastSendTick) >= CLI_SEND_INTERVAL_MS) {
      lastSendTick = now;

      /* Pack 4 floats: SOC%, remaining_Ah, current_A, packVoltage
       * Use g_snap_packV (balancer-safe) not the raw live field which
       * can hold glitch values during active balancer switching. */
      float txPayload[4];
      txPayload[0] = (int)SOC_GetPercent(&hSoc);
      txPayload[1] = SOC_GetRemainingAh(&hSoc);
      txPayload[2] = current_a;
      txPayload[3] = (g_snap_packV > 1.0f) ? g_snap_packV
                                            : hDaly.data.packVoltage;

      CLI_Frame_Send(CLI_CMD_SOC_DATA, (const uint8_t *)txPayload,
                     sizeof(txPayload));

      /* Temperature frame (NTC1) */
      CLI_Frame_Send(CLI_CMD_TEMP_DATA, (const uint8_t *)&temp_celsius,
                     sizeof(temp_celsius));

      /* Temperature frame (NTC2) */
      CLI_Frame_Send(CLI_CMD_TEMP2_DATA, (const uint8_t *)&temp2_celsius,
                     sizeof(temp2_celsius));

      /* Cell extrema: use snapshot — valid once g_snap_packV > 1 V.
       * Do NOT gate on DalyBMS_IsDataReady() here — it was already
       * cleared above by DalyBMS_ClearDataReady(), so this block would
       * never execute and the GUI would never receive cell data. */
      if (g_snap_packV > 1.0f) {
        uint8_t cell_extrema[10];
        cell_extrema[0] = g_snap_minIdx;
        memcpy(&cell_extrema[1], &g_snap_minCellmV, sizeof(float));
        cell_extrema[5] = g_snap_maxIdx;
        memcpy(&cell_extrema[6], &g_snap_maxCellmV, sizeof(float));
        CLI_Frame_Send(CLI_CMD_CELL_EXTREMA, cell_extrema, 10);

        /* All cell voltages: nCells (u8) + n×float32 LE (Volts) */
        uint8_t ncells = hDaly.data.numberOfCells;
        if (ncells > 0 && ncells <= DALY_EKF_MAX_CELLS) {
          uint8_t cell_buf[1 + DALY_EKF_MAX_CELLS * sizeof(float)];
          cell_buf[0] = ncells;
          for (uint8_t c = 0; c < ncells; c++) {
            float v = hDaly.data.cellVmV[c];
            memcpy(&cell_buf[1 + c * sizeof(float)], &v, sizeof(float));
          }
          CLI_Frame_Send(CLI_CMD_CELL_VOLT_ALL, cell_buf,
                         1 + ncells * sizeof(float));
        }
      }

  /* Fault status: 2-byte bitmask + 9-float thresholds (38 bytes total) */
      uint8_t faultBuf[2u + sizeof(FaultThresholds_t)];
      uint16_t faultMask = Fault_GetBitmask();
      faultBuf[0] = (uint8_t)(faultMask & 0xFFu);
      faultBuf[1] = (uint8_t)(faultMask >> 8u);
      memcpy(&faultBuf[2], Fault_GetThresholds(), sizeof(FaultThresholds_t));
      CLI_Frame_Send(CLI_CMD_FAULT_STATUS, faultBuf, sizeof(faultBuf));

      /* NEW LC data every ~100ms — reuse safe_temp1 from fault evaluation above */
      /* SOH tick */
      SOH_Tick100ms(&hSOH, current_a, g_snap_packV, SOC_GetPercent(&hSoc), safe_temp1, Fault_GetBitmask());

      /* LC update: SOC-driven, phase-aware (CC/CV/CD/IDLE).
       *
       * Pass hSoc.P_soc (Kalman covariance, Ah²) so LC can degrade its
       * confidence display when SOC estimate is uncertain — matching the
       * iPhone asterisk / dimmed % behaviour during low-confidence periods.
       *
       * FIX: full-charge anchor now uses g_snap_packV (filtered snapshot)
       * instead of the raw hDaly.data.packVoltage, which can read high
       * during an active balancer switching event and incorrectly trigger
       * LC_SetFull() mid-charge. */
      const LC_Data_t *lc_ptr = LC_Update(&hLC,
                                           SOC_GetPercent(&hSoc),
                                           hSoc.P_soc,           /* Kalman covariance */
                                           g_snap_packV,
                                           current_a,
                                           safe_temp1,
                                           g_snap_cellDiff);
      LC_Data_t lc = *lc_ptr;

      /* Hard full-charge anchor: use filtered snapshot voltage, not raw Daly.
       * Old code used hDaly.data.packVoltage which can spike during balancing,
       * causing LC_SetFull() to fire prematurely at partial SOC. */
      if (g_snap_packV >= g_soc_config.pack_full_voltage &&
          fabsf(current_a) < g_soc_config.taper_current) {
          LC_SetFull(&hLC);
      }
CLI_Frame_Send(CLI_CMD_LC_DATA, (const uint8_t*)&lc, sizeof(lc));

      /* SOH BMS_LIFE frame */
      BMS_LifeData_t soh_life = SOH_GetLifeData(&hSOH);
      CLI_Frame_Send(CLI_CMD_BMS_LIFE, (const uint8_t*)&soh_life, sizeof(soh_life));

      /* Charger status frame (0x25): 20 bytes
       *  [0] state  [1] comm_ok  [2] flags
       *  [3] bits: bit0=cv_phase, bit1=charge_done, bit2=temp gate blocked
       *  [4:8)  actual_V f32  [8:12) actual_I f32
       *  [12:16) cmd_V f32    [16:20) cmd_I f32
       * bit2 is new — it is the only way to tell "charger sitting at
       * output-OFF because the thermal gate refused to start" apart from
       * every other reason it might be off. Bit names live in
       * charger_config.h so the Python GUI decodes the same bits. */
      {
        uint8_t chgStatusBuf[20];
        chgStatusBuf[0] = (uint8_t)hChgRt.state;
        chgStatusBuf[1] = hChgRt.comm_ok;
        chgStatusBuf[2] = hChgRt.last_valid_flags;
        chgStatusBuf[3] = 0U;
        if (hChgRt.cv_phase) {
          chgStatusBuf[3] |= CHARGER_STATUS_BIT_CV_PHASE;
        }
        if (hChgRt.charge_done) {
          chgStatusBuf[3] |= CHARGER_STATUS_BIT_CHARGE_DONE;
        }
        if (hChgRt.tempStartBlocked) {
          chgStatusBuf[3] |= CHARGER_STATUS_BIT_TEMP_BLOCKED;
        }
        memcpy(&chgStatusBuf[4],  &hChgRt.actual_V,       sizeof(float));
        memcpy(&chgStatusBuf[8],  &hChgRt.actual_I,       sizeof(float));
        memcpy(&chgStatusBuf[12], &hChgRt.cmd_V_setpoint, sizeof(float));
        memcpy(&chgStatusBuf[16], &hChgRt.cmd_I_setpoint, sizeof(float));
        CLI_Frame_Send(CLI_CMD_CHARGER_STATUS_DATA, chgStatusBuf,
                       sizeof(chgStatusBuf));
      }

      /* CAN bus health frame (0x26) -- cumulative recovery count + live
       * Error_Passive dwell time, see cli_frame.h byte map and the
       * FDCAN1_HealthCheck() fix in fdcan.c for why this exists. */
      {
        uint8_t canHealthBuf[8];
        uint32_t recoveryCount = FDCAN1_GetBusOffRecoveryCount();
        uint32_t errPassiveSec = FDCAN1_GetErrorPassiveSeconds();
        memcpy(&canHealthBuf[0], &recoveryCount, sizeof(uint32_t));
        memcpy(&canHealthBuf[4], &errPassiveSec, sizeof(uint32_t));
        CLI_Frame_Send(CLI_CMD_CAN_HEALTH_DATA, canHealthBuf,
                       sizeof(canHealthBuf));
      }

      /* RTC Date and Time frame */

      RTC_TimeTypeDef sTime = {0};
      RTC_DateTypeDef sDate = {0};
      if (HAL_RTC_GetTime(&hrtc, &sTime, RTC_FORMAT_BIN) == HAL_OK) {
        HAL_RTC_GetDate(&hrtc, &sDate, RTC_FORMAT_BIN);
        RTC_DateTime_t rtcData;
        rtcData.year    = sDate.Year;
        rtcData.month   = sDate.Month;
        rtcData.date    = sDate.Date;
        rtcData.hours   = sTime.Hours;
        rtcData.minutes = sTime.Minutes;
        rtcData.seconds = sTime.Seconds;
        CLI_Frame_Send(CLI_CMD_RTC_DATA, (const uint8_t *)&rtcData,
                       sizeof(rtcData));
      }
    }

    /* ---- 8. Process incoming CLI commands ----
     * Handled at most ONE frame per main-loop iteration, against an RX layer
     * that could only hold ONE decoded frame (see cli_frame.c). The 100 ms
     * telemetry block above issues a dozen BLOCKING CLI_Frame_Send() calls,
     * so a two-command burst from the GUI -- "Set Thresholds" then "Save to
     * Flash" is exactly that -- routinely lost the second frame. The RX
     * layer is now a FIFO and this loop drains it. */
    for (uint8_t cliBurst = 0U; cliBurst < CLI_RX_QUEUE_DEPTH; cliBurst++) {
      if (!CLI_Frame_Process(&rxFrame)) {
        break;
      }
      switch (rxFrame.cmd) {

      case CLI_CMD_ZERO_CAL:
        CurrentSensor_StartZeroCalibration();
        break;

      case CLI_CMD_KNOWN_CAL:
        if (rxFrame.data_len >= 4) {
          float knownCurrent_mA;
          memcpy(&knownCurrent_mA, rxFrame.data, sizeof(float));
          CurrentSensor_StartKnownCalibration(knownCurrent_mA);
        }
        break;

      case CLI_CMD_SOC_SET_FULL:
        SOC_SetFull(&hSoc);
        break;

      case CLI_CMD_SOC_SET_EMPTY:
        SOC_SetEmpty(&hSoc);
        break;

      case CLI_CMD_SET_FAULT_THRESH: {
        /* ROOT CAUSE of "I can't set the fault thresholds":
         *  (1) SIZE -- required 36 B (9 floats) while the protocol header
         *      documented 0x20 as "24B = 6 x float". A host following the
         *      docs was dropped at the length check, silently.
         *  (2) ALL-OR-NOTHING VALIDATION -- at 36 B, a GUI exposing only
         *      the six original fields sends 0.0f for cellMax_V/cellMin_V/
         *      chargeOCLimit_A; ValidateFaultThresholds() then fails on
         *      cellMax_V > cellMin_V (0 > 0) and rejected the WHOLE struct,
         *      so the six valid pack thresholds were discarded too.
         * Now: seed from the thresholds in force, merge what was sent,
         * treat a trailing 0/non-finite field as "keep current", validate
         * the merged result, and report the outcome either way. */
        const uint16_t thrLen6 = (uint16_t)(6U * sizeof(float));
        const uint16_t thrLen9 = (uint16_t)sizeof(FaultThresholds_t);

        if (rxFrame.data_len >= thrLen6) {
          FaultThresholds_t newThr = *Fault_GetThresholds();
          memcpy(&newThr, rxFrame.data, thrLen6);

          if (rxFrame.data_len >= thrLen9) {
            FaultThresholds_t rxThr;
            memcpy(&rxThr, rxFrame.data, thrLen9);
            if (isfinite(rxThr.cellMax_V) && rxThr.cellMax_V > 0.0f) {
              newThr.cellMax_V = rxThr.cellMax_V;
            }
            if (isfinite(rxThr.cellMin_V) && rxThr.cellMin_V > 0.0f) {
              newThr.cellMin_V = rxThr.cellMin_V;
            }
            if (isfinite(rxThr.chargeOCLimit_A) &&
                rxThr.chargeOCLimit_A > 0.0f) {
              newThr.chargeOCLimit_A = rxThr.chargeOCLimit_A;
            }
          }

          if (ValidateFaultThresholds(&newThr)) {
            Fault_SetThresholds(&newThr);
            ErrorLog_Add("CLI: Fault thresholds applied (cmd 0x20)");
            Fault_WarnIfOvBelowCvTarget();
            uint8_t thrAck[2u + sizeof(FaultThresholds_t)];
            uint16_t ackMask = Fault_GetBitmask();
            thrAck[0] = (uint8_t)(ackMask & 0xFFu);
            thrAck[1] = (uint8_t)(ackMask >> 8u);
            memcpy(&thrAck[2], Fault_GetThresholds(),
                   sizeof(FaultThresholds_t));
            CLI_Frame_Send(CLI_CMD_FAULT_STATUS, thrAck, sizeof(thrAck));
          } else {
            ErrorLog_Add("CLI: Fault thresh REJECTED - range/order check");
          }
        } else {
          ErrorLog_Add("CLI: Fault thresh REJECTED - payload too short");
        }
        break;
      }

      case CLI_CMD_SET_SOC_CONFIG:
        if (rxFrame.data_len >= (uint16_t)sizeof(CLI_SOC_Config_Payload_t)) {
          CLI_SOC_Config_Payload_t payload;
          memcpy(&payload, rxFrame.data, sizeof(CLI_SOC_Config_Payload_t));

          if (ValidateSocConfig(&payload)) {
            g_soc_config.pack_uv_limit = payload.pack_uv_limit;
            g_soc_config.battery_capacity_ah = payload.battery_capacity_ah;
            g_soc_config.pack_full_voltage = payload.pack_full_voltage;
            memcpy(g_soc_config.soc_ref, payload.soc_ref,
                   sizeof(payload.soc_ref));
            memcpy(g_soc_config.pack_ocv, payload.pack_ocv,
                   sizeof(payload.pack_ocv));

            g_soc_config.ocv_min_pack_volt = g_soc_config.pack_ocv[1];
            /* Need to re-init with new capacity if capacity changed */
            SOC_Init(&hSoc, &g_soc_config, SOC_GetPercent(&hSoc), HAL_GetTick());
          }
        }
        break;

      case CLI_CMD_SET_CHARGER_CONFIG:
        /* RAM only — apply immediately, next 1 Hz tick uses the new profile.
         * Persist explicitly via CLI_CMD_SAVE_CAL, same as every other
         * config on this bus (fault thresholds, SOC config, calibration). */
        if (rxFrame.data_len >= (uint16_t)sizeof(CLI_ChargerConfig_t)) {
          CLI_ChargerConfig_t newChgCfg;
          memcpy(&newChgCfg, rxFrame.data, sizeof(CLI_ChargerConfig_t));
          if (ValidateChargerConfig(&newChgCfg)) {
            g_charger_config = newChgCfg;
            /* Changing cellCount or V/cell moves the CV target, which can
             * newly collide with the pack OV trip -- re-check. */
            Fault_WarnIfOvBelowCvTarget();
          }
        }
        break;

      case CLI_CMD_GET_CHARGER_CONFIG:
        CLI_Frame_Send(CLI_CMD_CHARGER_CONFIG_DATA,
                       (const uint8_t *)&g_charger_config,
                       sizeof(g_charger_config));
        break;

      case CLI_CMD_SAVE_CAL: {
        if (SaveSystemStateToFlash()) {
          ErrorLog_Add("CLI: Config saved to flash OK (cmd 0x14)");
        } else {
          ErrorLog_Add("CLI: Config save to flash FAILED (cmd 0x14)");
        }
        {
          uint8_t saveAck[2u + sizeof(FaultThresholds_t)];
          uint16_t saveMask = Fault_GetBitmask();
          saveAck[0] = (uint8_t)(saveMask & 0xFFu);
          saveAck[1] = (uint8_t)(saveMask >> 8u);
          memcpy(&saveAck[2], Fault_GetThresholds(),
                 sizeof(FaultThresholds_t));
          CLI_Frame_Send(CLI_CMD_FAULT_STATUS, saveAck, sizeof(saveAck));
        }
        CLI_Frame_Send(CLI_CMD_CHARGER_CONFIG_DATA,
                       (const uint8_t *)&g_charger_config,
                       sizeof(g_charger_config));
        break;
      }

      case CLI_CMD_SET_TEMP_CAL:
        if (rxFrame.data_len >= sizeof(float)) {
          float known_temp;
          memcpy(&known_temp, rxFrame.data, sizeof(float));
          NTC_Calibrate(known_temp, g_adc_raw);
        }
        break;

      case CLI_CMD_SET_TEMP2_CAL:
        if (rxFrame.data_len >= sizeof(float)) {
          float known_temp2;
          memcpy(&known_temp2, rxFrame.data, sizeof(float));
          NTC2_Calibrate(known_temp2, g_adc2_raw);
        }
        break;

      case CLI_CMD_SET_RTC:
        if (rxFrame.data_len >= (uint16_t)sizeof(RTC_DateTime_t)) {
          RTC_DateTime_t dt;
          memcpy(&dt, rxFrame.data, sizeof(RTC_DateTime_t));
          RTC_TimeTypeDef sTime = {0};
          RTC_DateTypeDef sDate = {0};
          sTime.Hours = dt.hours;
          sTime.Minutes = dt.minutes;
          sTime.Seconds = dt.seconds;
          sTime.TimeFormat = RTC_HOURFORMAT12_AM;
          sTime.DayLightSaving = RTC_DAYLIGHTSAVING_NONE;
          sTime.StoreOperation = RTC_STOREOPERATION_RESET;
          sDate.Year = dt.year;
          sDate.Month = dt.month;
          sDate.Date = dt.date;
          sDate.WeekDay =
              RTC_WEEKDAY_MONDAY; /* Ignored but required by struct */
          HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BIN);
          HAL_RTC_SetDate(&hrtc, &sDate, RTC_FORMAT_BIN);
        }
        break;

case CLI_CMD_READ_ERROR_LOGS: {
        /*
         * ROBUSTNESS FIX: Sending all 100 log entries in one shot blocks the
         * main loop for ~100+ ms, starving DalyBMS_Process() and delaying the
         * IWDG feed. Cap at 20 entries per command; the host can re-request
         * with an offset if needed, or simply re-send this command next tick.
         */
        uint32_t logCount = ErrorLog_GetCount();
        if (logCount > 20U) { logCount = 20U; }
        ErrorLog_Entry_t entry;
        for (uint32_t i = 0; i < logCount; i++) {
          if (ErrorLog_GetEntry(i, &entry)) {
            CLI_Frame_Send(CLI_CMD_ERROR_LOG_DATA, (const uint8_t *)&entry,
                           sizeof(entry));
          }
          /* Feed IWDG between log frames — each CLI_Frame_Send may take ~1 ms */
          HAL_IWDG_Refresh(&hiwdg);
        }
        break;
      }
      case CLI_CMD_SET_LC_ZERO: {
        LC_SetZero(&hLC); /* Force LC estimate = 0 */
        break;
      }
      case CLI_CMD_SET_SOH: {
        if (rxFrame.data_len >= sizeof(float)) {
          float soh_pct;
          memcpy(&soh_pct, rxFrame.data, sizeof(float));
          LC_SetSOH(&hLC, soh_pct); /* Update LC SOH % */
        }
        break;
      }
      case CLI_CMD_RESET_LIFE: {
        SOH_ResetLifeCounters(&hSOH);
        SaveSystemStateToFlash();
        break;
      }
      case CLI_CMD_CLEAR_FAULTS: {
        /* STUCK-FAULT FIX: Remote clear all latched fault flags so the BMS
         * can recover without a power cycle.  This is the GUI-level escape
         * hatch for any dead-band latching scenario that the auto-timeout
         * in FAULT_DEBOUNCE didn't catch (e.g. a fault that was triggered
         * by a transient condition that has fully cleared). */
        Fault_ClearAll();
        ErrorLog_Add("CLI: Faults cleared remotely by host command 0x54");
        break;
      }
      case CLI_CMD_RESET_STATE: {
        /* STUCK-STATE FIX: Force the drive state machine back to IDLE.
         * This is the GUI-level escape hatch if the dead-band timeout
         * (50 ticks ~5s) was insufficient for some reason, or if the user
         * wants to immediately force the system back to IDLE without
         * waiting for the timeout. */
        lastDriveState = SYS_STATE_IDLE;
        state_deadband_ticks = 0;
        spike_persist_cnt = 0;
        ErrorLog_Add("CLI: State reset to IDLE by host command 0x55");
        break;
      }
      default:
        break;
      }
    }

    /* ---- 8b. Host-command loss watchdog ---- */
    {
      static uint32_t reported_cli_drops = 0U;
      uint32_t cli_drops = CLI_Frame_GetDropCount();
      if (cli_drops != reported_cli_drops) {
        reported_cli_drops = cli_drops;
        ErrorLog_Add("CLI: RX queue overflow - host command dropped");
      }
    }
  }
  /* USER CODE END 3 */
}

/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void) {
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
   */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);

  /** Initializes the RCC Oscillators according to the specified parameters
   * in the RCC_OscInitTypeDef structure.
   */
  RCC_OscInitStruct.OscillatorType =
      RCC_OSCILLATORTYPE_HSI | RCC_OSCILLATORTYPE_LSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV4;
  RCC_OscInitStruct.PLL.PLLN = 85;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
   */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK |
                                RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK) {
    Error_Handler();
  }
}

/**
 * @brief ADC1 Initialization Function
 * @param None
 * @retval None
 */
static void MX_ADC1_Init(void) {

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_MultiModeTypeDef multimode = {0};
  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Common config
   */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.GainCompensation = 0;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc1.Init.LowPowerAutoWait = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  /* 16x hardware oversampling: TIM1 TRGO still fires at ~5 kHz, but
   * ADC_TRIGGEREDMODE_SINGLE_TRIGGER means a SINGLE trigger runs all 16
   * sub-conversions back-to-back internally and delivers one averaged,
   * right-shifted 12-bit result per trigger -- so HAL_ADC_ConvCpltCallback
   * still fires at ~5 kHz, each callback now carrying a 16x-averaged
   * sample instead of a single raw one. RightBitShift=4 divides the 16x
   * accumulator back down to 12-bit scale (2^4 = 16). */
  hadc1.Init.OversamplingMode = ENABLE;
  hadc1.Init.Oversampling.Ratio = ADC_OVERSAMPLING_RATIO_16;
  hadc1.Init.Oversampling.RightBitShift = ADC_RIGHTBITSHIFT_4;
  hadc1.Init.Oversampling.TriggeredMode = ADC_TRIGGEREDMODE_SINGLE_TRIGGER;
  hadc1.Init.Oversampling.OversamplingStopReset = ADC_REGOVERSAMPLING_RESUMED_MODE;
  if (HAL_ADC_Init(&hadc1) != HAL_OK) {
    Error_Handler();
  }

  /** Configure the ADC multi-mode
   */
  multimode.Mode = ADC_MODE_INDEPENDENT;
  if (HAL_ADCEx_MultiModeConfigChannel(&hadc1, &multimode) != HAL_OK) {
    Error_Handler();
  }

  /** Configure Regular Channel
   */
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  /* Was ADC_SAMPLETIME_2CYCLES_5 -- the shortest sampling time this ADC
   * supports, chosen originally with no time-budget need to be that
   * aggressive (TIM1 only triggers every ~200 us). 47.5 cycles gives the
   * sample-and-hold capacitor meaningfully more time to settle against the
   * ACS37612's output impedance / RC filter, still trivially inside the
   * ~200 us trigger period even with 16x oversampling added below. */
  sConfig.SamplingTime = ADC_SAMPLETIME_47CYCLES_5;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK) {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */
}

/**
 * @brief ADC2 Initialization Function
 * @param None
 * @retval None
 */
static void MX_ADC2_Init(void) {

  /* USER CODE BEGIN ADC2_Init 0 */

  /* USER CODE END ADC2_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC2_Init 1 */

  /* USER CODE END ADC2_Init 1 */

  /** Common config
   */
  hadc2.Instance = ADC2;
  hadc2.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc2.Init.Resolution = ADC_RESOLUTION_12B;
  hadc2.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc2.Init.GainCompensation = 0;
  hadc2.Init.ScanConvMode = ADC_SCAN_ENABLE;
  hadc2.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc2.Init.LowPowerAutoWait = DISABLE;
  hadc2.Init.ContinuousConvMode = DISABLE;
  hadc2.Init.NbrOfConversion = 2;
  hadc2.Init.DiscontinuousConvMode = ENABLE;
  hadc2.Init.NbrOfDiscConversion = 1;
  hadc2.Init.ExternalTrigConv = ADC_EXTERNALTRIG_T1_TRGO;
  hadc2.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_RISING;
  hadc2.Init.DMAContinuousRequests = DISABLE;
  hadc2.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc2.Init.OversamplingMode = DISABLE;
  if (HAL_ADC_Init(&hadc2) != HAL_OK) {
    Error_Handler();
  }

  /** Configure Regular Channel
   */
  sConfig.Channel = ADC_CHANNEL_12;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_47CYCLES_5;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK) {
    Error_Handler();
  }

  /** Configure Regular Channel
   */
  sConfig.Channel = ADC_CHANNEL_14;
  sConfig.Rank = ADC_REGULAR_RANK_2;
  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK) {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC2_Init 2 */

  /* USER CODE END ADC2_Init 2 */
}

/**
 * @brief FDCAN1 Initialization Function — implementation moved to fdcan.c.
 *        Bit timing is unchanged from the original CubeMX-generated values
 *        (NominalPrescaler=34, TimeSeg1=3, TimeSeg2=1) — confirmed correct
 *        for exactly 1 Mbps on this board's real 170 MHz FDCAN kernel
 *        clock (RCC.FDCANFreq_Value=170000000 per this project's .ioc).
 * @param None
 * @retval None
 */

/**
 * @brief IWDG Initialization Function
 * @param None
 * @retval None
 */
static void MX_IWDG_Init(void) {

  /* USER CODE BEGIN IWDG_Init 0 */

  /* USER CODE END IWDG_Init 0 */

  /* USER CODE BEGIN IWDG_Init 1 */

  /* USER CODE END IWDG_Init 1 */
  hiwdg.Instance = IWDG;
  hiwdg.Init.Prescaler = IWDG_PRESCALER_64;
  hiwdg.Init.Window = 4095;
  hiwdg.Init.Reload = 2000;
  if (HAL_IWDG_Init(&hiwdg) != HAL_OK) {
    Error_Handler();
  }
  /* USER CODE BEGIN IWDG_Init 2 */

  /* USER CODE END IWDG_Init 2 */
}

/**
 * @brief QUADSPI1 Initialization Function
 * @param None
 * @retval None
 */
static void MX_QUADSPI1_Init(void) {

  /* USER CODE BEGIN QUADSPI1_Init 0 */

  /* USER CODE END QUADSPI1_Init 0 */

  /* USER CODE BEGIN QUADSPI1_Init 1 */

  /* USER CODE END QUADSPI1_Init 1 */
  /* QUADSPI1 parameter configuration*/
  hqspi1.Instance = QUADSPI;
  hqspi1.Init.ClockPrescaler = 4;
  hqspi1.Init.FifoThreshold = 4;
  hqspi1.Init.SampleShifting = QSPI_SAMPLE_SHIFTING_NONE;
  hqspi1.Init.FlashSize = 22;
  hqspi1.Init.ChipSelectHighTime = QSPI_CS_HIGH_TIME_2_CYCLE;
  hqspi1.Init.ClockMode = QSPI_CLOCK_MODE_0;
  hqspi1.Init.FlashID = QSPI_FLASH_ID_1;
  hqspi1.Init.DualFlash = QSPI_DUALFLASH_DISABLE;
  if (HAL_QSPI_Init(&hqspi1) != HAL_OK) {
    Error_Handler();
  }
  /* USER CODE BEGIN QUADSPI1_Init 2 */

  /* USER CODE END QUADSPI1_Init 2 */
}

/**
 * @brief RTC Initialization Function
 * @param None
 * @retval None
 */
static void MX_RTC_Init(void) {

  /* USER CODE BEGIN RTC_Init 0 */

  /* USER CODE END RTC_Init 0 */

  /* USER CODE BEGIN RTC_Init 1 */

  /* USER CODE END RTC_Init 1 */

  /** Initialize RTC Only
   */
  hrtc.Instance = RTC;
  hrtc.Init.HourFormat = RTC_HOURFORMAT_24;
  hrtc.Init.AsynchPrediv = 127;
  hrtc.Init.SynchPrediv = 255;
  hrtc.Init.OutPut = RTC_OUTPUT_DISABLE;
  hrtc.Init.OutPutRemap = RTC_OUTPUT_REMAP_NONE;
  hrtc.Init.OutPutPolarity = RTC_OUTPUT_POLARITY_HIGH;
  hrtc.Init.OutPutType = RTC_OUTPUT_TYPE_OPENDRAIN;
  hrtc.Init.OutPutPullUp = RTC_OUTPUT_PULLUP_NONE;
  if (HAL_RTC_Init(&hrtc) != HAL_OK) {
    Error_Handler();
  }
  /* USER CODE BEGIN RTC_Init 2 */

  /* USER CODE END RTC_Init 2 */
}

/**
 * @brief TIM1 Initialization Function
 * @param None
 * @retval None
 */
static void MX_TIM1_Init(void) {

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 33999;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK) {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK) {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
  sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK) {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
}

/**
 * @brief TIM5 Initialization Function
 * @param None
 * @retval None
 */
static void MX_TIM5_Init(void) {

  /* USER CODE BEGIN TIM5_Init 0 */

  /* USER CODE END TIM5_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM5_Init 1 */

  /* USER CODE END TIM5_Init 1 */
  htim5.Instance = TIM5;
  htim5.Init.Prescaler = 0;
  htim5.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim5.Init.Period = 16999999;
  htim5.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim5.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim5) != HAL_OK) {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim5, &sClockSourceConfig) != HAL_OK) {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim5, &sMasterConfig) != HAL_OK) {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM5_Init 2 */

  /* USER CODE END TIM5_Init 2 */
}

/**
 * @brief TIM6 Initialization Function
 * @param None
 * @retval None
 */
static void MX_TIM6_Init(void) {

  /* USER CODE BEGIN TIM6_Init 0 */

  /* USER CODE END TIM6_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM6_Init 1 */

  /* USER CODE END TIM6_Init 1 */
  htim6.Instance = TIM6;
  htim6.Init.Prescaler = 11;
  htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim6.Init.Period = 59999;
  htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim6) != HAL_OK) {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK) {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM6_Init 2 */

  /* USER CODE END TIM6_Init 2 */
}

/**
 * @brief TIM15 Initialization Function
 * @param None
 * @retval None
 */
static void MX_TIM15_Init(void) {

  /* USER CODE BEGIN TIM15_Init 0 */

  /* USER CODE END TIM15_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM15_Init 1 */

  /* USER CODE END TIM15_Init 1 */
  htim15.Instance = TIM15;
  htim15.Init.Prescaler = 339;
  htim15.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim15.Init.Period = 49999;
  htim15.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim15.Init.RepetitionCounter = 0;
  htim15.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim15) != HAL_OK) {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim15, &sClockSourceConfig) != HAL_OK) {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim15, &sMasterConfig) !=
      HAL_OK) {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM15_Init 2 */

  /* USER CODE END TIM15_Init 2 */
}

/**
 * @brief UART5 Initialization Function
 * @param None
 * @retval None
 */
static void MX_UART5_Init(void) {

  /* USER CODE BEGIN UART5_Init 0 */

  /* USER CODE END UART5_Init 0 */

  /* USER CODE BEGIN UART5_Init 1 */

  /* USER CODE END UART5_Init 1 */
  huart5.Instance = UART5;
  huart5.Init.BaudRate = 9600;
  huart5.Init.WordLength = UART_WORDLENGTH_8B;
  huart5.Init.StopBits = UART_STOPBITS_1;
  huart5.Init.Parity = UART_PARITY_NONE;
  huart5.Init.Mode = UART_MODE_TX_RX;
  huart5.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart5.Init.OverSampling = UART_OVERSAMPLING_16;
  huart5.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart5.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart5.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart5) != HAL_OK) {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart5, UART_TXFIFO_THRESHOLD_1_8) !=
      HAL_OK) {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart5, UART_RXFIFO_THRESHOLD_1_8) !=
      HAL_OK) {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart5) != HAL_OK) {
    Error_Handler();
  }
  /* USER CODE BEGIN UART5_Init 2 */

  /* USER CODE END UART5_Init 2 */
}

/**
 * @brief USART2 Initialization Function
 * @param None
 * @retval None
 */
static void MX_USART2_UART_Init(void) {

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK) {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart2, UART_TXFIFO_THRESHOLD_1_8) !=
      HAL_OK) {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart2, UART_RXFIFO_THRESHOLD_1_8) !=
      HAL_OK) {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart2) != HAL_OK) {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */
}

/**
 * @brief GPIO Initialization Function
 * @param None
 * @retval None
 */
static void MX_GPIO_Init(void) {
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC,
                    LED4_D11_Pin | LED3_D10_Pin | LED2_D9_Pin | BLUE_LED_Pin |
                        STB_CAN_Pin,
                    GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LED1_D8_Pin | GREEN_LED_Pin | RED_LED_Pin,
                    GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(CAN_EN_GPIO_Port, CAN_EN_Pin, GPIO_PIN_SET);

  /*Configure GPIO pins : LED4_D11_Pin LED3_D10_Pin LED2_D9_Pin */
  GPIO_InitStruct.Pin = LED4_D11_Pin | LED3_D10_Pin | LED2_D9_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : LED1_D8_Pin GREEN_LED_Pin RED_LED_Pin */
  GPIO_InitStruct.Pin = LED1_D8_Pin | GREEN_LED_Pin | RED_LED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : BLUE_LED_Pin */
  GPIO_InitStruct.Pin = BLUE_LED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(BLUE_LED_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : STB_CAN_Pin */
  GPIO_InitStruct.Pin = STB_CAN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(STB_CAN_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : CAN_EN_Pin */
  GPIO_InitStruct.Pin = CAN_EN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(CAN_EN_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : wakeButton_Pin */
  GPIO_InitStruct.Pin = wakeButton_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(wakeButton_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/**
 * @brief  FDCAN RX FIFO0 callback.
 *         Charger status frames (CHARGER_RX_ID_STATUS) are dispatched to
 *         Process_Charger_Frame() in fdcan.c. Everything else reached here
 *         via the DroneCAN catch-all hardware filter and is enqueued into
 *         the existing can_rx_queue for canardHandleRxFrame() in the main
 *         loop, unchanged from before.
 */
void HAL_FDCAN_RxFifo0Callback(FDCAN_HandleTypeDef *hfdcan,
                               uint32_t RxFifo0ITs) {
  if ((RxFifo0ITs & FDCAN_IT_RX_FIFO0_NEW_MESSAGE) != RESET) {
    /*
     * ROBUSTNESS FIX: Never call Error_Handler() from an ISR.
     * Error_Handler spins with IRQs disabled → IWDG stops → system hang.
     * Instead: on GetRxMessage failure, skip this frame (already consumed
     * from HW FIFO by the interrupt) and re-arm the notification so future
     * frames are not lost. On ActivateNotification failure, the next RX
     * interrupt will simply not fire — a missed frame, not a hang.
     */
    FDCAN_RxHeaderTypeDef RxHeader;
    uint8_t RxData[8];

    if (HAL_FDCAN_GetRxMessage(hfdcan, FDCAN_RX_FIFO0, &RxHeader, RxData) ==
        HAL_OK) {
      if (RxHeader.Identifier == CHARGER_RX_ID_STATUS) {
        Process_Charger_Frame(RxHeader.Identifier, RxData,
                               (uint8_t)RxHeader.DataLength);
      } else {
        /* DroneCAN catch-all path — enqueue for main-loop processing,
           drop silently if queue full (unchanged behavior). */
        uint8_t next_head = (can_rx_head + 1) % CAN_RX_QUEUE_SIZE;
        if (next_head != can_rx_tail) {
          can_rx_queue[can_rx_head].frame.id =
              RxHeader.Identifier | CANARD_CAN_FRAME_EFF;
          can_rx_queue[can_rx_head].frame.data_len = RxHeader.DataLength;
          memcpy((void *)can_rx_queue[can_rx_head].frame.data, RxData,
                 RxHeader.DataLength);
          can_rx_queue[can_rx_head].timestamp_usec = HAL_GetTick() * 1000ULL;
          can_rx_head = next_head;
        }
      }
    }
    /* Re-arm notification regardless of GetRxMessage result */
    HAL_FDCAN_ActivateNotification(hfdcan, FDCAN_IT_RX_FIFO0_NEW_MESSAGE, 0);
  }
}

/**
 * @brief  FDCAN TX FIFO empty callback
 */
void HAL_FDCAN_TxFifoEmptyCallback(FDCAN_HandleTypeDef *hfdcan) {
  if (hfdcan->Instance == FDCAN1) {
    Process_CAN_Tx();
  }
}

/**
 * @brief Drains the libcanard TX queue via the shared Transmit_DroneCAN_Msg()
 *        helper in fdcan.c (enforces Classic CAN 2.0B Extended headers).
 */
void Process_CAN_Tx(void) {
  /* Bail immediately if TX FIFO is full — no point trying to push frames
   * onto a full FIFO. This prevents spinning here when the charger is
   * flooding the bus and the FIFO drains slowly. */
  if (HAL_FDCAN_GetTxFifoFreeLevel(&hfdcan1) == 0U) {
    return;
  }
  for (const CanardCANFrame *txf = canardPeekTxQueue(&canard); txf != NULL;
       txf = canardPeekTxQueue(&canard)) {
    if (Transmit_DroneCAN_Msg(txf->id & 0x1FFFFFFFUL,
                               (uint8_t *)txf->data, txf->data_len)) {
      canardPopTxQueue(&canard);
    } else {
      break;
    }
  }
}


/* USER CODE END 4 */

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void) {
  /* USER CODE BEGIN Error_Handler_Debug */
  /*
   * ROBUSTNESS FIX: Do NOT spin with IRQs disabled.
   * __disable_irq() + infinite loop kills the IWDG feed, locks the CPU, and
   * prevents any recovery. Instead: log the fault, then let the IWDG expire
   * (~2 s) and reset the MCU cleanly. The system boots fresh and resumes
   * normal operation — no permanent hang.
   */
  ErrorLog_Add("Error_Handler: HAL fault — awaiting IWDG reset");
  /* Do NOT call __disable_irq() — let IWDG run and fire the reset */
  while (1) { /* IWDG resets within ~2 s */ }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
 * @brief  Reports the name of the source file and the source line number
 *         where the assert_param error has occurred.
 * @param  file: pointer to the source file name
 * @param  line: assert_param error line source number
 * @retval None
 */
void assert_failed(uint8_t *file, uint32_t line) {
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line
number, ex: printf("Wrong parameters value: file %s on line %d\r\n", file,
line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
