/**
  ******************************************************************************
  * @file    can_frame_handlers.c
  * @brief   Application-level decode for frames dispatched out of main.c's
  *          HAL_FDCAN_RxFifo0Callback() by exact ID match.
  *
  * DroneCAN frames are NOT handled here — they go through the existing
  * can_rx_queue -> canardHandleRxFrame() pipeline in main.c, unchanged.
  ******************************************************************************
  */
#include "fdcan.h"
#include "charger_config.h"

/**
  * @brief  Handles the Solterra Charger broadcast status frame
  *         (ID 0x18FF50E5, dlc >= 5): actual_V, actual_I, fault flags.
  *
  * INTERRUPT CONTEXT — called directly from HAL_FDCAN_RxFifo0Callback().
  * This function must stay O(1): it only copies the raw bytes into
  * g_chargerRxStage via Charger_LatchRawFrame() and returns. All decoding,
  * bounds-checking, filtering, and state-machine work happens later, once
  * per main-loop iteration, in Charger_ProcessStatusFrame() — see
  * charger_config.h for why that split exists (a flooding/noisy charger
  * must never be able to add unbounded work at interrupt priority; that
  * was the root cause behind "charger data makes the BMS hang").
  */
void Process_Charger_Frame(uint32_t ext_id, uint8_t *data, uint8_t len)
{
  (void)ext_id;
  Charger_LatchRawFrame(&g_chargerRxStage, data, len);
}
