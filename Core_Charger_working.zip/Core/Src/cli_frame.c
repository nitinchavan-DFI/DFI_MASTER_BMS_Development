/**
 * @file    cli_frame.c
 * @brief   CLI frame protocol – interrupt-driven state-machine decoder &
 * encoder
 *
 * Refactored: does NOT define HAL_UART_RxCpltCallback directly.
 * Instead exposes CLI_Frame_RxCallback() to be called from the centralized
 * HAL callback in stm32g4xx_it.c.
 */

/* Includes ------------------------------------------------------------------*/
#include "cli_frame.h"
#include <string.h>

/* Private variables ---------------------------------------------------------*/
static UART_HandleTypeDef *cli_huart; /* UART handle                   */

static volatile CLI_RxState_t rx_state; /* Current state machine state   */
static uint8_t rx_byte;                 /* Single-byte interrupt buffer  */

static uint8_t rx_buf[CLI_MAX_FRAME_LENGTH]; /* Assembly buffer for raw frame */
static uint16_t rx_idx;                      /* Write index into rx_buf       */
static uint16_t rx_expected_len;             /* Total frame length from hdr   */
static uint8_t rx_checksum;                  /* Running checksum              */

/* ---------------------------------------------------------------------------
 * Decoded-frame FIFO.  Single producer (UART RX ISR) / single consumer (main
 * loop), so head and tail need no critical section: each index is written by
 * exactly one context and is a single naturally-aligned byte.
 *
 * Replaces the old scheme, which was one frame plus a "frame_available" flag.
 * Any frame arriving while that flag was still set was thrown away without a
 * trace, and the flag stayed set for as long as the main loop took to come
 * back around — which, thanks to the blocking telemetry TX burst every
 * 100 ms, is long enough to swallow the second half of a two-command burst
 * from the GUI.  That is the "set didn't take / save didn't happen" failure.
 * -------------------------------------------------------------------------*/
static CLI_Frame_t rx_queue[CLI_RX_QUEUE_DEPTH];
static volatile uint8_t rx_q_head;      /* ISR writes here      */
static volatile uint8_t rx_q_tail;      /* main loop reads here */
static volatile uint32_t rx_drop_count; /* frames lost to a full queue */

/* Private function prototypes -----------------------------------------------*/
static void CLI_ResetState(void);

/* Public functions ----------------------------------------------------------*/

void CLI_Frame_Init(UART_HandleTypeDef *huart) {
  cli_huart = huart;
  CLI_ResetState();
  rx_q_head = 0U;
  rx_q_tail = 0U;
  rx_drop_count = 0U;
  HAL_UART_Receive_IT(cli_huart, &rx_byte, 1);
}

bool CLI_Frame_Process(CLI_Frame_t *frame) {
  uint8_t tail = rx_q_tail;

  if (tail == rx_q_head) {
    return false; /* queue empty */
  }

  const CLI_Frame_t *src = &rx_queue[tail];

  /* Copy only the bytes that are actually populated — the old code memcpy'd
   * the whole 515-byte struct on every command, including 500-odd bytes of
   * stale payload nobody reads. */
  frame->cmd = src->cmd;
  frame->data_len = src->data_len;
  if (src->data_len > 0U) {
    memcpy(frame->data, src->data, src->data_len);
  }

  __DMB(); /* slot fully consumed before the producer may reuse it */
  rx_q_tail = (uint8_t)((tail + 1U) % CLI_RX_QUEUE_DEPTH);
  return true;
}

uint32_t CLI_Frame_GetDropCount(void) { return rx_drop_count; }

HAL_StatusTypeDef CLI_Frame_Send(uint8_t cmd, const uint8_t *data,
                                 uint16_t len) {
  if (len > CLI_MAX_DATA_LENGTH)
    return HAL_ERROR;

  static uint8_t tx_buf[CLI_MAX_FRAME_LENGTH];
  uint16_t total_len = CLI_FRAME_OVERHEAD + len;
  uint16_t idx = 0;

  /* Header */
  tx_buf[idx++] = CLI_HEADER_BYTE_1;
  tx_buf[idx++] = CLI_HEADER_BYTE_2;

  /* Length (little-endian) */
  tx_buf[idx++] = (uint8_t)(total_len & 0xFF);
  tx_buf[idx++] = (uint8_t)((total_len >> 8) & 0xFF);

  /* Command */
  tx_buf[idx++] = cmd;

  /* Data */
  if (data != NULL && len > 0) {
    memcpy(&tx_buf[idx], data, len);
    idx += len;
  }

  /* Checksum: sum of bytes from index 2 to (idx - 1) inclusive */
  uint8_t checksum = 0;
  for (uint16_t i = 2; i < idx; i++) {
    checksum += tx_buf[i];
  }
  tx_buf[idx++] = checksum;

  /* End bytes */
  tx_buf[idx++] = CLI_END_BYTE_1;
  tx_buf[idx++] = CLI_END_BYTE_2;

  return HAL_UART_Transmit(cli_huart, tx_buf, idx, 100);
}

/* Private functions ---------------------------------------------------------*/

static void CLI_ResetState(void) {
  rx_state = CLI_STATE_WAIT_HEADER1;
  rx_idx = 0;
  rx_expected_len = 0;
  rx_checksum = 0;
}

/* Refactored RX callback – called from centralized HAL callback -------------*/

void CLI_Frame_RxCallback(UART_HandleTypeDef *huart) {
  if (huart->Instance != cli_huart->Instance) {
    return;
  }

  switch (rx_state) {
  case CLI_STATE_WAIT_HEADER1:
    if (rx_byte == CLI_HEADER_BYTE_1) {
      rx_buf[0] = rx_byte;
      rx_idx = 1;
      rx_state = CLI_STATE_WAIT_HEADER2;
    }
    break;

  case CLI_STATE_WAIT_HEADER2:
    if (rx_byte == CLI_HEADER_BYTE_2) {
      rx_buf[1] = rx_byte;
      rx_idx = 2;
      rx_state = CLI_STATE_WAIT_LEN_LOW;
    } else if (rx_byte == CLI_HEADER_BYTE_1) {
      rx_buf[0] = rx_byte;
      rx_idx = 1;
    } else {
      CLI_ResetState();
    }
    break;

  case CLI_STATE_WAIT_LEN_LOW:
    rx_buf[rx_idx++] = rx_byte;
    rx_expected_len = rx_byte;
    rx_checksum = rx_byte;
    rx_state = CLI_STATE_WAIT_LEN_HIGH;
    break;

  case CLI_STATE_WAIT_LEN_HIGH:
    rx_buf[rx_idx++] = rx_byte;
    rx_expected_len |= ((uint16_t)rx_byte << 8);
    rx_checksum += rx_byte;

    if (rx_expected_len < CLI_MIN_FRAME_LENGTH ||
        rx_expected_len > CLI_MAX_FRAME_LENGTH) {
      CLI_ResetState();
    } else {
      rx_state = CLI_STATE_RECV_PAYLOAD;
    }
    break;

  case CLI_STATE_RECV_PAYLOAD:
    rx_buf[rx_idx++] = rx_byte;

    if (rx_idx < (rx_expected_len - 2)) {
      if (rx_idx <= (rx_expected_len - 3)) {
        rx_checksum += rx_byte;
      }
    }

    if (rx_idx >= (rx_expected_len - 2)) {
      uint8_t received_checksum = rx_buf[rx_idx - 1];
      rx_checksum &= 0xFF;

      if (rx_checksum != received_checksum) {
        CLI_ResetState();
      } else {
        rx_state = CLI_STATE_WAIT_END1;
      }
    }
    break;

  case CLI_STATE_WAIT_END1:
    if (rx_byte == CLI_END_BYTE_1) {
      rx_buf[rx_idx++] = rx_byte;
      rx_state = CLI_STATE_WAIT_END2;
    } else {
      CLI_ResetState();
    }
    break;

  case CLI_STATE_WAIT_END2:
    if (rx_byte == CLI_END_BYTE_2) {
      rx_buf[rx_idx++] = rx_byte;

      uint8_t next = (uint8_t)((rx_q_head + 1U) % CLI_RX_QUEUE_DEPTH);

      if (next == rx_q_tail) {
        /* Queue full — count it so the loss is visible instead of silent. */
        if (rx_drop_count < UINT32_MAX) {
          rx_drop_count++;
        }
      } else {
        CLI_Frame_t *slot = &rx_queue[rx_q_head];
        slot->cmd = rx_buf[4];
        slot->data_len = rx_expected_len - CLI_FRAME_OVERHEAD;
        if (slot->data_len > 0U) {
          memcpy(slot->data, &rx_buf[5], slot->data_len);
        }
        __DMB(); /* slot contents visible before head advances */
        rx_q_head = next;
      }
    }
    CLI_ResetState();
    break;

  default:
    CLI_ResetState();
    break;
  }

  /* Always re-arm the single-byte interrupt */
  HAL_UART_Receive_IT(cli_huart, &rx_byte, 1);
}
