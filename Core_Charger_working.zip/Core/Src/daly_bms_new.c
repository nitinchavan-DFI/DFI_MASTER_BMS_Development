/**
 * @file daly_bms_new.c
 * @brief New Daly BMS parser from Python daly_protocol_full.py
 * Streaming buffer parser + auto cell detection + temp (0x92)
 * Feeds raw UART bytes, keeps existing filters.
 */

#include "daly_bms.h"
#include <math.h>
#include <string.h>
#include <stdbool.h>

#define DALY_FRAME_LEN 13U
#define DALY_MAX_BUFFER_LEN 256U
#define DALY_MIN_CELLS 4U
#define DALY_MAX_CELLS 16U
#define DALY_AUTO_MIN_CELLS 12U
#define DALY_CELL_V_MIN_V 1.5f
#define DALY_CELL_V_MAX_V 5.5f

/* Streaming parser state in handle */
typedef struct {
  uint8_t buffer[DALY_MAX_BUFFER_LEN];
  uint16_t buffer_len;
  uint8_t num_cells;
  bool auto_detect;
} DalyBMS_NewParser_t;

bool DalyBMS_New_Init(DalyBMS_Handle_t *hbms, uint8_t num_cells, bool auto_detect) {
  DalyBMS_NewParser_t *p = &hbms->parser;
  p->buffer_len = 0;
  p->num_cells = (num_cells >= DALY_MIN_CELLS && num_cells <= DALY_MAX_CELLS) ? num_cells : DALY_MAX_CELLS;
  p->auto_detect = auto_detect;
  hbms->data.numberOfCells = p->num_cells;
  memset(hbms->data.cellVmV, 0, sizeof(hbms->data.cellVmV));
  return true;
}

void DalyBMS_New_Feed(DalyBMS_Handle_t *hbms, const uint8_t *bytes, uint16_t len) {
  DalyBMS_NewParser_t *p = &hbms->parser;
  uint16_t write_pos = p->buffer_len;
  uint16_t space = DALY_MAX_BUFFER_LEN - write_pos;
  uint16_t copy_len = (len > space) ? space : len;
  memcpy(&p->buffer[write_pos], bytes, copy_len);
  p->buffer_len += copy_len;
  
  /* Parse loop */
  while (p->buffer_len >= DALY_FRAME_LEN) {
    /* Find sync A5 */
    uint16_t i = 0;
    for (; i < p->buffer_len - 1; i++) {
      if (p->buffer[i] == 0xA5) break;
    }
    if (i > 0) {
      memmove(p->buffer, &p->buffer[i], p->buffer_len - i);
      p->buffer_len -= i;
    }
    
    if (p->buffer_len < DALY_FRAME_LEN) break;
    
    const uint8_t *frame = p->buffer;
    if (frame[3] != 0x08) {
      p->buffer_len--;
      memmove(p->buffer, &p->buffer[1], p->buffer_len);
      continue;
    }
    
    uint8_t chk = 0;
    for (uint8_t j = 0; j < 12; j++) chk += frame[j];
    if ((chk & 0xFF) != frame[12]) {
      p->buffer_len--;
      memmove(p->buffer, &p->buffer[1], p->buffer_len);
      continue;
    }
    
    /* Valid frame */
    uint8_t cmd = frame[2];
    const uint8_t *payload = &frame[4];
    
    switch (cmd) {
      case 0x90: {
        uint16_t raw_v = (payload[0] << 8) | payload[1];
        hbms->data.packVoltage = raw_v / 10.0f;
        uint16_t raw_i = (payload[4] << 8) | payload[5];
        hbms->data.packCurrent = (raw_i - 30000) / 10.0f;
        uint16_t raw_soc = (payload[6] << 8) | payload[7];
        hbms->data.packSOC = raw_soc / 10.0f;
        break;
      }
      case 0x92: {
        hbms->data.temperature = payload[0] - 40.0f;
        break;
      }
      case 0x91: {
        uint16_t raw_max = (payload[0] << 8) | payload[1];
        hbms->data.maxCellmV = raw_max / 1000.0f;
        hbms->data.maxCellVNum = payload[2];
        uint16_t raw_min = (payload[3] << 8) | payload[4];
        hbms->data.minCellmV = raw_min / 1000.0f;
        hbms->data.minCellVNum = payload[5];
        hbms->data.cellDiff = hbms->data.maxCellmV - hbms->data.minCellmV;
        break;
      }
      case 0x95: {
        uint8_t frame_num = payload[0];
        if (frame_num == 0 || frame_num == 0xFF) frame_num = 1;
        uint8_t base_idx = (frame_num - 1) * 3;
        for (uint8_t j = 0; j < 3; j++) {
          uint8_t idx = base_idx + j;
          if (idx >= p->num_cells) break;
          uint16_t raw_mv = (payload[1 + j*2] << 8) | payload[2 + j*2];
          float v = raw_mv / 1000.0f;
          if (v >= DALY_CELL_V_MIN_V && v <= DALY_CELL_V_MAX_V) {
            /* Apply EKF filter */
            DalyEKF_UpdateCell(&hbms->ekf, idx, v);
            hbms->data.cellVmV[idx] = DalyEKF_GetCellVoltage(&hbms->ekf, idx);
          }
        }
        /* Auto-detect */
        if (p->auto_detect) {
          uint8_t valid_count = 0;
          for (uint8_t i = 0; i < DALY_MAX_CELLS; i++) {
            if (hbms->data.cellVmV[i] > DALY_CELL_V_MIN_V) valid_count++;
            if (valid_count >= DALY_AUTO_MIN_CELLS) {
              p->num_cells = valid_count;
              hbms->data.numberOfCells = p->num_cells;
              break;
            }
          }
        }
        break;
      }
    }
    
    /* Consume frame */
    p->buffer_len -= DALY_FRAME_LEN;
    memmove(p->buffer, &p->buffer[DALY_FRAME_LEN], p->buffer_len);
  }
}

/* Update Process() to use new parser - feed recent RX bytes */
void DalyBMS_Process_New(DalyBMS_Handle_t *hbms) {
  /* Existing state machine logic... */
  /* In DALY_STATE_WAIT_RX, instead of fixed parse, feed to New_Feed */
  /* ... */
}

#endif /* End of new methods */

