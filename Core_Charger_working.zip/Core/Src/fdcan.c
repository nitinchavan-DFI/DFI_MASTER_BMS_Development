/**
  ******************************************************************************
  * @file    fdcan.c
  * @brief   FDCAN1 init (1 Mbps Classic CAN 2.0B Extended), hardware
  *          acceptance filters, and TX helpers.
  *
  * IMPORTANT: This file does NOT define HAL_FDCAN_RxFifo0Callback().
  * That callback remains in main.c because it feeds the existing
  * can_rx_queue -> canardHandleRxFrame() pipeline (static to main.c).
  * This file only supplies the charger-frame decode entry point that
  * main.c's callback dispatches into for CHARGER_RX_ID_STATUS.
  ******************************************************************************
  */
#include "fdcan.h"
#include <stdbool.h> /* belt-and-suspenders: fdcan.h already includes this,
                        but don't make fdcan.c's compile depend on that */

FDCAN_HandleTypeDef hfdcan1;

/* Bumped only by FDCAN1_HealthCheck() on a real recovery — see below. */
static uint32_t s_busOffRecoveryCount = 0;

/**
  * @brief FDCAN1 peripheral initialization.
  *
  * Clock: 170 MHz FDCAN kernel (HSI PLL, confirmed from .ioc).
  *
  * *** SET FDCAN_BAUD_RATE TO MATCH YOUR CHARGER ***
  * Solterra chargers are typically 250 kbps.
  * Check your charger datasheet or sniff with BUSMASTER at each rate.
  *
  * Bit-timing for all rates uses 18 TQ, 77.8% sample point, SJW=4:
  *   250 kbps : Prescaler=38, Seg1=13, Seg2=4  (170MHz/38/18 = 248.9kbps ~ 250k)
  *   500 kbps : Prescaler=19, Seg1=13, Seg2=4  (170MHz/19/18 = 497.8kbps ~ 500k)
  *   1000 kbps: Prescaler=10, Seg1=13, Seg2=4  (170MHz/10/18 = 944kbps ~ close)
  *
  * SJW=4 gives +/-4 TQ resync tolerance — much better than the old SJW=1
  * which caused continuous Stuff/Form errors on noisy harnesses.
  */

/* *** CHANGE THIS ONE LINE to match your charger baud rate *** */
#define FDCAN_BAUD_RATE  500000U

#if   FDCAN_BAUD_RATE == 250000U
  #define FDCAN_NOM_PRESCALER  38U   /* 170MHz/38/18 = 248.9 kbps */
#elif FDCAN_BAUD_RATE == 500000U
  #define FDCAN_NOM_PRESCALER  19U   /* 170MHz/19/18 = 497.8 kbps */
#elif FDCAN_BAUD_RATE == 1000000U
  #define FDCAN_NOM_PRESCALER  10U   /* 170MHz/10/18 = 944.4 kbps */
#else
  #error "FDCAN_BAUD_RATE must be 250000, 500000, or 1000000"
#endif

void MX_FDCAN1_Init(void)
{
  hfdcan1.Instance = FDCAN1;
  hfdcan1.Init.ClockDivider       = FDCAN_CLOCK_DIV1;
  hfdcan1.Init.FrameFormat        = FDCAN_FRAME_CLASSIC;
  hfdcan1.Init.Mode               = FDCAN_MODE_NORMAL;
  hfdcan1.Init.AutoRetransmission = ENABLE;
  hfdcan1.Init.TransmitPause      = DISABLE;
  hfdcan1.Init.ProtocolException  = DISABLE;

  /* 18 TQ total: 1 sync + Seg1=13 + Seg2=4, sample at 77.8%, SJW=4 */
  hfdcan1.Init.NominalPrescaler     = FDCAN_NOM_PRESCALER;
  hfdcan1.Init.NominalSyncJumpWidth = 4U;
  hfdcan1.Init.NominalTimeSeg1      = 13U;
  hfdcan1.Init.NominalTimeSeg2      = 4U;

  /* Unused in Classic CAN — safe defaults */
  hfdcan1.Init.DataPrescaler     = 1;
  hfdcan1.Init.DataSyncJumpWidth = 1;
  hfdcan1.Init.DataTimeSeg1      = 1;
  hfdcan1.Init.DataTimeSeg2      = 1;

  hfdcan1.Init.StdFiltersNbr    = 0;
  hfdcan1.Init.ExtFiltersNbr    = CANFILT_EXT_COUNT;
  hfdcan1.Init.TxFifoQueueMode  = FDCAN_TX_FIFO_OPERATION;

  if (HAL_FDCAN_Init(&hfdcan1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief  Configures hardware acceptance filters, the global filter,
  *         RX/TX-empty notifications, and starts FDCAN1.
  * @note   Call this AFTER canard is initialized and the node ID is set —
  *         same ordering as the original inline block in main() — so no
  *         frame can be handled before canardHandleRxFrame()'s target
  *         object exists.
  */
void FDCAN1_ConfigFiltersAndStart(void)
{
  FDCAN_FilterTypeDef sFilterConfig;

  /* Filter 0: Solterra Charger status broadcast — exact ID match only.
     MASK type with a full 29-bit mask (0x1FFFFFFF) means every bit of
     FilterID1 must match, i.e. only 0x18FF50E5 passes. */
  sFilterConfig.IdType       = FDCAN_EXTENDED_ID;
  sFilterConfig.FilterIndex  = CANFILT_IDX_CHARGER;
  sFilterConfig.FilterType   = FDCAN_FILTER_MASK;
  sFilterConfig.FilterConfig = FDCAN_FILTER_TO_RXFIFO0;
  sFilterConfig.FilterID1    = CHARGER_RX_ID_STATUS;
  sFilterConfig.FilterID2    = 0x1FFFFFFFUL;
  if (HAL_FDCAN_ConfigFilter(&hfdcan1, &sFilterConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /* Filter 1: Display ID range — explicitly rejected in hardware. This
     node only transmits to the display; nothing should legitimately
     arrive in this range. */
  sFilterConfig.IdType       = FDCAN_EXTENDED_ID;
  sFilterConfig.FilterIndex  = CANFILT_IDX_DISPLAY;
  sFilterConfig.FilterType   = FDCAN_FILTER_RANGE;
  sFilterConfig.FilterConfig = FDCAN_FILTER_REJECT;
  sFilterConfig.FilterID1    = DISPLAY_ID_RANGE_LOW;   /* 0x1FF710 */
  sFilterConfig.FilterID2    = DISPLAY_ID_RANGE_HIGH;  /* 0x1FF820 */
  if (HAL_FDCAN_ConfigFilter(&hfdcan1, &sFilterConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /* Filter 2: DroneCAN / UAVCAN v0
   * SAFETY CHANGE:
   * The previous implementation used a full 29-bit catch-all range
   * (0x00000000..0x1FFFFFFF). With charger connections, this can
   * unintentionally enqueue/dispatch a large amount of irrelevant CAN
   * traffic, starving the main loop and breaking CCCV timing.
   *
   * Limit DroneCAN acceptance to only the ID band this project actually
   * uses for DroneCAN transfers.
   *
   * If you change DroneCAN subject-ID ranges elsewhere, update the two
   * constants below to match.
   */
  #ifndef DRONECAN_ID_RANGE_LOW
  #define DRONECAN_ID_RANGE_LOW  0x18F00000UL
  #endif
  #ifndef DRONECAN_ID_RANGE_HIGH
  #define DRONECAN_ID_RANGE_HIGH 0x18FFFFFFUL
  #endif

  sFilterConfig.IdType       = FDCAN_EXTENDED_ID;
  sFilterConfig.FilterIndex  = CANFILT_IDX_DRONECAN;
  sFilterConfig.FilterType   = FDCAN_FILTER_RANGE;
  sFilterConfig.FilterConfig = FDCAN_FILTER_TO_RXFIFO0;
  sFilterConfig.FilterID1    = DRONECAN_ID_RANGE_LOW;
  sFilterConfig.FilterID2    = DRONECAN_ID_RANGE_HIGH;
  if (HAL_FDCAN_ConfigFilter(&hfdcan1, &sFilterConfig) != HAL_OK)
  {
    Error_Handler();
  }


  /* Anything that still doesn't match (stray 11-bit standard frame, or a
     remote frame) is dropped in hardware instead of overflowing RX FIFO0. */
  if (HAL_FDCAN_ConfigGlobalFilter(&hfdcan1,
                                    FDCAN_REJECT, FDCAN_REJECT,
                                    FDCAN_FILTER_REJECT, FDCAN_FILTER_REJECT
                                    ) != HAL_OK)
  {
    Error_Handler();
  }

  if (HAL_FDCAN_Start(&hfdcan1) != HAL_OK)
  {
    Error_Handler();
  }

  if (HAL_FDCAN_ActivateNotification(&hfdcan1, FDCAN_IT_RX_FIFO0_NEW_MESSAGE, 0) != HAL_OK)
  {
    Error_Handler();
  }

  if (HAL_FDCAN_ActivateNotification(&hfdcan1, FDCAN_IT_TX_FIFO_EMPTY, 0) != HAL_OK)
  {
    Error_Handler();
  }
}

/* ------------------------------------------------------------------------ */
/* Transmit helpers                                                          */
/*                                                                            */
/* NOTE on DataLength: this project's HAL (stm32g4xx_hal_fdcan.h) defines    */
/* FDCAN_DLC_BYTES_n as the raw byte count (0..8), NOT byte-count<<16. Do    */
/* not "correct" this to a shifted encoding — that would program invalid    */
/* DLCs on this HAL version.                                                 */
/* ------------------------------------------------------------------------ */

static uint8_t FDCAN_TransmitClassicExt(uint32_t ext_id, uint8_t *data, uint8_t len)
{
  FDCAN_TxHeaderTypeDef TxHeader;

  if (len > 8U)
  {
    return 0U;
  }

  TxHeader.Identifier          = ext_id & 0x1FFFFFFFUL;
  TxHeader.IdType              = FDCAN_EXTENDED_ID;
  TxHeader.TxFrameType         = FDCAN_DATA_FRAME;
  TxHeader.DataLength          = (uint32_t)len;   /* raw byte count on this HAL — see note above */
  TxHeader.ErrorStateIndicator = FDCAN_ESI_ACTIVE;
  TxHeader.BitRateSwitch       = FDCAN_BRS_OFF;        /* no slave here supports CAN FD */
  TxHeader.FDFormat            = FDCAN_CLASSIC_CAN;    /* Classic CAN 2.0B only */
  TxHeader.TxEventFifoControl  = FDCAN_NO_TX_EVENTS;
  TxHeader.MessageMarker       = 0;

  if (HAL_FDCAN_GetTxFifoFreeLevel(&hfdcan1) == 0U)
  {
    return 0U;
  }

  return (HAL_FDCAN_AddMessageToTxFifoQ(&hfdcan1, &TxHeader, data) == HAL_OK) ? 1U : 0U;
}

uint8_t Transmit_DroneCAN_Msg(uint32_t ext_id, uint8_t *data, uint8_t len)
{
  return FDCAN_TransmitClassicExt(ext_id, data, len);
}

uint8_t Transmit_Charger_Msg(uint32_t ext_id, uint8_t *data, uint8_t len)
{
  return FDCAN_TransmitClassicExt(ext_id, data, len);
}

uint8_t Transmit_Display_Msg(uint32_t ext_id, uint8_t *data, uint8_t len)
{
  return FDCAN_TransmitClassicExt(ext_id, data, len);
}

/* ------------------------------------------------------------------------ */
/* Bus health / bus-off recovery                                            */
/*                                                                            */
/* Design intent: a physical-layer CAN fault (bus disconnected, another     */
/* node at the wrong bit rate, an EMI burst, a short) must never become a   */
/* BMS fault. This function only ever touches the FDCAN peripheral itself   */
/* — it does not call Error_Handler(), does not reset the MCU, and does    */
/* not touch canard's node state. Worst case if recovery itself fails: CAN */
/* traffic stays down and this function quietly retries next second: the   */
/* voltage/current/temp monitoring and fault detection loop in main.c does */
/* not depend on FDCAN in any way and keeps running regardless.             */
/*                                                                            */
/* WHY THIS CHANGED — "CAN hang requiring a manual BMS reset" ─────────────  */
/* The original version only recovered on a formal Bus_Off (TEC/REC        */
/* latching the hardware's own BOFF bit). Its comment assumed Error_Passive */
/* "rides itself out" via AutoRetransmission and needs no help. That's true */
/* for a SHORT burst of errors, but if whatever is causing them is          */
/* continuous (a node at a slightly wrong bit rate, sustained EMI, a        */
/* marginal termination/impedance issue that gets worse under load), the    */
/* error counters can hover in the 128-255 range indefinitely — Error_      */
/* Passive persists, TX/RX both degrade badly, but the hardware never       */
/* crosses the exact 256 threshold that would set BOFF and trigger the old  */
/* recovery path. From the outside that looks exactly like "CAN hung" —     */
/* because it effectively has — and only a full reset (which re-inits the   */
/* peripheral from a clean TEC/REC state) would clear it. Recovering on     */
/* SUSTAINED Error_Passive (not just BusOff) closes that gap: if the        */
/* module has been continuously Error_Passive for                          */
/* FDCAN_ERROR_PASSIVE_RECOVERY_S consecutive HealthCheck calls (~seconds,  */
/* since this is called once per second from main.c's 1 Hz block), the same */
/* Stop/Start cycle used for Bus_Off is applied. A transient few-hundred-ms  */
/* Error_Passive blip (a real burst that DOES self-heal) will not trigger   */
/* this — the counter resets to 0 the instant the module reports healthy   */
/* again. */
/* Reduced to 1s: charger EMI bursts cause sustained Error_Passive that
 * must be cleared before the IWDG fires (~4s). The HealthCheck is called
 * once per second from the 1Hz block, so 1 = recover after 1 second of
 * continuous Error_Passive — fast enough to survive a charger EMI burst
 * without triggering IWDG reset. */
#define FDCAN_ERROR_PASSIVE_RECOVERY_S 1U

static uint32_t s_errorPassiveSeconds = 0;

bool FDCAN1_HealthCheck(void)
{
  FDCAN_ProtocolStatusTypeDef st;

  if (HAL_FDCAN_GetProtocolStatus(&hfdcan1, &st) != HAL_OK)
  {
    /* Transient register read issue — do nothing, try again next second.
       Never escalate a status-read failure into a system-wide action. */
    return false;
  }

  bool needs_recovery = false;

  if (st.BusOff != 0U)
  {
    needs_recovery = true;
    s_errorPassiveSeconds = 0;
  }
  else if (st.ErrorPassive != 0U)
  {
    /* Sustained (not merely momentary) Error_Passive — see comment block
       above for why this needs its own recovery path, separate from
       Bus_Off. */
    if (s_errorPassiveSeconds < 0xFFFFFFFFU)
    {
      s_errorPassiveSeconds++;
    }
    if (s_errorPassiveSeconds >= FDCAN_ERROR_PASSIVE_RECOVERY_S)
    {
      needs_recovery = true;
      s_errorPassiveSeconds = 0;
    }
  }
  else
  {
    /* Healthy, or merely Error_Warning — that one genuinely does ride
       itself out with no help, per the original design intent. */
    s_errorPassiveSeconds = 0;
  }

  if (!needs_recovery)
  {
    return false; /* healthy (or not yet past the sustained-error threshold) */
  }

  /* Bus_Off: hardware has unlatched itself from the bus. Stop/Start cycles
   * the peripheral through CCCR.INIT, which is what actually re-arms the
   * FDCAN core's own bus-off recovery sequence (128 x 11 consecutive
   * recessive bits) — this does NOT require reconfiguring filters, which
   * remain programmed in Message RAM across Stop/Start.
   *
   * Sustained Error_Passive: the same Stop/Start also resets TEC/REC to
   * a clean state, which is the only thing a manual BMS reset was
   * actually doing differently before this fix. */
  (void)HAL_FDCAN_Stop(&hfdcan1);

  if (HAL_FDCAN_Start(&hfdcan1) != HAL_OK)
  {
    /* Recovery attempt itself failed (e.g. bus still shorted). Do NOT call
       Error_Handler() — just leave FDCAN down and retry next second. */
    return false;
  }


  /* Some HAL versions clear notification enables across Stop(); re-arm
     unconditionally rather than assuming either behavior. 

     IMPORTANT: We only rely on RX FIFO0 interrupts for recovery.
     TX draining remains driven by main-loop / TX-empty ISR.
     Missing TX-empty notifications should not freeze the system
     (Process_CAN_Tx() is called continuously in main()). */
  (void)HAL_FDCAN_ActivateNotification(&hfdcan1, FDCAN_IT_RX_FIFO0_NEW_MESSAGE, 0);



  s_busOffRecoveryCount++;
  return true;
}

uint32_t FDCAN1_GetBusOffRecoveryCount(void)
{
  return s_busOffRecoveryCount;
}

uint32_t FDCAN1_GetErrorPassiveSeconds(void)
{
  return s_errorPassiveSeconds;
}
