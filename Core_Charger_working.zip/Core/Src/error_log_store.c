/**
 * @file    error_log_store.c
 * @brief   Error Log RingBuffer storage implementation
 */

#include "error_log_store.h"
#include "flash_map.h"
#include "w25q64.h"
#include <string.h>

#define ERROR_LOG_MAGIC 0x4552524CU /* "ERRL" */

/**
 * @brief Internal structure saved to flash.
 */
typedef struct {
  uint32_t magic;
  uint32_t head;  /* Index where the next write should happen */
  uint32_t count; /* Number of valid entries (0 to ERROR_LOG_MAX_ENTRIES) */
  ErrorLog_Entry_t entries[ERROR_LOG_MAX_ENTRIES];
  uint32_t crc32;
} ErrorLog_StoreData_t;

static QSPI_HandleTypeDef *sQspiHandle = NULL;
static ErrorLog_StoreData_t sLogStore;

/* ========================================================================== */
/*                       Software CRC-32 */
/* ========================================================================== */

static uint32_t ErrorLog_CRC32(const uint8_t *data, uint32_t length) {
  uint32_t crc = 0xFFFFFFFFU;
  for (uint32_t i = 0; i < length; i++) {
    crc ^= (uint32_t)data[i];
    for (int j = 0; j < 8; j++) {
      if (crc & 1U) {
        crc = (crc >> 1) ^ 0xEDB88320U;
      } else {
        crc >>= 1;
      }
    }
  }
  return crc ^ 0xFFFFFFFFU;
}

/* ========================================================================== */
/*                       Internal Methods */
/* ========================================================================== */

static bool ErrorLog_SaveToFlash(void) {
  if (sQspiHandle == NULL)
    return false;

  /* Compute CRC */
  uint32_t crc_len =
      (uint32_t)((uintptr_t)&sLogStore.crc32 - (uintptr_t)&sLogStore);
  sLogStore.crc32 = ErrorLog_CRC32((const uint8_t *)&sLogStore, crc_len);

  /* Structure size is around 6.4KB, requires erasing 2 sectors of 4KB */
  if (W25Q64_EraseSector(sQspiHandle, FLASH_PART_2_START) != W25Q64_OK)
    return false;
  if (W25Q64_EraseSector(sQspiHandle,
                         FLASH_PART_2_START + W25Q64_SECTOR_SIZE) != W25Q64_OK)
    return false;

  /* Write struct across pages */
  if (W25Q64_Write(sQspiHandle, (const uint8_t *)&sLogStore, FLASH_PART_2_START,
                   sizeof(ErrorLog_StoreData_t)) != W25Q64_OK) {
    return false;
  }

  return true;
}

static void ErrorLog_FormatEmpty(void) {
  memset(&sLogStore, 0, sizeof(sLogStore));
  sLogStore.magic = ERROR_LOG_MAGIC;
  sLogStore.head = 0;
  sLogStore.count = 0;
}

/* ========================================================================== */
/*                       Public API */
/* ========================================================================== */

bool ErrorLog_Init(QSPI_HandleTypeDef *hqspi) {
  sQspiHandle = hqspi;

  if (W25Q64_Init(hqspi) != W25Q64_OK) {
    return false;
  }

  /* Read from flash */
  if (W25Q64_Read(sQspiHandle, (uint8_t *)&sLogStore, FLASH_PART_2_START,
                  sizeof(ErrorLog_StoreData_t)) != W25Q64_OK) {
    ErrorLog_FormatEmpty();
    return false; /* Read failed, fall back to empty */
  }

  /* Validate CRC and Magic */
  if (sLogStore.magic != ERROR_LOG_MAGIC) {
    ErrorLog_FormatEmpty();
    return true; /* Not initialized in flash, start fresh */
  }

  uint32_t crc_len =
      (uint32_t)((uintptr_t)&sLogStore.crc32 - (uintptr_t)&sLogStore);
  uint32_t computed = ErrorLog_CRC32((const uint8_t *)&sLogStore, crc_len);

  if (computed != sLogStore.crc32) {
    ErrorLog_FormatEmpty();
    return true; /* Corrupted flash data, start fresh */
  }

  /* Ensure counts are within bounds */
  if (sLogStore.count > ERROR_LOG_MAX_ENTRIES) {
    sLogStore.count = ERROR_LOG_MAX_ENTRIES;
  }
  if (sLogStore.head >= ERROR_LOG_MAX_ENTRIES) {
    sLogStore.head = 0;
  }

  return true;
}

extern RTC_HandleTypeDef hrtc;

bool ErrorLog_Add(const char *message) {
  if (sQspiHandle == NULL)
    return false;

  uint32_t idx = sLogStore.head;

  RTC_TimeTypeDef sTime = {0};
  RTC_DateTypeDef sDate = {0};
  HAL_RTC_GetTime(&hrtc, &sTime, RTC_FORMAT_BIN);
  HAL_RTC_GetDate(&hrtc, &sDate, RTC_FORMAT_BIN);

  sLogStore.entries[idx].timestamp.year = sDate.Year;
  sLogStore.entries[idx].timestamp.month = sDate.Month;
  sLogStore.entries[idx].timestamp.date = sDate.Date;
  sLogStore.entries[idx].timestamp.hours = sTime.Hours;
  sLogStore.entries[idx].timestamp.minutes = sTime.Minutes;
  sLogStore.entries[idx].timestamp.seconds = sTime.Seconds;

  strncpy(sLogStore.entries[idx].message, message, ERROR_LOG_MSG_MAX_LEN - 1);
  sLogStore.entries[idx].message[ERROR_LOG_MSG_MAX_LEN - 1] =
      '\0'; /* Ensure null termination */

  sLogStore.head = (sLogStore.head + 1) % ERROR_LOG_MAX_ENTRIES;

  if (sLogStore.count < ERROR_LOG_MAX_ENTRIES) {
    sLogStore.count++;
  }

  return ErrorLog_SaveToFlash();
}

uint32_t ErrorLog_GetCount(void) { return sLogStore.count; }

bool ErrorLog_GetEntry(uint32_t index, ErrorLog_Entry_t *out_entry) {
  if (index >= sLogStore.count || out_entry == NULL) {
    return false;
  }

  /*
   * The oldest entry is at (head - count) modulo MAX_ENTRIES.
   * We need to properly wrap around depending on head and count.
   */
  uint32_t oldest_idx;
  if (sLogStore.count < ERROR_LOG_MAX_ENTRIES) {
    oldest_idx = 0;
  } else {
    oldest_idx = sLogStore.head;
  }

  uint32_t absolute_idx = (oldest_idx + index) % ERROR_LOG_MAX_ENTRIES;

  *out_entry = sLogStore.entries[absolute_idx];
  return true;
}

bool ErrorLog_Clear(void) {
  ErrorLog_FormatEmpty();
  return ErrorLog_SaveToFlash();
}
