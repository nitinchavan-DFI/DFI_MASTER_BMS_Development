/**
 * @file    daly_ekf.c
 * @brief   Double Kalman Filter + 100-sample median for Daly BMS cell voltages
 * @details Per-cell cascade: 100-sample median -> Fast KF -> Slow KF -> blended output.
 *          Fast KF tracks true voltage; Slow KF estimates long-term drift.
 *          Output = Fast - alpha*(Fast - Slow)  removes bias while keeping response.
 */

#include "daly_ekf.h"
#include <math.h>
#include <string.h>

/* -------------------------------------------------------------------------- */
/*  Kalman tuning                                                             */
/* -------------------------------------------------------------------------- */

/* Fast KF: moderate process noise, higher measurement noise (follows median) */
#define EKF_Q_FAST   0.0001f     /* Process noise (V^2)  */
#define EKF_R_FAST   0.0004f     /* Measurement noise ~20 mV RMS -> var=0.0004 V^2 */

/* Slow KF: very low process noise, rejects spikes, tracks drift */
#define EKF_Q_SLOW   0.000001f   /* 1e-6 V^2  */
#define EKF_R_SLOW   0.0001f     /* 10 mV RMS -> var=0.0001 V^2 */

/* Blend factor for drift removal (0 = pure fast, 1 = pure slow) */
#define EKF_DRIFT_ALPHA  0.15f

/* -------------------------------------------------------------------------- */
/*  Private helpers                                                           */
/* -------------------------------------------------------------------------- */

/**
 * @brief Single scalar Kalman filter update step.
 */
static inline float kalman_step(float x, float P, float z,
                                float Q, float R, float *P_out)
{
    /* Predict */
    float P_pred = P + Q;
    /* Update */
    float S = P_pred + R;
    float K = (S > 1e-12f) ? (P_pred / S) : 0.0f;
    float x_new = x + K * (z - x);
    float P_new = (1.0f - K) * P_pred;
    *P_out = P_new;
    return x_new;
}

/**
 * @brief Median of 100 floats using insertion sort on a local copy.
 *        100 elements -> trivial CPU load on STM32G4 @ 170 MHz.
 */
static float median_100(const float *arr)
{
    static float sorted[DALY_EKF_MEDIAN_LEN];
    memcpy(sorted, arr, sizeof(sorted));

    /* Insertion sort - O(n^2) but n=100 and nearly-sorted -> ~µs */
    for (int i = 1; i < DALY_EKF_MEDIAN_LEN; i++) {
        float key = sorted[i];
        int j = i - 1;
        while (j >= 0 && sorted[j] > key) {
            sorted[j + 1] = sorted[j];
            j--;
        }
        sorted[j + 1] = key;
    }
    /* Even count: average of two middle elements */
    return (sorted[DALY_EKF_MEDIAN_HALF - 1] + sorted[DALY_EKF_MEDIAN_HALF]) * 0.5f;
}

/* -------------------------------------------------------------------------- */
/*  Public API                                                                */
/* -------------------------------------------------------------------------- */

void DalyEKF_Init(DalyEKF_Handle_t *hek)
{
    memset(hek, 0, sizeof(*hek));
    hek->active_cells = 0;

    /* Seed Kalman states to typical Li-ion mid-point */
    for (int i = 0; i < DALY_EKF_MAX_CELLS; i++) {
        hek->x_fast[i]   = 3.7f;
        hek->P_fast[i]   = 1.0f;
        hek->x_slow[i]   = 3.7f;
        hek->P_slow[i]   = 1.0f;
        hek->filtered_v[i] = 3.7f;
    }
}

void DalyEKF_SetCellCount(DalyEKF_Handle_t *hek, uint8_t ncells)
{
    if (ncells > DALY_EKF_MAX_CELLS) {
        ncells = DALY_EKF_MAX_CELLS;
    }
    if (ncells == hek->active_cells) {
        return;
    }

    /* Reset buffers and filters when cell count changes */
    memset(hek->raw_buffer, 0, sizeof(hek->raw_buffer));
    memset(hek->buf_head,   0, sizeof(hek->buf_head));
    memset(hek->buf_count,  0, sizeof(hek->buf_count));

    for (int i = 0; i < DALY_EKF_MAX_CELLS; i++) {
        hek->x_fast[i]     = 3.7f;
        hek->P_fast[i]     = 1.0f;
        hek->x_slow[i]     = 3.7f;
        hek->P_slow[i]     = 1.0f;
        hek->filtered_v[i] = 3.7f;
    }

    hek->active_cells = ncells;
    hek->update_count = 0;
}

void DalyEKF_UpdateCell(DalyEKF_Handle_t *hek, uint8_t cell_idx, float raw_v)
{
    if (cell_idx >= hek->active_cells || cell_idx >= DALY_EKF_MAX_CELLS) {
        return;
    }

    /* --- 1. Push raw sample into circular median buffer --- */
    uint16_t head = hek->buf_head[cell_idx];
    hek->raw_buffer[cell_idx][head] = raw_v;
    hek->buf_head[cell_idx] = (head + 1U) % DALY_EKF_MEDIAN_LEN;

    if (hek->buf_count[cell_idx] < DALY_EKF_MEDIAN_LEN) {
        hek->buf_count[cell_idx]++;
    }

    /* Not enough history yet: seed filters with raw value */
    if (hek->buf_count[cell_idx] < DALY_EKF_MEDIAN_LEN) {
        hek->x_fast[cell_idx]   = raw_v;
        hek->x_slow[cell_idx]   = raw_v;
        hek->filtered_v[cell_idx] = raw_v;
        return;
    }

    /* --- 2. Compute median of last 100 samples (outlier rejection) --- */
    float med = median_100(hek->raw_buffer[cell_idx]);

    /* --- 3. Fast Kalman: track true voltage with moderate smoothing --- */
    float P_new_fast;
    float xf = kalman_step(hek->x_fast[cell_idx], hek->P_fast[cell_idx],
                           med, EKF_Q_FAST, EKF_R_FAST, &P_new_fast);
    hek->x_fast[cell_idx] = xf;
    hek->P_fast[cell_idx] = P_new_fast;

    /* --- 4. Slow Kalman: track long-term average (drift/bias estimation) --- */
    float P_new_slow;
    float xs = kalman_step(hek->x_slow[cell_idx], hek->P_slow[cell_idx],
                           xf, EKF_Q_SLOW, EKF_R_SLOW, &P_new_slow);
    hek->x_slow[cell_idx] = xs;
    hek->P_slow[cell_idx] = P_new_slow;

    /* --- 5. Double-Kalman blend: remove slow drift, keep fast response --- */
    float drift = xf - xs;
    float out = xf - (EKF_DRIFT_ALPHA * drift);

    /* Hard physical limits for Li-ion/LiFePO4 cells */
    if (out < 2.0f)  out = 2.0f;
    if (out > 4.5f)  out = 4.5f;

    /* NaN/Inf guard: reset filters if corrupted */
    if (!isfinite(out)) {
        out = raw_v;
        hek->x_fast[cell_idx]   = raw_v;
        hek->P_fast[cell_idx]   = 1.0f;
        hek->x_slow[cell_idx]   = raw_v;
        hek->P_slow[cell_idx]   = 1.0f;
    }

    hek->filtered_v[cell_idx] = out;
    hek->update_count++;
}

float DalyEKF_GetCellVoltage(const DalyEKF_Handle_t *hek, uint8_t cell_idx)
{
    if (cell_idx >= hek->active_cells) {
        return 0.0f;
    }
    return hek->filtered_v[cell_idx];
}
