#include "led_status.h"

/* Internal State Variables */
static SystemState_t current_sys_state = SYS_STATE_IDLE;
static uint8_t current_soc = 0;
static LedError_t current_error = LED_ERR_NONE;
static bool has_generic_fault = false;

/* Time tracking for blinking */
static uint32_t tick_100ms = 0;

/* ---- LED Rest Mode (idle sleep) ---- */
static bool led_sleeping = false;
static uint32_t idle_counter_100ms = 0;
static uint32_t idle_timeout_100ms = 600; /* 120 s × 10 = 1200 ticks (2 min) */
uint8_t red = 0;
uint8_t green = 0;
uint8_t blue = 0;

/**
 * @brief Helper to set the RGB Status LED (D22).
 */
static void Set_RGB(GPIO_PinState r, GPIO_PinState g, GPIO_PinState b) {

  red = r;
  green = g;
  blue = b;
  HAL_GPIO_WritePin(RED_LED_GPIO_Port, RED_LED_Pin, r);
  HAL_GPIO_WritePin(GREEN_LED_GPIO_Port, GREEN_LED_Pin, g);
  HAL_GPIO_WritePin(BLUE_LED_GPIO_Port, BLUE_LED_Pin, b);
}

uint8_t led1 = 0;
uint8_t led2 = 0;
uint8_t led3 = 0;
uint8_t led4 = 0;
/**
 * @brief Helper to set the SOC/Error indicator LEDs (D11, D10, D9, D8).
 */
static void Set_SOC_LEDs(GPIO_PinState d11, GPIO_PinState d10, GPIO_PinState d9,
                         GPIO_PinState d8) {
  /* Active-low: invert logic so callers use SET = ON, RESET = OFF */
  HAL_GPIO_WritePin(LED4_D11_GPIO_Port, LED4_D11_Pin, !d11);
  HAL_GPIO_WritePin(LED3_D10_GPIO_Port, LED3_D10_Pin, !d10);
  HAL_GPIO_WritePin(LED2_D9_GPIO_Port, LED2_D9_Pin, !d9);
  HAL_GPIO_WritePin(LED1_D8_GPIO_Port, LED1_D8_Pin, !d8);

  led1 = d8;
  led2 = d9;
  led3 = d10;
  led4 = d11;
}

/**
 * @brief Turn all LEDs OFF (RGB + SOC bar).
 */
static void All_LEDs_Off(void) {
  Set_RGB(GPIO_PIN_SET, GPIO_PIN_SET,
          GPIO_PIN_SET); /* Active-low: HIGH = OFF */
  Set_SOC_LEDs(GPIO_PIN_RESET, GPIO_PIN_RESET, GPIO_PIN_RESET, GPIO_PIN_RESET);
}

void LedStatus_Init(void) { All_LEDs_Off(); }

void LedStatus_SetSystemState(SystemState_t state) {
  current_sys_state = state;
}

void LedStatus_SetSoc(uint8_t soc) { current_soc = soc; }

void LedStatus_SetError(LedError_t error) { current_error = error; }

void LedStatus_SetGenericFault(bool has_fault) {
  has_generic_fault = has_fault;
}

void LedStatus_Wake(void) {
  led_sleeping = false;
  idle_counter_100ms = 0;
}

void LedStatus_SetIdleTimeout(uint32_t seconds) {
  idle_timeout_100ms = seconds * 10u;
}

void LedStatus_Update100ms(void) {
  tick_100ms++;

  /* ---- LED Rest Mode logic ---- */
  bool is_active = (current_sys_state != SYS_STATE_IDLE) || has_generic_fault ||
                   (current_sys_state == SYS_STATE_FAULT);

  if (is_active) {
    /* System is active — reset idle timer, wake up if sleeping */
    idle_counter_100ms = 0;
    led_sleeping = false;
  } else {
    /* System is idle — count towards timeout */
    if (idle_timeout_100ms > 0 && !led_sleeping) {
      idle_counter_100ms++;
      if (idle_counter_100ms >= idle_timeout_100ms) {
        led_sleeping = true;
      }
    }
  }

  /* If sleeping, force all LEDs OFF and skip normal display */
  if (led_sleeping) {
    All_LEDs_Off();
    return;
  }

  /* --- Update RGB Status LED (Table 3) --- */
  if (current_sys_state == SYS_STATE_FAULT) {
    /* Static RED for FAULT state */
    Set_RGB(GPIO_PIN_RESET, GPIO_PIN_SET,
            GPIO_PIN_SET); /* RED ON (active-low) */
  } else {
    if (has_generic_fault) {
      /* Toggle RED if generic fault present. Blink rate: 200ms ON, 200ms OFF
       * (2.5 Hz) — fast blink for <5 s fault visibility */
      if ((tick_100ms % 4) < 2) {
        Set_RGB(GPIO_PIN_RESET, GPIO_PIN_SET,
                GPIO_PIN_SET); /* RED (active-low) */
      } else {
        //				if (current_sys_state == SYS_STATE_IDLE)
        //{ 					Set_RGB(GPIO_PIN_RESET,
        // GPIO_PIN_RESET, GPIO_PIN_SET); /* BLUE */ } else {
        // Set_RGB(GPIO_PIN_RESET, GPIO_PIN_SET, GPIO_PIN_RESET); /* GREEN
        //*/
        //				}
        Set_RGB(GPIO_PIN_SET, GPIO_PIN_SET,
                GPIO_PIN_SET); /* OFF (active-low) */
      }
    } else {
      /* Static normal colors */
      if (current_sys_state == SYS_STATE_IDLE) {
        Set_RGB(GPIO_PIN_SET, GPIO_PIN_SET,
                GPIO_PIN_RESET); /* BLUE (active-low) */
      } else if (current_sys_state == SYS_STATE_DRIVE || current_sys_state == SYS_STATE_CHARGE) {
        Set_RGB(GPIO_PIN_SET, GPIO_PIN_RESET, GPIO_PIN_SET); /* GREEN ON active-low: GREEN low=ON */
      } else {
        /* IDLE -> BLUE only */
        Set_RGB(GPIO_PIN_SET, GPIO_PIN_SET, GPIO_PIN_RESET); /* BLUE ON */
      }
    }
  }

  /* --- Update SOC Indicator / Error Code (Tables 4, 5) --- */
  if (current_error != LED_ERR_NONE) {
    /* Error Code takes precedence (Table 5) */
    switch (current_error) {
    case LED_ERR_OVERVOLTAGE:
      Set_SOC_LEDs(GPIO_PIN_RESET, GPIO_PIN_RESET, GPIO_PIN_RESET,
                   GPIO_PIN_SET);
      break;
    case LED_ERR_UNDERVOLTAGE:
      Set_SOC_LEDs(GPIO_PIN_RESET, GPIO_PIN_RESET, GPIO_PIN_SET, GPIO_PIN_SET);
      break;
    case LED_ERR_OVERCURRENT:
      Set_SOC_LEDs(GPIO_PIN_RESET, GPIO_PIN_RESET, GPIO_PIN_SET,
                   GPIO_PIN_RESET);
      break;
    case LED_ERR_SEVERE_CELL_DISBALANCE:
      Set_SOC_LEDs(GPIO_PIN_SET, GPIO_PIN_RESET, GPIO_PIN_RESET, GPIO_PIN_SET);
      break;
    case LED_ERR_OVERTEMPERATURE:
      Set_SOC_LEDs(GPIO_PIN_RESET, GPIO_PIN_SET, GPIO_PIN_RESET,
                   GPIO_PIN_RESET);
      break;
    case LED_ERR_UNDERTEMPERATURE:
      Set_SOC_LEDs(GPIO_PIN_RESET, GPIO_PIN_SET, GPIO_PIN_RESET, GPIO_PIN_SET);
      break;
    case LED_ERR_THERMISTOR_NOT_CONNECTED:
      Set_SOC_LEDs(GPIO_PIN_SET, GPIO_PIN_RESET, GPIO_PIN_RESET,
                   GPIO_PIN_RESET);
      break;
    case LED_ERR_OVERTEMPERATURE2:
      Set_SOC_LEDs(GPIO_PIN_SET, GPIO_PIN_SET, GPIO_PIN_RESET, GPIO_PIN_SET);
      break;
    case LED_ERR_UNDERTEMPERATURE2:
      Set_SOC_LEDs(GPIO_PIN_SET, GPIO_PIN_SET, GPIO_PIN_SET, GPIO_PIN_RESET);
      break;
    case LED_ERR_THERMISTOR2_NOT_CONNECTED:
      Set_SOC_LEDs(GPIO_PIN_SET, GPIO_PIN_SET, GPIO_PIN_SET, GPIO_PIN_SET);
      break;
    default:
      break;
    }
  } else {
    /* Show SOC (Table 4) */
    if (current_soc < 15) {
      Set_SOC_LEDs(GPIO_PIN_SET, GPIO_PIN_RESET, GPIO_PIN_RESET,
                   GPIO_PIN_RESET);
    } else if (current_soc < 50) {
      Set_SOC_LEDs(GPIO_PIN_SET, GPIO_PIN_SET, GPIO_PIN_RESET, GPIO_PIN_RESET);
    } else if (current_soc < 75) {
      Set_SOC_LEDs(GPIO_PIN_SET, GPIO_PIN_SET, GPIO_PIN_SET, GPIO_PIN_RESET);
    } else {
      Set_SOC_LEDs(GPIO_PIN_SET, GPIO_PIN_SET, GPIO_PIN_SET, GPIO_PIN_SET);
    }
  }
}

void LedStatus_TIM_Callback(TIM_HandleTypeDef *htim) {
  /* Wait for 100ms TIM interval */
  /* Example: Assuming TIM15 is configured for 100ms interrupts */
  if (htim->Instance == TIM15) {
    LedStatus_Update100ms();
  }
}
