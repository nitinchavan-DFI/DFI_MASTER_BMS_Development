/**
 * @file    daly_bms.c
 * @brief   Daly BMS UART Driver — Non-Blocking Interrupt-Driven State Machine
 *
 * PARSING ALIGNED WITH PYTHON REFERENCE (daly_protocol_full.py)
 * ==============================================================
 *
 * Command sequence (matches Python CMD_SOC / CMD_TEMP / CMD_CELL_V):
 *   [0] 0x90 → Pack voltage / current / SOC
 *   [1] 0x92 → Temperature              (was 0x91 — now corrected)
 *   [2] 0x95 → Cell voltages (multi-frame)
 *
 * 0x91 (min/max cell) is NOT queried.
 *   Python derives min/max/delta from the cell_voltages array.
 *   We do the same: after every complete 0x95 cycle, DalyBMS_UpdateCellStats()
 *   scans cellVmV[] and writes minCellmV, maxCellmV, cellDiff.
 *   This eliminates the source of −3249 mV cell-diff readings in the log.
 *
 * Key parsing fixes vs previous version:
 *   [FIX-1] 0x90: pack voltage range guard before KF; KF seeded on first
 *           valid reading (not 0.0f) → eliminates 1084V ADC runaway.
 *   [FIX-2] 0x92: temperature now parsed as rxBuffer[4] − 40 (Python rule).
 *   [FIX-3] 0x95: frame_num read from rxBuffer[4]; handles 0/0xFF edge
 *           cases; base_idx = (frame_num−1)×3 — matches Python exactly.
 *   [FIX-4] Stream sync: DalyBMS_ValidateFrame() checks start byte,
 *           data-length byte (frame[3]==0x08), and checksum.
 *           If rxBuffer[0] != 0xA5 the frame is scanned for the sync byte
 *           before parsing begins.
 *   [FIX-5] Min/max/diff derived from 0x95 cell array, never from 0x91.
 *
 * Timeout recovery uses *blocking* HAL_UART_AbortReceive() to avoid
 * HAL_BUSY races that previously caused BMS hangs.
 */

#include "daly_bms.h"
#include <math.h>
#include <string.h>

/* -------------------------------------------------------------------------- */
/*  Command sequence — matches Python CMD_SOC / CMD_TEMP / CMD_CELL_V         */
/* -------------------------------------------------------------------------- */

static const DalyBMS_Command_t cmdSequence[DALY_NUM_QUERY_CMDS] = {
    DALY_CMD_VOUT_IOUT_SOC,   /* 0x90 — pack V / I / SOC                    */
    DALY_CMD_TEMPERATURE,     /* 0x92 — BMS temperature  (was 0x91: FIXED)  */
    DALY_CMD_CELL_VOLTAGES,   /* 0x95 — per-cell voltages, 3 per frame       */
};

/* -------------------------------------------------------------------------- */
/*  Forward declarations                                                       */
/* -------------------------------------------------------------------------- */

static void DalyBMS_BuildAndSend(DalyBMS_Handle_t *hbms, DalyBMS_Command_t cmd);
static void DalyBMS_StartRxIT(DalyBMS_Handle_t *hbms);
static bool DalyBMS_ValidateChecksum(const uint8_t *buf, uint8_t len);
static bool DalyBMS_SyncAndValidate(DalyBMS_Handle_t *hbms);
static void DalyBMS_ParseResponse(DalyBMS_Handle_t *hbms);
static void DalyBMS_AdvanceToNextCommand(DalyBMS_Handle_t *hbms);
static uint8_t DalyBMS_CalcFrames(DalyBMS_Handle_t *hbms, DalyBMS_Command_t cmd);
static void DalyBMS_UpdateCellStats(DalyBMS_Handle_t *hbms);

/* Per-command parsers */
static void Parse_0x90(DalyBMS_Handle_t *hbms);   /* Pack V / I / SOC   */
static void Parse_0x92(DalyBMS_Handle_t *hbms);   /* Temperature        */
static void Parse_0x95_Frame(DalyBMS_Handle_t *hbms); /* Cell voltages  */

/* -------------------------------------------------------------------------- */
/*  Validators (public — also used by unit tests)                             */
/* -------------------------------------------------------------------------- */

bool DalyBMS_ValidateCellVoltage(float raw_mv) {
    return (raw_mv >= DALY_CELL_V_MIN_MV) && (raw_mv <= DALY_CELL_V_MAX_MV);
}

/**
 * @brief  Full frame validator.
 *         Checks: start byte (A5), data-length byte (08), checksum.
 *         Python equivalent: checks buffer[0]==0xA5, frame[3]==0x08,
 *         sum(frame[:12]) & 0xFF == frame[12].
 */
bool DalyBMS_ValidateFrame(const uint8_t *buf, uint8_t len) {
    if (len < DALY_XFER_BUFFER_LEN) return false;

    /* [PY-SYNC] Start byte */
    if (buf[0] != DALY_FRAME_START)     return false;

    /* [PY-LEN]  Data-length field — Python checks frame[3] == 0x08 */
    if (buf[3] != DALY_FRAME_DATA_LEN_BYTE) return false;

    /* [PY-CHK]  Checksum: sum(bytes[0..11]) & 0xFF == bytes[12] */
    return DalyBMS_ValidateChecksum(buf, len);
}

/* -------------------------------------------------------------------------- */
/*  Public API                                                                 */
/* -------------------------------------------------------------------------- */

bool DalyBMS_Init(DalyBMS_Handle_t *hbms, UART_HandleTypeDef *huart) {
    if (hbms == NULL || huart == NULL) return false;

    hbms->huart = huart;
    memset(&hbms->data, 0, sizeof(hbms->data));

    /* Pre-load fixed TX bytes */
    memset(hbms->txBuffer, 0, DALY_XFER_BUFFER_LEN);
    hbms->txBuffer[0] = DALY_FRAME_START;   /* 0xA5 */
    hbms->txBuffer[1] = DALY_HOST_ADDR;     /* 0x40 */
    hbms->txBuffer[3] = DALY_DATA_LEN;      /* 0x08 */

    /* State machine */
    hbms->state            = DALY_STATE_IDLE;
    hbms->currentCmdIndex  = 0;
    hbms->frameIndex       = 0;
    hbms->framesExpected   = 1;
    hbms->retryCount       = 0;
    hbms->rxStartTick      = 0;
    hbms->lastUpdateTick   = 0;
    hbms->cellVoltageIndex = 0;

    /* Flags */
    hbms->dataReady  = false;
    hbms->txComplete = false;
    hbms->rxComplete = false;
    hbms->rxError    = false;

    /* Counters */
    hbms->updateCount = 0;
    hbms->errorCount  = 0;

    /* EKF */
    DalyEKF_Init(&hbms->ekf);

    return true;
}

void DalyBMS_SetCellCount(DalyBMS_Handle_t *hbms, uint8_t ncells) {
    if (hbms == NULL) return;
    if (ncells < DALY_MIN_CELLS) ncells = DALY_MIN_CELLS;
    if (ncells > DALY_MAX_CELLS) ncells = DALY_MAX_CELLS;
    hbms->data.numberOfCells = ncells;
    DalyEKF_SetCellCount(&hbms->ekf, ncells);
}

void DalyBMS_Process(DalyBMS_Handle_t *hbms) {
    switch (hbms->state) {

    /* ------------------------------------------------------------------ */
    case DALY_STATE_IDLE: {
        uint32_t now = HAL_GetTick();
        if ((now - hbms->lastUpdateTick) >= DALY_UPDATE_INTERVAL_MS) {
            hbms->lastUpdateTick   = now;
            hbms->currentCmdIndex  = 0;
            hbms->retryCount       = 0;
            hbms->cellVoltageIndex = 0;

            DalyBMS_Command_t cmd = cmdSequence[hbms->currentCmdIndex];
            hbms->framesExpected  = DalyBMS_CalcFrames(hbms, cmd);
            hbms->frameIndex      = 0;

            DalyBMS_BuildAndSend(hbms, cmd);
            hbms->state = DALY_STATE_SENDING;
        }
        break;
    }

    /* ------------------------------------------------------------------ */
    case DALY_STATE_SENDING: {
        if (hbms->txComplete) {
            hbms->txComplete = false;
            DalyBMS_StartRxIT(hbms);
            hbms->state = DALY_STATE_WAIT_RX;
        }
        break;
    }

    /* ------------------------------------------------------------------ */
    case DALY_STATE_WAIT_RX: {
        if (hbms->rxError) {
            hbms->rxError = false;
            hbms->state   = DALY_STATE_ERROR;
            break;
        }

        if (hbms->rxComplete) {
            hbms->rxComplete = false;

            /* Full frame validation: sync byte + data-length + checksum  */
            /* [FIX-4] SyncAndValidate also handles misaligned stream     */
            if (!DalyBMS_SyncAndValidate(hbms)) {
                hbms->state = DALY_STATE_ERROR;
                break;
            }

            hbms->state = DALY_STATE_PARSING;
        }

        /* Timeout */
        if ((HAL_GetTick() - hbms->rxStartTick) > DALY_UART_TIMEOUT_MS) {
            /* Blocking abort cancels the IT-driven receive cleanly.
             * Also clear hardware error flags so the next StartRxIT call
             * gets HAL_OK — prevents the "permanent timeout loop" that
             * occurs when framing errors leave huart5 in a busy state. */
            HAL_UART_AbortReceive(hbms->huart);
            __HAL_UART_CLEAR_FLAG(hbms->huart,
                                  UART_CLEAR_PEF | UART_CLEAR_FEF |
                                  UART_CLEAR_NEF | UART_CLEAR_OREF);
            hbms->huart->ErrorCode = HAL_UART_ERROR_NONE;
            hbms->huart->gState    = HAL_UART_STATE_READY;
            hbms->huart->RxState   = HAL_UART_STATE_READY;
            hbms->state = DALY_STATE_ERROR;
        }
        break;
    }

    /* ------------------------------------------------------------------ */
    case DALY_STATE_INTERFRAME_GUARD: {
        if ((HAL_GetTick() - hbms->rxStartTick) >= DALY_INTERFRAME_GUARD_MS) {
            DalyBMS_StartRxIT(hbms);
            hbms->state = DALY_STATE_WAIT_RX;
        }
        break;
    }

    /* ------------------------------------------------------------------ */
    case DALY_STATE_PARSING: {
        DalyBMS_ParseResponse(hbms);

        hbms->frameIndex++;
        if (hbms->frameIndex < hbms->framesExpected) {
            /* More frames for this command (0x95 multi-frame) */
            hbms->rxStartTick = HAL_GetTick();
            hbms->state       = DALY_STATE_INTERFRAME_GUARD;
        } else {
            /* Command complete */
            DalyBMS_AdvanceToNextCommand(hbms);
        }
        break;
    }

    /* ------------------------------------------------------------------ */
    case DALY_STATE_COMPLETE: {
        /* [FIX-5] Derive min/max/diff from 0x95 cell array — NOT from 0x91 */
        DalyBMS_UpdateCellStats(hbms);

        hbms->dataReady = true;
        hbms->updateCount++;
        hbms->state = DALY_STATE_IDLE;
        break;
    }

    /* ------------------------------------------------------------------ */
    case DALY_STATE_ERROR: {
        hbms->errorCount++;
        hbms->retryCount++;

        if (hbms->retryCount < DALY_MAX_RETRIES) {
            /* Retry same command */
            DalyBMS_Command_t cmd = cmdSequence[hbms->currentCmdIndex];
            DalyBMS_BuildAndSend(hbms, cmd);
            hbms->state = DALY_STATE_SENDING;
        } else {
            /* Skip and advance */
            hbms->retryCount = 0;
            DalyBMS_AdvanceToNextCommand(hbms);
        }
        break;
    }

    default:
        /* ROBUSTNESS FIX: unknown state — reset SM immediately */
        HAL_UART_AbortReceive(hbms->huart);
        __HAL_UART_CLEAR_FLAG(hbms->huart,
                              UART_CLEAR_PEF | UART_CLEAR_FEF |
                              UART_CLEAR_NEF | UART_CLEAR_OREF);
        hbms->huart->ErrorCode = HAL_UART_ERROR_NONE;
        hbms->huart->gState    = HAL_UART_STATE_READY;
        hbms->huart->RxState   = HAL_UART_STATE_READY;
        hbms->state = DALY_STATE_IDLE;
        hbms->errorCount++;
        break;
    }

    /*
     * ROBUSTNESS FIX: SM global stuck-state watchdog.
     *
     * If the SM is not IDLE or COMPLETE for longer than the full poll
     * cycle (update interval + 3 × timeout = ~2.5 s), something has
     * gone wrong that the per-state logic didn't catch (e.g. txComplete
     * never firing, interframe guard expired in wrong state, etc.).
     * Force-abort and return to IDLE so the next update cycle starts clean.
     *
     * rxStartTick is updated at TX start and at RX arm, so it is a
     * reasonable proxy for "last time the SM made progress."
     */
#define DALY_SM_STUCK_TIMEOUT_MS     (DALY_UPDATE_INTERVAL_MS + (3U * DALY_UART_TIMEOUT_MS))  /* ~2.5 s */

    if (hbms->state != DALY_STATE_IDLE &&
        hbms->state != DALY_STATE_COMPLETE) {
        uint32_t stuck_ms = HAL_GetTick() - hbms->rxStartTick;
        if (stuck_ms > DALY_SM_STUCK_TIMEOUT_MS) {
            HAL_UART_AbortReceive(hbms->huart);
            __HAL_UART_CLEAR_FLAG(hbms->huart,
                                  UART_CLEAR_PEF | UART_CLEAR_FEF |
                                  UART_CLEAR_NEF | UART_CLEAR_OREF);
            hbms->huart->ErrorCode = HAL_UART_ERROR_NONE;
            hbms->huart->gState    = HAL_UART_STATE_READY;
            hbms->huart->RxState   = HAL_UART_STATE_READY;
            hbms->rxError          = false;
            hbms->rxComplete       = false;
            hbms->txComplete       = false;
            hbms->retryCount       = 0;
            hbms->lastUpdateTick   = HAL_GetTick(); /* re-arm update timer */
            hbms->state            = DALY_STATE_IDLE;
            hbms->errorCount++;
        }
    }
}

void DalyBMS_StartUpdate(DalyBMS_Handle_t *hbms) {
    if (hbms->state == DALY_STATE_IDLE) {
        hbms->lastUpdateTick = HAL_GetTick() - DALY_UPDATE_INTERVAL_MS;
    }
}

bool            DalyBMS_IsDataReady(DalyBMS_Handle_t *hbms) { return hbms->dataReady; }
void            DalyBMS_ClearDataReady(DalyBMS_Handle_t *hbms) { hbms->dataReady = false; }
DalyBMS_State_t DalyBMS_GetState(DalyBMS_Handle_t *hbms) { return hbms->state; }

bool DalyBMS_IsDataValid(DalyBMS_Handle_t *hbms) {
    return (hbms->updateCount > 0u)
        && (hbms->data.numberOfCells >= DALY_MIN_CELLS)
        && (hbms->data.numberOfCells <= DALY_MAX_CELLS);
}

/* FET control functions removed — software FET switching not used.
 * Hardware protection is handled by the Daly BMS module itself.        */

/* -------------------------------------------------------------------------- */
/*  UART interrupt callbacks                                                   */
/* -------------------------------------------------------------------------- */

void DalyBMS_TxCpltCallback(DalyBMS_Handle_t *hbms, UART_HandleTypeDef *huart) {
    if (huart->Instance == hbms->huart->Instance) hbms->txComplete = true;
}

void DalyBMS_RxCpltCallback(DalyBMS_Handle_t *hbms, UART_HandleTypeDef *huart) {
    if (huart->Instance == hbms->huart->Instance) hbms->rxComplete = true;
}

void DalyBMS_ErrorCallback(DalyBMS_Handle_t *hbms, UART_HandleTypeDef *huart) {
    if (huart->Instance == hbms->huart->Instance) hbms->rxError = true;
}

/* -------------------------------------------------------------------------- */
/*  Private: frame build & TX                                                  */
/* -------------------------------------------------------------------------- */

static void DalyBMS_BuildAndSend(DalyBMS_Handle_t *hbms, DalyBMS_Command_t cmd) {
    hbms->txBuffer[2] = (uint8_t)cmd;
    for (uint8_t i = 4; i <= 11; i++) hbms->txBuffer[i] = 0x00u;

    uint8_t chk = 0;
    for (uint8_t i = 0; i <= 11; i++) chk += hbms->txBuffer[i];
    hbms->txBuffer[12] = chk;

    hbms->txComplete = false;
    hbms->rxComplete = false;
    hbms->rxError    = false;

    HAL_UART_Transmit_IT(hbms->huart, hbms->txBuffer, DALY_XFER_BUFFER_LEN);
}

static void DalyBMS_StartRxIT(DalyBMS_Handle_t *hbms) {
    memset(hbms->rxBuffer, 0, DALY_XFER_BUFFER_LEN);
    hbms->rxComplete  = false;
    hbms->rxError     = false;
    hbms->rxStartTick = HAL_GetTick();

    /* FIX: check return value of HAL_UART_Receive_IT.
     *
     * Previously this return value was ignored.  If huart5 was left in a
     * busy/error state (e.g. by the blocking FET-cutoff sequence or a prior
     * framing error whose flags were not yet cleared), Receive_IT returned
     * HAL_BUSY or HAL_ERROR silently.  rxComplete would never fire, the
     * state machine would wait 500 ms for the timeout, then retry — but
     * each retry would hit the same condition → permanent timeout loop →
     * dataReady never true → cells frozen.
     *
     * Fix: on non-OK return, forcibly clear UART state flags and set rxError
     * so DALY_STATE_ERROR is entered immediately, which calls AbortReceive
     * and resets lastUpdateTick — recovering in one cycle instead of looping.
     */
    if (HAL_UART_Receive_IT(hbms->huart, hbms->rxBuffer,
                             DALY_XFER_BUFFER_LEN) != HAL_OK) {
        /* Force-clear UART hardware flags so the next attempt can succeed */
        __HAL_UART_CLEAR_FLAG(hbms->huart,
                              UART_CLEAR_PEF | UART_CLEAR_FEF |
                              UART_CLEAR_NEF | UART_CLEAR_OREF);
        hbms->huart->ErrorCode = HAL_UART_ERROR_NONE;
        hbms->huart->gState    = HAL_UART_STATE_READY;
        hbms->huart->RxState   = HAL_UART_STATE_READY;
        hbms->rxError          = true;   /* → DALY_STATE_ERROR next tick  */
    }
}

/* -------------------------------------------------------------------------- */
/*  Private: frame validation                                                  */
/* -------------------------------------------------------------------------- */

static bool DalyBMS_ValidateChecksum(const uint8_t *buf, uint8_t len) {
    uint8_t chk = 0;
    for (uint8_t i = 0; i < len - 1u; i++) chk += buf[i];
    return (chk == buf[len - 1u]);
}

/**
 * @brief  Stream sync + full frame validation.
 *
 *         [PY-SYNC] Python parser: while buffer[0] != 0xA5: buffer.pop(0)
 *         We cannot pop from a fixed-size DMA buffer, so instead we scan
 *         forward for 0xA5 and shift the frame into alignment.
 *         After alignment: validate frame[3]==0x08 and checksum.
 *
 * @return true if a valid frame is in rxBuffer[0..12]; false otherwise.
 */
static bool DalyBMS_SyncAndValidate(DalyBMS_Handle_t *hbms) {
    uint8_t *buf = hbms->rxBuffer;

    /* [PY-SYNC] Scan for start byte */
    if (buf[0] != DALY_FRAME_START) {
        /* Search for 0xA5 within the buffer */
        uint8_t sync_pos = 0xFF;
        for (uint8_t i = 1; i < DALY_XFER_BUFFER_LEN; i++) {
            if (buf[i] == DALY_FRAME_START) { sync_pos = i; break; }
        }
        if (sync_pos == 0xFF) {
            hbms->errorCount++;
            return false;   /* No sync byte found — discard entire frame    */
        }
        /* Shift frame into alignment (partial — remaining bytes are 0x00) */
        uint8_t tmp[DALY_XFER_BUFFER_LEN];
        memset(tmp, 0, DALY_XFER_BUFFER_LEN);
        uint8_t avail = DALY_XFER_BUFFER_LEN - sync_pos;
        memcpy(tmp, buf + sync_pos, avail);
        memcpy(buf, tmp, DALY_XFER_BUFFER_LEN);
        /* A shifted frame will almost certainly fail the checksum below,   */
        /* causing a retry — which is the correct recovery path.            */
    }

    /* [PY-LEN] Data-length byte must be 0x08 */
    if (buf[3] != DALY_FRAME_DATA_LEN_BYTE) {
        hbms->errorCount++;
        return false;
    }

    /* [PY-CHK] Checksum */
    if (!DalyBMS_ValidateChecksum(buf, DALY_XFER_BUFFER_LEN)) {
        hbms->errorCount++;
        return false;
    }

    return true;
}

/* -------------------------------------------------------------------------- */
/*  Private: command sequencing                                                */
/* -------------------------------------------------------------------------- */

static uint8_t DalyBMS_CalcFrames(DalyBMS_Handle_t *hbms, DalyBMS_Command_t cmd) {
    if (cmd == DALY_CMD_CELL_VOLTAGES) {
        uint8_t n = hbms->data.numberOfCells;
        if (n >= DALY_MIN_CELLS && n <= DALY_MAX_CELLS) {
            return (uint8_t)ceilf((float)n / 3.0f);
        }
        return 1u;
    }
    return 1u;   /* 0x90 and 0x92 are single-frame responses */
}

static void DalyBMS_AdvanceToNextCommand(DalyBMS_Handle_t *hbms) {
    hbms->currentCmdIndex++;
    hbms->retryCount = 0;

    if (hbms->currentCmdIndex >= DALY_NUM_QUERY_CMDS) {
        hbms->state = DALY_STATE_COMPLETE;
    } else {
        DalyBMS_Command_t cmd = cmdSequence[hbms->currentCmdIndex];

        hbms->framesExpected = DalyBMS_CalcFrames(hbms, cmd);
        hbms->frameIndex     = 0;

        if (cmd == DALY_CMD_CELL_VOLTAGES) {
            hbms->cellVoltageIndex = 0;
        }

        DalyBMS_BuildAndSend(hbms, cmd);
        hbms->state = DALY_STATE_SENDING;
    }
}

static void DalyBMS_ParseResponse(DalyBMS_Handle_t *hbms) {
    DalyBMS_Command_t cmd = cmdSequence[hbms->currentCmdIndex];
    switch (cmd) {
    case DALY_CMD_VOUT_IOUT_SOC:  Parse_0x90(hbms);       break;
    case DALY_CMD_TEMPERATURE:    Parse_0x92(hbms);       break;
    case DALY_CMD_CELL_VOLTAGES:  Parse_0x95_Frame(hbms); break;
    default: break;
    }
}

/* -------------------------------------------------------------------------- */
/*  Private: derive min/max/diff from 0x95 cell array                         */
/*                                                                             */
/*  [FIX-5] Python approach: min_cell / max_cell / delta are @property        */
/*  accessors on DalyData that scan cell_voltages[].  We replicate this       */
/*  in C by calling this function once at the end of each complete cycle.     */
/* -------------------------------------------------------------------------- */

static void DalyBMS_UpdateCellStats(DalyBMS_Handle_t *hbms) {
    uint8_t n = hbms->data.numberOfCells;
    if (n == 0 || n > DALY_MAX_CELLS) return;

    float vmax    = 0.0f;
    float vmin    = 99999.0f;
    uint8_t imax  = 0;
    uint8_t imin  = 0;
    bool found    = false;

    for (uint8_t i = 0; i < n; i++) {
        float mv = hbms->data.cellVmV[i];
        if (!DalyBMS_ValidateCellVoltage(mv)) continue;  /* skip invalid   */
        if (!found || mv > vmax) { vmax = mv; imax = i; }
        if (!found || mv < vmin) { vmin = mv; imin = i; }
        found = true;
    }

    if (!found) return;   /* No valid cells yet — keep previous stats       */

    hbms->data.maxCellmV   = vmax;
    hbms->data.maxCellVNum = imax;
    hbms->data.minCellmV   = vmin;
    hbms->data.minCellVNum = imin;
    hbms->data.cellDiff    = vmax - vmin;   /* always >= 0 — no negatives   */
}

/* -------------------------------------------------------------------------- */
/*  Per-command parsers                                                        */
/* -------------------------------------------------------------------------- */

/*
 * 0x90 — Pack voltage / current / SOC
 *
 * Frame byte map (rxBuffer indices):
 *   [4..5]  Pack voltage → raw / 10.0  (V)        [PY: p[0:2] / 10]
 *   [6..7]  Unused in Python reference
 *   [8..9]  Current raw → (raw − 30000) / 10.0    [PY: p[4:6], off 30000]
 *   [10..11] SOC → raw / 10.0  (%)                [PY: p[6:8] / 10]
 *
 * [FIX-1] Pack voltage KF: seeded from first valid reading (not 0.0f).
 *         Input range-clamped to DALY_PACK_V_MIN_V..MAX_V before KF update.
 */

static float s_packV_kf_x    = 0.0f;
static float s_packV_kf_P    = 1.0f;
static bool  s_packV_kf_init = false;

static float _packV_kf_update(float z) {
    const float Q = 0.01f;
    const float R = 0.25f;
    s_packV_kf_P += Q;
    float K      = s_packV_kf_P / (s_packV_kf_P + R);
    s_packV_kf_x += K * (z - s_packV_kf_x);
    s_packV_kf_P *= (1.0f - K);
    return s_packV_kf_x;
}

static void Parse_0x90(DalyBMS_Handle_t *hbms) {
    const uint8_t *b = hbms->rxBuffer;

    /* --- Pack voltage [PY: p[0:2] / 10] --------------------------------- */
    float raw_packV = (float)((b[4] << 8) | b[5]) / 10.0f;

    /* [FIX-1a] Reject impossible values before feeding the KF             */
    if (raw_packV >= DALY_PACK_V_MIN_V && raw_packV <= DALY_PACK_V_MAX_V) {
        /* [FIX-1b] Seed KF with first valid reading instead of 0.0f       */
        if (!s_packV_kf_init) {
            s_packV_kf_x    = raw_packV;
            s_packV_kf_init = true;
        }
        hbms->data.packVoltage = _packV_kf_update(raw_packV);
    }
    /* else: keep last filtered value — do not update with corrupt data     */

    /* --- Current [PY: (p[4:6] − 30000) / 10] ---------------------------- */
    /* p[4] = rxBuffer[8], p[5] = rxBuffer[9]                               */
    uint16_t raw_i        = (uint16_t)((b[8] << 8) | b[9]);
    hbms->data.packCurrent = ((float)raw_i - (float)DALY_CURRENT_OFFSET) / 10.0f;

    /* --- SOC [PY: p[6:8] / 10] ------------------------------------------ */
    /* p[6] = rxBuffer[10], p[7] = rxBuffer[11]                              */
    hbms->data.packSOC = (float)((b[10] << 8) | b[11]) / 10.0f;
}

/*
 * 0x92 — Temperature
 *
 * [FIX-2] Python: temperature = p[0] − 40  where p[0] = frame[4]
 *         Previous C code queried 0x91 and had no temperature parser at all.
 *
 * Frame byte map:
 *   [4]  Temperature raw → raw − 40  (°C)
 */
static void Parse_0x92(DalyBMS_Handle_t *hbms) {
    /* [PY: self.data.temperature = p[0] - 40]  where p[0] = rxBuffer[4]   */
    hbms->data.temperature = (float)hbms->rxBuffer[4] - 40.0f;
}

/*
 * 0x95 — Cell voltages (3 cells per frame)
 *
 * Frame byte map:
 *   [4]       frame_num  (1-based; 0 and 0xFF treated as 1)    [PY: p[0]]
 *   [5..6]    cell[base+0] raw mV  (big-endian uint16)         [PY: p[1:3]]
 *   [7..8]    cell[base+1] raw mV                              [PY: p[3:5]]
 *   [9..10]   cell[base+2] raw mV                              [PY: p[5:7]]
 *
 * [FIX-3] Python uses frame_num from p[0] to compute base_idx:
 *             base_idx = (frame_num − 1) × 3
 *         Previous C code used a sequential cellVoltageIndex cursor that
 *         broke on out-of-order frames. We now match Python exactly.
 */
static void Parse_0x95_Frame(DalyBMS_Handle_t *hbms) {
    const uint8_t *b = hbms->rxBuffer;

    /* [PY-FRAME_NUM] frame_num = p[0] = rxBuffer[4]; handle 0 / 0xFF      */
    uint8_t frame_num = b[4];
    if (frame_num == 0u || frame_num == 0xFFu) {
        frame_num = 1u;
    }

    /* [PY] base_idx = (frame_num − 1) × 3 */
    uint8_t base_idx = (uint8_t)((frame_num - 1u) * 3u);

    for (uint8_t i = 0; i < 3u; i++) {
        uint8_t cell_idx = base_idx + i;

        /* Bounds check against configured cell count */
        if (cell_idx >= hbms->data.numberOfCells ||
            cell_idx >= DALY_MAX_CELLS) {
            break;
        }

        /* [PY] raw_v = struct.unpack(">H", p[1 + i*2 : 3 + i*2])[0]      */
        /* p[1] = rxBuffer[5], p[3] = rxBuffer[7], p[5] = rxBuffer[9]      */
        float raw_mv = (float)((b[5u + i * 2u] << 8) | b[6u + i * 2u]);

        /* [PY] if is_valid_voltage(v): store  (1.5V–5.5V in Python;       */
        /* we use 1500–4500 mV for Li-Ion safety)                           */
        if (DalyBMS_ValidateCellVoltage(raw_mv)) {
            float raw_v = raw_mv / 1000.0f;
            /* Feed into Double-Kalman EKF filter */
            DalyEKF_UpdateCell(&hbms->ekf, cell_idx, raw_v);
        }
        /* else: EKF holds last good estimate — not updated with bad data   */

        /* Store EKF output back as mV for consistent units with min/max    */
        hbms->data.cellVmV[cell_idx] =
            DalyEKF_GetCellVoltage(&hbms->ekf, cell_idx) * 1000.0f;

        /* Update legacy cursor (for diagnostics / backward compat only)    */
        hbms->cellVoltageIndex = cell_idx + 1u;
    }
}
