/**
 * @file    soc.c
 * @brief   SOC estimator with Kalman filtering and voltage-based drift correction
 * @details Fuses coulomb counting with OCV-derived corrections using a 1-D
 *          Kalman filter. Key fixes:
 *            - OCV init bug (flag set before check) FIXED
 *            - Voltage correction during rest prevents 15-min drift-to-0
 *            - Tighter offset learning with rest-period gating
 *            - Default capacity fixed from 0.05 Ah to 50 Ah
 */

#include "soc.h"
#include <math.h>

/* ================= INTERNAL ================= */

static float clamp(float v, float min, float max) {
  if (v < min) return min;
  if (v > max) return max;
  return v;
}

static float SOC_FromOCV(const SOC_Config_t *config, float ocv) {
  for (int i = 0; i < SOC_OCV_POINTS - 1; i++) {
    if (ocv >= config->pack_ocv[i] && ocv <= config->pack_ocv[i + 1]) {
      float r = (ocv - config->pack_ocv[i]) /
                (config->pack_ocv[i + 1] - config->pack_ocv[i]);
      return config->soc_ref[i] +
             r * (config->soc_ref[i + 1] - config->soc_ref[i]);
    }
  }
  if (ocv <= config->pack_ocv[0]) return 0.0f;
  if (ocv >= config->pack_ocv[SOC_OCV_POINTS - 1]) return 100.0f;
  return 0.0f;
}

/* Kalman tuning:
 * Q_coulomb: uncertainty in coulomb counting (Ah^2 per step).
 *            Scales with dt and current noise.
 * R_ocv:     uncertainty in OCV->SOC mapping (Ah^2).
 *            Larger value = trust voltage correction less.
 */
#define SOC_KF_Q_COULOMB(dt_sec)  (fabsf(dt_sec) * 0.001f * 0.001f)
#define SOC_KF_R_OCV              (25.0f)   /* ~5 Ah std dev -> variance 25 */

/* Rest detection thresholds */
#define SOC_REST_CURRENT_THRESH   0.3f      /* A: must be below this */
#define SOC_REST_VOLTAGE_DELTA_V  0.05f     /* V: pack must be stable */
#define SOC_REST_MIN_DURATION_MS  10000U    /* 10 s rest before OCV correction */
#define SOC_REST_OFFSET_LEARN_MS  30000U    /* 30 s rest before offset learn */

/* Offset clamp */
#define SOC_OFFSET_MAX_A          1.0f
#define SOC_OFFSET_MIN_A         -1.0f

/* ============================================ */

void SOC_Init(SOC_Handle_t *soc, const SOC_Config_t *config,
              float initial_soc_percent, uint32_t time_ms) {
  soc->config = config;
  soc->soc_percent = clamp(initial_soc_percent, 0.0f, 100.0f);
  soc->remaining_ah =
      (soc->soc_percent / 100.0f) * soc->config->battery_capacity_ah;

  soc->current_a = 0.0f;
  soc->current_offset = 0.0f;

  /* Kalman init: high initial uncertainty */
  soc->P_soc = 100.0f;          /* 10 Ah initial std dev */
  soc->Q_coulomb = 0.0f;
  soc->R_ocv = SOC_KF_R_OCV;

  /* Rest detection init */
  soc->rest_start_ms = 0;
  soc->last_voltage_v = 0.0f;
  soc->voltage_stable_ms = 0;

  soc->last_update_ms = time_ms;
  soc->ocv_used_at_startup = false;
}

void SOC_Update(SOC_Handle_t *soc, float measured_current_a,
                float pack_voltage_v, uint32_t time_ms) {
  float dt_sec = (float)((int32_t)(time_ms - soc->last_update_ms)) / 1000.0f;
  soc->last_update_ms = time_ms;

  if (dt_sec <= 0.0f || dt_sec > soc->config->max_dt_sec) return;

  /* --- 1. Coulomb counting prediction --- */
  float current = measured_current_a - soc->current_offset;
  soc->current_a = current;

  float delta_ah = (current * dt_sec) / 3600.0f;
  if (current < 0.0f) delta_ah *= soc->config->charge_efficiency;

  float x_pred = soc->remaining_ah - delta_ah;
  float P_pred = soc->P_soc + SOC_KF_Q_COULOMB(dt_sec);

  /* --- 2. OCV correction during rest (Kalman update) --- */
  bool resting = (fabsf(current) < SOC_REST_CURRENT_THRESH);
  bool voltage_stable =
      (fabsf(pack_voltage_v - soc->last_voltage_v) < SOC_REST_VOLTAGE_DELTA_V);

  if (voltage_stable) {
    soc->voltage_stable_ms += (uint32_t)(dt_sec * 1000.0f);
  } else {
    soc->voltage_stable_ms = 0;
  }
  soc->last_voltage_v = pack_voltage_v;

  if (resting) {
    if (soc->rest_start_ms == 0) {
      soc->rest_start_ms = time_ms;
    }
    uint32_t rest_duration = time_ms - soc->rest_start_ms;

    /* Only correct SOC after sufficient rest AND voltage stability */
    if (rest_duration >= SOC_REST_MIN_DURATION_MS &&
        soc->voltage_stable_ms >= SOC_REST_MIN_DURATION_MS &&
        pack_voltage_v >= soc->config->ocv_min_pack_volt) {

      float ocv_soc = SOC_FromOCV(soc->config, pack_voltage_v);
      float z_ah = (ocv_soc / 100.0f) * soc->config->battery_capacity_ah;

      /* Kalman update with OCV measurement */
      float S = P_pred + soc->R_ocv;
      float K = (S > 1e-6f) ? (P_pred / S) : 0.0f;
      x_pred = x_pred + K * (z_ah - x_pred);
      P_pred = (1.0f - K) * P_pred;
    }

    /* --- 3. Offset auto-learning (only after long rest) --- */
    if (rest_duration >= SOC_REST_OFFSET_LEARN_MS) {
      /* Tight IIR: only adapt very slowly */
      float alpha = 0.0005f;  /* ~2000 samples to converge */
      float new_offset = (1.0f - alpha) * soc->current_offset +
                         alpha * measured_current_a;
      soc->current_offset = clamp(new_offset, SOC_OFFSET_MIN_A, SOC_OFFSET_MAX_A);
    }
  } else {
    /* Not resting: reset rest timer */
    soc->rest_start_ms = 0;
    soc->voltage_stable_ms = 0;
  }

  /* --- 4. Clamp and store --- */
  soc->remaining_ah = clamp(x_pred, 0.0f, soc->config->battery_capacity_ah);
  soc->P_soc = P_pred;
  soc->soc_percent =
      (soc->remaining_ah / soc->config->battery_capacity_ah) * 100.0f;

  /* NaN/Inf guard */
  if (!isfinite(soc->soc_percent) || !isfinite(soc->remaining_ah)) {
    soc->soc_percent = 50.0f;
    soc->remaining_ah = 0.5f * soc->config->battery_capacity_ah;
    soc->P_soc = 100.0f;
    soc->current_offset = 0.0f;
  }
}

bool SOC_InitFromOCV(SOC_Handle_t *soc, float pack_voltage, float current_a) {
  (void)current_a;

  /* CRITICAL FIX: check flag BEFORE setting it. The old code set it first
   * then immediately returned false, so OCV init NEVER worked. */
  if (soc->ocv_used_at_startup) return false;

  /* Battery must be resting (or at least voltage above min threshold) */
  if (pack_voltage < soc->config->ocv_min_pack_volt) return false;

  float ocv_soc = SOC_FromOCV(soc->config, pack_voltage);

  if (ocv_soc < soc->config->ocv_min_soc_percent) return false;

  soc->soc_percent = ocv_soc;
  soc->remaining_ah = (ocv_soc / 100.0f) * soc->config->battery_capacity_ah;

  /* Reset Kalman uncertainty after OCV anchor */
  soc->P_soc = 10.0f;

  soc->ocv_used_at_startup = true;
  return true;
}

/* ===== HARD CALIBRATION ===== */

void SOC_SetFull(SOC_Handle_t *soc) {
  soc->remaining_ah = soc->config->battery_capacity_ah;
  soc->soc_percent = 100.0f;
  soc->P_soc = 5.0f;  /* Low uncertainty after full charge */
}

void SOC_SetEmpty(SOC_Handle_t *soc) {
  soc->remaining_ah = 0.0f;
  soc->soc_percent = 0.0f;
  soc->P_soc = 5.0f;
}

/* ===== GETTERS ===== */

float SOC_GetPercent(const SOC_Handle_t *soc) { return soc->soc_percent; }

float SOC_GetRemainingAh(const SOC_Handle_t *soc) { return soc->remaining_ah; }

uint16_t SOC_CRC16(const VerifiedSOC_t *vsoc) {
  uint16_t crc = 0;
  const uint8_t *data = (const uint8_t*)vsoc;
  for (int i = 0; i < (int)sizeof(VerifiedSOC_t) - 2; i++) {
    crc ^= data[i];
    for (int j = 0; j < 8; j++) {
      crc = (crc >> 1) ^ ((crc & 1) ? 0xA001 : 0);
    }
  }
  return crc;
}
