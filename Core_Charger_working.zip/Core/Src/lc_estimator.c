/**
 * @file    lc_estimator.c
 * @brief   iPhone-style Life Capacity estimator — CC/CV/CD/IDLE phase logic,
 *          real SOC linkage, Kalman confidence, fake OV separation.
 *
 * ── WHAT CHANGED vs ORIGINAL ─────────────────────────────────────────────────
 *
 *  1. LC_Update() signature adds `soc_kalman_P` (SOC covariance).
 *     Confidence now degrades when SOC Kalman uncertainty is high, matching
 *     real iPhone behaviour (asterisk / dimmed % when battery uncertain).
 *
 *  2. CC→CV transition now records `cv_entry_packV` (pack voltage at the
 *     moment CC ended). CV-done condition checks BOTH:
 *       a. SOC ≥ 99.5%  (Kalman-filtered, not raw)
 *       b. |I| < LC_TAPER_CURRENT_A × LC_TAPER_DONE_FRAC  (C/40)
 *     This prevents false 100% when balancer pulses briefly reduce current
 *     below the taper threshold mid-CC.
 *
 *  3. Phase detection: CC vs CV boundary now also cross-checks pack voltage
 *     against cv_entry_packV to avoid CV false-entry at pack voltages that
 *     are clearly still in the CC region (> 1V below nominal full voltage).
 *
 *  4. CD load-sag pessimism: `usable_frac` now uses EMA current (not
 *     instantaneous) so a brief high-current pulse doesn't collapse LC%.
 *
 *  5. Wh estimate uses `soc_pct` (real Kalman SOC) directly for capacity
 *     fraction instead of lc_display — avoids Wh / LC% mismatch during
 *     CV freeze when lc_display is frozen but SOC is still ticking up.
 *
 *  6. lc_voltage_at_soc() v_empty corrected: 42.0V is wrong for a 13S pack
 *     (13 × 3.0V = 39.0V empty). Now uses pack UV limit derived from
 *     LC_NOMINAL_FULL_V / 13 * cells_approx logic — uses SOC OCV table
 *     anchor (42V pack = 13×3.23V, correct for a near-empty 13S pack at
 *     rest) — kept as 42.0V since that matches SOC OCV table floor.
 *
 *  7. NaN/Inf guard extended to remaining_time_s (was already there) and
 *     also clamps remaining_wh to [0, LC_NOMINAL_CAP_AH × LC_NOMINAL_FULL_V].
 *
 * ── FAKE OV SEPARATION ───────────────────────────────────────────────────────
 *
 *  LC does NOT perform any voltage-level fault detection.
 *  Cell OV / Pack OV is the exclusive responsibility of fault_detector.c,
 *  which receives filtered_min/max_cellV already in VOLTS from
 *  signal_filter.c (after the mV→V conversion).
 *  LC only uses pack_v for:
 *    a. Wh estimation (energy = capacity × voltage)
 *    b. Voltage-sag load correction (I × Ri)
 *    c. CV anchor voltage (cv_entry_packV)
 *  It never compares voltages against OV/UV thresholds.
 */

#include "lc_estimator.h"
#include <math.h>
#include <string.h>

/* ── Internal helpers ───────────────────────────────────────────────────── */

static float lc_clampf(float v, float lo, float hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

/**
 * Temperature derate factor [0.0–1.0].
 * Cold batteries lose usable capacity; hot batteries risk safety cutoff.
 * Linear interpolation in the transition zones (10–15 °C, 45–50 °C).
 */
static float lc_temp_derate(float temp_c)
{
    if (temp_c <= LC_TEMP_LOW_DEG)  return 0.88f;   /* ≤10 °C: −12% */
    if (temp_c >= LC_TEMP_HIGH_DEG) return 0.90f;   /* ≥50 °C: −10% */

    if (temp_c < 15.0f) {
        /* Linear 0.88 → 1.0 over 10–15 °C */
        float t = (temp_c - LC_TEMP_LOW_DEG) / 5.0f;
        return 0.88f + t * (1.0f - 0.88f);
    }
    if (temp_c > 45.0f) {
        /* Linear 1.0 → 0.90 over 45–50 °C */
        float t = (LC_TEMP_HIGH_DEG - temp_c) / 5.0f;
        return 0.90f + t * (1.0f - 0.90f);
    }
    return 1.0f;  /* 15–45 °C: no derate */
}

/**
 * Cell imbalance derate factor [0.0–1.0].
 * High cell spread means BMS will cut off earlier (weakest cell hits UV first),
 * so usable pack energy is less than nominal.
 */
static float lc_imbalance_derate(float cell_diff_mv)
{
    if (cell_diff_mv > 500.0f) return 0.85f;
    if (cell_diff_mv > 200.0f) return 0.925f;
    if (cell_diff_mv > 100.0f) return 0.970f;
    return 1.0f;
}

/**
 * Estimate average pack voltage at a given SOC% (two-segment linear model).
 * Used only when pack_v is not available (< 1 V sentinel).
 * Uses runtime config values from the handle when available, otherwise
 * falls back to hardcoded defaults.
 *
 * Anchors: 0% → v_empty, 50% → mid_v, 100% → pack_full_voltage.
 * v_empty ≈ cellCount × 3.0V (typical LFP/LMO empty voltage).
 * mid_v = pack_full_voltage - (pack_full_voltage - v_empty) × 0.5f.
 */
static float lc_voltage_at_soc(float soc_pct, const LC_Handle_t *hlc)
{
    float v_empty, v_full, v_mid;

    if (hlc && hlc->pack_full_voltage > 1.0f && hlc->cell_count > 0U) {
        /* Runtime config: derive from pack parameters */
        v_full  = hlc->pack_full_voltage;
        v_empty = (float)hlc->cell_count * 3.0f;  /* 3.0V per cell empty */
        v_mid   = v_full - (v_full - v_empty) * 0.5f;
    } else {
        /* Fallback to hardcoded defaults */
        v_full  = LC_NOMINAL_FULL_V;
        v_empty = 42.0f;
        v_mid   = LC_NOMINAL_MID_V;
    }

    if (soc_pct <= 50.0f) {
        float t = soc_pct / 50.0f;
        return v_empty + t * (v_mid - v_empty);
    } else {
        float t = (soc_pct - 50.0f) / 50.0f;
        return v_mid + t * (v_full - v_mid);
    }
}

/* ── Phase detection ────────────────────────────────────────────────────── */

/**
 * Determine candidate phase from current alone.
 * Voltage cross-check for CV is applied separately in lc_update_phase()
 * to avoid the function needing pack_v as a parameter.
 */
static LC_Phase_t lc_detect_candidate(float current_a)
{
    if (current_a > LC_CHARGE_MIN_CURRENT_A) {
        /* Charging — CC if bulk current, CV if tapering */
        return (current_a >= LC_TAPER_CURRENT_A) ? LC_PHASE_CC : LC_PHASE_CV;
    }
    if (current_a < -LC_DISCHARGE_MIN_CURRENT_A) {
        return LC_PHASE_CD;
    }
    return LC_PHASE_IDLE;
}

/**
 * Debounced phase commitment.
 *
 * A phase change is only committed after LC_PHASE_DEBOUNCE_TICKS consecutive
 * ticks of the same candidate. This prevents balancer current pulses
 * (which look like brief CC→CV transitions) from corrupting the phase state.
 *
 * Extra CC/CV guard: if the candidate is CV but pack voltage is more than
 * 1 V below the CV entry voltage (or nominal full voltage if no CV entry
 * has occurred yet), we reject the CV candidate and treat it as CC.
 * This avoids false CV entry at partial SOC when current briefly dips.
 *
 * @param hlc        Handle.
 * @param candidate  Phase inferred from current this tick.
 * @param pack_v     Current pack voltage (V).
 * @return           true if committed phase changed this tick.
 */
static bool lc_update_phase(LC_Handle_t *hlc, LC_Phase_t candidate, float pack_v)
{
    /* ── CC/CV boundary voltage guard ──────────────────────────────────── */
    if (candidate == LC_PHASE_CV) {
        /* Reference voltage: use CV-entry anchor if we've been in CV before,
         * otherwise use the nominal full voltage as the ceiling. */
        float cv_ref_v = (hlc->cv_entry_packV > 1.0f)
                         ? hlc->cv_entry_packV
                         : LC_NOMINAL_FULL_V;

        /* If pack is more than 1 V below CV reference, current dipped due to
         * load / balancer — not a genuine CV taper. Keep it as CC. */
        if (pack_v < (cv_ref_v - 1.0f)) {
            candidate = LC_PHASE_CC;
        }
    }

    /* ── Standard debounce ──────────────────────────────────────────────── */
    if (candidate == hlc->phase_candidate) {
        if (hlc->phase_ticks < LC_PHASE_DEBOUNCE_TICKS) {
            hlc->phase_ticks++;
        }
        if (hlc->phase_ticks >= LC_PHASE_DEBOUNCE_TICKS &&
            candidate != hlc->phase) {

            /* Phase transition committed */
            hlc->phase = candidate;

            if (candidate == LC_PHASE_CV) {
                /* Entering CV: freeze LC display and record pack voltage */
                hlc->lc_at_cv_entry  = hlc->lc_display;
                hlc->cv_entry_packV  = pack_v;
                hlc->cv_complete     = false;
            }
            return true;
        }
    } else {
        /* New candidate — restart debounce counter */
        hlc->phase_candidate = candidate;
        hlc->phase_ticks     = 1;
    }
    return false;
}

/* ── Public API ─────────────────────────────────────────────────────────── */

void LC_Init(LC_Handle_t *hlc, float soh_pct, float init_soc)
{
    memset(hlc, 0, sizeof(*hlc));

    hlc->soh_pct            = lc_clampf(soh_pct,   0.0f, 100.0f);
    hlc->pack_full_voltage  = LC_NOMINAL_FULL_V;   /* Hardcoded default */
    hlc->pack_capacity_ah   = LC_NOMINAL_CAP_AH;   /* Hardcoded default */
    hlc->cell_count         = 13U;                  /* 13S default */
    hlc->soc_pct            = lc_clampf(init_soc,  0.0f, 100.0f);
    hlc->lc_display         = hlc->soc_pct;        /* Open at true SOC */
    hlc->lc_at_cv_entry     = hlc->lc_display;
    hlc->cv_entry_packV     = 0.0f;                /* Not yet in CV */
    hlc->phase              = LC_PHASE_IDLE;
    hlc->phase_candidate    = LC_PHASE_IDLE;
    hlc->phase_ticks        = LC_PHASE_DEBOUNCE_TICKS; /* Start committed */
    hlc->confidence         = 0.70f;               /* Moderate confidence at boot */
    hlc->soc_kalman_P       = 100.0f;              /* High uncertainty at boot */

    /* Populate data immediately so first LC_GetData() call is valid */
    hlc->data.lc_percent       = hlc->lc_display;
    hlc->data.charge_phase     = (uint8_t)LC_PHASE_IDLE;
    hlc->data.confidence       = hlc->confidence;
    hlc->data.remaining_wh     = 0.0f;
    hlc->data.remaining_time_s = 0.0f;
}

void LC_InitWithConfig(LC_Handle_t *hlc,
                       float soh_pct,
                       float init_soc,
                       float pack_full_voltage,
                       float battery_capacity_ah,
                       uint8_t cellCount)
{
    memset(hlc, 0, sizeof(*hlc));

    hlc->soh_pct            = lc_clampf(soh_pct,   0.0f, 100.0f);
    hlc->pack_full_voltage  = (pack_full_voltage > 1.0f) ? pack_full_voltage : LC_NOMINAL_FULL_V;
    hlc->pack_capacity_ah   = (battery_capacity_ah > 0.01f) ? battery_capacity_ah : LC_NOMINAL_CAP_AH;
    hlc->cell_count         = (cellCount > 0U && cellCount <= 32U) ? cellCount : 13U;
    hlc->soc_pct            = lc_clampf(init_soc,  0.0f, 100.0f);
    hlc->lc_display         = hlc->soc_pct;        /* Open at true SOC */
    hlc->lc_at_cv_entry     = hlc->lc_display;
    hlc->cv_entry_packV     = 0.0f;                /* Not yet in CV */
    hlc->phase              = LC_PHASE_IDLE;
    hlc->phase_candidate    = LC_PHASE_IDLE;
    hlc->phase_ticks        = LC_PHASE_DEBOUNCE_TICKS; /* Start committed */
    hlc->confidence         = 0.70f;               /* Moderate confidence at boot */
    hlc->soc_kalman_P       = 100.0f;              /* High uncertainty at boot */

    /* Populate data immediately so first LC_GetData() call is valid */
    hlc->data.lc_percent       = hlc->lc_display;
    hlc->data.charge_phase     = (uint8_t)LC_PHASE_IDLE;
    hlc->data.confidence       = hlc->confidence;
    hlc->data.remaining_wh     = 0.0f;
    hlc->data.remaining_time_s = 0.0f;
}

const LC_Data_t *LC_Update(LC_Handle_t *hlc,
                           float soc_pct,
                           float soc_kalman_P,
                           float pack_v,
                           float current_a,
                           float temp_c,
                           float cell_diff_mv)
{
    LC_Data_t *out = &hlc->data;

    /* ── 1. SOC shadow ──────────────────────────────────────────────────── */
    hlc->soc_pct      = lc_clampf(soc_pct,     0.0f, 100.0f);
    hlc->soc_kalman_P = lc_clampf(soc_kalman_P, 0.0f, 1e6f);

    /* ── 1b. Auto-reset cv_complete when SOC drops below full ──────────── */
    /*
     * Once cv_complete is true (battery confirmed full), it must stay true
     * as long as the battery remains full. When SOC drops below 99.0%
     * (discharge starts), we reset cv_complete so the next charge cycle
     * goes through CV-completion detection properly.
     *
     * Without this, a battery that was once full and then partially
     * discharged would have cv_complete permanently stuck at true, and
     * step 4b would lock LC at 100% even at 80% SOC — wrong.
     */
    if (hlc->cv_complete && hlc->soc_pct < 99.0f) {
        hlc->cv_complete = false;
    }

    /* ── 2. Phase detection (debounced, voltage-guarded) ────────────────── */
    LC_Phase_t candidate = lc_detect_candidate(current_a);
    lc_update_phase(hlc, candidate, pack_v);

    /* ── 3. Current EMA for time-remaining and sag correction ───────────── */
    /*
     * Use EMA (τ ≈ 12 ticks = 1.2 s) so a single high-current spike does
     * not collapse LC%. This matches iPhone behaviour where the remaining
     * time estimate is smoothed over several seconds.
     */
    float abs_current  = fabsf(current_a);
    hlc->avg_current_a = 0.92f * hlc->avg_current_a + 0.08f * abs_current;

    /* ── 4. LC% update — per-phase rules ────────────────────────────────── */
    float target_lc = hlc->soc_pct;  /* LC target = Kalman SOC (1:1) */
    float prev_lc   = hlc->lc_display;

    switch (hlc->phase) {

    /* -------------------------------------------------------------------- */
    case LC_PHASE_CC:
    /*
     * CC charging: SOC rises quickly.
     * LC follows with a gentle IIR lag (alpha_cc = 0.05, τ ≈ 2 s).
     * Hard cap at 99.0%: we never show 100% until CV taper is done.
     *
     * cv_complete is NOT reset here. Previously it was set to false every
     * CC tick, which immediately undid LC_SetFull() from main.c — causing
     * the "LC running like a timer at 100%" symptom. cv_complete is now
     * auto-reset in step 1b when SOC drops below 99%, and on CV entry in
     * lc_update_phase(). No need to reset it here.
     */
        hlc->lc_display += LC_ALPHA_CC * (target_lc - hlc->lc_display);
        hlc->lc_display  = lc_clampf(hlc->lc_display, 0.0f, 99.0f);
        break;

    /* -------------------------------------------------------------------- */
    case LC_PHASE_CV:
    /*
     * CV taper: LC is FROZEN at lc_at_cv_entry.
     *
     * Snap to 100% ONLY when BOTH conditions are true simultaneously:
     *   a. SOC (Kalman) ≥ 99.5%   — battery truly full per Kalman estimator.
     *   b. |I| < taper_done_thresh — current has decayed to C/40 level.
     *
     * Using EMA current (not instantaneous) prevents balancer pulses that
     * briefly reduce current from triggering a false 100% snap.
     *
     * This exactly mirrors Apple: the phone stays at 99% for potentially
     * several minutes while current tapers, then jumps to 100%.
     */
        if (!hlc->cv_complete) {
            bool soc_full   = (hlc->soc_pct  >= 99.5f);
            bool taper_done = (hlc->avg_current_a
                               < LC_TAPER_CURRENT_A * LC_TAPER_DONE_FRAC);
            if (soc_full && taper_done) {
                hlc->lc_display  = 100.0f;
                hlc->cv_complete = true;
            } else {
                hlc->lc_display = hlc->lc_at_cv_entry;  /* Frozen */
            }
        }
        /* else: already complete — remain at 100.0f */
        break;

    /* -------------------------------------------------------------------- */
    case LC_PHASE_CD:
    /*
     * Discharging: LC may ONLY decrease (monotone-down guard).
     *
     * Voltage-sag pessimism using EMA current:
     *   usable_frac = (V_pack - I_ema × Ri) / V_pack
     *
     * This accounts for the fact that at high current, the terminal voltage
     * sags below OCV and the BMS will cut off sooner than coulombs suggest.
     * Using EMA current (not instantaneous) avoids overcorrection on transients.
     *
     * Result: displayed LC at high load is slightly lower than raw SOC —
     * exactly the "better to under-promise" behaviour Apple uses.
     */
        {
            float v_sag       = hlc->avg_current_a * LC_R_INTERNAL_OHM;
            float usable_frac = (pack_v > 1.0f)
                                ? lc_clampf((pack_v - v_sag) / pack_v,
                                            0.80f, 1.0f)
                                : 1.0f;
            float cd_target   = target_lc * usable_frac;

            hlc->lc_display += LC_ALPHA_CD * (cd_target - hlc->lc_display);

            /* Monotone-down guard: discharge LC can NEVER go up */
            if (hlc->lc_display > prev_lc) {
                hlc->lc_display = prev_lc;
            }
            hlc->lc_display = lc_clampf(hlc->lc_display, 0.0f, 100.0f);
        }
        break;

    /* -------------------------------------------------------------------- */
    case LC_PHASE_IDLE:
    default:
    /*
     * Idle / rest: very slow drift toward true Kalman SOC.
     * alpha_idle = 0.005 → τ ≈ 200 ticks = 20 s of visible movement.
     * Over a 3-minute rest this corrects ~50% of any accumulated offset,
     * imperceptibly to the user — identical to iPhone's rest-period correction.
     */
        hlc->lc_display += LC_ALPHA_IDLE * (target_lc - hlc->lc_display);
        hlc->lc_display  = lc_clampf(hlc->lc_display, 0.0f, 100.0f);
        break;
    }

    /* ── 4b. Full-battery lock ─────────────────────────────────────────── */
    /*
     * Lock LC at 100% when the battery is confirmed full. Two conditions
     * act as a belt-and-suspenders guard:
     *
     *   a. cv_complete == true  — set by LC_SetFull() or CV-phase completion.
     *   b. soc_pct >= 99.5%     — SOC Kalman estimate is at full.
     *
     * Condition (a) alone is insufficient because the CC phase used to
     * reset cv_complete every tick. Even with that reset removed (step 4),
     * condition (b) ensures that a misinterpreted or stale cv_complete
     * (e.g. from a partial charge) never incorrectly locks at 100%.
     *
     * When new discharge begins, cv_complete auto-clears in step 1b (SOC
     * drops below 99%), and the lock is released — LC tracks normally.
     */
    if (hlc->cv_complete || hlc->soc_pct >= 99.5f) {
        hlc->lc_display = 100.0f;
    }

    /* ── 5. Round to 1% integer steps ──────────────────────────────────── */
    /*
     * Round to nearest whole percent, then clamp [1, 100].
     * Never show 0% unless LC_SetZero() was called — same as iPhone
     * which shows "1%" at very low SOC rather than "0%".
     */
    float lc_rounded = floorf(hlc->lc_display + 0.5f);
    lc_rounded = lc_clampf(lc_rounded, 1.0f, 100.0f);

    /* ── 6. Derate factors ──────────────────────────────────────────────── */
    float d_temp  = lc_temp_derate(temp_c);
    float d_imbal = lc_imbalance_derate(cell_diff_mv);
    float d_soh   = lc_clampf(hlc->soh_pct / 100.0f, 0.0f, 1.0f);

    /* ── 7. Remaining Wh ────────────────────────────────────────────────── */
    /*
     * Use real Kalman SOC fraction for Wh, not lc_display.
     * Reason: during CV phase, lc_display is frozen at e.g. 97% while
     * SOC is still being accurately counted up to 100%. Using lc_display
     * for Wh would under-report the actual energy available.
     *
     * Wh = capacity_Ah × SOH × SOC_frac × V_avg × d_temp × d_imbal
     *
     * Uses runtime pack_capacity_ah and pack_full_voltage from handle
     * (set via LC_InitWithConfig()) instead of hardcoded defaults.
     */
    float cap_ah         = (hlc->pack_capacity_ah > 0.01f)
                           ? hlc->pack_capacity_ah
                           : LC_NOMINAL_CAP_AH;
    float full_v         = (hlc->pack_full_voltage > 1.0f)
                           ? hlc->pack_full_voltage
                           : LC_NOMINAL_FULL_V;
    float soc_frac       = lc_clampf(hlc->soc_pct / 100.0f, 0.0f, 1.0f);
    float avg_v          = (pack_v > 1.0f)
                           ? pack_v
                           : lc_voltage_at_soc(lc_rounded, hlc);
    float remaining_wh   = cap_ah * d_soh * soc_frac
                           * avg_v * d_temp * d_imbal;
    /* Clamp to physical maximum */
    float max_wh         = cap_ah * full_v;
    remaining_wh         = lc_clampf(remaining_wh, 0.0f, max_wh);

    /* ── 8. Time remaining ──────────────────────────────────────────────── */
    /*
     * t = Wh / P  where P = I_ema × V_avg (Watts)
     * EMA current prevents jitter from transient loads.
     * Falls back to 24 h placeholder when current is negligible.
     */
    float remaining_time_s;
    if (hlc->avg_current_a > 0.2f && avg_v > 1.0f) {
        float power_w      = hlc->avg_current_a * avg_v;
        remaining_time_s   = (remaining_wh / power_w) * 3600.0f;
        /* Cap at 48 h — longer estimates are meaningless */
        remaining_time_s   = lc_clampf(remaining_time_s, 0.0f, 172800.0f);
    } else {
        remaining_time_s = 86400.0f;  /* 24 h idle placeholder */
    }

    /* ── 9. Confidence ──────────────────────────────────────────────────── */
    /*
     * Confidence integrates multiple signals:
     *  a. Phase stability: CV taper (small noisy current) → lower confidence.
     *  b. Pack voltage sanity: if V < 10V, data is clearly wrong → 0.40.
     *  c. SOH: degraded battery → harder to estimate remaining capacity.
     *  d. Temperature: outside 10–50 °C range → OCV table less accurate.
     *  e. Kalman covariance: high P_soc means SOC is uncertain → degrade LC conf.
     *     Normalised: P_soc / LC_CONF_HIGH_P_THRESH (clipped to 0–1).
     *
     * Result is smoothed with a slow IIR (τ ≈ 33 ticks = 3.3 s) so
     * confidence doesn't spike/drop on single-sample events.
     */
    float base_conf = 0.90f;

    /* Phase penalty */
    if (hlc->phase == LC_PHASE_CV && !hlc->cv_complete) {
        base_conf = 0.72f;   /* CV taper: current small and noisy */
    }

    /* Voltage sanity */
    if (pack_v < 10.0f) {
        base_conf = 0.40f;
    }

    /* SOH penalty */
    if (d_soh < 0.70f) {
        base_conf *= 0.90f;
    }

    /* Temperature penalty */
    if (temp_c < LC_TEMP_LOW_DEG || temp_c > LC_TEMP_HIGH_DEG) {
        base_conf *= 0.87f;
    }

    /* Kalman covariance penalty: high P_soc → uncertain SOC → uncertain LC */
    if (hlc->soc_kalman_P > 0.0f) {
        float P_norm    = lc_clampf(hlc->soc_kalman_P / LC_CONF_HIGH_P_THRESH,
                                    0.0f, 1.0f);
        base_conf      *= (1.0f - 0.30f * P_norm);  /* up to −30% at max uncertainty */
    }

    /* Slow IIR smoothing */
    hlc->confidence = 0.97f * hlc->confidence + 0.03f * base_conf;
    hlc->confidence = lc_clampf(hlc->confidence, 0.0f, 1.0f);

    /* ── 10. Publish ────────────────────────────────────────────────────── */
    out->lc_percent        = lc_rounded;
    out->remaining_wh      = remaining_wh;
    out->remaining_time_s  = remaining_time_s;
    out->confidence        = hlc->confidence;
    out->charge_phase      = (uint8_t)hlc->phase;

    /* NaN / Inf hard guard (should never trigger if inputs are finite) */
    if (!isfinite(out->lc_percent))       out->lc_percent       = 50.0f;
    if (!isfinite(out->remaining_wh))     out->remaining_wh     = 0.0f;
    if (!isfinite(out->remaining_time_s)) out->remaining_time_s = 0.0f;
    if (!isfinite(out->confidence))       out->confidence       = 0.50f;

    return out;
}

/* ── Hard calibration anchors ───────────────────────────────────────────── */

void LC_SetZero(LC_Handle_t *hlc)
{
    hlc->lc_display     = 0.0f;
    hlc->phase          = LC_PHASE_IDLE;
    hlc->cv_complete    = false;
    hlc->cv_entry_packV = 0.0f;
    hlc->data.lc_percent    = 1.0f;   /* Show 1%, not 0% — matches Apple */
    hlc->data.remaining_wh  = 0.0f;
}

void LC_SetFull(LC_Handle_t *hlc)
{
    hlc->lc_display      = 100.0f;
    hlc->cv_complete     = true;
    hlc->data.lc_percent = 100.0f;
}

void LC_SetSOH(LC_Handle_t *hlc, float soh_pct)
{
    hlc->soh_pct = lc_clampf(soh_pct, 0.0f, 100.0f);
}

const LC_Data_t *LC_GetData(const LC_Handle_t *hlc)
{
    return &hlc->data;
}

const char *LC_PhaseStr(LC_Phase_t phase)
{
    switch (phase) {
        case LC_PHASE_CC:   return "CC";
        case LC_PHASE_CV:   return "CV";
        case LC_PHASE_CD:   return "CD";
        case LC_PHASE_IDLE: return "IDLE";
        default:            return "??";
    }
}
