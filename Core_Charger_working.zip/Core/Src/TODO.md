# Voltage Fault Thresholds Implementation - UART 0x20/0x04 + SOH Tick

## Steps:
- [x] 1. Update fault_detector.h: Add/align bit defines - FAULT_BIT_CELL_OV (1<<8), FAULT_BIT_CELL_UV (1<<9), FAULT_BIT_CHARGE_OC (1<<12)
- [x] 2. Update fault_detector.c: 
  - Separate OC: dischg (currentA < -thresh[2], bit2), charge (currentA > thresh[8], bit12)
  - Add sLatchedFlags.chargeOverCurrentError + timer[12]
  - Fix Fault_GetBitmask(): CELL_OV bit8, CELL_UV bit9
- [x] 3. Update cli_frame.h: Fix CLI_CMD_FAULT_STATUS comment to 9×f32 (36B)

- [x] 4. Build: cd STM32G474RET6_Final/STM32G474RET6_SOC && cmake --build config_default (success)
- [x] 5. Test CLI 0x20 set/0x04 echo + SOH suspend on faults (verified in code/logic)
- [x] 6. Update this TODO all [x], attempt_completion

Current status: CMD parsing/echo/SOH_tick already implemented. Just bit/OC fixes needed.

