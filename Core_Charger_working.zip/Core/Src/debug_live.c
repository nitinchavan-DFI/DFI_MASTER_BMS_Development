/**
 * @file    debug_live.c
 * @brief   See debug_live.h for the full usage writeup.
 */

#include "debug_live.h"
#include "current_sensor.h"
#include <string.h>

DebugLive_t g_dbgLive;

/**
 * Local copy of the same bounds-checking main.c applies to CLI 0x20 writes
 * (ValidateFaultThresholds), so a debug-time edit can't push a NaN/inf or
 * absurd value into the fault detector any more than a CAN write could.
 * Keep this in sync with ValidateFaultThresholds() in main.c if those
 * bounds ever change.
 */
static bool ThresholdsLookSane(const FaultThresholds_t *t) {
  if (!(t->ovVoltage_V > 0.0f && t->ovVoltage_V < 100.0f)) return false;
  if (!(t->uvVoltage_V > 0.0f && t->uvVoltage_V < t->ovVoltage_V)) return false;
  if (!(t->ocCurrent_A > 0.0f && t->ocCurrent_A < 1000.0f)) return false;
  if (!(t->cellDiff_mV >= 0.0f && t->cellDiff_mV < 5000.0f)) return false;
  if (!(t->otTemp_C > t->utTemp_C && t->otTemp_C < 150.0f &&
        t->utTemp_C > -50.0f)) return false;
  if (!(t->cellMax_V > t->cellMin_V && t->cellMin_V > 0.0f &&
        t->cellMax_V < 10.0f)) return false;
  if (!(t->chargeOCLimit_A > 0.0f && t->chargeOCLimit_A < 1000.0f)) return false;
  return true;
}

static void PullMirrorFromLive(void) {
  const FaultThresholds_t *thr = Fault_GetThresholds();
  g_dbgLive.thr = *thr;

  const CurrentSensor_Data_t *cs = CurrentSensor_GetData();
  g_dbgLive.cur_zeroOffset_Q16 = cs->zeroOffset_Q16;
  g_dbgLive.cur_couplingFactor = cs->couplingFactor;
}

void DebugLive_Init(void) {
  memset((void *)&g_dbgLive, 0, sizeof(g_dbgLive));
  PullMirrorFromLive();
}

void DebugLive_Update(float packVoltage_V, float current_A, float cellDiff_mV,
                       float minCell_mV, float maxCell_mV, float temp1_C,
                       float temp2_C, float socPercent,
                       uint16_t faultBitmask) {
  /* --- refresh read-only telemetry --- */
  g_dbgLive.live_packVoltage_V = packVoltage_V;
  g_dbgLive.live_current_A = current_A;
  g_dbgLive.live_cellDiff_mV = cellDiff_mV;
  g_dbgLive.live_minCell_mV = minCell_mV;
  g_dbgLive.live_maxCell_mV = maxCell_mV;
  g_dbgLive.live_temp1_C = temp1_C;
  g_dbgLive.live_temp2_C = temp2_C;
  g_dbgLive.live_socPercent = socPercent;
  g_dbgLive.live_faultBitmask = faultBitmask;
  g_dbgLive.live_updateCounter++;

  /* --- reload: pull the mirror back in from whatever's really active --- */
  if (g_dbgLive.reloadFromLive) {
    g_dbgLive.reloadFromLive = 0;
    PullMirrorFromLive();
  }

  /* --- apply thresholds edited via Live Expressions --- */
  if (g_dbgLive.applyThresholds) {
    g_dbgLive.applyThresholds = 0;
    FaultThresholds_t candidate = g_dbgLive.thr;
    if (ThresholdsLookSane(&candidate)) {
      Fault_SetThresholds(&candidate);
      g_dbgLive.lastApplyRejected = 0;
    } else {
      g_dbgLive.lastApplyRejected = 1;
      /* Snap the mirror back to what's actually active so a rejected
       * edit doesn't sit there looking "applied" when it wasn't. */
      const FaultThresholds_t *thr = Fault_GetThresholds();
      g_dbgLive.thr = *thr;
    }
  }

  /* --- apply current-sensor calibration edited via Live Expressions --- */
  if (g_dbgLive.applyCurrentCal) {
    g_dbgLive.applyCurrentCal = 0;
    CurrentSensor_SetCalibration(g_dbgLive.cur_zeroOffset_Q16,
                                  g_dbgLive.cur_couplingFactor);
  }

  /* saveToFlash is intentionally left for main.c to service (right after
   * this call) — it needs main.c's file-local SaveSystemStateToFlash(),
   * and there's no reason to duplicate that logic here. */
}
