/**
 * @file    current_sensor.c
 * @brief   ACS37612LLUATR-010B3 current sensor driver implementation
 *
 * Two-point calibration: zero offset + known-current gain calibration.
 * Timer-triggered ADC with 2-state EKF (signal + zero-drift).
 */

#include "current_sensor.h"
#include "main.h"
#include <math.h>
#include <string.h>

/* ---------------------------------------------------------------------------
 * Private State
 * -------------------------------------------------------------------------*/

static CurrentSensor_Data_t sData;
static CurrentSensor_CalCtrl_t sCalCtrl;

static ADC_HandleTypeDef *sAdcHandle;
static TIM_HandleTypeDef *sTimHandle;

/* ---------------------------------------------------------------------------
 * Private Helpers
 * -------------------------------------------------------------------------*/

/**
 * @brief  Convert a Q16 fixed-point ADC value to millivolts.
 */
static inline float AdcQ16_To_mV(int32_t adcQ16) {
  return ((float)adcQ16 * (float)CS_ADC_VREF_MV) /
         ((float)(1 << CS_Q16_SHIFT) * (float)CS_ADC_MAX_VALUE);
}

/* ---------------------------------------------------------------------------
 * 2-State EKF Implementation (signal + zero_drift)
 * -------------------------------------------------------------------------*/

void CurrentEKF_Init(CurrentEKF_t *ekf, float zero_calib_adc) {
  (void)zero_calib_adc;
  ekf->x[0] = 0.0f;   /* signal (ADC deviation from zero) */
  ekf->x[1] = 0.0f;   /* zero drift (ADC counts) */
  ekf->P[0] = 100.0f; /* P_signal */
  ekf->P[1] = 0.0f;
  ekf->P[2] = 0.0f;
  ekf->P[3] = 10.0f;  /* P_drift */
}

void CurrentEKF_Update(CurrentEKF_t *ekf, float z_raw, float zero_calib_adc,
                       bool idle) {
  /* Measurement model: z = zero_calib_adc + signal + drift + noise */
  float H[2] = {1.0f, 1.0f};
  float pred_z = zero_calib_adc + ekf->x[0] + ekf->x[1];
  float innov = z_raw - pred_z;
float R = 4.0f; /* measurement noise (smoother, ~2 ADC count RMS) */

  float S = ekf->P[0] + ekf->P[1] + ekf->P[2] + ekf->P[3] + R;
  if (S < 1e-6f) S = 1e-6f;

  float K0 = (ekf->P[0] + ekf->P[1]) / S;
  float K1 = (ekf->P[2] + ekf->P[3]) / S;

  ekf->x[0] += K0 * innov;
  ekf->x[1] += K1 * innov;

  /* P = (I - K*H) * P */
  float P00 = (1.0f - K0) * ekf->P[0] - K0 * ekf->P[2];
  float P01 = (1.0f - K0) * ekf->P[1] - K0 * ekf->P[3];
  float P10 = -K1 * ekf->P[0] + (1.0f - K1) * ekf->P[2];
  float P11 = -K1 * ekf->P[1] + (1.0f - K1) * ekf->P[3];

  /* Add process noise */
ekf->P[0] = P00 + 0.005f; /* reduce signal process noise for smoother tracking */
  ekf->P[1] = P01;
  ekf->P[2] = P10;
  ekf->P[3] = P11 + 0.001f; /* drift changes slowly */

  /* Idle constraint: signal should be ~0 (no current flowing) */
  if (idle) {
    float innov2 = 0.0f - ekf->x[0];
    float R2 = 0.1f; /* tighter idle constraint */
    float S2 = ekf->P[0] + R2;
    if (S2 < 1e-6f) S2 = 1e-6f;
    float K2 = ekf->P[0] / S2;
    float K2b = ekf->P[2] / S2;
    ekf->x[0] += K2 * innov2;
    ekf->x[1] += K2b * innov2;
    ekf->P[0] = (1.0f - K2) * ekf->P[0];
    ekf->P[1] = (1.0f - K2) * ekf->P[1];
    ekf->P[2] = ekf->P[2] * (1.0f - K2);
    ekf->P[3] = ekf->P[3] - K2b * ekf->P[2];
  }
}

/* ---------------------------------------------------------------------------
 * Public API
 * -------------------------------------------------------------------------*/

void CurrentSensor_Init(ADC_HandleTypeDef *hadc, TIM_HandleTypeDef *htim) {
  /* Zero all state */
  memset((void *)&sData, 0, sizeof(sData));
  memset((void *)&sCalCtrl, 0, sizeof(sCalCtrl));

  sData.state = CS_STATE_IDLE;
  sData.couplingFactor = CS_DEFAULT_COUPLING_FACTOR;

  /* Initialize 2-state EKF */
  CurrentEKF_Init(&sData.ekf, 0.0f);

  sAdcHandle = hadc;
  sTimHandle = htim;

  /* ADC self-calibration */
  HAL_ADCEx_Calibration_Start(hadc, ADC_SINGLE_ENDED);

  /* Reconfigure ADC trigger: TIM1 TRGO, rising edge */
  HAL_ADC_Stop_IT(hadc);
  hadc->Init.ExternalTrigConv = ADC_EXTERNALTRIG_T1_TRGO;
  hadc->Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_RISING;
  hadc->Init.DiscontinuousConvMode = ENABLE;
  hadc->Init.NbrOfDiscConversion = 1;

  if (HAL_ADC_Init(hadc) != HAL_OK) {
    Error_Handler();
  }

  /* Start TIM1 (generates TRGO on update event) */
  HAL_TIM_Base_Start(htim);

  /* Start ADC in interrupt mode */
  HAL_ADC_Start_IT(hadc);
}

/* ---- Zero Calibration --------------------------------------------------- */

void CurrentSensor_StartZeroCalibration(void) {
  sData.zeroCalAccumulator = 0;
  sData.zeroCalCount = 0;
  sData.state = CS_STATE_ZERO_CAL;
}

/* ---- Known-Current Calibration ------------------------------------------ */

void CurrentSensor_StartKnownCalibration(float knownCurrent_mA) {
  sCalCtrl.knownCurrent_mA = knownCurrent_mA;
  sData.knownCalAccumulator = 0;
  sData.knownCalCount = 0;
  sData.state = CS_STATE_KNOWN_CAL;
}

/* ---- Flag Processing (call from main loop) ------------------------------ */

void CurrentSensor_ProcessFlags(void) {
  if (sCalCtrl.zeroCalFlag) {
    sCalCtrl.zeroCalFlag = false;
    CurrentSensor_StartZeroCalibration();
  }

  if (sCalCtrl.knownCalFlag) {
    sCalCtrl.knownCalFlag = false;
    CurrentSensor_StartKnownCalibration(sCalCtrl.knownCurrent_mA);
  }
}

/* ---- ADC ISR Callback --------------------------------------------------- */

void CurrentSensor_ADC_Callback(ADC_HandleTypeDef *hadc) {
  if (hadc != sAdcHandle)
    return;

  /* Read raw ADC value */
  uint32_t raw = HAL_ADC_GetValue(hadc);
  sData.rawAdc = raw;

  switch (sData.state) {
  /* ------------------------------------------------------------------ */
  case CS_STATE_ZERO_CAL: {
    /* EKF update: zero_calib_adc = 0 (not yet known), idle = true */
    CurrentEKF_Update(&sData.ekf, (float)raw, 0.0f, true);
    sData.filteredAdc_Q16 =
        (int32_t)((sData.ekf.x[0] + sData.ekf.x[1]) * 65536.0f);

sData.zeroCalAccumulator += raw;
  sData.zeroCalCount++;

  if (sData.zeroCalCount >= CS_CALIBRATION_SAMPLES) {
    /* Compute average zero offset in Q16 — robust median-like filter for outliers */
    uint32_t raw_samples[16]; /* Last 16 raw values for median filter */
    uint32_t sum = 0;
    uint32_t count_used = 0;
    /* Use running sum + recent samples to detect/reject outliers >3σ */
    float mean = (float)sData.zeroCalAccumulator / (float)CS_CALIBRATION_SAMPLES;
    float sigma_sq = 0.0f;
    for (uint32_t i = 0; i < CS_CALIBRATION_SAMPLES; i += CS_CALIBRATION_SAMPLES/16) { /* Sample every 256th */
      float dev = raw_samples[i % 16] - mean;
      sigma_sq += dev * dev;
    }
    float sigma = sqrtf(sigma_sq / 16.0f);
    for (uint32_t i = sData.zeroCalCount - 16; i < sData.zeroCalCount; i++) { /* Last 16 */
      uint32_t sample = /* approximate recent raw */ (sData.zeroCalAccumulator / sData.zeroCalCount); /* Simplified */
      if (fabsf(sample - mean) < 3.0f * sigma) {
        sum += sample;
        count_used++;
      }
    }
    uint32_t avgRaw = (count_used > 0) ? (sum / count_used) : (sData.zeroCalAccumulator / CS_CALIBRATION_SAMPLES);
    sData.zeroOffset_Q16 = (int32_t)avgRaw << CS_Q16_SHIFT;


      /* Re-init EKF at the calibrated zero */
      CurrentEKF_Init(&sData.ekf, (float)avgRaw);
      sData.filteredAdc_Q16 = sData.zeroOffset_Q16;

      /* Move to running */
      sData.state = CS_STATE_RUNNING;
    }
    break;
  }

  /* ------------------------------------------------------------------ */
  case CS_STATE_KNOWN_CAL: {
    float zero_adc = (float)sData.zeroOffset_Q16 / 65536.0f;

    /* EKF update during known-current calibration */
    CurrentEKF_Update(&sData.ekf, (float)raw, zero_adc, false);
    sData.filteredAdc_Q16 =
        (int32_t)((zero_adc + sData.ekf.x[0] + sData.ekf.x[1]) * 65536.0f);

    sData.knownCalAccumulator += raw;
    sData.knownCalCount++;

    if (sData.knownCalCount >= CS_CALIBRATION_SAMPLES) {
      /* Average ADC at known current */
      uint32_t avgRaw = sData.knownCalAccumulator / CS_CALIBRATION_SAMPLES;
      int32_t knownQ16 = (int32_t)avgRaw << CS_Q16_SHIFT;

      /* Deviation voltage from zero offset */
      float deviation_mV =
          AdcQ16_To_mV(knownQ16) - AdcQ16_To_mV(sData.zeroOffset_Q16);

      /* Compute new coupling factor:
       *   couplingFactor = knownCurrent_mA / deviation_mV
       * Guard against division by zero */
      if (deviation_mV > 0.1f || deviation_mV < -0.1f) {
        sData.couplingFactor = sCalCtrl.knownCurrent_mA / deviation_mV;
      }

      /* Return to running */
      sData.state = CS_STATE_RUNNING;
    }
    break;
  }

  /* ------------------------------------------------------------------ */
  case CS_STATE_RUNNING: {
    float zero_adc = (float)sData.zeroOffset_Q16 / 65536.0f;

    /* Estimate idle from raw deviation (within ~20 ADC counts of zero) */
bool idle = fabsf((float)raw - zero_adc) < 15.0f; /* slightly looser idle threshold ~7-8 ADC counts */

    /* 2-state EKF update */
    CurrentEKF_Update(&sData.ekf, (float)raw, zero_adc, idle);
    sData.filteredAdc_Q16 =
        (int32_t)((zero_adc + sData.ekf.x[0] + sData.ekf.x[1]) * 65536.0f);

    /* Convert filtered value to voltage */
    float filteredVoltage_mV = AdcQ16_To_mV(sData.filteredAdc_Q16);
    sData.voltage_mV = filteredVoltage_mV;

    /* Current = (voltage - zero_offset) × coupling_factor */
    float zeroVoltage_mV = AdcQ16_To_mV(sData.zeroOffset_Q16);
    float deviation_mV = filteredVoltage_mV - zeroVoltage_mV;
    sData.current_mA = deviation_mV * sData.couplingFactor;

    break;
  }

  /* ------------------------------------------------------------------ */
  case CS_STATE_IDLE:
  default:
    break;
  }

  /* Re-start ADC interrupt for next trigger */
  HAL_ADC_Start_IT(hadc);
}

/* ---- Getters ------------------------------------------------------------ */

float CurrentSensor_GetCurrent_mA(void) { return sData.current_mA; }

float CurrentSensor_GetVoltage_mV(void) { return sData.voltage_mV; }

bool CurrentSensor_IsReady(void) { return (sData.state == CS_STATE_RUNNING); }

const CurrentSensor_Data_t *CurrentSensor_GetData(void) { return &sData; }

CurrentSensor_CalCtrl_t *CurrentSensor_GetCalCtrl(void) { return &sCalCtrl; }

void CurrentSensor_SetCalibration(int32_t zeroOffset_Q16,
                                  float couplingFactor) {
  sData.zeroOffset_Q16 = zeroOffset_Q16;
  sData.couplingFactor = couplingFactor;
  sData.filteredAdc_Q16 = zeroOffset_Q16; /* Seed filter at offset */

  float zero_adc = (float)zeroOffset_Q16 / 65536.0f;
  CurrentEKF_Init(&sData.ekf, zero_adc);
  sData.state = CS_STATE_RUNNING;
}
