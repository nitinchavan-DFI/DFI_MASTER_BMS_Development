/**
 * @file    daly_bms.h
 * @brief   Daly BMS UART Communication Driver for STM32 (Non-Blocking)
 *
 * Command set (matches Python reference daly_protocol_full.py):
 *   0x90 → Pack voltage, current, SOC
 *   0x92 → Temperature                  ← was wrongly querying 0x91
 *   0x95 → Cell voltages (3 cells/frame)
 *
 * 0x91 (min/max cell voltage) is NOT queried.  Min, max, and cell-diff
 * are derived from the 0x95 cell array after every complete cycle — this
 * matches the Python parser and eliminates the unvalidated 0x91 path that
 * produced negative cellDiff values (−3249 mV) seen in the BMS log.
 *
 * Frame structure (13 bytes):
 *   TX:  A5 40 CMD 08 00 00 00 00 00 00 00 00 CHK
 *   RX:  A5 01 CMD 08 DATA[8] CHK
 *   CHK: sum(bytes[0..11]) & 0xFF
 */

#ifndef DALY_BMS_H
#define DALY_BMS_H

#include "stm32g4xx_hal.h"
#include "daly_ekf.h"
#include <stdbool.h>
#include <stdint.h>

/* -------------------------------------------------------------------------- */
/*  Protocol constants                                                         */
/* -------------------------------------------------------------------------- */

#define DALY_XFER_BUFFER_LEN     13U
#define DALY_FRAME_START         0xA5U   /**< Sync byte — validated in stream scan */
#define DALY_FRAME_DATA_LEN_BYTE 0x08U   /**< frame[3] must equal this             */
#define DALY_HOST_ADDR           0x40U
#define DALY_START_BYTE          0xA5U   /**< Alias kept for compatibility          */
#define DALY_DATA_LEN            0x08U   /**< Alias kept for compatibility          */

/* Timing */
#define DALY_UART_TIMEOUT_MS       500U
#define DALY_INTERFRAME_GUARD_MS    50U  /**< Guard between multi-frame 0x95 RX    */
#define DALY_UPDATE_INTERVAL_MS   1000U

/* Retry / query config */
#define DALY_MAX_RETRIES      3U
#define DALY_NUM_QUERY_CMDS   3U         /**< 0x90, 0x92, 0x95                     */

/* Cell count */
#define DALY_MAX_CELLS       48U
#define DALY_MIN_CELLS        1U

/**
 * Current offset — Daly encodes current as (actual_A × 10) + 30000.
 * Python reference: (raw_i − 30000) / 10.0
 */
#define DALY_CURRENT_OFFSET  30000

/* -------------------------------------------------------------------------- */
/*  Cell voltage validation                                                    */
/*                                                                             */
/*  Python reference uses 1.5 V – 5.5 V.                                      */
/*  We keep 1500 – 4500 mV (tighter upper bound for Li-Ion safety).            */
/*  Values are in millivolts because 0x95 returns mV (÷ 1000 → V).            */
/* -------------------------------------------------------------------------- */

#define DALY_CELL_V_MIN_MV   1500.0f   /**< Min plausible cell voltage (mV) */
#define DALY_CELL_V_MAX_MV   4500.0f   /**< Max plausible cell voltage (mV) */

/**
 * @brief  Pack voltage plausibility limits.
 *         Adjust PACK_V_MAX_V for your cell count:
 *           12S → 12 × 4.25 = 51.0 V
 *           14S → 14 × 4.25 = 59.5 V
 *         Set conservatively — used to reject ADC runaway frames.
 */
#define DALY_PACK_V_MIN_V    30.0f
#define DALY_PACK_V_MAX_V    60.0f

/* -------------------------------------------------------------------------- */
/*  Command enum                                                               */
/* -------------------------------------------------------------------------- */

typedef enum {
  DALY_CMD_VOUT_IOUT_SOC        = 0x90, /**< Pack V / I / SOC               */
  DALY_CMD_TEMPERATURE          = 0x92, /**< BMS temperature (byte − 40 °C) */
  DALY_CMD_CELL_VOLTAGES        = 0x95, /**< Cell voltages, 3 per frame      */
  /* 0x91 (min/max cell) deliberately omitted — derived from 0x95 array      */
  DALY_CMD_MIN_MAX_CELL_VOLTAGE = 0x91, /**< Not queried; kept for reference */
  DALY_CMD_BMS_RESET            = 0x00,
  /* DALY_CMD_DISCHRG_FET / DALY_CMD_CHRG_FET removed — FET control not used */
} DalyBMS_Command_t;

/* -------------------------------------------------------------------------- */
/*  State machine                                                              */
/* -------------------------------------------------------------------------- */

typedef enum {
  DALY_STATE_IDLE,
  DALY_STATE_SENDING,
  DALY_STATE_WAIT_RX,
  DALY_STATE_INTERFRAME_GUARD,   /**< Brief pause between multi-frame 0x95   */
  DALY_STATE_PARSING,
  DALY_STATE_COMPLETE,
  DALY_STATE_ERROR,
} DalyBMS_State_t;

/* -------------------------------------------------------------------------- */
/*  Data model                                                                 */
/*                                                                             */
/*  Mirrors Python DalyData class fields exactly.                              */
/*  cellVmV[] stores values in MILLIVOLTS (raw from 0x95, before ÷ 1000).    */
/*  min/max/cellDiff are derived from cellVmV[] after each 0x95 cycle —       */
/*  they are NEVER populated from the 0x91 frame.                             */
/* -------------------------------------------------------------------------- */

typedef struct {
  /* 0x90 fields */
  float    packVoltage;     /**< Pack voltage (V)                            */
  float    packCurrent;     /**< Signed current (A); + = charge, − = disch. */
  float    packSOC;         /**< State of charge (%)                         */

  /* 0x92 fields */
  float    temperature;     /**< BMS temperature (°C)  — from 0x92 frame    */

  /* Derived from 0x95 cell array (same as Python .min_cell / .max_cell)     */
  float    maxCellmV;       /**< Highest cell voltage seen in this cycle (mV)*/
  uint8_t  maxCellVNum;     /**< 0-based index of max-voltage cell           */
  float    minCellmV;       /**< Lowest cell voltage seen in this cycle (mV) */
  uint8_t  minCellVNum;     /**< 0-based index of min-voltage cell           */
  float    cellDiff;        /**< maxCellmV − minCellmV  (always ≥ 0)        */

  /* 0x95 fields */
  uint8_t  numberOfCells;   /**< Configured cell count                       */
  float    cellVmV[DALY_MAX_CELLS]; /**< EKF-filtered cell voltages (mV)    */
} DalyBMS_Data_t;

/* -------------------------------------------------------------------------- */
/*  Driver handle                                                              */
/* -------------------------------------------------------------------------- */

typedef struct {
  UART_HandleTypeDef *huart;

  uint8_t txBuffer[DALY_XFER_BUFFER_LEN];
  uint8_t rxBuffer[DALY_XFER_BUFFER_LEN];

  volatile DalyBMS_State_t state;
  uint8_t  currentCmdIndex;
  uint8_t  frameIndex;
  uint8_t  framesExpected;
  uint8_t  retryCount;

  uint32_t rxStartTick;
  uint32_t lastUpdateTick;
  uint8_t  cellVoltageIndex;   /**< Running write cursor (legacy; frame_num  */
                                /**<  now used instead — kept for diagnostics)*/

  volatile bool dataReady;
  volatile bool txComplete;
  volatile bool rxComplete;
  volatile bool rxError;

  DalyBMS_Data_t data;

  uint32_t updateCount;
  uint32_t errorCount;

  /* EKF per-cell filter */
  DalyEKF_Handle_t ekf;
} DalyBMS_Handle_t;

/* -------------------------------------------------------------------------- */
/*  Public API                                                                 */
/* -------------------------------------------------------------------------- */

bool            DalyBMS_Init(DalyBMS_Handle_t *hbms, UART_HandleTypeDef *huart);
void            DalyBMS_SetCellCount(DalyBMS_Handle_t *hbms, uint8_t ncells);
void            DalyBMS_Process(DalyBMS_Handle_t *hbms);
void            DalyBMS_StartUpdate(DalyBMS_Handle_t *hbms);
bool            DalyBMS_IsDataReady(DalyBMS_Handle_t *hbms);
void            DalyBMS_ClearDataReady(DalyBMS_Handle_t *hbms);
DalyBMS_State_t DalyBMS_GetState(DalyBMS_Handle_t *hbms);
bool            DalyBMS_IsDataValid(DalyBMS_Handle_t *hbms);

/* UART interrupt callbacks — call from HAL_UART_TxCpltCallback etc. */
void DalyBMS_TxCpltCallback(DalyBMS_Handle_t *hbms, UART_HandleTypeDef *huart);
void DalyBMS_RxCpltCallback(DalyBMS_Handle_t *hbms, UART_HandleTypeDef *huart);
void DalyBMS_ErrorCallback(DalyBMS_Handle_t *hbms, UART_HandleTypeDef *huart);

/* Validators (exposed for unit tests) */
bool DalyBMS_ValidateCellVoltage(float raw_mv);
bool DalyBMS_ValidateFrame(const uint8_t *buf, uint8_t len);

#endif /* DALY_BMS_H */
