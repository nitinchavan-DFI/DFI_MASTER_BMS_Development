/**
 * @file    charger_config.h
 * @brief   Solterra charger: RX status handling and plug-and-play command
 *          computation. ISR only latches raw bytes; all decode and state
 *          machine work runs in the main loop via Charger_ProcessStatusFrame().
 */
#ifndef CHARGER_CONFIG_H
#define CHARGER_CONFIG_H

#ifdef __cplusplus
extern "C" {
#endif

#include "cli_frame.h" /* CLI_ChargerConfig_t */
#include <stdint.h>
#include <stdbool.h>

/* ---- Factory defaults (used on first boot / invalid flash) ---- */
#define CHARGER_CONFIG_DEFAULT_CELL_V 4.20f     /**< V/cell               */
#define CHARGER_CONFIG_DEFAULT_ICHG_A 15.0f     /**< Full charge current ceiling (A) */
#define CHARGER_CONFIG_DEFAULT_ITAPER_A 1.0f     /**< CV cutoff: stop charging when charger-reported current drops to 1A */
#define CHARGER_CONFIG_DEFAULT_SOC_TAPER 95.0f  /**< Taper start SOC %    */
#define CHARGER_CONFIG_DEFAULT_CELLS 14U        /**< Series cell count    */

/**
 * @brief  Populate cfg with the factory-default charge profile.
 */
void ChargerConfig_LoadDefaults(CLI_ChargerConfig_t *cfg);

/* ── Solterra charger status broadcast (CHARGER_RX_ID_STATUS, ID 0x18FF50E5) ──
 * Byte layout per the DFI BMS CAN Packet Map (BIG-ENDIAN V/I, unlike every
 * other frame on this bus — verified against the real charger, do not
 * "fix" this to little-endian):
 *   [0-1] actual_V_x10  uint16 BE  (V x10)
 *   [2-3] actual_I_x10  uint16 BE  (A x10)
 *   [4]   flags         uint8      bits0-2 = fault code, bit3 = inhibited
 * dlc >= 5 required; shorter frames are discarded as malformed.
 */
#define CHARGER_FLAG_FAULT_MASK 0x07U /**< bits 0-2: fault code (any != 0) */
#define CHARGER_FLAG_INHIBITED  0x08U /**< bit 3                          */

/* ── Charger CMD control-byte polarity (byte[4] of CHARGER_TX_ID_CMD) ──────
 * RESOLVED — confirmed against real hardware (BUSMASTER capture, 2026-07-10):
 * with this firmware sending ctrl=0x01 for "enabled", the real charger
 * accepted the V/I setpoints (visible in Signal Watch) but never started
 * charging (actual_I stayed 0). That matches bms_master_gui_charging_
 * display.py's build_charger_cmd() convention exactly: 0x00 = START/
 * enabled, 0x01 = STOP/disabled, the ORIGINAL packet-map spec. The
 * previous "flipped at explicit request" value was wrong. */
#define CHARGER_CTRL_ENABLED_VALUE  0x00U
#define CHARGER_CTRL_DISABLED_VALUE 0x01U

/** @brief  Charger state machine (derived from the RX status broadcast). */
typedef enum {
  CHARGER_STATE_DISCONNECTED = 0, /**< No valid status frame ever/lately seen */
  CHARGER_STATE_READY        = 1, /**< Present, reports V=0/I=0, not faulted  */
  CHARGER_STATE_CHARGING     = 2, /**< Present, reports V>0 && I>0            */
  CHARGER_STATE_FAULT        = 3, /**< Charger-reported fault bits active     */
  CHARGER_STATE_INHIBITED    = 4, /**< Charger-reported inhibited bit active  */
  CHARGER_STATE_TIMEOUT      = 5, /**< Was connected, silent > COMM_TIMEOUT   */
} ChargerState_t;

#define CHARGER_COMM_TIMEOUT_MS 5000U /**< 5.0 s silence -> TIMEOUT */

/* ── Temp1 charge-start thermal gate (sticky/latched) ─────────────────────
 * A pre-emptive, charger-specific gate on the START/continue command,
 * separate from and more conservative than the pack-wide OT fault
 * (FAULT_BIT_OT, 55.0°C set / 52.0°C clear — see fault_detector.h). That
 * fault stops everything (charge + discharge) as a last-resort safety
 * trip. This gate exists so the BMS refuses to (re)start a Solterra
 * charge session well before Temp1 ever gets that hot:
 *
 *   - BLOCK  charging start: Temp1 >= CHARGER_TEMP_START_BLOCK_C   (50.0°C)
 *   - RESUME charging start: Temp1 <= CHARGER_TEMP_START_RESUME_C -
 *                                     CHARGER_TEMP_START_TOL_C     (46.2°C)
 *
 * Between the resume point (46.2°C) and the block point (50.0°C) the gate
 * holds its previous state (sticky) — this is the 0.8°C "tolerance" band,
 * and it exists purely to stop the gate chattering on/off if Temp1 sits
 * right at a boundary. It is intentionally NOT a simple ">47°C" test —
 * see Charger_ComputeCommand() for the latch logic. */
#define CHARGER_TEMP_START_BLOCK_C   50.0f /**< °C — hard block, start/continue NOT supported */
#define CHARGER_TEMP_START_RESUME_C  47.0f /**< °C — resume point once blocked                */
#define CHARGER_TEMP_START_TOL_C     0.8f  /**< °C — tolerance/hysteresis band around resume  */

/* ── Sentinel values for the temp1_C argument of Charger_ComputeCommand() ──
 * The gate is a pure comparison against the two thresholds above, so the
 * caller can steer it entirely through the value it passes. Two sentinels
 * are defined so every caller agrees on the meaning:
 *
 *   CHARGER_TEMP_NOT_READY_C (0.0f)
 *     "No temperature sample yet." Sits below the resume point, so it does
 *     NOT block — correct for the first few hundred ms after boot, before
 *     the ADC has produced a sample.
 *
 *   CHARGER_TEMP_SENSOR_FAIL_C (999.0f)
 *     "The sensor is present-but-broken: open circuit, out of range, NaN."
 *     Sits above the block point, so the existing sticky latch blocks and
 *     STAYS blocked until a plausible reading <= 46.2 °C arrives. This is
 *     the important one: NTC_ADC_To_Celsius() returns -999.0f on an open
 *     circuit, and -999 is *below* the resume point, so passing the raw
 *     reading through would UNBLOCK the gate on a disconnected thermistor
 *     and permit a full-current charge with no thermal sensing at all.
 *     FAULT_BIT_THERM_MISSING does not save you either — it is not in
 *     CHARGER_GATING_FAULT_MASK.
 */
#define CHARGER_TEMP_NOT_READY_C     0.0f
#define CHARGER_TEMP_SENSOR_FAIL_C   999.0f

/** Lowest/highest temperature accepted as a real reading (°C). Anything
 *  outside this window is treated as CHARGER_TEMP_SENSOR_FAIL_C. */
#define CHARGER_TEMP_PLAUSIBLE_MIN_C (-40.0f)
#define CHARGER_TEMP_PLAUSIBLE_MAX_C (150.0f)

/* ── CLI_CMD_CHARGER_STATUS_DATA (0x25) byte[3] bit map ───────────────────
 * byte[3] was documented as "reserved" and main.c was already packing
 * cv_phase/charge_done into it. Named here so main.c and the Python GUI
 * decode the same bits. bit2 is new: without it, a charge session refused
 * by the thermal gate is indistinguishable from any other reason the
 * charger sits at output-OFF — the BMS just sends STOP forever and says
 * nothing about why. */
#define CHARGER_STATUS_BIT_CV_PHASE     0x01U /**< in constant-voltage phase */
#define CHARGER_STATUS_BIT_CHARGE_DONE  0x02U /**< CV taper termination hit  */
#define CHARGER_STATUS_BIT_TEMP_BLOCKED 0x04U /**< thermal gate is inhibiting */

/** @brief  Raw ISR->main-loop handoff slot. ISR writer, main-loop reader —
 *          see Charger_LatchRawFrame()/Charger_ProcessStatusFrame() for the
 *          short critical section that makes the 8-byte handoff atomic
 *          (a plain byte-array copy is NOT atomic on Cortex-M4, unlike the
 *          single-word g_adc_raw handoff used elsewhere in this project). */
typedef struct {
  uint8_t raw[8];
  uint8_t len;
  volatile uint8_t pending;   /**< 1 = unread frame waiting                */
  uint32_t overrun_count;     /**< ISR latched a new frame before main loop
                                    consumed the previous one (diagnostic) */
} ChargerRxStage_t;

/** @brief  Live charger runtime: state machine + last command. */
typedef struct {
  ChargerState_t state;
  uint8_t  comm_ok;            /**< 1 = frames arriving within timeout      */
  uint8_t  last_valid_flags;   /**< Last received flags byte                */
  uint8_t  cv_phase;           /**< 1 = charger has entered CV phase        */
  uint8_t  charge_done;        /**< 1 = CV cutoff current reached (full)    */
  uint32_t last_valid_rx_tick; /**< HAL_GetTick() of last accepted frame    */
  uint8_t  everConnected;      /**< 1 once any valid frame has ever arrived */
  uint8_t  tempStartBlocked;   /**< 1 = Temp1 gate currently inhibiting the
                                     charge-start cmd (sticky, see
                                     CHARGER_TEMP_START_BLOCK_C/RESUME_C)    */
  float    actual_V;           /**< Charger-reported voltage (V)            */
  float    actual_I;           /**< Charger-reported current (A)            */
  float    cmd_V_setpoint;     /**< Last commanded V setpoint               */
  float    cmd_I_setpoint;     /**< Last commanded I setpoint               */
} ChargerRuntime_t;

/** @brief  RX staging buffer — defined in charger_config.c, latched from
 *          ISR context by Charger_LatchRawFrame() / Process_Charger_Frame(). */
/**
 * Fixed taper current threshold for ideal charge termination (A).
 * When charger-reported actual current drops to this level in CV mode,
 * the BMS commands STOP. This is NOT sent to the charger — it is a
 * BMS-side monitoring threshold only. The charger's own taper continues
 * naturally until it hits zero or receives the STOP command.
 */
#define CHARGER_TAPER_CURRENT_A  2.0f

extern ChargerRxStage_t g_chargerRxStage;

/**
 * @brief  Zero a runtime handle to its power-on-safe state (DISCONNECTED,
 *         derate stage INHIBIT until a real temperature reading proves
 *         otherwise). Call once at boot.
 */
void Charger_RuntimeInit(ChargerRuntime_t *rt);

/**
 * @brief  ISR-context latch: copies up to 8 raw bytes out of the FDCAN RX
 *         message into *stage and sets the pending flag. O(1), no
 *         floating-point math, no function calls out — safe to call from
 *         HAL_FDCAN_RxFifo0Callback() no matter how fast/noisy the charger
 *         is. If the previous frame was never consumed, it is silently
 *         overwritten and stage->overrun_count is bumped (diagnostic only
 *         — losing a status sample is harmless, this is a broadcast).
 */
void Charger_LatchRawFrame(ChargerRxStage_t *stage, const uint8_t *data, uint8_t len);

/**
 * @brief  Main-loop-context consumer: call once per iteration (unconditional
 *         — cheap). Runs the comm-timeout watchdog every call, and if
 *         stage->pending is set, decodes + filters + debounces the staged
 *         frame and updates the DISCONNECTED/READY/CHARGING/FAULT/
 *         INHIBITED state machine in *rt.
 * @param  rt        Runtime handle to update.
 * @param  stage     Staging buffer written by Charger_LatchRawFrame().
 * @param  tick_ms   HAL_GetTick() snapshot for this loop iteration.
 */
void Charger_ProcessStatusFrame(ChargerRuntime_t *rt, ChargerRxStage_t *stage,
                                 uint32_t tick_ms);

/**
 * @brief  Compute the Solterra charge command (CC/CV, plug-and-play).
 *
 * Three stop paths (checked in this order):
 *   a) PATH T  — CHARGER-SIDE TEMP1 GATE (independent of pack safety):
 *      Temp1 >= CHARGER_TEMP_START_BLOCK_C (50.0°C) → immediate STOP,
 *      reset CC/CV state. Sticky until Temp1 <= CHARGER_TEMP_START_RESUME_C
 *      - CHARGER_TEMP_START_TOL_C (46.2°C). Does not read faultBitmask or
 *      fault_detector's otTemp_C — entirely separate thresholds/state from
 *      path (b) below, evaluated only against the raw Temp1 reading.
 *   b) PATH A  — PACK-LEVEL FAULT STOP: OV or OT fault (faultBitmask,
 *      55.0°C/52.0°C hysteresis in fault_detector.c) → immediate STOP,
 *      reset CC/CV state.
 *   c) PATH B  — NORMAL TERMINATION: CV mode + charger-reported actual
 *      current ≤ CHARGER_TAPER_CURRENT_A (2.0A) → STOP, set charge_done=1.
 *
 * CC phase: send chargeCurrentFull_A until charger-reported V >= pack target.
 * CV phase: charger self-limits voltage; BMS monitors actual current for
 *           taper-done condition.
 *
 * @param  temp1_C  Current Temp1 (NTC1) reading in °C. Pass 0.0f if the
 *                   ADC hasn't produced a first sample yet (same "not
 *                   ready" sentinel used elsewhere, e.g. main.c's
 *                   safe_temp1) — 0.0f sits below the resume threshold so
 *                   it does not spuriously block charging at boot.
 */
void Charger_ComputeCommand(ChargerRuntime_t *rt, const CLI_ChargerConfig_t *cfg,
                             float soc_percent, uint16_t faultBitmask,
                             float temp1_C,
                             float *out_v_setpoint, float *out_i_setpoint,
                             uint8_t *out_enabled);

#ifdef __cplusplus
}
#endif

#endif /* CHARGER_CONFIG_H */
