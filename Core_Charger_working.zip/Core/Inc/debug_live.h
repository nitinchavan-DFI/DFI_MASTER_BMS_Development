/**
 * @file    debug_live.h
 * @brief   SWD/debug-time parameter view + live tuning via STM32CubeIDE's
 *          "Live Expressions" view — a bench-side mirror of the same
 *          thresholds and calibration the GUI reads/writes over CAN.
 *
 * ── WHY THIS EXISTS ──────────────────────────────────────────────────────
 * Earlier, simpler firmware kept its tunables as plain globals in main.c,
 * so pausing in STM32CubeIDE and adding them to Live Expressions "just
 * worked". After the refactor into calib_store / fault_detector /
 * current_sensor modules, the equivalent values became internal `static`
 * state private to each .c file (fault_detector.c: sThresh, current_sensor.c:
 * sData) — still technically inspectable with file-qualified names, but
 * scattered and awkward, and NOT safe to edit directly (writing sThresh via
 * SWD skips validation and CalibStore persistence).
 *
 * This module puts one flat, non-static struct back in front of you:
 * g_dbgLive. Add just that one name to Live Expressions and expand it.
 *
 * ── HOW TO USE (STM32CubeIDE) ────────────────────────────────────────────
 *   1. Start a normal debug session (same ST-Link SWD connection used to
 *      flash the board — no extra hardware or wiring).
 *   2. Window > Show View > Debug > "Live Expressions".
 *   3. Add new expression -> type:  g_dbgLive   -> expand the tree.
 *      Everything updates once per main-loop iteration, whether the
 *      target is running free or paused at a breakpoint.
 *   4. To change a threshold: expand g_dbgLive.thr, double-click the field
 *      you want (e.g. ovVoltage_V), type the new value, press Enter, then
 *      set g_dbgLive.applyThresholds to 1. The firmware validates it with
 *      the same bounds check used for CAN/GUI writes and clears the flag
 *      once serviced (≤ one loop tick later). If the edit fails
 *      validation, applyThresholds is cleared WITHOUT being applied and
 *      g_dbgLive.lastApplyRejected is set to 1 — g_dbgLive.thr also snaps
 *      back to the real active values so a rejected edit doesn't sit
 *      there looking "applied" when it wasn't.
 *   5. Same pattern for current-sensor calibration: edit cur_zeroOffset_Q16
 *      / cur_couplingFactor, then set applyCurrentCal = 1.
 *   6. To persist whatever is currently active to external flash (same
 *      effect as the GUI's "Save" / CLI_CMD_SAVE_CAL), set saveToFlash = 1.
 *   7. To discard unsaved edits sitting in thr / cur_* and pull the mirror
 *      back in from whatever's actually running, set reloadFromLive = 1.
 *
 * This is additive and debug-build-only in spirit — nothing about the
 * existing CLI/GUI threshold path is touched, and both control paths write
 * to the exact same live state (Fault_SetThresholds / CurrentSensor
 * calibration), so they can never disagree with each other.
 */

#ifndef DEBUG_LIVE_H
#define DEBUG_LIVE_H

#ifdef __cplusplus
extern "C" {
#endif

#include "fault_detector.h" /* FaultThresholds_t */
#include <stdbool.h>
#include <stdint.h>

typedef struct {
  /* ---- Command flags: set from Live Expressions; firmware clears them
   *      once serviced. Any nonzero value is treated as "1". ---- */
  volatile uint8_t applyThresholds;   /**< 1 = push thr into the live fault detector (validated) */
  volatile uint8_t applyCurrentCal;   /**< 1 = push cur_* into the live current sensor */
  volatile uint8_t saveToFlash;       /**< 1 = persist live state to flash (same as CLI_CMD_SAVE_CAL) */
  volatile uint8_t reloadFromLive;    /**< 1 = overwrite thr/cur_* below with what's actually active */
  volatile uint8_t lastApplyRejected; /**< firmware sets 1 if the last applyThresholds failed validation */

  /* ---- Editable mirror: edit these, then raise the matching flag above.
   *      Not read by the firmware until the flag is set. ---- */
  FaultThresholds_t thr; /**< 9 fault thresholds, same layout as CLI 0x20 */
  int32_t cur_zeroOffset_Q16;
  float cur_couplingFactor;

  /* ---- Read-only live telemetry: refreshed every main-loop iteration
   *      regardless of the flags above. ---- */
  float live_packVoltage_V;
  float live_current_A;
  float live_cellDiff_mV;
  float live_minCell_mV;
  float live_maxCell_mV;
  float live_temp1_C;
  float live_temp2_C;
  float live_socPercent;
  uint16_t live_faultBitmask;
  uint32_t live_updateCounter; /**< increments every call — if this is frozen
                                    while the target shows "running", the
                                    main loop itself is stuck, not just this
                                    mirror */
} DebugLive_t;

/** The single global instance — add "g_dbgLive" to Live Expressions. */
extern DebugLive_t g_dbgLive;

/**
 * @brief  Seed the mirror from whatever is already active. Call once at
 *         boot, after Fault_Init() and current-sensor calibration restore.
 */
void DebugLive_Init(void);

/**
 * @brief  Call once per main-loop iteration. Refreshes the read-only
 *         telemetry fields and services applyThresholds / applyCurrentCal /
 *         reloadFromLive. (saveToFlash is serviced by the caller — see
 *         main.c — since it needs main.c's own SaveSystemStateToFlash().)
 */
void DebugLive_Update(float packVoltage_V, float current_A, float cellDiff_mV,
                       float minCell_mV, float maxCell_mV, float temp1_C,
                       float temp2_C, float socPercent,
                       uint16_t faultBitmask);

#ifdef __cplusplus
}
#endif

#endif /* DEBUG_LIVE_H */
