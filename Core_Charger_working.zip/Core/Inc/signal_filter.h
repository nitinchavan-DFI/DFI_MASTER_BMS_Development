/**
 * @file    signal_filter.h
 * @brief   Automotive-grade signal filtering for BMS telemetry
 *          Kalman + MA(5) + Median(3) + Rate-limiter + Balancer immunity
 *          Rejects glitches, provides validated/filtered values for fault/SOC
 */

#ifndef SIGNAL_FILTER_H
#define SIGNAL_FILTER_H

#ifdef __cplusplus
extern "C" {
#endif

#include "daly_bms.h"
#include <stdbool.h>
#include <stdint.h>

/* ---- Filter Windows (O(1) circular) ------------------------------------- */
#define FILTER_MA_WINDOW 5      /* Moving average */
#define FILTER_MEDIAN_WINDOW 3  /* Median (sort 3) */
#define FILTER_RATE_LIMIT_V_100MS 0.5f  /* Max dV/dt */
#define FILTER_BALANCER_IMMUNITY_MS 500 /* Ignore during/after balance */

/* ---- Kalman Constants (simple 1D position-velocity) ---------------------- */
#define KALMAN_Q 0.01f     /* Process noise */
#define KALMAN_R 0.1f      /* Measurement noise */
#define KALMAN_INIT_X 50.0f /* Initial packV estimate */

/* ---- Outputs ------------------------------------------------------------- */
typedef struct {
  float filtered_packV;
  float filtered_min_cellV;
  float filtered_max_cellV;
  bool valid;           /* True if passed all validations */
  uint32_t glitch_reject_count; /* Stats */
} FilteredData_t;

/* ---- Handle -------------------------------------------------------------- */
typedef struct {
  /* Circular buffers */
  float ma_packV[FILTER_MA_WINDOW];
  float ma_minV[FILTER_MA_WINDOW];
  float ma_maxV[FILTER_MA_WINDOW];
  float median_packV[FILTER_MEDIAN_WINDOW];
  float median_minV[FILTER_MEDIAN_WINDOW];
  float median_maxV[FILTER_MEDIAN_WINDOW];
  
  /* [FIX-CellMinMax-ghost] Each MA buffer MUST have its own independent
   * write cursor. A single shared ma_head was being advanced inside
   * moving_average() on every call, and SignalFilter_Update() calls it
   * 3x per cycle (packV, minV, maxV) on the SAME head variable. That
   * desynced each 5-slot ring buffer from itself by 3 slots/cycle,
   * causing stale/overwritten-out-of-order samples to surface in the
   * average — observed as filtered_min/max_cellV ghosting down into the
   * 180-400 mV range for several seconds before the ring re-aligned.   */
  uint8_t ma_head_packV;
  uint8_t ma_head_minV;
  uint8_t ma_head_maxV;
  uint8_t median_head;
  
  /* Kalman states */
  float kalman_x;  /* Estimate */
  float kalman_P;  /* Error cov */
  float kalman_prevV;
  
  /* Immunity timer */
  uint32_t balancer_end_tick;
  
  /* Stats */
  uint32_t total_samples;
  uint32_t rejected_glitch;
  uint32_t rejected_rate;
} SignalFilter_Handle_t;

/**
 * @brief Init filter with defaults
 */
void SignalFilter_Init(SignalFilter_Handle_t *hfilter);

/**
 * @brief Update with raw Daly data + current/balance state
 * @param hfilter  Filter handle
 * @param hDaly    Raw Daly data (if dataReady)
 * @param current_a Pack current (A)
 * @param tick_ms  HAL_GetTick()
 * @return FilteredData_t (use if valid)
 * Time: O(1) ~10us @ 170MHz
 */
FilteredData_t SignalFilter_Update(SignalFilter_Handle_t *hfilter, const DalyBMS_Data_t *pdaly, float current_a, uint32_t tick_ms);

/**
 * @brief Physical consistency validation
 */
bool SignalFilter_ValidateRaw(const DalyBMS_Data_t *pdaly, float current_a);

#ifdef __cplusplus
}
#endif

#endif /* SIGNAL_FILTER_H */
