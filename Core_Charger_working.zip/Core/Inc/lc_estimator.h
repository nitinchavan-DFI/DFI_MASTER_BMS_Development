/**
 * @file    lc_estimator.h
 * @brief   Life Capacity (LC) estimator — iPhone-style SOC-mapped display.
 *
 * ── DESIGN PHILOSOPHY ────────────────────────────────────────────────────────
 *
 *  LC% is a USER-FACING DISPLAY number derived from SOC%, not raw coulombs.
 *  It mirrors Apple iPhone BMS behaviour:
 *    1. Never goes UP during discharge (monotone-down guard).
 *    2. Reaches 100% ONLY after CC→CV transition AND taper current settles.
 *    3. Moves in clean 1% integer steps — no flicker, no 2% jumps.
 *    4. Slightly pessimistic at high loads (under-promise, over-deliver).
 *    5. Self-corrects during rest (same as iPhone "Optimised Charging" idle).
 *
 * ── CC / CV CONCEPT LINK ─────────────────────────────────────────────────────
 *
 *  CC  (Constant Current):
 *    Charger supplies rated current; pack voltage rises.
 *    SOC climbs quickly. LC tracks SOC with a modest IIR lag (alpha_cc).
 *    LC is clamped to 99% max — we never show 100% until CV taper completes.
 *
 *  CV  (Constant Voltage):
 *    Pack is near full. Charger holds voltage; current tapers exponentially.
 *    LC is FROZEN at the value it had when CC→CV transition was confirmed.
 *    Only when SOC ≥ 99.5% AND |I| < LC_TAPER_DONE_FRAC × LC_TAPER_CURRENT_A
 *    does LC snap to exactly 100.0%.
 *    This prevents the premature "100%" display Apple specifically avoids.
 *
 *  CD  (Constant Discharge / dynamic load):
 *    LC follows SOC downward with monotone-down guard.
 *    A voltage-sag correction (I × Ri) gives load-adjusted pessimism:
 *    at high current, displayed LC is slightly lower than raw SOC would be.
 *
 *  IDLE (|I| < threshold):
 *    LC drifts very slowly toward true SOC (alpha_idle ≈ 0.005).
 *    Corrects any accumulated CC/CD drift imperceptibly over ~3 minutes.
 *
 * ── SOC LINKAGE ──────────────────────────────────────────────────────────────
 *
 *  LC is tightly linked to the Kalman-filtered SOC from soc.c:
 *    target_lc = SOC_GetPercent()   (1:1 mapping, with phase-specific lag)
 *
 *  Hard calibration anchors propagate immediately:
 *    SOC_SetFull()  → LC_SetFull()   (snaps to 100%)
 *    SOC_SetEmpty() → LC_SetZero()   (snaps to 1% display minimum)
 *
 *  Confidence reflects Kalman covariance:
 *    high P_soc (uncertain SOC) → lower LC confidence.
 *
 * ── OUTPUTS (LC_Data_t) ──────────────────────────────────────────────────────
 *    lc_percent       — 1-100 display value (1% integer steps)
 *    remaining_wh     — Energy remaining (Wh), SOH + temp + imbalance derated
 *    remaining_time_s — Estimated runtime at current EMA draw (s)
 *    confidence       — 0.0–1.0 quality flag (drives display dimming / asterisk)
 *    charge_phase     — CC / CV / CD / IDLE for telemetry
 */

#ifndef LC_ESTIMATOR_H
#define LC_ESTIMATOR_H

#include <stdint.h>
#include <stdbool.h>

/* ── Configuration ──────────────────────────────────────────────────────── */

/**
 * Default nominal pack capacity (Ah) — used ONLY when LC_InitWithConfig()
 * is not called and the legacy LC_Init() API is used instead.
 * Overridden at runtime by battery_capacity_ah from config when using
 * LC_InitWithConfig().
 */
#define LC_NOMINAL_CAP_AH           72.0f

/**
 * Default nominal pack voltage at 100% SOC (V) — used ONLY with legacy
 * LC_Init(). Overridden at runtime by pack_full_voltage when using
 * LC_InitWithConfig().
 */
#define LC_NOMINAL_FULL_V           54.6f

/** Default nominal pack voltage at 50% SOC (V) — used ONLY with legacy
 * LC_Init(). Overridden at runtime by (cellCount * cellNominalV) when
 * using LC_InitWithConfig(). cellNominalV ≈ pack_full_voltage / cellCount.
 */
#define LC_NOMINAL_MID_V            48.8f

/**
 * Taper current threshold (A).
 * Above this during charging  → CC phase.
 * Below this during charging  → CV phase.
 * C/20 rule for 72 Ah pack = 3.6 A.
 */
#define LC_TAPER_CURRENT_A          3.6f

/**
 * Fraction of LC_TAPER_CURRENT_A below which charge is declared DONE.
 * i.e. taper_done when |I| < LC_TAPER_CURRENT_A * LC_TAPER_DONE_FRAC.
 * 0.5 → must fall to C/40 before LC snaps to 100%.
 */
#define LC_TAPER_DONE_FRAC          0.5f

/** Minimum positive current (A) to classify as "charging". */
#define LC_CHARGE_MIN_CURRENT_A     1.5f

/** Minimum negative current magnitude (A) to classify as "discharging". */
#define LC_DISCHARGE_MIN_CURRENT_A  1.5f

/** DC internal resistance (Ω) — used for voltage-sag load correction. */
#define LC_R_INTERNAL_OHM           0.025f

/** Temperature below which capacity derate is applied (°C). */
#define LC_TEMP_LOW_DEG             10.0f

/** Temperature above which capacity derate is applied (°C). */
#define LC_TEMP_HIGH_DEG            50.0f

/**
 * IIR smoothing alpha values per phase.
 * alpha = 1.0 → instant tracking; alpha → 0 → frozen.
 *
 * CC  : fast ramp — follows SOC closely during bulk charge.
 * CV  : 0 — display frozen until taper completion confirmed.
 * CD  : moderate — smooth discharge, never bounces up.
 * IDLE: very slow drift — corrects overnight without user noticing.
 */
#define LC_ALPHA_CC                 0.05f
#define LC_ALPHA_CV                 0.00f
#define LC_ALPHA_CD                 0.03f
#define LC_ALPHA_IDLE               0.005f

/**
 * Number of consecutive 100 ms ticks a candidate phase must be seen before
 * the phase change is committed (debounce against balancer current pulses).
 */
#define LC_PHASE_DEBOUNCE_TICKS     5

/**
 * Kalman covariance threshold above which LC confidence is reduced.
 * If SOC_Handle_t.P_soc > this, LC confidence is degraded proportionally.
 * Units: Ah² (P_soc is in Ah²).
 */
#define LC_CONF_HIGH_P_THRESH       50.0f

/* ── Types ──────────────────────────────────────────────────────────────── */

/** Battery operating phase inferred from current and voltage. */
typedef enum {
    LC_PHASE_IDLE = 0,  /**< |I| below threshold — at rest / standby        */
    LC_PHASE_CC,        /**< Charging, constant current (I ≥ taper thresh)  */
    LC_PHASE_CV,        /**< Charging, CV taper    (I < taper, V near full) */
    LC_PHASE_CD,        /**< Discharging (constant or dynamic load)         */
} LC_Phase_t;

/** Published every 100 ms. Maps directly to CLI_CMD_LC_DATA frame. */
typedef struct {
    float    lc_percent;        /**< Display LC% [1.0–100.0], 1% steps      */
    float    remaining_wh;      /**< Estimated energy remaining (Wh)         */
    float    remaining_time_s;  /**< Time remaining at current EMA draw (s)  */
    float    confidence;        /**< Estimator confidence [0.0–1.0]          */
    uint8_t  charge_phase;      /**< LC_Phase_t cast to uint8 (for UART)     */
    uint8_t  _pad[3];
} LC_Data_t;

/** Internal estimator state. Zero-initialise before calling LC_Init(). */
typedef struct {
    /* Configuration */
    float        soh_pct;           /**< State-of-Health % [0–100]           */
    float        pack_full_voltage; /**< Pack voltage at 100% SOC (V)        */
    float        pack_capacity_ah;  /**< Pack nominal capacity (Ah)          */
    uint8_t      cell_count;        /**< Number of cells in series           */

    /* Phase detection */
    LC_Phase_t   phase;             /**< Committed (debounced) phase         */
    LC_Phase_t   phase_candidate;   /**< Candidate phase being debounced     */
    uint8_t      phase_ticks;       /**< Consecutive ticks of candidate      */

    /* SOC shadow — updated every LC_Update() call */
    float        soc_pct;           /**< Latest SOC% from Kalman estimator   */
    float        soc_kalman_P;      /**< SOC Kalman covariance (Ah²)         */

    /* LC display state */
    float        lc_display;        /**< Smoothed LC% [0–100] internal float */
    float        lc_at_cv_entry;    /**< LC% frozen when CV phase entered    */
    bool         cv_complete;       /**< True once taper-done confirmed      */

    /* CV voltage anchor: pack voltage when CC→CV transition occurred */
    float        cv_entry_packV;    /**< Pack voltage at CC→CV (V)           */

    /* Current EMA (for time-remaining and sag correction) */
    float        avg_current_a;     /**< EMA of |current_a| (A)              */

    /* Confidence IIR */
    float        confidence;        /**< Smoothed confidence [0–1]           */

    /* Published output (returned by LC_Update / LC_GetData) */
    LC_Data_t    data;
} LC_Handle_t;

/* ── Public API ─────────────────────────────────────────────────────────── */

/**
 * @brief Initialise LC estimator — legacy API (uses default hardcoded values).
 *
 * Call once after SOC_Init() so the opening LC value matches real SOC.
 * Uses default LC_NOMINAL_CAP_AH / LC_NOMINAL_FULL_V / LC_NOMINAL_MID_V.
 * Prefer LC_InitWithConfig() for runtime-configurable pack parameters.
 *
 * @param hlc       Handle (must be zero-filled by caller before first call).
 * @param soh_pct   State-of-Health % (0–100). Use 100.0f if unknown.
 * @param init_soc  SOC% from SOC_GetPercent() — sets the opening LC display.
 */
void LC_Init(LC_Handle_t *hlc, float soh_pct, float init_soc);

/**
 * @brief Initialise LC estimator with runtime pack configuration.
 *
 * Preferred over LC_Init() — uses actual pack parameters from config,
 * not hardcoded defaults. Passed values are typically sourced from
 * g_soc_config.pack_full_voltage, g_soc_config.battery_capacity_ah,
 * and g_charger_config.cellCount.
 *
 * Calculates internal mid-voltage as the linear midpoint:
 *   mid_v = pack_full_voltage - (pack_full_voltage - v_empty) * 0.5f
 * where v_empty ≈ cellCount * 3.0V (typical LFP/LMO empty voltage).
 *
 * @param hlc               Handle (must be zero-filled before first call).
 * @param soh_pct           State-of-Health % (0–100). Use 100.0f if unknown.
 * @param init_soc          SOC% from SOC_GetPercent().
 * @param pack_full_voltage Pack voltage at 100% SOC (V) from config.
 * @param battery_capacity_ah Nominal pack capacity (Ah) from config.
 * @param cellCount         Number of cells in series from config.
 */
void LC_InitWithConfig(LC_Handle_t *hlc,
                       float soh_pct,
                       float init_soc,
                       float pack_full_voltage,
                       float battery_capacity_ah,
                       uint8_t cellCount);

/**
 * @brief Update LC estimator — call every 100 ms in the main BMS tick.
 *
 * @param hlc           Estimator handle.
 * @param soc_pct       SOC% from SOC_GetPercent().
 * @param soc_kalman_P  SOC Kalman error covariance (Ah²) from SOC_Handle_t.P_soc.
 *                      Pass 0.0f if unavailable — confidence will default to 0.85.
 * @param pack_v        Filtered pack voltage (V).
 * @param current_a     Pack current (A). Positive = charging, negative = discharge.
 * @param temp_c        Battery temperature (°C).
 * @param cell_diff_mv  Worst-case cell spread (max − min, mV).
 * @return              Const pointer to updated LC_Data_t.
 */
const LC_Data_t *LC_Update(LC_Handle_t *hlc,
                           float soc_pct,
                           float soc_kalman_P,
                           float pack_v,
                           float current_a,
                           float temp_c,
                           float cell_diff_mv);

/** Force LC to 0% — call after UV/empty event (mirrors SOC_SetEmpty). */
void LC_SetZero(LC_Handle_t *hlc);

/** Force LC to 100% — call after confirmed full-charge anchor (mirrors SOC_SetFull). */
void LC_SetFull(LC_Handle_t *hlc);

/** Update SOH% — call whenever SOH estimator refreshes its result. */
void LC_SetSOH(LC_Handle_t *hlc, float soh_pct);

/** Get last published data without triggering an update. */
const LC_Data_t *LC_GetData(const LC_Handle_t *hlc);

/** Returns short ASCII string for phase label (debug / CLI). */
const char *LC_PhaseStr(LC_Phase_t phase);

#endif /* LC_ESTIMATOR_H */
