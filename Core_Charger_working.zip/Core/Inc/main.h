/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32g4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */
#include <stdbool.h>

/* Persist calibration / SOC / fault thresholds / charger config to the
 * external W25Q64. Returns false if the erase, program or read-back
 * verify failed. Declared here because soc_extended.c also calls it and
 * was relying on an implicit declaration (which defaults the return type
 * to int and silently conflicts with the real bool-returning definition). */
bool SaveSystemStateToFlash(void);

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define LED4_D11_Pin GPIO_PIN_1
#define LED4_D11_GPIO_Port GPIOC
#define LED3_D10_Pin GPIO_PIN_2
#define LED3_D10_GPIO_Port GPIOC
#define LED2_D9_Pin GPIO_PIN_3
#define LED2_D9_GPIO_Port GPIOC
#define LED1_D8_Pin GPIO_PIN_1
#define LED1_D8_GPIO_Port GPIOA
#define BLUE_LED_Pin GPIO_PIN_8
#define BLUE_LED_GPIO_Port GPIOC
#define STB_CAN_Pin GPIO_PIN_9
#define STB_CAN_GPIO_Port GPIOC
#define CAN_EN_Pin GPIO_PIN_8
#define CAN_EN_GPIO_Port GPIOA
#define GREEN_LED_Pin GPIO_PIN_9
#define GREEN_LED_GPIO_Port GPIOA
#define RED_LED_Pin GPIO_PIN_10
#define RED_LED_GPIO_Port GPIOA
#define wakeButton_Pin GPIO_PIN_9
#define wakeButton_GPIO_Port GPIOB
#define wakeButton_EXTI_IRQn EXTI9_5_IRQn

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
