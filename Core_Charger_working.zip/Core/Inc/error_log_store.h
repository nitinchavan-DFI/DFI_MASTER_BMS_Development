/**
 * @file    error_log_store.h
 * @brief   Error Log RingBuffer storage in W25Q64 Flash
 */

#ifndef ERROR_LOG_STORE_H
#define ERROR_LOG_STORE_H

#ifdef __cplusplus
extern "C" {
#endif

#include "cli_frame.h"
#include "stm32g4xx_hal.h"
#include <stdbool.h>
#include <stdint.h>

#define ERROR_LOG_MAX_ENTRIES 100
#define ERROR_LOG_MSG_MAX_LEN 58

/**
 * @brief Represents a single error log entry.
 */
typedef struct {
  RTC_DateTime_t timestamp; /**< System time or RTC time when error occurred */
  char message[ERROR_LOG_MSG_MAX_LEN]; /**< Null-terminated error message */
} ErrorLog_Entry_t;

/**
 * @brief Initialize the error log storage mechanism.
 *        Reads the existing logs from flash into RAM.
 *
 * @param hqspi Pointer to the QSPI handle.
 * @retval true on success, false otherwise.
 */
bool ErrorLog_Init(QSPI_HandleTypeDef *hqspi);

/**
 * @brief Add a new error to the log. If the log is full (100 entries),
 *        the oldest entry is overwritten.
 *
 * @param message The error message string (will be truncated to
 * ERROR_LOG_MSG_MAX_LEN-1).
 * @retval true on success, false if flash write failed.
 */
bool ErrorLog_Add(const char *message);

/**
 * @brief Get the current number of error logs (0 to ERROR_LOG_MAX_ENTRIES).
 */
uint32_t ErrorLog_GetCount(void);

/**
 * @brief Retrieve a specific error log entry.
 *
 * @param index Index of the entry to retrieve. 0 is the oldest, (count-1) is
 * the newest.
 * @param out_entry Pointer to the struct where the entry will be copied.
 * @retval true on success, false if index is out of bounds.
 */
bool ErrorLog_GetEntry(uint32_t index, ErrorLog_Entry_t *out_entry);

/**
 * @brief Clear all error logs from flash and RAM.
 * @retval true on success, false otherwise.
 */
bool ErrorLog_Clear(void);

#ifdef __cplusplus
}
#endif

#endif /* ERROR_LOG_STORE_H */
