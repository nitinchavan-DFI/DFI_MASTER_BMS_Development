/**
 * @file    soc.h
 * @brief   SOC estimator with Kalman filtering and voltage-based drift correction
 * @details Coulomb counting fused with OCV correction via a 1-D Kalman filter.
 *          Prevents the 15-minute SOC drift-to-zero bug by nudging the estimate
 *          toward voltage-derived SOC during rest periods.
 */

#ifndef INC_SOC_H_
#define INC_SOC_H_

#include <stdbool.h>
#include <stdint.h>

#define SOC_OCV_POINTS 11

typedef struct {
  float pack_uv_limit;
  float battery_capacity_ah;
  float pack_full_voltage;
  float taper_current;
  float idle_current_a;
  float max_dt_sec;
  float ocv_min_pack_volt;
  float ocv_min_soc_percent;
  float charge_efficiency;
  float soc_ref[SOC_OCV_POINTS];
  float pack_ocv[SOC_OCV_POINTS];
} SOC_Config_t;

/* Default Configuration Values */
#define SOC_DEFAULT_PACK_UV_LIMIT 40.0f
#define SOC_DEFAULT_BATTERY_CAPACITY_AH 72.0f   /* Updated for actual pack capacity */
#define SOC_DEFAULT_PACK_FULL_VOLTAGE 54.6f
#define SOC_DEFAULT_TAPER_CURRENT (SOC_DEFAULT_BATTERY_CAPACITY_AH / 20.0f)
#define SOC_DEFAULT_IDLE_CURRENT_A 0.8f
#define SOC_DEFAULT_MAX_DT_SEC 5.0f
#define SOC_DEFAULT_OCV_MIN_PACK_VOLT (SOC_DEFAULT_PACK_UV_LIMIT + 2.0f)
#define SOC_DEFAULT_OCV_MIN_SOC_PERCENT 10.0f
#define SOC_DEFAULT_CHARGE_EFFICIENCY 0.995f

#define SOC_DEFAULT_SOC_REF_ARRAY                                              \
  { 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 }
#define SOC_DEFAULT_PACK_OCV_ARRAY                                             \
  {                                                                            \
    42.0f, 44.5f, 46.2f, 47.4f, 48.2f, 48.8f, 49.2f, 49.8f, 50.4f, 51.5f,      \
        54.6f                                                                  \
  }

/* ================================================ */

#define SOC_VERIFIED_BUFFER_SIZE 3

typedef struct {
  float soc;
  float remaining_ah;
  uint32_t timestamp;
  uint16_t crc;
} VerifiedSOC_t;

typedef struct {
  /* Configuration Pointer */
  const SOC_Config_t *config;

  /* State */
  float remaining_ah;
  float soc_percent;

  /* Current handling */
  float current_a;
  float current_offset;

  /* Kalman filter for SOC (fuses coulomb counting + OCV correction) */
  float P_soc;              /* Error covariance of remaining_ah */
  float Q_coulomb;          /* Process noise (coulomb counting uncertainty) */
  float R_ocv;              /* Measurement noise (OCV-derived SOC uncertainty) */

  /* Rest detection for OCV correction */
  uint32_t rest_start_ms;
  float    last_voltage_v;
  uint32_t voltage_stable_ms;

  /* Time */
  uint32_t last_update_ms;

  /* Flags */
  bool ocv_used_at_startup;

} SOC_Handle_t;

/* ========= API ========= */

void SOC_Init(SOC_Handle_t *soc, const SOC_Config_t *config,
              float initial_soc_percent, uint32_t time_ms);

/**
 * @brief Update SOC with current and pack voltage.
 * @param measured_current_a  Pack current (A), positive = charge
 * @param pack_voltage_v      Pack voltage (V) for OCV correction
 * @param time_ms             HAL_GetTick()
 */
void SOC_Update(SOC_Handle_t *soc, float measured_current_a,
                float pack_voltage_v, uint32_t time_ms);

/* One-time startup OCV guess */
bool SOC_InitFromOCV(SOC_Handle_t *soc, float pack_voltage, float current_a);

/* Hard calibration anchors */
void SOC_SetFull(SOC_Handle_t *soc);
void SOC_SetEmpty(SOC_Handle_t *soc);

/* Getters */
float SOC_GetPercent(const SOC_Handle_t *soc);
float SOC_GetRemainingAh(const SOC_Handle_t *soc);

uint16_t SOC_CRC16(const VerifiedSOC_t *vsoc);

#endif /* INC_SOC_H_ */
