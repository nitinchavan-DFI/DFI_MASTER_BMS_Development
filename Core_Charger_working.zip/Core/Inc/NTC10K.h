/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : NTC10K.h
 * @brief          : NTC10K thermistor driver — public API
 *
 * Circuit assumption:
 *   VCC (3.3V)
 *     |
 *   [SERIES_R = 10K]
 *     |
 *     +----> ADC pin (PB2 / ADC2_CH12)
 *     |
 *   [NTC 10K]
 *     |
 *    GND
 *
 *   R_ntc = SERIES_R * adc_raw / (ADC_MAX_VAL - adc_raw)
 ******************************************************************************
 */
/* USER CODE END Header */

#ifndef NTC10K_H
#define NTC10K_H

#include "stm32g4xx_hal.h"
#include <stdint.h>

/* ---- Sensor & circuit constants ----------------------------------------- */
#define NTC_NOMINAL_R 10000.0f  /* NTC resistance at 25 C (ohm)      */
#define NTC_NOMINAL_T_K 298.15f /* Nominal temperature in Kelvin      */
#define NTC_B_DEFAULT 3950.0f   /* Default Steinhart-Hart B constant  */
#define SERIES_R 10000.0f       /* Pull-up series resistor (ohm)      */
#define ADC_MAX_VAL 4095.0f     /* 12-bit ADC full scale              */
#define KELVIN_OFFSET 273.15f   /* Celsius to Kelvin offset           */

/* ---- Sampling / timing --------------------------------------------------
 *   TIM6 fires at 170 MHz / ((11+1) * (59999+1)) = ~236 Hz
 *   ADC_AVG_SAMPLES averaged readings  -> ready at ~236/8  = ~29.5 Hz
 *   PRINT_EVERY ready-events           -> print at ~29.5/29 = ~1 Hz
 * -------------------------------------------------------------------------*/
#define ADC_AVG_SAMPLES 8u    /* ISR samples to average per reading */
#define PRINT_EVERY 29u       /* Averaged readings between prints   */
#define CALIB_ADC_SAMPLES 64u /* Blocking samples for calibration   */

/* ---- Calibration result codes ------------------------------------------- */
typedef enum {
  NTC_CALIB_OK = 0,        /* Calibration successful, g_calib_b updated  */
  NTC_CALIB_ERR_ADC_RANGE, /* ADC value at rail (0 or 4095)              */
  NTC_CALIB_ERR_TEMP_CLOSE /* Reference temp too close to 25 C           */
} NTC_CalibResult_t;

/* ---- Shared state (written in ISR, read in main loop) ------------------- */
/* NTC1 (ADC2 Channel 12 - Rank 1) */
extern volatile uint32_t g_adc_raw;  /* Latest averaged ADC value           */
extern volatile uint8_t g_adc_ready; /* Flag: new averaged sample ready     */
extern float g_calib_b; /* Active B coefficient (printed by main) */

/* NTC2 (ADC2 Channel 14 - Rank 2) */
extern volatile uint32_t g_adc2_raw;  /* Latest averaged ADC2 value          */
extern volatile uint8_t g_adc2_ready; /* Flag: new averaged NTC2 sample ready */
extern float g_calib2_b; /* Active B coefficient for NTC2         */

/* ---- Public API --------------------------------------------------------- */
/* NTC1 */
float NTC_ADC_To_Celsius(uint32_t adc_val);
NTC_CalibResult_t NTC_Calibrate(float known_temp_c, uint32_t adc_val);
uint32_t NTC_GetCalibADC(void);

/* NTC2 */
float NTC2_ADC_To_Celsius(uint32_t adc_val);
NTC_CalibResult_t NTC2_Calibrate(float known_temp_c, uint32_t adc_val);

/* ---- ISR dispatch functions (called from stm32g4xx_it.c) --------------- */
void NTC10K_ADC_Callback(ADC_HandleTypeDef *hadc);
void NTC10K_TIM_Callback(TIM_HandleTypeDef *htim);

#endif /* NTC10K_H */
