/**
 * @file    daly_ekf.h
 * @brief   Double Kalman Filter + 100-sample median for Daly BMS cell voltages
 * @details Per-cell filtering: 100-sample median removes outliers/spikes,
 *          cascaded fast+slow Kalman smooths noise and tracks drift.
 */

#ifndef DALY_EKF_H
#define DALY_EKF_H

#include <stdint.h>
#include <stdbool.h>

#define DALY_EKF_MAX_CELLS     16U
#define DALY_EKF_MEDIAN_LEN    100U
#define DALY_EKF_MEDIAN_HALF   50U

typedef struct {
    /* Median circular buffer: raw values per cell */
    float raw_buffer[DALY_EKF_MAX_CELLS][DALY_EKF_MEDIAN_LEN];
    uint16_t buf_head[DALY_EKF_MAX_CELLS];
    uint16_t buf_count[DALY_EKF_MAX_CELLS];

    /* Fast Kalman: tracks actual voltage (high bandwidth) */
    float x_fast[DALY_EKF_MAX_CELLS];
    float P_fast[DALY_EKF_MAX_CELLS];

    /* Slow Kalman: tracks long-term average (drift estimation) */
    float x_slow[DALY_EKF_MAX_CELLS];
    float P_slow[DALY_EKF_MAX_CELLS];

    /* Final filtered output per cell (Volts) */
    float filtered_v[DALY_EKF_MAX_CELLS];

    uint8_t active_cells;
    uint32_t update_count;
} DalyEKF_Handle_t;

void DalyEKF_Init(DalyEKF_Handle_t *hek);
void DalyEKF_SetCellCount(DalyEKF_Handle_t *hek, uint8_t ncells);
void DalyEKF_UpdateCell(DalyEKF_Handle_t *hek, uint8_t cell_idx, float raw_v);
float DalyEKF_GetCellVoltage(const DalyEKF_Handle_t *hek, uint8_t cell_idx);

#endif /* DALY_EKF_H */
