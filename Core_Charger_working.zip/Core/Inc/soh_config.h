/**
 * @file soh_config.h
 * @brief SOH estimator tuneable constants for automotive-grade BMS
 */

#ifndef SOH_CONFIG_H
#define SOH_CONFIG_H

/* Fusion weights */
#define SOH_WEIGHT_CAP     0.50f
#define SOH_WEIGHT_RINT    0.30f  
#define SOH_WEIGHT_CYCLE   0.20f

/* Cycle counting */
#define SOH_N_80PCT_CYCLES 500u    /* Cycles to 80% SOH */
#define SOH_MIN_CYCLE_DOD  0.80f   /* Min DoD for full cycle credit */
#define SOH_DISCHG_THRESH_A -0.5f  /* Discharge detection (A) */
#define SOH_CHARGE_THRESH_A +0.5f  /* Charge detection (A) */

/* Capacity measurement validity gates */
#define SOH_MEAS_MIN_DURATION_S 60u
#define SOH_SOC_START_MIN_PCT   90.0f
#define SOH_SOC_END_MAX_PCT     15.0f
#define SOH_TEMP_MIN_C          10.0f
#define SOH_TEMP_MAX_C          45.0f
#define SOH_CURR_SAT_A         195.0f
#define SOH_VOLT_DEV_MAX_MV    500.0f

/* Internal resistance */
#define SOH_RINT_DELTA_I_MIN_A  5.0f
#define SOH_RINT_DELTA_T_MAX_MS 500u
#define SOH_RINT_WINDOW_SIZE    20u
#define SOH_RINT_EOL_FACTOR     2.0f   /* EOL when R_now = 2x R_new */

/* Life estimation */
#define SOH_DEFAULT_LIFE_YEARS  5.0f
#define SOH_MIN_CALENDAR_WINDOW_DAYS 7u

/* Flash */
#define SOH_FLASH_MAGIC     0xB33FB33Fu
#define SOH_FLASH_VERSION   1u
#define SOH_FLASH_MIN_WRITE_S 10u

/* Hardware config */
#define CELL_COUNT          14u     /* 14S default; #undef/redefine for 12S */
#define DEFAULT_RINT_NEW_OHM 0.001f /* 1 mOhm typical large pack */

#endif /* SOH_CONFIG_H */

