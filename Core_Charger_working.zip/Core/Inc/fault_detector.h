/**
 * @file    fault_detector.h
 * @brief   Software fault detector for battery management
 *
 * Monitors 6 error conditions using configurable thresholds:
 *   - overVoltageError      : packVoltage > ov_thresh
 *   - underVoltageError     : packVoltage < uv_thresh
 *   - overCurrentError      : |current_a| > oc_thresh
 *   - servalCellDisableError: cellDiff_mV > cell_diff_thresh
 *   - overTemperatureError  : tempC > ot_thresh
 *   - underTemperatureError : tempC < ut_thresh
 *
 * Thresholds are set via CLI (0x20) and persisted in CalibStore.
 * Fault status is broadcast via CLI (0x04) every 1000 ms.
 */

#ifndef FAULT_DETECTOR_H
#define FAULT_DETECTOR_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdbool.h>
#include <stdint.h>

/* ---- Default thresholds --------------------------------------------------
 * These are the values that load on a fresh board (invalid/blank flash) and
 * the per-field fallback when a stored record has an implausible entry.
 * Taken from the commissioning set entered in the GUI.
 *
 * Note that four of them are deliberately "effectively disabled" rather than
 * physically meaningful trip points:
 *   cellDiff_mV 15000  — no real pack spread reaches 15 V, so the imbalance
 *                        fault never latches
 *   utTemp_C   -10000  — under-temperature never latches (thermistor-MISSING
 *                        detection is a separate path and still works)
 *   ocCurrent_A   300  — well above anything this pack sources
 *   chargeOCLimit 150  — likewise for charge
 * That is a legitimate way to switch a fault off, so the accept envelope
 * below is sized to allow it. What is NOT relaxed is the ordering between
 * related thresholds — uv < ov, ot > ut, cellMax > cellMin — because the
 * detector's hysteresis maths depends on those holding.
 * ------------------------------------------------------------------------*/
#define FAULT_OV_DEFAULT 58.8f  /**< V   — overvoltage limit          */
#define FAULT_UV_DEFAULT 42.0f  /**< V   — undervoltage limit         */
#define FAULT_OC_DEFAULT 300.0f /**< A   — discharge overcurrent      */
#define FAULT_CELL_DIFF_DEFAULT 15000.0f /**< mV — imbalance (disabled)  */
#define FAULT_OT_DEFAULT 55.0f      /**< °C  — overtemperature limit   */
#define FAULT_UT_DEFAULT -10000.0f  /**< °C  — undertemp (disabled)    */
#define FAULT_CELL_MAX_DEFAULT 4.26f /**< V  — per-cell OV limit        */
#define FAULT_CELL_MIN_DEFAULT 3.00f /**< V  — per-cell UV limit        */
#define FAULT_CHARGE_OC_DEFAULT 150.0f /**< A — charge overcurrent      */

/* ---- Accept envelope for a threshold write (CLI 0x20) -------------------
 * Deliberately generous: wide enough that the "set it out of range to turn
 * the fault off" idiom above is accepted, narrow enough to still catch a
 * garbage payload (NaN, wrong endianness, misaligned struct). The previous
 * bands were sized for physically-plausible values only — cellDiff < 5000
 * and utTemp > -50 — which silently rejected the commissioning set.
 * ------------------------------------------------------------------------*/
#define FAULT_ACCEPT_V_MAX          1000.0f    /**< pack V ceiling        */
#define FAULT_ACCEPT_I_MAX          10000.0f   /**< current ceiling (A)   */
#define FAULT_ACCEPT_CELLDIFF_MAX   100000.0f  /**< cell spread max (mV)  */
#define FAULT_ACCEPT_TEMP_MAX       1000.0f    /**< °C ceiling            */
#define FAULT_ACCEPT_TEMP_MIN       (-100000.0f)/**< °C floor (disable)   */
#define FAULT_ACCEPT_CELL_V_MAX     100.0f     /**< per-cell V ceiling    */

/* ---- Hysteresis margins (compile-time) ---------------------------------- */
#define FAULT_HYST_OV_V 1.0f     /**< Overvoltage hysteresis (V)      */
#define FAULT_HYST_UV_V 1.0f     /**< Undervoltage hysteresis (V)     */
#define FAULT_HYST_OC_A 1.0f     /**< Overcurrent hysteresis (A)      */
#define FAULT_HYST_CELL_mV 50.0f /**< Cell-diff hysteresis (mV)       */
#define FAULT_HYST_OT_C 3.0f     /**< Over-temperature hysteresis (°C)*/
#define FAULT_HYST_UT_C 3.0f     /**< Under-temperature hysteresis (°C)*/

/* ---- Bitmask positions for CLI status byte ------------------------------- */
#define FAULT_BIT_OV (1u << 0)        /**< overVoltageError                 */
#define FAULT_BIT_UV (1u << 1)        /**< underVoltageError                */
#define FAULT_BIT_OC (1u << 2)        /**< overCurrentError                 */
#define FAULT_BIT_CELL_DIFF (1u << 3) /**< cellDiffError           */

#define FAULT_BIT_OT (1u << 4)        /**< overTemperatureError             */
#define FAULT_BIT_UT (1u << 5)        /**< underTemperatureError            */
#define FAULT_BIT_THERM_MISSING                                                \
  (1u << 6)                     /**< thermistorNotConnectedError       */
#define FAULT_BIT_OT2 (1u << 7) /**< overTemperature2Error             */
#define FAULT_BIT_UT2 (1u << 10) /**< underTemperature2Error            */
#define FAULT_BIT_THERM2_MISSING (1u << 11) /**< thermistor2NotConnectedError      */

#define FAULT_BIT_CELL_OV      (1u << 8)  /**< cellOverVoltageError             */
#define FAULT_BIT_CELL_UV      (1u << 9)  /**< cellUnderVoltageError            */
#define FAULT_BIT_CHARGE_OC    (1u << 12) /**< chargeOverCurrentError           */

/* ---- Types --------------------------------------------------------------- */

/**
 * @brief  Configurable thresholds for all nine fault conditions.
 *
 *         Wire form: 9 × float32 LE = 36 bytes, in the field order below.
 *         This comment said "6 × float = 24 bytes" long after cellMax_V,
 *         cellMin_V and chargeOCLimit_A were appended — the mismatch is why
 *         CLI_CMD_SET_FAULT_THRESH (0x20) writes were being dropped. The
 *         handler in main.c now accepts both the 24-byte legacy form and the
 *         full 36-byte form; keep this comment in step with the struct.
 */
typedef struct {
  float ovVoltage_V;     /**< Pack OV threshold (V)            */
  float uvVoltage_V;     /**< Pack UV threshold (V)            */
  float ocCurrent_A;     /**< Discharge OC threshold (A)       */
  float cellDiff_mV;     /**< Cell imbalance threshold (mV)    */
  float otTemp_C;        /**< Temperature OT threshold (°C)   */
  float utTemp_C;        /**< Temperature UT threshold (°C)   */
  float cellMax_V;       /**< Individual cell OV threshold (V) */
  float cellMin_V;       /**< Individual cell UV threshold (V) */
  float chargeOCLimit_A; /**< Charge OC threshold (A)          */
} FaultThresholds_t;

/** @brief  Active fault flags (one per condition). */
typedef struct {
  bool overVoltageError;
  bool underVoltageError;
  bool overCurrentError;
  bool cellDiffError;
  bool overTemperatureError;
  bool underTemperatureError;
  bool thermistorNotConnectedError;
  bool overTemperature2Error;
  bool underTemperature2Error;
  bool thermistor2NotConnectedError;
  bool cellOverVoltageError;     /* Confidence-based */
  bool cellUnderVoltageError;
  bool chargeOverCurrentError;
  bool predictiveWarning;        /* Imbalance trend */
} FaultFlags_t;

#include "fault_confidence.h"

#define FAULT_DEBOUNCE_TICKS 5   /* ~5 seconds @ 1 Hz Daly cadence */

/**
 * @brief Clear all latched faults (CLI command or reset).
 */
void Fault_ClearAll(void);

/* ---- Public API ---------------------------------------------------------- */

/**
 * @brief  Initialise the fault detector.
 * @param  thr  Pointer to threshold values to use, or NULL for defaults.
 */
void Fault_Init(const FaultThresholds_t *thr);

/**
 * @brief  Replace active thresholds at runtime (e.g. from CLI command 0x20).
 * @param  thr  New threshold values.
 */
void Fault_SetThresholds(const FaultThresholds_t *thr);

/**
 * @brief  Get pointer to current active thresholds (read-only).
 */
const FaultThresholds_t *Fault_GetThresholds(void);

/**
 * @brief  Evaluate all fault conditions against current measurements.
 *         Call from main loop after BMS data and current reading are fresh.
 *
 * @param  packVoltage  Pack voltage (V)
 * @param  current_a    Signed current (A, positive = charge)
 * @param  cellDiff_mV  Max − Min cell voltage difference (mV)
 * @param  tempC        NTC1 temperature (°C), or −999.0f if invalid
 * @param  tempC2       NTC2 temperature (°C), or −999.0f if invalid
 */
void Fault_Update(float packV, float currentA, float cellDiff, float temp1, float temp2, float minCell_mV, float maxCell_mV); // MODIFIED

/**
 * @brief  Get pointer to current fault flags (read-only).
 */
const FaultFlags_t *Fault_GetFlags(void);

/**
 * @brief  Get a 1-byte bitmask of all active faults (FAULT_BIT_* defines).
 */
uint16_t Fault_GetBitmask(void);

#ifdef __cplusplus
}
#endif

#endif /* FAULT_DETECTOR_H */
