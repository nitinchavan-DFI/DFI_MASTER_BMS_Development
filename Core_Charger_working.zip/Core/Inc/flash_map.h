/**
 * @file    flash_map.h
 * @brief   W25Q64 Flash Memory Partition Map
 *
 * Divides the 8MB (0x800000) flash into 3 main sections:
 * - Partition 1: Calibration Store (~2.66 MB)
 * - Partition 2: Error Logs Store (~2.66 MB)
 * - Partition 3: Firmware / OTA     (~2.66 MB)
 */

#ifndef FLASH_MAP_H
#define FLASH_MAP_H

#ifdef __cplusplus
extern "C" {
#endif

/* Total 8MB W25Q64 */
#define FLASH_TOTAL_SIZE (8U * 1024U * 1024U)

/* Partition 1: Calibration (Sector 0 starts here) */
#define FLASH_PART_1_START 0x000000U
#define FLASH_PART_1_SIZE 0x2AA000U

/* Partition 2: Error Logs (Starts right after Part 1) */
#define FLASH_PART_2_START (FLASH_PART_1_START + FLASH_PART_1_SIZE)
#define FLASH_PART_2_SIZE 0x2AA000U

/* Partition 3: Firmware / OTA (Starts right after Part 2) */
#define FLASH_PART_3_START (FLASH_PART_2_START + FLASH_PART_2_SIZE)
#define FLASH_PART_3_SIZE (FLASH_TOTAL_SIZE - FLASH_PART_3_START)

#ifdef __cplusplus
}
#endif

#endif /* FLASH_MAP_H */
