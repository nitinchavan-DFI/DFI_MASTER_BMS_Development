/**
 * @file    current_sensor.h
 * @brief   ACS37612LLUATR-010B3 Hall-effect current sensor driver
 *
 * Timer-triggered ADC with EMA low-pass filter and two-point calibration:
 *   1. Zero calibration  — measures offset with no current flowing
 *   2. Known-current cal — computes gain from a known reference current
 *
 * ADC1 Channel 1 (PA0) is triggered by TIM1 TRGO at ~5 kHz.
 */

#ifndef CURRENT_SENSOR_H
#define CURRENT_SENSOR_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32g4xx_hal.h"
#include <stdbool.h>
#include <stdint.h>

/* ---------------------------------------------------------------------------
 * Sensor / ADC Configuration
 * -------------------------------------------------------------------------*/

/** ADC reference voltage in millivolts */
#define CS_ADC_VREF_MV 3300

/** ADC resolution (12-bit) */
#define CS_ADC_MAX_VALUE 4095

/** Sensor supply voltage in millivolts */
#define CS_SENSOR_VCC_MV 3300

/** Quiescent (zero-current) output voltage = Vcc / 2 */
#define CS_SENSOR_QUIESCENT_MV (CS_SENSOR_VCC_MV / 2)

/**
 * Default coupling factor: milliamps per millivolt of sensor output deviation.
 * This is the initial value before known-current calibration overrides it.
 *
 * >>> ADJUST THIS FOR YOUR HARDWARE <<<
 */
#define CS_DEFAULT_COUPLING_FACTOR 160.0f

/* ---------------------------------------------------------------------------
 * Filter Configuration
 * -------------------------------------------------------------------------*/

/** Fixed-point shift for Q16 arithmetic */
#define CS_Q16_SHIFT 16

/* ---------------------------------------------------------------------------
 * 2-State Extended Kalman Filter Types (signal + zero_drift)
 * -------------------------------------------------------------------------*/

typedef struct {
  float x[2];   /* [0]=signal (ADC counts), [1]=zero drift (ADC counts) */
  float P[4];   /* Covariance [P00, P01, P10, P11] */
} CurrentEKF_t;

/* ---------------------------------------------------------------------------
 * Calibration Configuration
 * -------------------------------------------------------------------------*/

/** Number of ADC samples to average during any calibration step */
#define CS_CALIBRATION_SAMPLES 4096

/* ---------------------------------------------------------------------------
 * Types
 * -------------------------------------------------------------------------*/

/** Driver state machine */
typedef enum {
  CS_STATE_IDLE = 0,  /**< Not started */
  CS_STATE_ZERO_CAL,  /**< Zero-current calibration in progress */
  CS_STATE_KNOWN_CAL, /**< Known-current calibration in progress */
  CS_STATE_RUNNING    /**< Normal operation */
} CurrentSensor_State_t;

/** Current sensor data */
typedef struct {
  volatile CurrentSensor_State_t state;

  /* Raw / filtered ADC values */
  volatile uint32_t rawAdc;         /**< Latest raw ADC reading */
  volatile int32_t filteredAdc_Q16; /**< Filtered value in Q16 */

  CurrentEKF_t ekf; /**< 2-state EKF (signal + zero drift) */

  /* Zero calibration */
  volatile uint32_t
      zeroCalAccumulator;         /**< Sum of ADC values during zero cal */
  volatile uint32_t zeroCalCount; /**< Number of zero cal samples so far */
  volatile int32_t
      zeroOffset_Q16; /**< Calibrated zero offset in Q16 ADC counts */

  /* Known-current calibration */
  volatile uint32_t
      knownCalAccumulator;         /**< Sum of ADC values during known cal */
  volatile uint32_t knownCalCount; /**< Number of known cal samples so far */

  /* Gain (coupling factor) — updated by known-current calibration */
  volatile float couplingFactor; /**< mA per mV deviation (runtime) */

  /* Converted results */
  volatile float voltage_mV; /**< Latest filtered voltage in mV */
  volatile float current_mA; /**< Latest filtered current in mA */
} CurrentSensor_Data_t;

/**
 * Calibration control variables (set from UART / application code).
 * These are the "knobs" to trigger calibration from outside.
 */
typedef struct {
  volatile bool zeroCalFlag;      /**< Set true to start zero calibration */
  volatile bool knownCalFlag;     /**< Set true to start known-current cal */
  volatile float knownCurrent_mA; /**< Known reference current in mA */
} CurrentSensor_CalCtrl_t;

/* ---------------------------------------------------------------------------
 * Public API
 * -------------------------------------------------------------------------*/

/**
 * @brief  Initialise the current sensor driver.
 *         Calibrates ADC, sets TIM1 TRGO trigger, starts timer + ADC IT.
 * @param  hadc  Pointer to ADC handle (ADC1)
 * @param  htim  Pointer to TIM handle (TIM1)
 */
void CurrentSensor_Init(ADC_HandleTypeDef *hadc, TIM_HandleTypeDef *htim);

/**
 * @brief  Request zero-current calibration.
 *         Ensure NO current is flowing through the busbar!
 */
void CurrentSensor_StartZeroCalibration(void);

/**
 * @brief  Request known-current calibration.
 *         Apply the known reference current BEFORE calling this.
 * @param  knownCurrent_mA  The reference current in milliamps
 */
void CurrentSensor_StartKnownCalibration(float knownCurrent_mA);

/**
 * @brief  ADC conversion-complete callback.
 *         Must be called from HAL_ADC_ConvCpltCallback().
 * @param  hadc  Pointer to ADC handle
 */
void CurrentSensor_ADC_Callback(ADC_HandleTypeDef *hadc);

/**
 * @brief  Process calibration control flags (call from main loop).
 *         Checks zeroCalFlag / knownCalFlag and triggers calibration.
 */
void CurrentSensor_ProcessFlags(void);

/**
 * @brief  Get the latest filtered and calibrated current reading.
 * @return Current in milliamps
 */
float CurrentSensor_GetCurrent_mA(void);

/**
 * @brief  Get the latest filtered ADC voltage.
 * @return Voltage in millivolts
 */
float CurrentSensor_GetVoltage_mV(void);

/**
 * @brief  Check if the driver is in normal running state.
 * @return true if running, false if idle or calibrating
 */
bool CurrentSensor_IsReady(void);

/**
 * @brief  Get pointer to internal data (for debug / UART reporting).
 */
const CurrentSensor_Data_t *CurrentSensor_GetData(void);

/**
 * @brief  Get pointer to calibration control struct (for UART commands).
 */
CurrentSensor_CalCtrl_t *CurrentSensor_GetCalCtrl(void);

/**
 * @brief  Restore saved calibration and transition to RUNNING state.
 *         Call this at boot when valid flash data is available, so that
 *         a fresh zero calibration is not needed.
 * @param  zeroOffset_Q16  Saved zero offset in Q16 fixed-point
 * @param  couplingFactor  Saved mA-per-mV coupling factor
 */
void CurrentSensor_SetCalibration(int32_t zeroOffset_Q16, float couplingFactor);

/**
 * @brief  Initialize the 2-state EKF for current + zero-drift
 * @param  zero_calib_adc  Calibrated zero offset in ADC counts
 */
void CurrentEKF_Init(CurrentEKF_t *ekf, float zero_calib_adc);

/**
 * @brief  Update the 2-state EKF with new raw ADC measurement
 * @param  z_raw           Raw ADC measurement
 * @param  zero_calib_adc  Calibrated zero offset (constant bias)
 * @param  idle            true if |current| < idle threshold (enables zero-drift learning)
 */
void CurrentEKF_Update(CurrentEKF_t *ekf, float z_raw, float zero_calib_adc,
                       bool idle);

#ifdef __cplusplus
}
#endif

#endif /* CURRENT_SENSOR_H */
