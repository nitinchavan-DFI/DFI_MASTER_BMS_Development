/**
  ******************************************************************************
  * @file    fdcan.h
  * @brief   FDCAN1 bit-timing/filter config and TX helpers for the 3-protocol
  *          multiplexed bus (DroneCAN, Solterra Charger, Display).
  *
  * NOTE: The RX FIFO0 ISR itself stays in main.c because it feeds the
  * existing static can_rx_queue -> canardHandleRxFrame() pipeline. This
  * header only exposes what main.c needs to call into: peripheral init,
  * filter/start (must run AFTER canard is initialized), TX helpers, and the
  * charger frame decoder.
  ******************************************************************************
  */
#ifndef __FDCAN_H
#define __FDCAN_H

#ifdef __cplusplus
extern "C" {
#endif

#include "main.h"
#include <stdbool.h>

/* ---------------------------------------------------------------------- */
/* Extended (29-bit) CAN IDs — from DFI BMS Master GUI CAN Packet Map v1.4 */
/* ---------------------------------------------------------------------- */

/* Solterra Charger (Slave 2, Tx/Rx) */
#define CHARGER_TX_ID_CMD          0x1806E5F4UL   /* BMS -> Charger, charge command, 1 Hz */
#define CHARGER_RX_ID_STATUS       0x18FF50E5UL   /* Charger -> BMS, broadcast status, dlc >= 5 */

/* Display (Slave 1) — this node only transmits to it; the display never
   sources bus traffic, so these IDs are outbound-only and are explicitly
   rejected on RX (see FDCAN1_ConfigFiltersAndStart in fdcan.c). */
#define DISPLAY_ID_VIT             0x1FF820UL     /* BMS_VIT */
#define DISPLAY_ID_OVRVIEW         0x1FF810UL     /* BMS_OvrView */
#define DISPLAY_ID_CELL_DELTAV     0x1FF710UL     /* Cell_DeltaV */
#define DISPLAY_ID_RANGE_LOW       DISPLAY_ID_CELL_DELTAV
#define DISPLAY_ID_RANGE_HIGH      DISPLAY_ID_VIT

/* DroneCAN / UAVCAN v0 has no fixed ID sub-range (canard packs
   priority/type/node into the full 29-bit field) — it is the catch-all
   default, handled entirely by the existing can_rx_queue/canard pipeline
   in main.c. Nothing here decodes it. */

/* Hardware filter bank indices. ORDER MATTERS: the FDCAN peripheral applies
   the FIRST matching filter, not the most specific, so the narrow filters
   (Charger, Display) must be indexed before the DroneCAN catch-all. */
#define CANFILT_IDX_CHARGER        0
#define CANFILT_IDX_DISPLAY        1
#define CANFILT_IDX_DRONECAN       2
#define CANFILT_EXT_COUNT          3

extern FDCAN_HandleTypeDef hfdcan1;

/* Peripheral init only (clock + bit timing). Safe to call early, before
   canard is initialized — matches your existing call site in main(). */
void MX_FDCAN1_Init(void);

/* Filter config, global filter, notification activation, and HAL_FDCAN_Start.
   MUST be called AFTER canard is initialized and the node ID is set, same
   ordering your original inline block used — the bus must not go live
   before canardHandleRxFrame()'s target object exists. */
void FDCAN1_ConfigFiltersAndStart(void);

/**
 * @brief  Call once per second from the main loop. Detects Bus_Off / stuck
 *         Error_Passive and recovers the FDCAN *peripheral only* — never
 *         calls Error_Handler(), never resets the MCU, never touches
 *         canard's node identity or any BMS state. A CAN transceiver fault
 *         (disconnected bus, wrong bit rate on another node, EMI burst)
 *         must degrade CAN traffic, not the rest of the BMS.
 * @return true if a recovery action was just taken this call (main.c uses
 *         this to immediately kick Process_CAN_Tx() and flush anything
 *         canard queued up while the bus was down, instead of waiting on
 *         a TX-FIFO-empty interrupt that may not fire on its own).
 */
bool FDCAN1_HealthCheck(void);

/**
 * @brief  Total number of bus-off recoveries since boot — surfaced for
 *         telemetry/diagnostics (e.g. CLI or a future CAN health frame).
 *         A number that keeps climbing means something on the physical
 *         bus is unhealthy even though the BMS itself keeps running.
 */
uint32_t FDCAN1_GetBusOffRecoveryCount(void);

/**
 * @brief  Consecutive seconds the module has reported Error_Passive right
 *         now (0 if currently healthy). Recovery fires once this reaches
 *         FDCAN_ERROR_PASSIVE_RECOVERY_S (fdcan.c) — watching this climb
 *         toward that threshold live is a useful early warning that the
 *         bus is degrading before a recovery cycle actually happens.
 */
uint32_t FDCAN1_GetErrorPassiveSeconds(void);

/* Transmit helpers — thin wrappers enforcing Classic CAN 2.0B Extended
   headers (FDF=Classic, BRS=Off) so no call site can accidentally request
   CAN FD framing on a bus where no slave supports it. */
uint8_t Transmit_DroneCAN_Msg(uint32_t ext_id, uint8_t *data, uint8_t len);
uint8_t Transmit_Charger_Msg(uint32_t ext_id, uint8_t *data, uint8_t len);
uint8_t Transmit_Display_Msg(uint32_t ext_id, uint8_t *data, uint8_t len);

/* Charger status decoder — called from main.c's HAL_FDCAN_RxFifo0Callback
   when RxHeader.Identifier == CHARGER_RX_ID_STATUS. */
void Process_Charger_Frame(uint32_t ext_id, uint8_t *data, uint8_t len);

#ifdef __cplusplus
}
#endif

#endif /* __FDCAN_H */
