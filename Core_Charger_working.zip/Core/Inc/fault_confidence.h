/**
 * @file    fault_confidence.h
 * @brief   Confidence-based fault detector: score(0-100)+voting+adaptive+predict
 */

#ifndef FAULT_CONFIDENCE_H
#define FAULT_CONFIDENCE_H

#include "signal_filter.h"
#include "fault_detector.h"
#include <stdint.h>

#define FAULT_CONFIDENCE_MAX 100U
#define FAULT_CONFIDENCE_INC 10U
#define FAULT_CONFIDENCE_DEC 5U
#define FAULT_CONFIDENCE_LATCH 80U
#define FAULT_CONFIDENCE_CLEAR 20U
#define FAULT_HISTORY_SIZE 20U  /* Majority >70% = 14 */

#define FAULT_PREDICT_TREND_SEC 30U  /* 3s trend for prediction */

/* Extended flags (add to FaultFlags_t) */
typedef enum {
  FAULT_FLAG_CELL_OV = 0,
  FAULT_FLAG_CELL_UV,
  FAULT_FLAG_CHARGE_OC,
  FAULT_FLAG_PREDICTIVE_IMBALANCE,
  NUM_CONFIDENCE_FAULTS
} ConfidenceFault_t;

/* Per-fault confidence state */
typedef struct {
  uint8_t score;       /* 0-100 */
  uint32_t timer_100ms;
  float trend_delta;   /* For prediction */
} ConfidenceState_t;

/* Fault history for voting */
typedef struct {
  uint16_t mask;       /* Fault_GetBitmask() snapshot */
  uint32_t timestamp;  /* tick_ms */
} FaultHistory_t;

/* Handle */
typedef struct {
  ConfidenceState_t conf[NUM_CONFIDENCE_FAULTS];
  FaultHistory_t history[FAULT_HISTORY_SIZE];
  uint8_t hist_head;
  uint8_t hist_count;
  
  /* Adaptive factors */
  float temp_factor;   /* OT/UV tighter if hot */
  float current_factor; /* OC tighter if high I */
} FaultConfidence_Handle_t;

/* Init */
void FaultConfidence_Init(FaultConfidence_Handle_t *hc);

/* Update (100ms call) */
void FaultConfidence_Update(FaultConfidence_Handle_t *hc, const FilteredData_t *filtered, 
                           float current_a, float temp1C, float temp2C, 
                           const FaultThresholds_t *thresh, bool balancer_active);

/* Get extended bitmask (legacy + new) */
uint16_t FaultConfidence_GetBitmask(const FaultConfidence_Handle_t *hc);

/* Get confidence scores array (for CLI) */
const ConfidenceState_t* FaultConfidence_GetScores(const FaultConfidence_Handle_t *hc);

/* Prediction warning (trend > thresh) */
bool FaultConfidence_PredictiveWarning(const FaultConfidence_Handle_t *hc);

#endif
