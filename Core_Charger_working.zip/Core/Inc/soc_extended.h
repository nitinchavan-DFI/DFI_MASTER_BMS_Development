/**
 * @file    soc_extended.h
 * @brief   Verified SOC persistence: buffer[3] w/CRC16, stable update, boot restore
 *          Ensures no default 50% reset, survives glitches/reboots
 */

#ifndef SOC_EXTENDED_H
#define SOC_EXTENDED_H

#include "soc.h"
#include <stdbool.h>
#include <stdint.h>

#include "soc.h" // FIXED

#define SOC_CRC16_POLY 0x8005U  /* CRC-16-CCITT */

// FIXED: VerifiedSOC_t moved to soc.h to eliminate duplicate definition

/* Extended handle */
typedef struct {
  SOC_Handle_t base;  /* Original SOC */
  
  /* Persistence buffer (circular, newest at idx=latest_idx) */
  VerifiedSOC_t buffer[SOC_VERIFIED_BUFFER_SIZE];
  uint8_t latest_idx;
  
  /* Update conditions */
  bool soc_stable;      /* From filter valid + low current */
  uint32_t last_save_tick;
  uint32_t save_interval_ms;  /* 5min */
  float last_soc_percent;
} SOC_Extended_Handle_t;

/**
 * @brief Init extended SOC (loads flash verified if valid)
 * @param soc_extended Extended handle
 * @param config Base config
 * @param time_ms HAL_GetTick()
 * @return true if restored valid verified SOC (no default)
 */
bool SOC_Extended_Init(SOC_Extended_Handle_t *soc_extended, const SOC_Config_t *config, uint32_t time_ms);

/**
 * @brief Update: base SOC_Update + check if verified-update needed
 * @param soc_extended Handle
 * @param current_a Measured current
 * @param filter_valid From signal_filter (data clean?)
 * @param no_fault Active faults?
 * @param time_ms tick
 */
void SOC_Extended_Update(SOC_Extended_Handle_t *soc_extended, float current_a, bool filter_valid, bool no_fault, uint32_t time_ms);

/**
 * @brief Save current SOC to buffer[latest] if stable change >=1%
 * @note Call from calib_store_Save if needed
 */
void SOC_Extended_SaveIfNeeded(SOC_Extended_Handle_t *soc_extended);

/**
 * @brief Get latest verified SOC% (buffer[latest_idx])
 */
float SOC_Extended_GetVerifiedPercent(const SOC_Extended_Handle_t *soc_extended);

/**
 * @brief CRC16 for VerifiedSOC_t (append/validate)
 */
uint16_t SOC_Extended_CRC16(const VerifiedSOC_t *psoc);

#endif /* SOC_EXTENDED_H */
