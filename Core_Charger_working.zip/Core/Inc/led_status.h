#ifndef __LED_STATUS_H
#define __LED_STATUS_H

#ifdef __cplusplus
extern "C" {
#endif

#include "main.h"
#include <stdbool.h>
#include <stdint.h>

/**
 * @brief System operating states as per Table 3.
 */
typedef enum {
  SYS_STATE_IDLE,   /* BLUE Static */
  SYS_STATE_DRIVE,  /* GREEN Static */
  SYS_STATE_CHARGE, /* GREEN Static */
  SYS_STATE_FAULT   /* RED Static */
} SystemState_t;

/**
 * @brief Error codes as per Table 5.
 */
typedef enum {
  LED_ERR_NONE = 0,
  LED_ERR_OVERVOLTAGE,
  LED_ERR_UNDERVOLTAGE,
  LED_ERR_OVERCURRENT,
  LED_ERR_SEVERE_CELL_DISBALANCE,
  LED_ERR_OVERTEMPERATURE,
  LED_ERR_UNDERTEMPERATURE,
  LED_ERR_THERMISTOR_NOT_CONNECTED,
  LED_ERR_OVERTEMPERATURE2,
  LED_ERR_UNDERTEMPERATURE2,
  LED_ERR_THERMISTOR2_NOT_CONNECTED
} LedError_t;

/**
 * @brief Initializes the LED status module.
 */
void LedStatus_Init(void);

/**
 * @brief Sets the overall system state for the RGB LED.
 * @param state The new system state.
 */
void LedStatus_SetSystemState(SystemState_t state);

/**
 * @brief Sets the SOC to be indicated on the D8-D11 LEDs.
 * @param soc Current State of Charge (0-100%).
 */
void LedStatus_SetSoc(uint8_t soc);

/**
 * @brief Sets an error condition to be displayed on the D8-D11 LEDs.
 *        If an error is active, it takes precedence over SOC display.
 * @param error The error code to display.
 */
void LedStatus_SetError(LedError_t error);

/**
 * @brief Enables or disables the generic fault toggle on the RGB LED.
 *        When true, the RGB LED toggles RED in non-FAULT states.
 * @param has_fault True if generic fault is present.
 */
void LedStatus_SetGenericFault(bool has_fault);

/**
 * @brief Updates the LED states. Must be called every 100ms.
 */
void LedStatus_Update100ms(void);

/**
 * @brief Timer callback integration. Should be called from
 * HAL_TIM_PeriodElapsedCallback.
 * @param htim Pointer to a TIM_HandleTypeDef structure.
 */
void LedStatus_TIM_Callback(TIM_HandleTypeDef *htim);

/**
 * @brief Wake the LEDs from rest mode.  Resets the idle timer and
 *        immediately turns LEDs back on.  Call from the PB9 EXTI ISR.
 */
void LedStatus_Wake(void);

/**
 * @brief Set the idle timeout before LEDs enter rest mode.
 * @param seconds Timeout in seconds (default 120).  Set 0 to disable.
 */
void LedStatus_SetIdleTimeout(uint32_t seconds);

#ifdef __cplusplus
}
#endif

#endif /* __LED_STATUS_H */
