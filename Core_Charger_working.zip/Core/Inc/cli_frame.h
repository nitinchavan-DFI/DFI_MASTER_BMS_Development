/**
 * @file    cli_frame.h
 * @brief   CLI frame protocol – interrupt-driven UART frame decoder/encoder
 *
 * Frame format (little-endian length):
 *   [0xAA][0x55][LEN_L][LEN_H][CMD][DATA...][CHECKSUM][0x0D][0x0A]
 *
 *   - LEN  = total frame length (header + len + cmd + data + checksum + end)
 *   - CHECKSUM = sum(bytes from LEN_L to last DATA byte) & 0xFF
 *   - Min frame = 8 bytes (no data), Max data = 512 bytes
 */

#ifndef CLI_FRAME_H
#define CLI_FRAME_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32g4xx_hal.h"
#include <stdbool.h>
#include <stdint.h>

/* Exported defines ----------------------------------------------------------*/
#define CLI_HEADER_BYTE_1 0xAA
#define CLI_HEADER_BYTE_2 0x55
#define CLI_END_BYTE_1 0x0D
#define CLI_END_BYTE_2 0x0A

#define CLI_MIN_FRAME_LENGTH 8U
#define CLI_MAX_DATA_LENGTH 512U
#define CLI_MAX_FRAME_LENGTH                                                   \
  (CLI_MIN_FRAME_LENGTH + CLI_MAX_DATA_LENGTH) /* 520 */

/* Overhead = header(2) + length(2) + cmd(1) + checksum(1) + end(2) = 8 */
#define CLI_FRAME_OVERHEAD 8U

/**
 * @brief  Depth of the decoded-frame RX queue (ISR producer, main consumer).
 *
 * Was effectively 1: the ISR held a single decoded frame and dropped every
 * further frame until the main loop consumed it.  Because the 100 ms
 * telemetry block issues a dozen *blocking* CLI_Frame_Send() calls, a host
 * burst — "Set Thresholds" immediately followed by "Save to Flash" is the
 * common one — routinely lost the second frame.  From the GUI that is
 * indistinguishable from "the write did not take" / "save does not work".
 * 4 frames ≈ 2 KB of RAM on a 128 KB part.
 */
#define CLI_RX_QUEUE_DEPTH 4U

/* ---- Application Command IDs ---- */
#define CLI_CMD_SOC_DATA 0x01 /* STM32 → PC: SOC%, Ah, I, V  (16B) */
#define CLI_CMD_BMS_DATA 0x02 /* STM32 → PC: BMS summary     (32B) */
#define CLI_CMD_TEMP_DATA                                                      \
  0x03 /* STM32 → PC: temperature °C   (4B float)               */
#define CLI_CMD_FAULT_STATUS                                                   \
  0x04 /* STM32 → PC: fault bitmask (uint16,2B) + 9×f32 thresholds (36B) LE */
#define CLI_CMD_RTC_DATA                                                       \
  0x05 /* STM32 -> PC: date/time (6B: YY MM DD hh mm ss) */
#define CLI_CMD_TEMP2_DATA                                                     \
  0x07 /* STM32 → PC: NTC2 temperature °C (4B float)     */
#define CLI_CMD_CELL_EXTREMA 0x08 /* STM32 → PC: min_cell_idx(u8), min_V(f32), max_cell_idx(u8), max_V(f32) (10B) */
#define CLI_CMD_CELL_VOLT_ALL 0x0C /* STM32 → PC: nCells(u8) + n×float32 LE cellV (1-16 cells) */
#define CLI_CMD_ZERO_CAL                                                       \
  0x10 /* PC → STM32: zero calibration                    (0B)   */
#define CLI_CMD_SET_FAULT_THRESH                                               \
  0x20 /* PC → STM32: set fault thresholds.                                */
     /* PAYLOAD SIZE — this comment used to say "24B = 6×float", which is   */
     /* what the GUI was written against, while FaultThresholds_t grew to   */
     /* 9 floats (36 B) when cell OV / cell UV / charge OC were added.  The */
     /* handler demanded >= 36 B, so a 24 B write was dropped in silence.   */
     /* Both are now accepted:                                             */
     /*   24 B = 6×f32 LE: ov_V, uv_V, oc_A, cellDiff_mV, ot_C, ut_C        */
     /*   36 B = the above + cellMax_V, cellMin_V, chargeOC_A               */
     /* In the 36 B form a trailing field that is 0.0f or non-finite means  */
     /* "not supplied — keep the value the BMS is already using", so a GUI  */
     /* that only exposes the original six fields no longer has its whole   */
     /* write rejected.  On success the BMS immediately pushes an unsolicited*/
     /* CLI_CMD_FAULT_STATUS (0x04) frame containing the thresholds now in  */
     /* force, so "Set" can be confirmed by read-back with no extra poll.   */
     /* A rejected or short write is recorded in the error log (0x31).      */
#define CLI_CMD_KNOWN_CAL 0x11     /* PC → STM32: known-I cal    (4B float) */
#define CLI_CMD_SOC_SET_FULL 0x12  /* PC → STM32: SOC = 100%       (0B) */
#define CLI_CMD_SOC_SET_EMPTY 0x13 /* PC → STM32: SOC = 0%         (0B) */
#define CLI_CMD_SAVE_CAL 0x14      /* PC → STM32: save cal to flash (0B) */
#define CLI_CMD_SET_SOC_CONFIG 0x21 /* PC → STM32: configure SOC    (100B) */
#define CLI_CMD_SET_TEMP_CAL 0x15   /* PC → STM32: set temp offset  (4B)   */
#define CLI_CMD_SET_TEMP2_CAL 0x16  /* PC → STM32: set NTC2 temp cal (4B)  */
#define CLI_CMD_SET_RTC 0x30        /* PC -> STM32: set time         (6B) */
#define CLI_CMD_READ_ERROR_LOGS 0x31 /* PC -> STM32: request error logs (0B) */
#define CLI_CMD_FAULT_STATUS 0x04
#define CLI_CMD_RTC_DATA 0x05
#define CLI_CMD_ERROR_LOG_DATA 0x06
#define CLI_CMD_TEMP2_DATA 0x07
#define CLI_CMD_CELL_EXTREMA 0x08
#define CLI_CMD_LC_DATA 0x50 /* STM32 → PC: LC Wh/sec/conf (12B) */
#define CLI_CMD_SET_LC_ZERO 0x51 /* PC → STM32: force LC=0 (0B) */
#define CLI_CMD_SET_SOH 0x52 /* PC → STM32: set SOH% (4B float) */

/* ── System reset / fault clear commands ───────────────────────────────── */
#define CLI_CMD_CLEAR_FAULTS    0x54 /* PC → STM32: clear all latched faults (0B) */
#define CLI_CMD_RESET_STATE     0x55 /* PC → STM32: reset lastDriveState to IDLE (0B) */

#define CLI_CMD_BMS_LIFE 0x0A     /* STM32 → PC: BMS life data (16B) */
#define CLI_CMD_RESET_LIFE 0x53   /* PC → STM32: reset SOH counters (0B) */

/* ---- PC->STM32 ---- */
#define CLI_CMD_ZERO_CAL 0x10
#define CLI_CMD_KNOWN_CAL 0x11
#define CLI_CMD_SOC_SET_FULL 0x12
#define CLI_CMD_SOC_SET_EMPTY 0x13
#define CLI_CMD_SAVE_CAL 0x14
#define CLI_CMD_SET_TEMP_CAL 0x15
#define CLI_CMD_SET_TEMP2_CAL 0x16
#define CLI_CMD_SET_FAULT_THRESH 0x20
#define CLI_CMD_SET_SOC_CONFIG 0x21
#define CLI_CMD_SET_RTC 0x30
#define CLI_CMD_READ_ERROR_LOGS 0x31

/* ---- Solterra charger charge-profile config ---- */
#define CLI_CMD_SET_CHARGER_CONFIG                                            \
  0x22 /* PC -> STM32: set charge profile (20B, see CLI_ChargerConfig_t) */
#define CLI_CMD_GET_CHARGER_CONFIG                                            \
  0x23 /* PC -> STM32: request current charge profile        (0B)       */
#define CLI_CMD_CHARGER_CONFIG_DATA                                           \
  0x24 /* STM32 -> PC: charge profile reply (20B, CLI_ChargerConfig_t)  */
#define CLI_CMD_CHARGER_STATUS_DATA                                           \
  0x25 /* STM32 -> PC: live charger status (20B), sent every 100 ms.       */
      /* Byte map (all little-endian):                                    */
      /*   [0] state u8   0 DISCONNECTED 1 READY 2 CHARGING               */
      /*                  3 FAULT 4 INHIBITED 5 TIMEOUT                   */
      /*   [1] comm_ok u8                                                 */
      /*   [2] last_valid_flags u8 (raw Solterra status flags byte)       */
      /*   [3] reserved u8                                                */
      /*   [4:8)  actual_V f32   (from charger)                           */
      /*   [8:12) actual_I f32   (from charger)                           */
      /*   [12:16) cmd_V_setpoint f32 (what the BMS is commanding)        */
      /*   [16:20) cmd_I_setpoint f32                                     */
      /* Python: struct.unpack('<4Bffff', data)                           */
#define CLI_CMD_CAN_HEALTH_DATA                                               \
  0x26 /* STM32 -> PC: CAN bus health (8B), sent every 100 ms.           */
      /* Added alongside the FDCAN1_HealthCheck() fix for "CAN hangs,    */
      /* only a manual BMS reset fixes it" — that turned out to be       */
      /* sustained Error_Passive with no formal Bus_Off, which the old   */
      /* recovery logic never caught (see fdcan.c). This makes both the  */
      /* cumulative recovery count and live Error_Passive dwell time     */
      /* visible in the GUI, not just after the fact in the Error Logs.  */
      /*   [0:4) bus_off_recovery_count u32 LE                           */
      /*   [4:8) error_passive_seconds  u32 LE (0 = currently healthy)   */
      /* Python: struct.unpack('<2I', data)                              */

/* Exported types ------------------------------------------------------------*/

#pragma pack(push, 1)

typedef struct {
  float pack_uv_limit;
  float battery_capacity_ah;
  float pack_full_voltage;
  float soc_ref[11];
  float pack_ocv[11];
} CLI_SOC_Config_Payload_t;

typedef struct {
  uint8_t year;    // Years since 2000 (0-99)
  uint8_t month;   // 1-12
  uint8_t date;    // 1-31
  uint8_t hours;   // 0-23
  uint8_t minutes; // 0-59
  uint8_t seconds; // 0-59
} RTC_DateTime_t;
#pragma pack(pop)

/**
 * @brief  Solterra charger charge-profile config (PC <-> STM32 <-> Flash).
 *
 * Wire layout (packed, 24 bytes):
 *   float cellVoltageSetpoint_V  4
 *   float chargeCurrentFull_A    4
 *   float cvCutoffCurrent_A      4   NEW — CV phase ends when charger-reported
 *                                        I drops below this value; 0 = disabled
 *   float socTaperStart_pct      4   kept for flash compat, unused in pure CC/CV
 *   uint8_t cellCount            1
 *   uint8_t chargeEnable         1   DEPRECATED, always send 1
 *   uint8_t[2] reserved          2   padding
 * Total = 24 bytes. PC side: struct.pack('<4f2B2x', ...)
 *
 * CC/CV logic (Charger_ComputeCommand):
 *   CC phase : send chargeCurrentFull_A until charger-reported V >= pack target
 *   CV phase : charger holds V at target; BMS sends chargeCurrentFull_A still
 *              (charger self-limits); charging stops when charger-reported I
 *              drops below cvCutoffCurrent_A (CV cutoff / termination current).
 */
#pragma pack(push, 1)
typedef struct {
  float    cellVoltageSetpoint_V; /**< Target per-cell voltage (V/cell)        */
  float    chargeCurrentFull_A;   /**< CC phase current ceiling (A)            */
  float    cvCutoffCurrent_A;     /**< CV termination current (A); 0=disabled  */
  float    socTaperStart_pct;     /**< Reserved / flash compat                 */
  uint8_t  cellCount;             /**< Series cell count (S)                   */
  uint8_t  chargeEnable;          /**< DEPRECATED — ignored, always send 1     */
  uint8_t  reserved[2];           /**< Padding                                 */
} CLI_ChargerConfig_t;
#pragma pack(pop)


/** @brief  Receiver state machine states */
typedef enum {
  CLI_STATE_WAIT_HEADER1 = 0,
  CLI_STATE_WAIT_HEADER2,
  CLI_STATE_WAIT_LEN_LOW,
  CLI_STATE_WAIT_LEN_HIGH,
  CLI_STATE_RECV_PAYLOAD,
  CLI_STATE_WAIT_END1,
  CLI_STATE_WAIT_END2
} CLI_RxState_t;

/** @brief  Decoded frame ready for application consumption */
typedef struct {
  uint8_t cmd;                       /**< Command byte          */
  uint8_t data[CLI_MAX_DATA_LENGTH]; /**< Payload data          */
  uint16_t data_len;                 /**< Length of payload data */
} CLI_Frame_t;

/* Exported functions --------------------------------------------------------*/

/**
 * @brief  Initialise the CLI frame receiver (starts UART interrupt reception).
 * @param  huart  Pointer to the UART handle (e.g. &huart2)
 */
void CLI_Frame_Init(UART_HandleTypeDef *huart);

/**
 * @brief  Call from the main loop.  Pops the oldest queued frame, if any.
 *
 * @note   Backed by a CLI_RX_QUEUE_DEPTH-deep FIFO, so the caller should
 *         drain in a loop (up to CLI_RX_QUEUE_DEPTH iterations) rather than
 *         handling a single frame per pass — otherwise the queue can only
 *         ever grow shallower than the bursts it exists to absorb.
 *
 * @param  frame  Pointer to a CLI_Frame_t that receives the decoded frame
 * @retval true   A valid frame was available and has been copied
 * @retval false  Queue empty
 */
bool CLI_Frame_Process(CLI_Frame_t *frame);

/**
 * @brief  Number of decoded frames discarded because the RX queue was full.
 *         Non-zero means the main loop is not draining fast enough — host
 *         commands are being lost.  Zero is the healthy value.
 */
uint32_t CLI_Frame_GetDropCount(void);

/**
 * @brief  Encode and transmit a CLI frame (blocking TX).
 * @param  cmd   Command byte
 * @param  data  Pointer to payload data (may be NULL if len == 0)
 * @param  len   Length of payload data (0 – CLI_MAX_DATA_LENGTH)
 * @retval HAL_StatusTypeDef  HAL_OK on success
 */
HAL_StatusTypeDef CLI_Frame_Send(uint8_t cmd, const uint8_t *data,
                                 uint16_t len);

/**
 * @brief  UART RX complete callback – call from the centralized
 *         HAL_UART_RxCpltCallback when the UART instance matches CLI.
 * @param  huart  Pointer to the UART handle
 */
void CLI_Frame_RxCallback(UART_HandleTypeDef *huart);

#ifdef __cplusplus
}
#endif

#endif /* CLI_FRAME_H */
