/**
  ******************************************************************************
  * @file    power_manager.c
  * @brief   Automotive deep-sleep state machine for the DFI Mosaic BMS.
  *          STM32G474RET6.
  *
  * Contains no board knowledge. Every hardware touch goes through
  * power_manager_port.h.
  ******************************************************************************
  */

#include "power_manager.h"
#include "power_manager_port.h"
#include <string.h>

extern RTC_HandleTypeDef hrtc;

/* ==========================================================================
 * Forward declarations
 * ==========================================================================
 * pm_enter_hibernate() calls pm_full_wake(), which is defined further down.
 * Without these the file only compiles by implicit declaration, which is an
 * error under C99 and a silent int-returning guess under older compilers.
 * ========================================================================== */
static void pm_full_wake(PM_WakeSource_t src);
static void pm_tick_start(void);
static void pm_tick_stop(void);
static void pm_persist_save(void);

/* ==========================================================================
 * Ladder table
 * ========================================================================== */
static const uint32_t pm_ladder_s[] = PM_UV_LADDER_SECONDS;
#define PM_LADDER_STAGES  ((uint8_t)(sizeof(pm_ladder_s) / sizeof(pm_ladder_s[0])))

/* ==========================================================================
 * Module state
 * ==========================================================================
 * Everything here is lost across Standby. The subset that must survive is
 * mirrored into the RTC backup registers by pm_persist_save().
 * ========================================================================== */
typedef struct
{
    PM_State_t      state;
    PM_WakeSource_t last_wake;

    uint8_t         uv_stage;             /* 0 = no fault, 1..N = ladder index */
    bool            hibernate_latched;
    uint32_t        stage_elapsed_s;
    uint32_t        cumulative_fault_s;

    uint32_t        inactivity_ref_ms;
    int32_t         sleep_lock;
    bool            sleep_requested;

    float           last_pack_v;
    float           last_current_a;
    uint8_t         current_confirm;
} PM_Ctx_t;

static PM_Ctx_t pm;

/* Set from EXTI context. volatile: written in an ISR, read in thread mode. */
static volatile bool pm_evt_can    = false;
static volatile bool pm_evt_button = false;
static volatile bool pm_evt_tick   = false;

/* ==========================================================================
 * Backup-register persistence
 * ==========================================================================
 * The ladder must survive Standby (SRAM is lost) and any unexpected reset,
 * otherwise a watchdog reset or a brownout would silently restart the
 * protection sequence at stage 0 and the pack would be indicated to death.
 * ========================================================================== */

static uint32_t pm_persist_pack(void)
{
    return ((uint32_t)pm.state          & 0x0FUL)
         | (((uint32_t)pm.uv_stage      & 0x0FUL) << 4)
         | (((uint32_t)(pm.hibernate_latched ? 1U : 0U)) << 8);
}

static void pm_persist_unpack(uint32_t v)
{
    pm.state             = (PM_State_t)(v & 0x0FUL);
    pm.uv_stage          = (uint8_t)((v >> 4) & 0x0FUL);
    pm.hibernate_latched = (((v >> 8) & 0x01UL) != 0UL);
}

static uint32_t pm_persist_checksum(uint32_t packed, uint32_t elapsed, uint32_t cumul)
{
    /* Deliberately trivial. Its only job is to reject uninitialised backup
     * RAM on a virgin board, not to resist tampering. */
    return (PM_BKP_MAGIC_VALUE ^ packed ^ (elapsed * 2654435761UL) ^ (cumul * 40503UL));
}

static void pm_persist_save(void)
{
    const uint32_t packed  = pm_persist_pack();
    const uint32_t elapsed = pm.stage_elapsed_s;
    const uint32_t cumul   = pm.cumulative_fault_s;

    HAL_PWR_EnableBkUpAccess();
    HAL_RTCEx_BKUPWrite(&hrtc, PM_BKP_PACKED_REG,         packed);
    HAL_RTCEx_BKUPWrite(&hrtc, PM_BKP_STAGE_ELAPSED_REG,  elapsed);
    HAL_RTCEx_BKUPWrite(&hrtc, PM_BKP_CUMULATIVE_REG,     cumul);
    HAL_RTCEx_BKUPWrite(&hrtc, PM_BKP_CHECKSUM_REG,
                        pm_persist_checksum(packed, elapsed, cumul));
    HAL_RTCEx_BKUPWrite(&hrtc, PM_BKP_MAGIC_REG,          PM_BKP_MAGIC_VALUE);
}

static bool pm_persist_load(void)
{
    if (HAL_RTCEx_BKUPRead(&hrtc, PM_BKP_MAGIC_REG) != PM_BKP_MAGIC_VALUE)
    {
        return false;
    }

    const uint32_t packed  = HAL_RTCEx_BKUPRead(&hrtc, PM_BKP_PACKED_REG);
    const uint32_t elapsed = HAL_RTCEx_BKUPRead(&hrtc, PM_BKP_STAGE_ELAPSED_REG);
    const uint32_t cumul   = HAL_RTCEx_BKUPRead(&hrtc, PM_BKP_CUMULATIVE_REG);
    const uint32_t crc     = HAL_RTCEx_BKUPRead(&hrtc, PM_BKP_CHECKSUM_REG);

    if (crc != pm_persist_checksum(packed, elapsed, cumul))
    {
        return false;
    }

    pm_persist_unpack(packed);
    pm.stage_elapsed_s    = elapsed;
    pm.cumulative_fault_s = cumul;

    /* Defend against a corrupt stage index driving an out-of-bounds table
     * read. Anything nonsensical is escalated, never de-escalated. */
    if (pm.uv_stage > PM_LADDER_STAGES)
    {
        pm.uv_stage          = PM_LADDER_STAGES;
        pm.hibernate_latched = true;
    }

    return true;
}

/* ==========================================================================
 * RTC wake-up tick
 * ==========================================================================
 * CK_SPRE gives a 1 s resolution counter, so the tick period is expressed
 * directly in seconds. Long ladder intervals are counted in software ticks
 * rather than programmed into the RTC, which avoids the 18.2 h ceiling of
 * CK_SPRE_16BITS mode and keeps the IWDG fed throughout.
 * ========================================================================== */

static void pm_tick_start(void)
{
    (void)HAL_RTCEx_DeactivateWakeUpTimer(&hrtc);

    /* NOTE: STM32G4 HAL takes a 4th WakeUpAutoClr argument. Older HAL
     * revisions expose a 3-argument form -- drop the trailing 0U if the
     * compiler complains about too many arguments here. */
    (void)HAL_RTCEx_SetWakeUpTimer_IT(&hrtc,
                                      (uint32_t)(PM_TICK_SECONDS - 1U),
                                      RTC_WAKEUPCLOCK_CK_SPRE_16BITS,
                                      0U);
}

static void pm_tick_stop(void)
{
    (void)HAL_RTCEx_DeactivateWakeUpTimer(&hrtc);
}

void HAL_RTCEx_WakeUpTimerEventCallback(RTC_HandleTypeDef *rtc)
{
    (void)rtc;
    pm_evt_tick = true;
}

/* ==========================================================================
 * EXTI plumbing
 * ==========================================================================
 * Deliberately NOT a HAL_GPIO_EXTI_Callback() definition. main.c almost
 * certainly already has one; a second definition would be a duplicate symbol.
 * Call PM_EXTI_Notify() from the existing callback instead.
 * ========================================================================== */

void PM_EXTI_Notify(uint16_t gpio_pin)
{
    if (gpio_pin == PM_CAN_RX_PIN)
    {
        pm_evt_can = true;
    }
    else if (gpio_pin == PM_WAKE_BTN_PIN)
    {
        pm_evt_button = true;
    }
    else
    {
        /* not ours */
    }
}

static void pm_arm_can_exti(void)
{
    GPIO_InitTypeDef g = {0};
    g.Pin  = PM_CAN_RX_PIN;
    g.Mode = GPIO_MODE_IT_FALLING;
    g.Pull = GPIO_PULLUP;          /* recessive is high; keep it defined */
    HAL_GPIO_Init(PM_CAN_RX_PORT, &g);

    __HAL_GPIO_EXTI_CLEAR_IT(PM_CAN_RX_PIN);
    HAL_NVIC_SetPriority(PM_CAN_RX_EXTI_IRQn, 5, 0);
    HAL_NVIC_EnableIRQ(PM_CAN_RX_EXTI_IRQn);
}

static void pm_arm_button_exti(void)
{
    GPIO_InitTypeDef g = {0};
    g.Pin  = PM_WAKE_BTN_PIN;
#if (PM_WAKE_BTN_ACTIVE_LOW == 1)
    g.Mode = GPIO_MODE_IT_FALLING;
    g.Pull = GPIO_PULLUP;
#else
    g.Mode = GPIO_MODE_IT_RISING;
    g.Pull = GPIO_PULLDOWN;
#endif
    HAL_GPIO_Init(PM_WAKE_BTN_PORT, &g);

    __HAL_GPIO_EXTI_CLEAR_IT(PM_WAKE_BTN_PIN);
    HAL_NVIC_SetPriority(PM_WAKE_BTN_EXTI_IRQn, 5, 0);
    HAL_NVIC_EnableIRQ(PM_WAKE_BTN_EXTI_IRQn);
}

/* ==========================================================================
 * Low-power entry
 * ========================================================================== */

static void pm_prepare_for_stop(void)
{
    /* Flash power-down in Stop. Bit name is CMSIS-version dependent, hence
     * the guard: on a header that does not define it the line vanishes and
     * costs a few microamps rather than failing the build. */
#if defined(PWR_CR1_FPD_STOP)
    SET_BIT(PWR->CR1, PWR_CR1_FPD_STOP);
#endif

    /* Leaving the debug-in-low-power bits set holds the debug clock domain
     * alive through Stop and costs milliamps. This is the single most common
     * reason a "working" low-power build measures 100x over budget on the
     * bench: it only shows up when the debugger is attached, so it hides
     * during bring-up and appears in production. */
    CLEAR_BIT(DBGMCU->CR, DBGMCU_CR_DBG_SLEEP
                        | DBGMCU_CR_DBG_STOP
                        | DBGMCU_CR_DBG_STANDBY);

    /* Clear stale wake flags, otherwise the WFI falls straight through. */
#if defined(PWR_SCR_CWUF)
    SET_BIT(PWR->SCR, PWR_SCR_CWUF);
#endif
}

/**
  * @brief  Enter Stop 1 and block until something wakes us.
  * @retval true  if a bare housekeeping tick woke us (clock tree still at
  *               HSI16, no peripherals restored)
  * @retval false if a real wake event is pending
  */
static bool pm_enter_stop1(void)
{
    pm_prepare_for_stop();

    HAL_SuspendTick();
    HAL_PWREx_EnterSTOP1Mode(PWR_STOPENTRY_WFI);
    /* ---- execution resumes here at HSI16, PLL off ---- */
    HAL_ResumeTick();

    return (pm_evt_tick && !pm_evt_can && !pm_evt_button);
}

static void pm_enter_hibernate(void)
{
    pm.state             = PM_STATE_HIBERNATE;
    pm.hibernate_latched = true;
    pm_persist_save();

    PMP_OpenPowerPath();
    PMP_AllRailsOff();
    PMP_CanEnterSleep();
    PMP_FlashEnterDeepPowerDown();
    PMP_PeripheralsSuspend();
    PMP_FaultLed(false);

    /* No FAULT-based wake from here: no measurement, no ladder, nothing but
     * the button. Below this voltage the cheapest thing the BMS can do for the
     * cells is stop looking at them.
     *
     * The RTC tick is NOT stopped when hibernating via Stop 1, though, and the
     * reason is the IWDG. It keeps running in Stop, cannot be disabled once
     * started, and this build's period is 4.002 s. Stopping the tick here
     * would reset the MCU every 4 s forever -- each reset paying a full boot
     * at milliamps, which is worse for the pack than not hibernating at all,
     * and the backup-register latch would silently re-enter hibernate on every
     * one of those boots so the symptom would be invisible.
     *
     * The tick still costs nothing measurable: a bare wake that kicks the
     * watchdog and goes straight back to Stop, ~20 us at HSI16 every 3 s. It
     * is explicitly NOT a measurement point in this state. */
#if (PM_HIBERNATE_USE_STOP1 == 1) && (PM_IWDG_ENABLED == 1)
    pm_tick_start();
#else
    pm_tick_stop();
#endif

#if (PM_HIBERNATE_USE_STOP1 == 1)
    /* Button is not on a PWR WKUP pin (PB9), so Standby is unusable. Stop 1
     * with only the button EXTI armed costs roughly 4 uA more. */
    PMP_ParkGpio();
    pm_arm_button_exti();

    pm_evt_button = false;      /* consume the press that got us here */

    for (;;)
    {
        (void)pm_enter_stop1();

        PMP_WatchdogKick();

        if (pm_evt_button && PMP_WakeButtonPressed())
        {
            break;
        }
        pm_evt_can    = false;
        pm_evt_tick   = false;
        pm_evt_button = false;
    }

    /* Button pressed: release the latch and restart the UV checking cycle from
     * stage 1, per "once the wake button is pressed, immediately start doing
     * this UV fault checking cycle again".
     *
     * Without this the latch stays set, PM_Task re-enters hibernate on its
     * very next call, and the button appears to do nothing at all -- the pack
     * would need a physical disconnect to recover. */
    pm_evt_button         = false;
    pm.hibernate_latched  = false;
    pm.uv_stage           = 1U;
    pm.stage_elapsed_s    = 0U;
    pm.cumulative_fault_s = 0U;
    pm.current_confirm    = 0U;
    pm.state              = PM_STATE_UV_INDICATE;
    pm_persist_save();

    pm_full_wake(PM_WAKE_BUTTON);
    return;
#else
    PMP_ParkGpio();

    /* The parking pass may have left the button pin in analog mode, which is
     * not a valid configuration for the PWR wake-up path. Put it back to a
     * plain input with a defined pull BEFORE arming Standby. Getting this
     * wrong bricks the pack: the BMS enters hibernate and no button press can
     * ever bring it back. */
    {
        GPIO_InitTypeDef g = {0};
        g.Pin  = PM_WAKE_BTN_PIN;
        g.Mode = GPIO_MODE_INPUT;
#if (PM_WAKE_BTN_ACTIVE_LOW == 1)
        g.Pull = GPIO_PULLUP;
#else
        g.Pull = GPIO_PULLDOWN;
#endif
        HAL_GPIO_Init(PM_WAKE_BTN_PORT, &g);
    }

#if defined(PWR_SCR_CWUF)
    SET_BIT(PWR->SCR, PWR_SCR_CWUF);
#endif
    HAL_PWR_EnableWakeUpPin(PM_WAKE_BTN_PWR_WKUP);

    /* Standby: SRAM and register state are lost. Wake is a full reset, which
     * is why the ladder lives in the backup registers. */
    HAL_PWR_EnterSTANDBYMode();
    /* Not reached. */
#endif
}

/* ==========================================================================
 * Measurement and fault evaluation
 * ========================================================================== */

typedef enum
{
    PM_UV_UNKNOWN = 0,   /* measurement not trustworthy -- change nothing */
    PM_UV_OK,            /* above the clear threshold                    */
    PM_UV_HOLD,          /* inside the hysteresis band                   */
    PM_UV_FAULT          /* at or below the near-UV threshold            */
} PM_UvVerdict_t;

static PM_UvVerdict_t pm_sample_and_judge(bool *current_detected)
{
    float v = 0.0f;
    float i = 0.0f;

    *current_detected = false;

    if (!PMP_SampleOnce(&v, &i))
    {
        /* A stalled Daly link or a sensor that failed to settle must not be
         * able to fabricate a UV trip. This is the same failure mode that
         * previously froze pack_voltage and latched faults permanently. */
        return PM_UV_UNKNOWN;
    }

    pm.last_pack_v    = v;
    pm.last_current_a = i;

    const float mag = (i < 0.0f) ? -i : i;
    if (mag >= PM_WAKE_CURRENT_A)
    {
        if (pm.current_confirm < 0xFFU)
        {
            pm.current_confirm++;
        }
        if (pm.current_confirm >= PM_WAKE_CURRENT_CONFIRM_CNT)
        {
            *current_detected = true;
        }
    }
    else
    {
        pm.current_confirm = 0U;
    }

    if (v >= PM_UV_CLEAR_V)
    {
        return PM_UV_OK;
    }
    if (v <= PM_UV_NEAR_V)
    {
        return PM_UV_FAULT;
    }
    return PM_UV_HOLD;
}

/* ==========================================================================
 * Indication window
 * ==========================================================================
 * Ten seconds of blinking, not ten seconds of steady LED. Same visibility to
 * an operator, one tenth of the charge out of a pack that has none to spare.
 * ========================================================================== */

static void pm_run_indication(void)
{
    pm.state = PM_STATE_UV_INDICATE;
    pm_persist_save();

#if (PM_INDICATE_ON_CAN == 1)
    PMP_IndicateOnCan(pm.uv_stage, pm.last_pack_v);
#endif

    const uint32_t start = HAL_GetTick();
    while ((HAL_GetTick() - start) < PM_INDICATE_MS)
    {
        const uint32_t phase = (HAL_GetTick() - start) % PM_INDICATE_LED_PERIOD_MS;
        PMP_FaultLed(phase < PM_INDICATE_LED_ON_MS);

        PMP_WatchdogKick();

        /* An operator pressing the button during the indication window is
         * asking for a full wake, and should get one. */
        if (pm_evt_button)
        {
            break;
        }
    }

    PMP_FaultLed(false);
}

/* ==========================================================================
 * Sleep loop
 * ==========================================================================
 * Enters Stop 1 repeatedly, servicing housekeeping ticks without restoring
 * the clock tree, and returns only on a real wake event or when the stage
 * deadline expires.
 * ========================================================================== */

static PM_WakeSource_t pm_sleep_until(uint32_t deadline_s, uint32_t measure_every_n)
{
    uint32_t tick_count = 0U;

    PMP_OpenPowerPath();
    PMP_AllRailsOff();
    PMP_PeripheralsSuspend();
    PMP_FlashEnterDeepPowerDown();
    PMP_CanEnterSleep();
    PMP_ParkGpio();
    pm_arm_button_exti();
    pm_arm_can_exti();
    pm_tick_start();

    for (;;)
    {
        /* Entering Stop while the bus is dominant produces an instant wake
         * and a tight spin. Wait for recessive first. */
        if (PMP_CanBusIsDominant())
        {
            PMP_WatchdogKick();
            continue;
        }

        pm_evt_tick = false;
        (void)pm_enter_stop1();

        /* ---- real wake events, highest priority first ---- */
        if (pm_evt_button)
        {
            /* Debounce and qualify in software: a wake button on a long
             * harness picks up enough noise to self-trigger. */
            uint32_t held = 0U;
            while (PMP_WakeButtonPressed() && (held < PM_WAKE_BTN_HOLD_MS))
            {
                HAL_Delay(10U);
                held += 10U;
                PMP_WatchdogKick();
            }
            if (held >= PM_WAKE_BTN_HOLD_MS)
            {
                return PM_WAKE_BUTTON;
            }
            pm_evt_button = false;
        }

        if (pm_evt_can)
        {
            pm_evt_can = false;
            return PM_WAKE_CAN;
        }

        /* ---- housekeeping tick ---- */
        if (pm_evt_tick)
        {
            pm_evt_tick = false;
            tick_count++;

            pm.stage_elapsed_s += PM_TICK_SECONDS;
            if (pm.uv_stage > 0U)
            {
                pm.cumulative_fault_s += PM_TICK_SECONDS;
            }

            PMP_WatchdogKick();

            if ((measure_every_n != 0U) && ((tick_count % measure_every_n) == 0U))
            {
                /* Measurement needs the full clock tree for the ADC timing
                 * the driver was configured against. */
                PMP_RestoreClocks();

                bool current_detected = false;
                const PM_UvVerdict_t verdict = pm_sample_and_judge(&current_detected);

                if (current_detected)
                {
                    return PM_WAKE_CURRENT;
                }
                if ((verdict == PM_UV_FAULT) && (pm.uv_stage == 0U))
                {
                    return PM_WAKE_UNDERVOLTAGE;
                }
                if ((verdict == PM_UV_OK) && (pm.uv_stage > 0U))
                {
                    /* Recovered -- reset the ladder and go back to plain
                     * deep sleep. */
                    pm.uv_stage           = 0U;
                    pm.stage_elapsed_s    = 0U;
                    pm.cumulative_fault_s = 0U;
                    pm_persist_save();
                }
            }

            /* Persist sparingly: the backup registers are cheap to write but
             * every write costs a few microseconds of run time. Once a
             * minute is plenty for a ladder measured in hours. */
            if ((tick_count % (60U / PM_TICK_SECONDS + 1U)) == 0U)
            {
                pm_persist_save();
            }

            if ((deadline_s != 0U) && (pm.stage_elapsed_s >= deadline_s))
            {
                return PM_WAKE_STAGE_EXPIRY;
            }
        }
    }
}

/**
  * @brief  Full wake: restore clocks, GPIO, peripherals, rails and CAN.
  */
static void pm_full_wake(PM_WakeSource_t src)
{
    PMP_RestoreClocks();
    pm_tick_stop();
    PMP_RestoreGpio();
    PMP_FlashExitDeepPowerDown();
    PMP_PeripheralsResume();
    PMP_AllRailsOn();
    PMP_CanExitSleep();

    pm.last_wake          = src;
    pm.inactivity_ref_ms  = HAL_GetTick();
    pm.sleep_requested    = false;
}

/* ==========================================================================
 * Public API
 * ========================================================================== */

void PM_Init(void)
{
    memset(&pm, 0, sizeof(pm));
    pm.state            = PM_STATE_ACTIVE;
    pm.last_wake        = PM_WAKE_RESET;
    pm.inactivity_ref_ms = HAL_GetTick();

    HAL_PWR_EnableBkUpAccess();

    const bool came_from_standby = (__HAL_PWR_GET_FLAG(PWR_FLAG_SB) != 0U);
    __HAL_PWR_CLEAR_FLAG(PWR_FLAG_SB);
    HAL_PWR_DisableWakeUpPin(PM_WAKE_BTN_PWR_WKUP);
#if defined(PWR_SCR_CWUF)
    SET_BIT(PWR->SCR, PWR_SCR_CWUF);
#endif

    const bool restored = pm_persist_load();

    if (came_from_standby && restored && pm.hibernate_latched)
    {
        /* Woken out of pack-protection hibernate by the button. Per the
         * specification the whole UV checking cycle restarts from the
         * beginning rather than resuming where it left off. */
        PM_ClearHibernateLatch();
        pm.last_wake = PM_WAKE_BUTTON;
    }
    else if (restored && (pm.uv_stage > 0U))
    {
        /* An unexpected reset mid-ladder. Resume at the same stage: a reset
         * loop must not be able to walk the ladder back to stage 0 and
         * indicate the pack flat. */
        pm.state = PM_STATE_UV_BACKOFF;
    }
    else
    {
        pm.uv_stage           = 0U;
        pm.stage_elapsed_s    = 0U;
        pm.cumulative_fault_s = 0U;
    }

    pm_persist_save();
}

void PM_NotifyActivity(void)
{
    pm.inactivity_ref_ms = HAL_GetTick();
}

void PM_LockAcquire(void)
{
    pm.sleep_lock++;
}

void PM_LockRelease(void)
{
    if (pm.sleep_lock > 0)
    {
        pm.sleep_lock--;
    }
}

void PM_RequestSleep(void)
{
    pm.sleep_requested = true;
}

void PM_ClearHibernateLatch(void)
{
    pm.hibernate_latched  = false;
    pm.uv_stage           = 0U;
    pm.stage_elapsed_s    = 0U;
    pm.cumulative_fault_s = 0U;
    pm.state              = PM_STATE_ACTIVE;
    pm_persist_save();
}

void PM_GetStatus(PM_Status_t *out)
{
    if (out == NULL)
    {
        return;
    }
    out->state              = pm.state;
    out->last_wake          = pm.last_wake;
    out->uv_stage           = pm.uv_stage;
    out->hibernate_latched  = pm.hibernate_latched ? 1U : 0U;
    out->stage_elapsed_s    = pm.stage_elapsed_s;
    out->cumulative_fault_s = pm.cumulative_fault_s;
    out->last_pack_v        = pm.last_pack_v;
    out->last_current_a     = pm.last_current_a;
}

uint8_t PM_GetPackedStatus(void)
{
    return (uint8_t)(((uint8_t)pm.state & 0x07U)
                   | (((uint8_t)pm.uv_stage & 0x0FU) << 3)
                   | (pm.hibernate_latched ? 0x80U : 0x00U));
}

/* -------------------------------------------------------------------------- */

void PM_Task(void)
{
    /* A button press in ACTIVE is an activity event, nothing more. */
    if (pm_evt_button)
    {
        pm_evt_button = false;
        PM_NotifyActivity();
    }
    if (pm_evt_can)
    {
        pm_evt_can = false;
        PM_NotifyActivity();
    }

    if (pm.hibernate_latched)
    {
        pm_enter_hibernate();
        return;
    }

    if (pm.sleep_lock > 0)
    {
        return;
    }

    switch (pm.state)
    {
    /* ---------------------------------------------------------------- */
    case PM_STATE_ACTIVE:
    {
        const bool timed_out =
            ((HAL_GetTick() - pm.inactivity_ref_ms) >= PM_INACTIVITY_TIMEOUT_MS);

        if (!timed_out && !pm.sleep_requested)
        {
            return;
        }

        /* If a UV ladder is already in progress, resume it rather than
         * dropping into plain deep sleep. Going to DEEP_SLEEP here would let
         * the next UV detection re-initialise the stage to 1, so any CAN or
         * button wake would silently restart protection from the beginning --
         * defeating PM_UV_RESET_LADDER_ON_COMMS == 0 by the back door. On the
         * Solterra bus, which broadcasts continuously, that would have meant
         * the ladder never got past stage 1. */
        pm.state           = (pm.uv_stage > 0U) ? PM_STATE_UV_BACKOFF
                                                : PM_STATE_DEEP_SLEEP;
        pm.stage_elapsed_s = 0U;
        pm_persist_save();
        break;
    }

    /* ---------------------------------------------------------------- */
    case PM_STATE_DEEP_SLEEP:
    {
        /* No deadline: sleep indefinitely until an event arrives. */
        const PM_WakeSource_t src = pm_sleep_until(0U, PM_MEASURE_EVERY_N_TICKS);

        if (src == PM_WAKE_UNDERVOLTAGE)
        {
            /* Only start the ladder if one is not already running. Resetting
             * unconditionally here is what let a wake-then-resleep cycle pin
             * the ladder at stage 1 indefinitely. */
            if (pm.uv_stage == 0U)
            {
                pm.uv_stage           = 1U;
                pm.cumulative_fault_s = 0U;
            }
            pm.stage_elapsed_s    = 0U;
            pm.state              = PM_STATE_UV_INDICATE;
            PMP_RestoreClocks();
            pm_persist_save();
        }
        else
        {
            pm_full_wake(src);
            pm.state = PM_STATE_ACTIVE;
            pm_persist_save();
        }
        break;
    }

    /* ---------------------------------------------------------------- */
    case PM_STATE_UV_INDICATE:
    {
        pm_run_indication();

        if (pm_evt_button)
        {
            pm_evt_button = false;
            pm_full_wake(PM_WAKE_BUTTON);
            pm.state = PM_STATE_ACTIVE;
            pm_persist_save();
            break;
        }

        pm.state           = PM_STATE_UV_BACKOFF;
        pm.stage_elapsed_s = 0U;
        pm_persist_save();
        break;
    }

    /* ---------------------------------------------------------------- */
    case PM_STATE_UV_BACKOFF:
    {
        if (pm.uv_stage == 0U)
        {
            pm.state = PM_STATE_DEEP_SLEEP;
            break;
        }

        const uint8_t  idx      = (uint8_t)(pm.uv_stage - 1U);
        const uint32_t deadline = pm_ladder_s[(idx < PM_LADDER_STAGES) ? idx
                                                                      : (PM_LADDER_STAGES - 1U)];

        const PM_WakeSource_t src =
            pm_sleep_until(deadline, PM_MEASURE_EVERY_N_TICKS_BACKOFF);

        switch (src)
        {
        case PM_WAKE_STAGE_EXPIRY:
        {
            PMP_RestoreClocks();

            bool current_detected = false;
            const PM_UvVerdict_t verdict = pm_sample_and_judge(&current_detected);

            if (verdict == PM_UV_OK)
            {
                pm.uv_stage           = 0U;
                pm.stage_elapsed_s    = 0U;
                pm.cumulative_fault_s = 0U;
                pm.state              = PM_STATE_DEEP_SLEEP;
                pm_persist_save();
                break;
            }

            if (verdict == PM_UV_UNKNOWN)
            {
                /* Could not measure. Re-run the same stage rather than
                 * escalating on missing evidence. */
                pm.stage_elapsed_s = 0U;
                pm_persist_save();
                break;
            }

#if (PM_UV_ABS_TIMEOUT_ENABLE == 1)
            if (pm.cumulative_fault_s >= PM_UV_ABS_TIMEOUT_S)
            {
                pm.hibernate_latched = true;
                pm_persist_save();
                break;
            }
#endif
            /* Fault still present: climb one rung. Falling off the top of
             * the ladder is permanent pack protection. */
            pm.uv_stage++;
            pm.stage_elapsed_s = 0U;

            if (pm.uv_stage > PM_LADDER_STAGES)
            {
                pm.uv_stage          = PM_LADDER_STAGES;
                pm.hibernate_latched = true;
                pm_persist_save();
                break;
            }

            pm.state = PM_STATE_UV_INDICATE;
            pm_persist_save();
            break;
        }

        case PM_WAKE_CURRENT:
            /* Something is charging the pack. Serve it awake -- the ladder
             * index is preserved and will be cleared by the voltage
             * recovering above PM_UV_CLEAR_V, not by the wake itself. */
            pm_full_wake(src);
            pm.state = PM_STATE_ACTIVE;
            pm_persist_save();
            break;

        case PM_WAKE_CAN:
        case PM_WAKE_BUTTON:
        default:
            pm_full_wake(src);
#if (PM_UV_RESET_LADDER_ON_COMMS == 1)
            pm.uv_stage           = 0U;
            pm.cumulative_fault_s = 0U;
#endif
            pm.state = PM_STATE_ACTIVE;
            pm_persist_save();
            break;
        }
        break;
    }

    /* ---------------------------------------------------------------- */
    case PM_STATE_HIBERNATE:
    default:
        pm_enter_hibernate();
        break;
    }
}
