/**
 * @file    cli_frame.c
 * @brief   CLI frame protocol – interrupt-driven state-machine decoder &
 *          encoder.
 *
 * ============================================================================
 * RX PATH FIX — "BMS transmits fine but never accepts a CLI command"
 * ============================================================================
 *
 * The frame decoder itself was correct (verified byte-for-byte against a
 * well-formed 0x20 / 24 B frame and a 0-payload 0x14 frame). The failure was
 * in the *arming* of the receiver, not the parsing of it.
 *
 * The old scheme re-armed a one-byte HAL_UART_Receive_IT() from inside
 * HAL_UART_RxCpltCallback() and ignored the return value. That single-byte
 * IT chain has several ways to stop dead and never restart, and every one of
 * them looks exactly like the reported symptom — telemetry keeps streaming
 * out (blocking TX, unaffected) while nothing the GUI sends is ever seen:
 *
 *   1. RE-ARM RETURN IGNORED. HAL_UART_Receive_IT() returns HAL_BUSY when
 *      huart->RxState != READY. One HAL_BUSY and the chain is broken
 *      permanently — there is nothing left that would ever call it again,
 *      because the only thing that re-armed it was the callback that now
 *      never fires.
 *
 *   2. THE HAL CAN DISARM RX BEHIND OUR BACK. On overrun,
 *      HAL_UART_IRQHandler() treats ORE as a *blocking* error and calls
 *      UART_EndRxTransfer(), which clears RXNEIE and drops RxISR. On HAL
 *      revisions where UART_WaitOnFlagUntilTimeout() is not guarded against
 *      the TXE/TC flags, the same UART_EndRxTransfer() is reached from inside
 *      the blocking CLI_Frame_Send() — and that path does NOT call
 *      HAL_UART_ErrorCallback(), so nothing re-arms. With telemetry issuing
 *      ~11 blocking sends every 100 ms, one stray byte or line glitch on
 *      USART2 kills CLI RX for good.
 *
 *   3. RECOVERY DISCARDED QUEUED COMMANDS. HAL_UART_ErrorCallback() called
 *      CLI_Frame_Init(), which zeroes rx_q_head/rx_q_tail — so a decoded but
 *      not-yet-consumed host command was thrown away by an unrelated noise
 *      blip on the line.
 *
 * FIX: USART2 RX no longer goes through HAL's RX state machine at all.
 * RXNEIE is enabled directly, bytes are pulled straight out of RDR in
 * CLI_Frame_IRQHandler(), and RX error flags are cleared in the same place.
 * There is no re-arm to fail, no HAL RxState to get stuck, and no HAL error
 * path to interfere. CLI_Frame_Process() additionally re-enables RXNEIE if it
 * ever finds it cleared, so the receiver is self-healing from the main loop.
 *
 * Everything else is unchanged: frame format, checksum window, the decoded
 * frame FIFO, CLI_Frame_Process()'s signature and CLI_Frame_Send() are all
 * bit-identical to before. TX still uses blocking HAL_UART_Transmit(), and
 * UART5 / the Daly driver are untouched.
 *
 * g_cliRxStats is there so the remaining ambiguity is observable rather than
 * silent — see cli_frame.h for how to read it.
 */

/* Includes ------------------------------------------------------------------*/
#include "cli_frame.h"
#include <string.h>

/* Private variables ---------------------------------------------------------*/
static UART_HandleTypeDef *cli_huart;        /* UART handle (TX side)        */
static USART_TypeDef      *cli_usart;        /* Cached raw peripheral        */

static volatile CLI_RxState_t rx_state;      /* Current state machine state  */

static uint8_t rx_buf[CLI_MAX_FRAME_LENGTH]; /* Assembly buffer for raw frame */
static uint16_t rx_idx;                      /* Write index into rx_buf       */
static uint16_t rx_expected_len;             /* Total frame length from hdr   */
static uint8_t rx_checksum;                  /* Running checksum              */

/* RX diagnostics. Add "g_cliRxStats" to Live Expressions to see, in one
 * glance, which half of the link is at fault. */
volatile CLI_RxStats_t g_cliRxStats;

/* ---------------------------------------------------------------------------
 * Decoded-frame FIFO.  Single producer (UART RX ISR) / single consumer (main
 * loop), so head and tail need no critical section: each index is written by
 * exactly one context and is a single naturally-aligned byte.
 * -------------------------------------------------------------------------*/
static CLI_Frame_t rx_queue[CLI_RX_QUEUE_DEPTH];
static volatile uint8_t rx_q_head;      /* ISR writes here      */
static volatile uint8_t rx_q_tail;      /* main loop reads here */
static volatile uint32_t rx_drop_count; /* frames lost to a full queue */

/* Private function prototypes -----------------------------------------------*/
static void CLI_ResetState(void);
static void CLI_FeedByte(uint8_t b);

/* Public functions ----------------------------------------------------------*/

void CLI_Frame_Init(UART_HandleTypeDef *huart) {
  if (huart == NULL) {
    return;
  }

  cli_huart = huart;
  cli_usart = huart->Instance;

  CLI_ResetState();
  rx_q_head = 0U;
  rx_q_tail = 0U;
  rx_drop_count = 0U;
  memset((void *)&g_cliRxStats, 0, sizeof(g_cliRxStats));

  CLI_Frame_Rearm();
}

void CLI_Frame_Rearm(void) {
  if (cli_usart == NULL) {
    return; /* called before CLI_Frame_Init() — nothing to do */
  }

  /* Clear any stale RX error flag. Left set, ORE re-triggers the interrupt
   * forever; on the HAL path it also caused UART_EndRxTransfer() to disarm
   * the receiver. */
  __HAL_UART_CLEAR_FLAG(cli_huart, UART_CLEAR_OREF | UART_CLEAR_FEF |
                                       UART_CLEAR_NEF | UART_CLEAR_PEF);

  /* Drop whatever is sitting in RDR — it predates this re-arm. */
  (void)cli_usart->RDR;

  /* Keep the HAL RX state machine parked. RxState must stay READY so no HAL
   * code path (notably UART_WaitOnFlagUntilTimeout() inside the blocking
   * CLI_Frame_Send()) believes an IT reception is in flight and tries to
   * "abort" it by clearing RXNEIE. */
  if (cli_huart != NULL) {
    cli_huart->RxState = HAL_UART_STATE_READY;
    cli_huart->RxISR = NULL;
  }

  /* Deliberately NOT enabling USART_CR3_EIE: framing/noise flags are polled
   * and cleared in CLI_Frame_IRQHandler() instead, so HAL_UART_ErrorCallback()
   * never fires for this UART and can never fight us over the state. ORE still
   * raises an interrupt because RXNEIE is set (RM0440, USART interrupt table). */
  __HAL_UART_ENABLE_IT(cli_huart, UART_IT_RXNE);
}

void CLI_Frame_IRQHandler(void) {
  if (cli_usart == NULL) {
    return;
  }

  uint32_t isr = cli_usart->ISR;

  /* ---- RX error flags ------------------------------------------------- */
  if ((isr & (UART_FLAG_ORE | UART_FLAG_FE | UART_FLAG_NE | UART_FLAG_PE)) !=
      0U) {
    if ((isr & UART_FLAG_ORE) != 0U) {
      g_cliRxStats.overrun_events++;
    }
    if ((isr & (UART_FLAG_FE | UART_FLAG_NE | UART_FLAG_PE)) != 0U) {
      g_cliRxStats.frame_noise_events++;
    }

    __HAL_UART_CLEAR_FLAG(cli_huart, UART_CLEAR_OREF | UART_CLEAR_FEF |
                                         UART_CLEAR_NEF | UART_CLEAR_PEF);

    /* A lost or mangled byte makes the frame in flight unusable; resync on
     * the next header instead of trying to finish a frame with a hole in it. */
    CLI_ResetState();
  }

  /* ---- Drain every byte the peripheral has ---------------------------- */
  while ((cli_usart->ISR & UART_FLAG_RXNE) != 0U) {
    uint8_t b = (uint8_t)(cli_usart->RDR & 0xFFU);
    g_cliRxStats.bytes++;
    CLI_FeedByte(b);
  }

  /* Belt and braces: the receiver leaves this ISR armed, always. */
  __HAL_UART_ENABLE_IT(cli_huart, UART_IT_RXNE);
}

bool CLI_Frame_Process(CLI_Frame_t *frame) {
  /* Self-heal: if anything ever cleared RXNEIE, bring the receiver back
   * rather than staying deaf until the next power cycle. Costs one register
   * read per main-loop iteration. */
  if ((cli_usart != NULL) &&
      (__HAL_UART_GET_IT_SOURCE(cli_huart, UART_IT_RXNE) == 0U)) {
    g_cliRxStats.rearm_events++;
    CLI_Frame_Rearm();
  }

  uint8_t tail = rx_q_tail;

  if (tail == rx_q_head) {
    return false; /* queue empty */
  }

  const CLI_Frame_t *src = &rx_queue[tail];

  /* Copy only the bytes that are actually populated. */
  frame->cmd = src->cmd;
  frame->data_len = src->data_len;
  if (src->data_len > 0U) {
    memcpy(frame->data, src->data, src->data_len);
  }

  __DMB(); /* slot fully consumed before the producer may reuse it */
  rx_q_tail = (uint8_t)((tail + 1U) % CLI_RX_QUEUE_DEPTH);
  return true;
}

uint32_t CLI_Frame_GetDropCount(void) { return rx_drop_count; }

HAL_StatusTypeDef CLI_Frame_Send(uint8_t cmd, const uint8_t *data,
                                 uint16_t len) {
  if (len > CLI_MAX_DATA_LENGTH)
    return HAL_ERROR;

  static uint8_t tx_buf[CLI_MAX_FRAME_LENGTH];
  uint16_t total_len = CLI_FRAME_OVERHEAD + len;
  uint16_t idx = 0;

  /* Header */
  tx_buf[idx++] = CLI_HEADER_BYTE_1;
  tx_buf[idx++] = CLI_HEADER_BYTE_2;

  /* Length (little-endian) */
  tx_buf[idx++] = (uint8_t)(total_len & 0xFF);
  tx_buf[idx++] = (uint8_t)((total_len >> 8) & 0xFF);

  /* Command */
  tx_buf[idx++] = cmd;

  /* Data */
  if (data != NULL && len > 0) {
    memcpy(&tx_buf[idx], data, len);
    idx += len;
  }

  /* Checksum: sum of bytes from index 2 to (idx - 1) inclusive */
  uint8_t checksum = 0;
  for (uint16_t i = 2; i < idx; i++) {
    checksum += tx_buf[i];
  }
  tx_buf[idx++] = checksum;

  /* End bytes */
  tx_buf[idx++] = CLI_END_BYTE_1;
  tx_buf[idx++] = CLI_END_BYTE_2;

  return HAL_UART_Transmit(cli_huart, tx_buf, idx, 100);
}

/**
 * @brief  Retained for source compatibility only.
 *
 * USART2 RX is no longer serviced through HAL_UART_Receive_IT(), so the HAL
 * RX-complete callback never fires for it. Left as a no-op so the existing
 * call in HAL_UART_RxCpltCallback() (stm32g4xx_it.c) still links.
 */
void CLI_Frame_RxCallback(UART_HandleTypeDef *huart) { (void)huart; }

/* Private functions ---------------------------------------------------------*/

static void CLI_ResetState(void) {
  rx_state = CLI_STATE_WAIT_HEADER1;
  rx_idx = 0;
  rx_expected_len = 0;
  rx_checksum = 0;
}

/**
 * @brief  Byte-at-a-time frame decoder. Logic is unchanged from the version
 *         that was driven off HAL_UART_RxCpltCallback(); only the byte source
 *         and the reject counters are new.
 *
 * Frame: [0xAA][0x55][LEN_L][LEN_H][CMD][DATA...][CHECKSUM][0x0D][0x0A]
 *        LEN      = total frame length, little-endian
 *        CHECKSUM = sum(LEN_L .. last DATA byte) & 0xFF
 */
static void CLI_FeedByte(uint8_t rx_byte) {
  switch (rx_state) {
  case CLI_STATE_WAIT_HEADER1:
    if (rx_byte == CLI_HEADER_BYTE_1) {
      rx_buf[0] = rx_byte;
      rx_idx = 1;
      rx_state = CLI_STATE_WAIT_HEADER2;
    }
    break;

  case CLI_STATE_WAIT_HEADER2:
    if (rx_byte == CLI_HEADER_BYTE_2) {
      rx_buf[1] = rx_byte;
      rx_idx = 2;
      rx_state = CLI_STATE_WAIT_LEN_LOW;
    } else if (rx_byte == CLI_HEADER_BYTE_1) {
      rx_buf[0] = rx_byte;
      rx_idx = 1;
    } else {
      g_cliRxStats.rej_header++;
      CLI_ResetState();
    }
    break;

  case CLI_STATE_WAIT_LEN_LOW:
    rx_buf[rx_idx++] = rx_byte;
    rx_expected_len = rx_byte;
    rx_checksum = rx_byte;
    rx_state = CLI_STATE_WAIT_LEN_HIGH;
    break;

  case CLI_STATE_WAIT_LEN_HIGH:
    rx_buf[rx_idx++] = rx_byte;
    rx_expected_len |= ((uint16_t)rx_byte << 8);
    rx_checksum += rx_byte;

    if (rx_expected_len < CLI_MIN_FRAME_LENGTH ||
        rx_expected_len > CLI_MAX_FRAME_LENGTH) {
      g_cliRxStats.rej_len++;
      CLI_ResetState();
    } else {
      rx_state = CLI_STATE_RECV_PAYLOAD;
    }
    break;

  case CLI_STATE_RECV_PAYLOAD:
    rx_buf[rx_idx++] = rx_byte;

    if (rx_idx < (rx_expected_len - 2)) {
      if (rx_idx <= (rx_expected_len - 3)) {
        rx_checksum += rx_byte;
      }
    }

    if (rx_idx >= (rx_expected_len - 2)) {
      uint8_t received_checksum = rx_buf[rx_idx - 1];
      rx_checksum &= 0xFF;

      if (rx_checksum != received_checksum) {
        g_cliRxStats.rej_checksum++;
        g_cliRxStats.last_bad_cmd = rx_buf[4];
        g_cliRxStats.last_ck_expected = rx_checksum;
        g_cliRxStats.last_ck_received = received_checksum;
        CLI_ResetState();
      } else {
        rx_state = CLI_STATE_WAIT_END1;
      }
    }
    break;

  case CLI_STATE_WAIT_END1:
    if (rx_byte == CLI_END_BYTE_1) {
      rx_buf[rx_idx++] = rx_byte;
      rx_state = CLI_STATE_WAIT_END2;
    } else {
      g_cliRxStats.rej_end++;
      CLI_ResetState();
    }
    break;

  case CLI_STATE_WAIT_END2:
    if (rx_byte == CLI_END_BYTE_1) {
      /* Tolerate an extra 0x0D (some hosts translate line endings). */
      break;
    }
    if (rx_byte == CLI_END_BYTE_2) {
      rx_buf[rx_idx++] = rx_byte;

      uint8_t next = (uint8_t)((rx_q_head + 1U) % CLI_RX_QUEUE_DEPTH);

      if (next == rx_q_tail) {
        /* Queue full — count it so the loss is visible instead of silent. */
        if (rx_drop_count < UINT32_MAX) {
          rx_drop_count++;
        }
        g_cliRxStats.queue_drops++;
      } else {
        CLI_Frame_t *slot = &rx_queue[rx_q_head];
        slot->cmd = rx_buf[4];
        slot->data_len = rx_expected_len - CLI_FRAME_OVERHEAD;
        if (slot->data_len > 0U) {
          memcpy(slot->data, &rx_buf[5], slot->data_len);
        }
        __DMB(); /* slot contents visible before head advances */
        rx_q_head = next;
        g_cliRxStats.frames_ok++;
        g_cliRxStats.last_good_cmd = slot->cmd;
        g_cliRxStats.last_good_len = slot->data_len;
      }
    } else {
      g_cliRxStats.rej_end++;
    }
    CLI_ResetState();
    break;

  default:
    CLI_ResetState();
    break;
  }
}
