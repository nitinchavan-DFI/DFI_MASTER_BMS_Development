/**
 * @file    w25q64.c
 * @brief   W25Q64FVSSIG QSPI NOR Flash Driver Implementation
 *
 * Full driver for the Winbond W25Q64FV connected via the STM32 QUADSPI
 * peripheral.  Supports standard SPI reads, Quad-Output fast reads,
 * page programming, sector / block / chip erase, and power management.
 */

/* Includes ----------------------------------------------------------------- */
#include "w25q64.h"

/* ========================================================================== */
/*                       Internal Helpers */
/* ========================================================================== */

/**
 * @brief  Send a command-only QSPI instruction (no address, no data).
 */
static W25Q64_StatusTypeDef W25Q64_SendCommand(QSPI_HandleTypeDef *hqspi,
                                               uint32_t instruction) {
  QSPI_CommandTypeDef cmd = {0};

  cmd.InstructionMode = QSPI_INSTRUCTION_1_LINE;
  cmd.Instruction = instruction;
  cmd.AddressMode = QSPI_ADDRESS_NONE;
  cmd.AlternateByteMode = QSPI_ALTERNATE_BYTES_NONE;
  cmd.DataMode = QSPI_DATA_NONE;
  cmd.DummyCycles = 0;
  cmd.DdrMode = QSPI_DDR_MODE_DISABLE;
  cmd.DdrHoldHalfCycle = QSPI_DDR_HHC_ANALOG_DELAY;
  cmd.SIOOMode = QSPI_SIOO_INST_EVERY_CMD;

  if (HAL_QSPI_Command(hqspi, &cmd, W25Q64_TIMEOUT_DEFAULT) != HAL_OK) {
    return W25Q64_ERROR;
  }
  return W25Q64_OK;
}

/**
 * @brief  Issue Write Enable (WREN) command.
 */
static W25Q64_StatusTypeDef W25Q64_WriteEnable(QSPI_HandleTypeDef *hqspi) {
  if (W25Q64_SendCommand(hqspi, W25Q64_CMD_WRITE_ENABLE) != W25Q64_OK) {
    return W25Q64_ERROR;
  }

  /* Auto-poll until WEL bit is set */
  QSPI_AutoPollingTypeDef poll = {0};
  QSPI_CommandTypeDef cmd = {0};

  cmd.InstructionMode = QSPI_INSTRUCTION_1_LINE;
  cmd.Instruction = W25Q64_CMD_READ_SR1;
  cmd.AddressMode = QSPI_ADDRESS_NONE;
  cmd.AlternateByteMode = QSPI_ALTERNATE_BYTES_NONE;
  cmd.DataMode = QSPI_DATA_1_LINE;
  cmd.DummyCycles = 0;
  cmd.NbData = 1;
  cmd.DdrMode = QSPI_DDR_MODE_DISABLE;
  cmd.DdrHoldHalfCycle = QSPI_DDR_HHC_ANALOG_DELAY;
  cmd.SIOOMode = QSPI_SIOO_INST_EVERY_CMD;

  poll.Match = W25Q64_SR1_WEL;
  poll.Mask = W25Q64_SR1_WEL;
  poll.MatchMode = QSPI_MATCH_MODE_AND;
  poll.StatusBytesSize = 1;
  poll.Interval = 0x10;
  poll.AutomaticStop = QSPI_AUTOMATIC_STOP_ENABLE;

  if (HAL_QSPI_AutoPolling(hqspi, &cmd, &poll, W25Q64_TIMEOUT_DEFAULT) !=
      HAL_OK) {
    return W25Q64_ERROR;
  }
  return W25Q64_OK;
}

/**
 * @brief  Read a single status register byte.
 * @param  reg_cmd  One of W25Q64_CMD_READ_SR1 / SR2 / SR3.
 * @param  pReg     Pointer to receive the register value.
 */
static W25Q64_StatusTypeDef W25Q64_ReadStatusReg(QSPI_HandleTypeDef *hqspi,
                                                 uint32_t reg_cmd,
                                                 uint8_t *pReg) {
  QSPI_CommandTypeDef cmd = {0};

  cmd.InstructionMode = QSPI_INSTRUCTION_1_LINE;
  cmd.Instruction = reg_cmd;
  cmd.AddressMode = QSPI_ADDRESS_NONE;
  cmd.AlternateByteMode = QSPI_ALTERNATE_BYTES_NONE;
  cmd.DataMode = QSPI_DATA_1_LINE;
  cmd.DummyCycles = 0;
  cmd.NbData = 1;
  cmd.DdrMode = QSPI_DDR_MODE_DISABLE;
  cmd.DdrHoldHalfCycle = QSPI_DDR_HHC_ANALOG_DELAY;
  cmd.SIOOMode = QSPI_SIOO_INST_EVERY_CMD;

  if (HAL_QSPI_Command(hqspi, &cmd, W25Q64_TIMEOUT_DEFAULT) != HAL_OK) {
    return W25Q64_ERROR;
  }
  if (HAL_QSPI_Receive(hqspi, pReg, W25Q64_TIMEOUT_DEFAULT) != HAL_OK) {
    return W25Q64_ERROR;
  }
  return W25Q64_OK;
}

/**
 * @brief  Write a single status register byte.
 * @param  reg_cmd  One of W25Q64_CMD_WRITE_SR1 / SR2 / SR3.
 * @param  value    The byte value to write.
 */
static W25Q64_StatusTypeDef W25Q64_WriteStatusReg(QSPI_HandleTypeDef *hqspi,
                                                  uint32_t reg_cmd,
                                                  uint8_t value) {
  if (W25Q64_WriteEnable(hqspi) != W25Q64_OK) {
    return W25Q64_ERROR;
  }

  QSPI_CommandTypeDef cmd = {0};

  cmd.InstructionMode = QSPI_INSTRUCTION_1_LINE;
  cmd.Instruction = reg_cmd;
  cmd.AddressMode = QSPI_ADDRESS_NONE;
  cmd.AlternateByteMode = QSPI_ALTERNATE_BYTES_NONE;
  cmd.DataMode = QSPI_DATA_1_LINE;
  cmd.DummyCycles = 0;
  cmd.NbData = 1;
  cmd.DdrMode = QSPI_DDR_MODE_DISABLE;
  cmd.DdrHoldHalfCycle = QSPI_DDR_HHC_ANALOG_DELAY;
  cmd.SIOOMode = QSPI_SIOO_INST_EVERY_CMD;

  if (HAL_QSPI_Command(hqspi, &cmd, W25Q64_TIMEOUT_DEFAULT) != HAL_OK) {
    return W25Q64_ERROR;
  }
  if (HAL_QSPI_Transmit(hqspi, &value, W25Q64_TIMEOUT_DEFAULT) != HAL_OK) {
    return W25Q64_ERROR;
  }

  /* Wait for the write to complete */
  return W25Q64_WaitForReady(hqspi, W25Q64_TIMEOUT_DEFAULT);
}

/**
 * @brief  Perform a software reset (Enable Reset + Reset Device).
 */
static W25Q64_StatusTypeDef W25Q64_Reset(QSPI_HandleTypeDef *hqspi) {
  if (W25Q64_SendCommand(hqspi, W25Q64_CMD_ENABLE_RESET) != W25Q64_OK) {
    return W25Q64_ERROR;
  }
  if (W25Q64_SendCommand(hqspi, W25Q64_CMD_RESET_DEVICE) != W25Q64_OK) {
    return W25Q64_ERROR;
  }
  /* tRST = 30 µs typical.  Use HAL_Delay(1) for safety. */
  HAL_Delay(1);
  return W25Q64_OK;
}

/**
 * @brief  Enable Quad SPI mode by setting the QE bit in Status Register 2.
 *         If QE is already set this is a no-op.
 */
static W25Q64_StatusTypeDef W25Q64_EnableQuad(QSPI_HandleTypeDef *hqspi) {
  uint8_t sr2 = 0;
  if (W25Q64_ReadStatusReg(hqspi, W25Q64_CMD_READ_SR2, &sr2) != W25Q64_OK) {
    return W25Q64_ERROR;
  }
  if ((sr2 & W25Q64_SR2_QE) != 0) {
    return W25Q64_OK; /* Already enabled */
  }
  sr2 |= W25Q64_SR2_QE;
  return W25Q64_WriteStatusReg(hqspi, W25Q64_CMD_WRITE_SR2, sr2);
}

/* ========================================================================== */
/*                     Auto-Poll for BUSY == 0 */
/* ========================================================================== */

/**
 * @brief  Use QSPI hardware auto-polling to wait until the BUSY bit clears.
 */
static W25Q64_StatusTypeDef W25Q64_AutoPollReady(QSPI_HandleTypeDef *hqspi,
                                                 uint32_t timeout_ms) {
  QSPI_CommandTypeDef cmd = {0};
  QSPI_AutoPollingTypeDef poll = {0};

  cmd.InstructionMode = QSPI_INSTRUCTION_1_LINE;
  cmd.Instruction = W25Q64_CMD_READ_SR1;
  cmd.AddressMode = QSPI_ADDRESS_NONE;
  cmd.AlternateByteMode = QSPI_ALTERNATE_BYTES_NONE;
  cmd.DataMode = QSPI_DATA_1_LINE;
  cmd.DummyCycles = 0;
  cmd.NbData = 1;
  cmd.DdrMode = QSPI_DDR_MODE_DISABLE;
  cmd.DdrHoldHalfCycle = QSPI_DDR_HHC_ANALOG_DELAY;
  cmd.SIOOMode = QSPI_SIOO_INST_EVERY_CMD;

  poll.Match = 0x00U; /* BUSY = 0 */
  poll.Mask = W25Q64_SR1_BUSY;
  poll.MatchMode = QSPI_MATCH_MODE_AND;
  poll.StatusBytesSize = 1;
  poll.Interval = 0x10;
  poll.AutomaticStop = QSPI_AUTOMATIC_STOP_ENABLE;

  if (HAL_QSPI_AutoPolling(hqspi, &cmd, &poll, timeout_ms) != HAL_OK) {
    return W25Q64_TIMEOUT;
  }
  return W25Q64_OK;
}

/* ========================================================================== */
/*                          Public API */
/* ========================================================================== */

/* ----- Initialisation ----------------------------------------------------- */

W25Q64_StatusTypeDef W25Q64_Init(QSPI_HandleTypeDef *hqspi) {
  /* 1. Software reset */
  if (W25Q64_Reset(hqspi) != W25Q64_OK) {
    return W25Q64_ERROR;
  }

  /* 2. Verify JEDEC ID */
  uint32_t id = 0;
  if (W25Q64_ReadID(hqspi, &id) != W25Q64_OK) {
    return W25Q64_ERROR;
  }
  uint8_t mfr = (uint8_t)(id >> 16);
  uint16_t dev_id = (uint16_t)(id & 0xFFFFU);
  if (mfr != W25Q64_MANUFACTURER_ID || dev_id != W25Q64_DEVICE_ID) {
    return W25Q64_ERROR; /* Unexpected chip */
  }

  /* 3. Enable Quad mode */
  if (W25Q64_EnableQuad(hqspi) != W25Q64_OK) {
    return W25Q64_ERROR;
  }

  return W25Q64_OK;
}

/* ----- Identification ----------------------------------------------------- */

W25Q64_StatusTypeDef W25Q64_ReadID(QSPI_HandleTypeDef *hqspi, uint32_t *pID) {
  QSPI_CommandTypeDef cmd = {0};
  uint8_t buf[3] = {0};

  cmd.InstructionMode = QSPI_INSTRUCTION_1_LINE;
  cmd.Instruction = W25Q64_CMD_JEDEC_ID;
  cmd.AddressMode = QSPI_ADDRESS_NONE;
  cmd.AlternateByteMode = QSPI_ALTERNATE_BYTES_NONE;
  cmd.DataMode = QSPI_DATA_1_LINE;
  cmd.DummyCycles = 0;
  cmd.NbData = 3;
  cmd.DdrMode = QSPI_DDR_MODE_DISABLE;
  cmd.DdrHoldHalfCycle = QSPI_DDR_HHC_ANALOG_DELAY;
  cmd.SIOOMode = QSPI_SIOO_INST_EVERY_CMD;

  if (HAL_QSPI_Command(hqspi, &cmd, W25Q64_TIMEOUT_DEFAULT) != HAL_OK) {
    return W25Q64_ERROR;
  }
  if (HAL_QSPI_Receive(hqspi, buf, W25Q64_TIMEOUT_DEFAULT) != HAL_OK) {
    return W25Q64_ERROR;
  }

  *pID =
      ((uint32_t)buf[0] << 16) | ((uint32_t)buf[1] << 8) | ((uint32_t)buf[2]);
  return W25Q64_OK;
}

/* ----- Read --------------------------------------------------------------- */

W25Q64_StatusTypeDef W25Q64_Read(QSPI_HandleTypeDef *hqspi, uint8_t *pData,
                                 uint32_t address, uint32_t size) {
  QSPI_CommandTypeDef cmd = {0};

  cmd.InstructionMode = QSPI_INSTRUCTION_1_LINE;
  cmd.Instruction = W25Q64_CMD_READ;
  cmd.AddressMode = QSPI_ADDRESS_1_LINE;
  cmd.AddressSize = QSPI_ADDRESS_24_BITS;
  cmd.Address = address;
  cmd.AlternateByteMode = QSPI_ALTERNATE_BYTES_NONE;
  cmd.DataMode = QSPI_DATA_1_LINE;
  cmd.DummyCycles = 0;
  cmd.NbData = size;
  cmd.DdrMode = QSPI_DDR_MODE_DISABLE;
  cmd.DdrHoldHalfCycle = QSPI_DDR_HHC_ANALOG_DELAY;
  cmd.SIOOMode = QSPI_SIOO_INST_EVERY_CMD;

  if (HAL_QSPI_Command(hqspi, &cmd, W25Q64_TIMEOUT_DEFAULT) != HAL_OK) {
    return W25Q64_ERROR;
  }
  if (HAL_QSPI_Receive(hqspi, pData, W25Q64_TIMEOUT_DEFAULT) != HAL_OK) {
    return W25Q64_ERROR;
  }
  return W25Q64_OK;
}

W25Q64_StatusTypeDef W25Q64_FastReadQuad(QSPI_HandleTypeDef *hqspi,
                                         uint8_t *pData, uint32_t address,
                                         uint32_t size) {
  QSPI_CommandTypeDef cmd = {0};

  cmd.InstructionMode = QSPI_INSTRUCTION_1_LINE;
  cmd.Instruction = W25Q64_CMD_FAST_READ_QUAD_OUT;
  cmd.AddressMode = QSPI_ADDRESS_1_LINE;
  cmd.AddressSize = QSPI_ADDRESS_24_BITS;
  cmd.Address = address;
  cmd.AlternateByteMode = QSPI_ALTERNATE_BYTES_NONE;
  cmd.DataMode = QSPI_DATA_4_LINES;
  cmd.DummyCycles = 8; /* 8 dummy clocks for Quad Output Fast Read */
  cmd.NbData = size;
  cmd.DdrMode = QSPI_DDR_MODE_DISABLE;
  cmd.DdrHoldHalfCycle = QSPI_DDR_HHC_ANALOG_DELAY;
  cmd.SIOOMode = QSPI_SIOO_INST_EVERY_CMD;

  if (HAL_QSPI_Command(hqspi, &cmd, W25Q64_TIMEOUT_DEFAULT) != HAL_OK) {
    return W25Q64_ERROR;
  }
  if (HAL_QSPI_Receive(hqspi, pData, W25Q64_TIMEOUT_DEFAULT) != HAL_OK) {
    return W25Q64_ERROR;
  }
  return W25Q64_OK;
}

/* ----- Write -------------------------------------------------------------- */

W25Q64_StatusTypeDef W25Q64_WritePage(QSPI_HandleTypeDef *hqspi,
                                      const uint8_t *pData, uint32_t address,
                                      uint32_t size) {
  if (size == 0 || size > W25Q64_PAGE_SIZE) {
    return W25Q64_ERROR;
  }

  /* Write Enable */
  if (W25Q64_WriteEnable(hqspi) != W25Q64_OK) {
    return W25Q64_ERROR;
  }

  QSPI_CommandTypeDef cmd = {0};

  cmd.InstructionMode = QSPI_INSTRUCTION_1_LINE;
  cmd.Instruction = W25Q64_CMD_PAGE_PROGRAM;
  cmd.AddressMode = QSPI_ADDRESS_1_LINE;
  cmd.AddressSize = QSPI_ADDRESS_24_BITS;
  cmd.Address = address;
  cmd.AlternateByteMode = QSPI_ALTERNATE_BYTES_NONE;
  cmd.DataMode = QSPI_DATA_1_LINE;
  cmd.DummyCycles = 0;
  cmd.NbData = size;
  cmd.DdrMode = QSPI_DDR_MODE_DISABLE;
  cmd.DdrHoldHalfCycle = QSPI_DDR_HHC_ANALOG_DELAY;
  cmd.SIOOMode = QSPI_SIOO_INST_EVERY_CMD;

  if (HAL_QSPI_Command(hqspi, &cmd, W25Q64_TIMEOUT_DEFAULT) != HAL_OK) {
    return W25Q64_ERROR;
  }
  if (HAL_QSPI_Transmit(hqspi, (uint8_t *)pData, W25Q64_TIMEOUT_DEFAULT) !=
      HAL_OK) {
    return W25Q64_ERROR;
  }

  /* Wait for the page program to complete */
  return W25Q64_AutoPollReady(hqspi, W25Q64_TIMEOUT_PAGE_PROGRAM);
}

W25Q64_StatusTypeDef W25Q64_Write(QSPI_HandleTypeDef *hqspi,
                                  const uint8_t *pData, uint32_t address,
                                  uint32_t size) {
  uint32_t remaining = size;
  uint32_t addr = address;
  const uint8_t *src = pData;

  while (remaining > 0) {
    /* Bytes left in the current page */
    uint32_t page_offset = addr % W25Q64_PAGE_SIZE;
    uint32_t page_remaining = W25Q64_PAGE_SIZE - page_offset;
    uint32_t chunk = (remaining < page_remaining) ? remaining : page_remaining;

    W25Q64_StatusTypeDef status = W25Q64_WritePage(hqspi, src, addr, chunk);
    if (status != W25Q64_OK) {
      return status;
    }

    addr += chunk;
    src += chunk;
    remaining -= chunk;
  }
  return W25Q64_OK;
}

/* ----- Erase -------------------------------------------------------------- */

/**
 * @brief  Generic erase helper: write-enable → erase command → wait.
 */
static W25Q64_StatusTypeDef W25Q64_EraseSendCommand(QSPI_HandleTypeDef *hqspi,
                                                     uint32_t instruction,
                                                     uint32_t address) {
  if (W25Q64_WriteEnable(hqspi) != W25Q64_OK) {
    return W25Q64_ERROR;
  }

  QSPI_CommandTypeDef cmd = {0};

  cmd.InstructionMode = QSPI_INSTRUCTION_1_LINE;
  cmd.Instruction = instruction;
  cmd.AddressMode = QSPI_ADDRESS_1_LINE;
  cmd.AddressSize = QSPI_ADDRESS_24_BITS;
  cmd.Address = address;
  cmd.AlternateByteMode = QSPI_ALTERNATE_BYTES_NONE;
  cmd.DataMode = QSPI_DATA_NONE;
  cmd.DummyCycles = 0;
  cmd.DdrMode = QSPI_DDR_MODE_DISABLE;
  cmd.DdrHoldHalfCycle = QSPI_DDR_HHC_ANALOG_DELAY;
  cmd.SIOOMode = QSPI_SIOO_INST_EVERY_CMD;

  if (HAL_QSPI_Command(hqspi, &cmd, W25Q64_TIMEOUT_DEFAULT) != HAL_OK) {
    return W25Q64_ERROR;
  }
  return W25Q64_OK;
}

static W25Q64_StatusTypeDef W25Q64_EraseGeneric(QSPI_HandleTypeDef *hqspi,
                                                uint32_t instruction,
                                                uint32_t address,
                                                uint32_t timeout_ms) {
  if (W25Q64_EraseSendCommand(hqspi, instruction, address) != W25Q64_OK) {
    return W25Q64_ERROR;
  }
  return W25Q64_AutoPollReady(hqspi, timeout_ms);
}

W25Q64_StatusTypeDef W25Q64_EraseSectorStart(QSPI_HandleTypeDef *hqspi,
                                             uint32_t address) {
  /* Same command as W25Q64_EraseSector(), just without the trailing
   * AutoPollReady() block -- the erase runs autonomously on-chip after
   * this returns. Caller polls W25Q64_IsBusy(). */
  return W25Q64_EraseSendCommand(hqspi, W25Q64_CMD_SECTOR_ERASE, address);
}

W25Q64_StatusTypeDef W25Q64_EraseSector(QSPI_HandleTypeDef *hqspi,
                                        uint32_t address) {
  return W25Q64_EraseGeneric(hqspi, W25Q64_CMD_SECTOR_ERASE, address,
                             W25Q64_TIMEOUT_SECTOR_ERASE);
}

W25Q64_StatusTypeDef W25Q64_EraseBlock32(QSPI_HandleTypeDef *hqspi,
                                         uint32_t address) {
  return W25Q64_EraseGeneric(hqspi, W25Q64_CMD_BLOCK_ERASE_32K, address,
                             W25Q64_TIMEOUT_BLOCK_ERASE);
}

W25Q64_StatusTypeDef W25Q64_EraseBlock64(QSPI_HandleTypeDef *hqspi,
                                         uint32_t address) {
  return W25Q64_EraseGeneric(hqspi, W25Q64_CMD_BLOCK_ERASE_64K, address,
                             W25Q64_TIMEOUT_BLOCK_ERASE);
}

W25Q64_StatusTypeDef W25Q64_EraseChip(QSPI_HandleTypeDef *hqspi) {
  if (W25Q64_WriteEnable(hqspi) != W25Q64_OK) {
    return W25Q64_ERROR;
  }
  if (W25Q64_SendCommand(hqspi, W25Q64_CMD_CHIP_ERASE) != W25Q64_OK) {
    return W25Q64_ERROR;
  }
  return W25Q64_AutoPollReady(hqspi, W25Q64_TIMEOUT_CHIP_ERASE);
}

/* ----- Status ------------------------------------------------------------- */

bool W25Q64_IsBusy(QSPI_HandleTypeDef *hqspi) {
  uint8_t sr1 = 0;
  if (W25Q64_ReadStatusReg(hqspi, W25Q64_CMD_READ_SR1, &sr1) != W25Q64_OK) {
    return true; /* Assume busy on read failure */
  }
  return (sr1 & W25Q64_SR1_BUSY) != 0;
}

W25Q64_StatusTypeDef W25Q64_WaitForReady(QSPI_HandleTypeDef *hqspi,
                                         uint32_t timeout_ms) {
  return W25Q64_AutoPollReady(hqspi, timeout_ms);
}

/* ----- Power Management --------------------------------------------------- */

W25Q64_StatusTypeDef W25Q64_PowerDown(QSPI_HandleTypeDef *hqspi) {
  return W25Q64_SendCommand(hqspi, W25Q64_CMD_POWER_DOWN);
}

W25Q64_StatusTypeDef W25Q64_ReleasePowerDown(QSPI_HandleTypeDef *hqspi) {
  W25Q64_StatusTypeDef status =
      W25Q64_SendCommand(hqspi, W25Q64_CMD_RELEASE_POWER_DOWN);
  if (status != W25Q64_OK) {
    return status;
  }
  /* tRES1 = 3 µs min. Use HAL_Delay(1) for safety. */
  HAL_Delay(1);
  return W25Q64_OK;
}
