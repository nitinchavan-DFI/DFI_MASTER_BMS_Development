/**
  ******************************************************************************
  * @file    power_manager_port.c
  * @brief   Board port layer for the deep-sleep subsystem, DFI Mosaic BMS.
  *
  * All board knowledge lives here. power_manager.c contains none.
  * Every pin, handle and API name below was checked against this tree.
  ******************************************************************************
  */

#include "power_manager_port.h"
#include "power_manager_conf.h"

#include "stm32g4xx_hal.h"

#include "current_sensor.h"
#include "daly_bms.h"
#include "led_status.h"
#include "w25q64.h"
#include "fdcan.h"
#include "cli_frame.h"
#include <string.h>

/* ---- Handles owned by main.c -------------------------------------------- */
extern ADC_HandleTypeDef   hadc1;
extern ADC_HandleTypeDef   hadc2;
extern QSPI_HandleTypeDef  hqspi1;
extern TIM_HandleTypeDef   htim1;
extern TIM_HandleTypeDef   htim5;
extern TIM_HandleTypeDef   htim6;
extern TIM_HandleTypeDef   htim15;
extern UART_HandleTypeDef  huart2;
extern UART_HandleTypeDef  huart5;
extern DalyBMS_Handle_t    hDaly;
/* hfdcan1 is declared extern by fdcan.h */
#if (PM_IWDG_ENABLED == 1)
extern IWDG_HandleTypeDef  hiwdg;
#endif

/* main.c owns the clock tree; re-entered after every Stop exit. */
extern void SystemClock_Config(void);

/* ==========================================================================
 * Compile-time sanity
 * ==========================================================================
 * The single most dangerous misconfiguration in this module is an RTC tick
 * longer than the IWDG period: the board would appear to "reset randomly in
 * deep sleep" and the cause is invisible without a scope on NRST. Catch it at
 * build time instead. 1.024 accounts for the LSI/prediv stretch documented in
 * power_manager_conf.h section 8.
 * ========================================================================== */
#if ((PM_TICK_SECONDS * 1024U) >= PM_IWDG_PERIOD_MS)
#error "PM_TICK_SECONDS exceeds the IWDG period -- the MCU will reset in deep sleep."
#endif

/* PM_UV_CLEAR_V > PM_UV_NEAR_V is checked below, not here: both are float
 * expressions, and the C preprocessor only evaluates integer constant
 * expressions in #if -- a float comparison in #if is a hard compile error,
 * not a warning. _Static_assert runs after the compiler has parsed the
 * constants, which is why it works where #if cannot. */

#if (PM_HIBERNATE_USE_STOP1 == 0)
#warning "Hibernate is configured for Standby, but wakeButton (PB9) is not a PWR WKUP pin."
#endif

/* Staleness limit on the Daly link. Historically the Daly stalling was what
 * froze pack_voltage and latched faults permanently, so a stale reading must
 * be reported as "no information" rather than passed off as a measurement. */
#define PM_DALY_MAX_AGE_MS      (5000U)
#define PM_PACK_V_MIN_PLAUSIBLE (5.0f)
#define PM_PACK_V_MAX_PLAUSIBLE (80.0f)

_Static_assert((PM_UV_CLEAR_V > PM_UV_NEAR_V),
               "PM_UV_CLEAR_V must be above PM_UV_NEAR_V or the UV ladder will chatter.");
_Static_assert((PM_UV_NEAR_V > PM_UV_TRIP_V) || (PM_UV_NEAR_MARGIN_V < 0.0f),
               "PM_UV_NEAR_V collapsed onto PM_UV_TRIP_V -- check the margin sign.");

static bool pm_gpio_parked = false;

/* ==========================================================================
 * Rails
 * ==========================================================================
 * All three are absent on the current board (see conf section 5b). The bodies
 * compile away to nothing so the firmware is correct as-is; it simply cannot
 * reach the microamp target until the load switches are fitted.
 * ========================================================================== */
void PMP_SenseRail(bool on)
{
#if (PM_HAS_SENSE_RAIL == 1)
    HAL_GPIO_WritePin(PM_SENSE_EN_PORT, PM_SENSE_EN_PIN,
                      on ? PM_SENSE_EN_ON_LEVEL
                         : ((PM_SENSE_EN_ON_LEVEL == GPIO_PIN_SET) ? GPIO_PIN_RESET
                                                                   : GPIO_PIN_SET));
#else
    (void)on;   /* ACS37610 is hard-powered: ~10 mA, always. */
#endif
}

void PMP_VDivRail(bool on)
{
#if (PM_HAS_VDIV_RAIL == 1)
    HAL_GPIO_WritePin(PM_VDIV_EN_PORT, PM_VDIV_EN_PIN,
                      on ? PM_VDIV_EN_ON_LEVEL
                         : ((PM_VDIV_EN_ON_LEVEL == GPIO_PIN_SET) ? GPIO_PIN_RESET
                                                                  : GPIO_PIN_SET));
#else
    (void)on;   /* No MCU-side pack divider on this board. */
#endif
}

void PMP_DalyRail(bool on)
{
#if (PM_HAS_DALY_RAIL == 1)
    HAL_GPIO_WritePin(PM_DALY_EN_PORT, PM_DALY_EN_PIN,
                      on ? PM_DALY_EN_ON_LEVEL
                         : ((PM_DALY_EN_ON_LEVEL == GPIO_PIN_SET) ? GPIO_PIN_RESET
                                                                  : GPIO_PIN_SET));
#else
    (void)on;
#endif
}

void PMP_AllRailsOff(void)
{
    PMP_SenseRail(false);
    PMP_VDivRail(false);
    PMP_DalyRail(false);
}

void PMP_AllRailsOn(void)
{
    PMP_DalyRail(true);
    PMP_VDivRail(true);
    PMP_SenseRail(true);
}

/* ==========================================================================
 * CAN transceiver and the RX-pin-as-EXTI trick
 * ========================================================================== */
void PMP_CanEnterSleep(void)
{
    GPIO_InitTypeDef g = {0};

    /* Stop the peripheral first: FDCAN cannot receive in Stop anyway, and
     * leaving it clocked keeps its domain alive. */
    (void)HAL_FDCAN_Stop(&hfdcan1);

    /* Transceiver to standby. The receiver stays biased so a dominant bit on
     * the bus still pulls RXD low, which is what we EXTI on. */
    HAL_GPIO_WritePin(PM_CAN_EN_PORT,  PM_CAN_EN_PIN,  PM_CAN_EN_SLEEP_LEVEL);
    HAL_GPIO_WritePin(PM_CAN_STB_PORT, PM_CAN_STB_PIN, PM_CAN_STB_STANDBY_LEVEL);

    /* PA11: AF9 -> EXTI falling. Recessive idles high, dominant pulls low. */
    g.Pin  = PM_CAN_RX_PIN;
    g.Mode = GPIO_MODE_IT_FALLING;
    g.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(PM_CAN_RX_PORT, &g);

    __HAL_GPIO_EXTI_CLEAR_IT(PM_CAN_RX_PIN);
    HAL_NVIC_ClearPendingIRQ(PM_CAN_RX_EXTI_IRQn);
    HAL_NVIC_SetPriority(PM_CAN_RX_EXTI_IRQn, 1, 0);
    HAL_NVIC_EnableIRQ(PM_CAN_RX_EXTI_IRQn);
}

void PMP_CanExitSleep(void)
{
    GPIO_InitTypeDef g = {0};

    HAL_NVIC_DisableIRQ(PM_CAN_RX_EXTI_IRQn);
    __HAL_GPIO_EXTI_CLEAR_IT(PM_CAN_RX_PIN);

    /* PA11 back to FDCAN1_RX. */
    g.Pin       = PM_CAN_RX_PIN;
    g.Mode      = GPIO_MODE_AF_PP;
    g.Pull      = GPIO_NOPULL;
    g.Speed     = GPIO_SPEED_FREQ_VERY_HIGH;
    g.Alternate = PM_CAN_RX_AF;
    HAL_GPIO_Init(PM_CAN_RX_PORT, &g);

    HAL_GPIO_WritePin(PM_CAN_STB_PORT, PM_CAN_STB_PIN, PM_CAN_STB_NORMAL_LEVEL);
    HAL_GPIO_WritePin(PM_CAN_EN_PORT,  PM_CAN_EN_PIN,  PM_CAN_EN_NORMAL_LEVEL);

    /* TJA104x t_wake is a few tens of microseconds; 1 ms is generous and only
     * costs once per wake. */
    HAL_Delay(1U);

    /* Re-apply the hardware acceptance filters and restart. Using the existing
     * helper rather than a bare HAL_FDCAN_Start keeps the filter table and the
     * bit timing in one place -- the 170 MHz kernel-clock timing is only
     * correct because PMP_RestoreClocks ran first. */
    MX_FDCAN1_Init();
    FDCAN1_ConfigFiltersAndStart();
}

bool PMP_CanBusIsDominant(void)
{
    /* Called before arming the EXTI. Entering Stop while the bus is already
     * dominant produces an immediate wake and a spin loop that never sleeps. */
    return (HAL_GPIO_ReadPin(PM_CAN_RX_PORT, PM_CAN_RX_PIN) == GPIO_PIN_RESET);
}

/* ==========================================================================
 * External flash
 * ========================================================================== */
void PMP_FlashEnterDeepPowerDown(void)
{
#if (PM_FLASH_DEEP_POWER_DOWN == 1)
    (void)W25Q64_PowerDown(&hqspi1);
#endif
}

void PMP_FlashExitDeepPowerDown(void)
{
#if (PM_FLASH_DEEP_POWER_DOWN == 1)
    (void)W25Q64_ReleasePowerDown(&hqspi1);
    /* tRES1 is ~3 us on the W25Q64; 1 ms covers it with margin. Skipping this
     * makes the first read after a wake return garbage. */
    HAL_Delay(1U);
#endif
}

/* ==========================================================================
 * Measurement
 * ========================================================================== */
bool PMP_MeasurePackVoltage(float *volts)
{
    float v;
    uint32_t age;

    if (volts == NULL)
    {
        return false;
    }
    *volts = 0.0f;

    /* There is no MCU-side pack divider on this board, so pack voltage comes
     * from the Daly slave over UART5. Two consequences for deep sleep:
     *   - the Daly must be awake, which is why PM_HAS_DALY_RAIL gating is a
     *     rework item rather than a free win;
     *   - a stalled link must NOT be read as a low voltage. Returning false
     *     here is load-bearing: the state machine treats false as "no
     *     information" and will not advance the ladder on it. */
    age = HAL_GetTick() - hDaly.lastUpdateTick;
    if (age > PM_DALY_MAX_AGE_MS)
    {
        return false;
    }

    v = hDaly.data.packVoltage;
    if ((v < PM_PACK_V_MIN_PLAUSIBLE) || (v > PM_PACK_V_MAX_PLAUSIBLE))
    {
        return false;
    }

    *volts = v;
    return true;
}

bool PMP_MeasureCurrent(float *amps)
{
    if (amps == NULL)
    {
        return false;
    }
    *amps = 0.0f;

    if (!CurrentSensor_IsReady())
    {
        return false;
    }

    *amps = CurrentSensor_GetCurrent_mA() / 1000.0f;
    return true;
}

/* Upper bound on one Daly poll transaction. The Daly answers 0x90 in well
 * under 100 ms at 9600 baud; 400 ms is generous and still far inside the
 * 4.002 s IWDG, which is kicked inside the loop regardless. */
#define PM_DALY_POLL_TIMEOUT_MS (400U)

bool PMP_SampleOnce(float *volts, float *amps)
{
    bool     v_ok = false;
    bool     i_ok;
    uint32_t t0;

    PMP_SenseRail(true);
    PMP_VDivRail(true);
    PMP_DalyRail(true);
    HAL_Delay(PM_SENSE_SETTLE_MS);

    /* Current first: it is an MCU-side ADC read and needs nothing but the
     * sensor rail settled. */
    i_ok = PMP_MeasureCurrent(amps);

    /* Pack voltage has to come off the Daly over UART5, and during deep sleep
     * nothing has been polling it -- the cached hDaly.data.packVoltage is by
     * definition stale. Reading the cache here is what would make the ladder
     * silently never advance, so run a real transaction and wait for it.
     *
     * DalyBMS_Process() is the same non-blocking pump the main loop uses, so
     * this reuses the driver's own framing, checksum and plausibility checks
     * rather than duplicating them. */
    DalyBMS_ClearDataReady(&hDaly);
    DalyBMS_StartUpdate(&hDaly);

    t0 = HAL_GetTick();
    while ((HAL_GetTick() - t0) < PM_DALY_POLL_TIMEOUT_MS)
    {
        DalyBMS_Process(&hDaly);
        PMP_WatchdogKick();

        if (DalyBMS_IsDataReady(&hDaly))
        {
            v_ok = PMP_MeasurePackVoltage(volts);
            break;
        }
    }

    if (!v_ok)
    {
        /* Timed out or implausible. The state machine treats this as "no
         * information" and will neither advance the ladder nor declare
         * recovery -- deliberate, and the reason the historical Daly stall
         * could latch faults forever is not reproduced here. */
        *volts = 0.0f;
    }

    PMP_DalyRail(false);
    PMP_VDivRail(false);
    PMP_SenseRail(false);

    /* Return on the VOLTAGE only. Voltage is the load-bearing signal for the
     * UV ladder; requiring both would mean a current sensor that failed to
     * report ready blocks battery protection entirely, which is backwards. A
     * failed current read degrades to "no current detected" -- the pack stays
     * asleep rather than waking spuriously, and the voltage ladder keeps
     * running. If the sensor is genuinely dead, current-based wake is
     * unavailable either way. */
    if (!i_ok)
    {
        *amps = 0.0f;
    }
    return v_ok;
}

/* ==========================================================================
 * Indication
 * ========================================================================== */
void PMP_FaultLed(bool on)
{
    HAL_GPIO_WritePin(PM_FAULT_LED_PORT, PM_FAULT_LED_PIN,
                      on ? PM_FAULT_LED_ON_LEVEL
                         : ((PM_FAULT_LED_ON_LEVEL == GPIO_PIN_SET) ? GPIO_PIN_RESET
                                                                    : GPIO_PIN_SET));
}

void PMP_IndicateOnCan(uint8_t uv_stage, float pack_v)
{
#if (PM_INDICATE_ON_CAN == 1)
    /* Reuses the existing CLI framing so the Tkinter GUI can show which
     * ladder stage the pack is in without a new protocol or DBC change.
     * Payload: [stage][reserved][pack_v float LE] = 6 bytes. */
    uint8_t payload[6];

    payload[0] = uv_stage;
    payload[1] = 0U;
    (void)memcpy(&payload[2], &pack_v, sizeof(float));

    CLI_Frame_Send(CLI_CMD_PM_UV_STAGE, payload, (uint16_t)sizeof(payload));
#else
    (void)uv_stage;
    (void)pack_v;
#endif
}

/* ==========================================================================
 * Wake button
 * ========================================================================== */
bool PMP_WakeButtonPressed(void)
{
    GPIO_PinState s = HAL_GPIO_ReadPin(PM_WAKE_BTN_PORT, PM_WAKE_BTN_PIN);

#if (PM_WAKE_BTN_ACTIVE_LOW == 1)
    return (s == GPIO_PIN_RESET);
#else
    return (s == GPIO_PIN_SET);
#endif
}

/* ==========================================================================
 * Power path
 * ========================================================================== */
void PMP_OpenPowerPath(void)
{
    /* No charge/discharge FET GPIO exists in this firmware -- the Daly slave
     * owns the FETs and there is no 0xD9/0xDA write path in daly_bms.c. So
     * this is deliberately a no-op and hibernate leaves the FET state to the
     * Daly's own protection.
     *
     * >>> HW <<< if the FETs are ever brought under STM32 control, drive them
     * open here. Hibernate is the one state where the BMS stops watching, so
     * the pack must not be left able to discharge through a closed path. */
}

/* ==========================================================================
 * Peripheral suspend / resume
 * ========================================================================== */
void PMP_PeripheralsSuspend(void)
{
    /* Timers first: TIM1 TRGO drives the ADC2 NTC chain and the current-sensor
     * ADC1 pipeline. Stopping the trigger before the ADCs avoids a conversion
     * landing mid-teardown. */
    (void)HAL_TIM_Base_Stop_IT(&htim6);
    (void)HAL_TIM_Base_Stop_IT(&htim5);
    (void)HAL_TIM_Base_Stop_IT(&htim15);
    (void)HAL_TIM_Base_Stop(&htim1);

    (void)HAL_ADC_Stop_IT(&hadc2);
    (void)HAL_ADC_Stop_IT(&hadc1);
    (void)HAL_ADC_Stop(&hadc1);
    (void)HAL_ADCEx_DisableVoltageRegulator(&hadc1);
    (void)HAL_ADCEx_DisableVoltageRegulator(&hadc2);

    /* UART5 = Daly, USART2 = CLI/GUI. Aborting cancels any in-flight IT/DMA
     * so a half-received frame cannot fire a callback on the way into Stop. */
    (void)HAL_UART_Abort(&huart5);
    (void)HAL_UART_Abort(&huart2);

    /* VREFBUF and the internal comparator/opamp domains, if any of them were
     * enabled, hold hundreds of microamps on their own. */
#if defined(VREFBUF)
    CLEAR_BIT(VREFBUF->CSR, VREFBUF_CSR_ENVR);
#endif
}

void PMP_PeripheralsResume(void)
{
    (void)HAL_ADCEx_EnableVoltageRegulator(&hadc1);
    (void)HAL_ADCEx_EnableVoltageRegulator(&hadc2);

    /* ADC1 keeps its calibration across Stop 1 (VDDA never drops), so a
     * recalibration is not required and would cost 
     * milliseconds every wake. */
    (void)HAL_ADC_Start_IT(&hadc2);
    (void)HAL_TIM_Base_Start(&htim1);
    (void)HAL_TIM_Base_Start_IT(&htim6);
    (void)HAL_TIM_Base_Start_IT(&htim5);
    (void)HAL_TIM_Base_Start_IT(&htim15);

    /* Kick a fresh Daly poll cycle. StartUpdate re-arms the IT receive without
     * disturbing the cell count or the EKF state. */
    DalyBMS_StartUpdate(&hDaly);
}

/* ==========================================================================
 * GPIO parking
 * ==========================================================================
 * Only pins that are outputs or unused get parked. Everything the sleeping
 * BMS still needs is left alone:
 *   PA11  FDCAN1_RX, re-armed as EXTI by PMP_CanEnterSleep
 *   PB9   wakeButton EXTI
 *   PC9   STB_CAN, PA8 CAN_EN -- must hold their levels through Stop
 *   PA13/PA14 SWD, unless PM_DISABLE_SWD_IN_SLEEP
 * ========================================================================== */
void PMP_ParkGpio(void)
{
#if (PM_PARK_UNUSED_GPIO == 1)
    GPIO_InitTypeDef g = {0};

    g.Mode = GPIO_MODE_ANALOG;
    g.Pull = GPIO_NOPULL;

    /* LEDs off before parking, or a parked pin can leave one dimly lit. */
    HAL_GPIO_WritePin(GPIOA, LED1_D8_Pin | GREEN_LED_Pin | RED_LED_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOC, LED4_D11_Pin | LED3_D10_Pin | LED2_D9_Pin | BLUE_LED_Pin,
                      GPIO_PIN_RESET);

    /* GPIOA: park the QSPI pins (flash is in DPD), FDCAN1_TX, and the LEDs.
     * PA0 is ADC1_IN1 and already analog. Keep PA8, PA11. */
    g.Pin = GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_6 | GPIO_PIN_7
          | GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_12;
#if (PM_DISABLE_SWD_IN_SLEEP == 1)
    g.Pin |= GPIO_PIN_13 | GPIO_PIN_14;
#endif
    HAL_GPIO_Init(GPIOA, &g);

    /* GPIOB: QSPI PB0/PB1, USART2 PB3/PB4. PB2 and PB11 are ADC2 inputs and
     * already analog. Keep PB9. */
    g.Pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_3 | GPIO_PIN_4;
    HAL_GPIO_Init(GPIOB, &g);

    /* GPIOC: LEDs and UART5 TX. Keep PC9 (STB_CAN). */
    g.Pin = LED4_D11_Pin | LED3_D10_Pin | LED2_D9_Pin | BLUE_LED_Pin | GPIO_PIN_12;
    HAL_GPIO_Init(GPIOC, &g);

    /* GPIOD: UART5 RX on PD2. */
    g.Pin = GPIO_PIN_2;
    HAL_GPIO_Init(GPIOD, &g);

    pm_gpio_parked = true;
#endif
}

void PMP_RestoreGpio(void)
{
#if (PM_PARK_UNUSED_GPIO == 1)
    if (!pm_gpio_parked)
    {
        return;
    }
    pm_gpio_parked = false;

    /* MX_GPIO_Init is static in main.c, so the plain-GPIO pins are restored
     * here. The peripheral pins (QSPI, USART2, UART5, FDCAN1) are restored by
     * the HAL MSP when each peripheral is re-initialised in
     * PMP_PeripheralsResume / PMP_CanExitSleep, so they are not touched. */
    GPIO_InitTypeDef g = {0};

    g.Mode  = GPIO_MODE_OUTPUT_PP;
    g.Pull  = GPIO_NOPULL;
    g.Speed = GPIO_SPEED_FREQ_LOW;
    g.Pin   = LED4_D11_Pin | LED3_D10_Pin | LED2_D9_Pin | BLUE_LED_Pin;
    HAL_GPIO_Init(GPIOC, &g);

    g.Speed = GPIO_SPEED_FREQ_HIGH;
    g.Pin   = LED1_D8_Pin | GREEN_LED_Pin | RED_LED_Pin;
    HAL_GPIO_Init(GPIOA, &g);

    /* STB_CAN and CAN_EN keep their levels through Stop, but re-declaring the
     * mode is harmless and covers the case where a park pass touched them. */
    g.Pull  = GPIO_PULLUP;
    g.Speed = GPIO_SPEED_FREQ_LOW;
    g.Pin   = STB_CAN_Pin;
    HAL_GPIO_Init(STB_CAN_GPIO_Port, &g);
    g.Pin   = CAN_EN_Pin;
    HAL_GPIO_Init(CAN_EN_GPIO_Port, &g);
#endif
}

/* ==========================================================================
 * Clocks
 * ========================================================================== */
void PMP_RestoreClocks(void)
{
    /* Stop 1 exit lands on HSI16 with the PLL off. Every baud rate, ADC
     * prescaler and FDCAN bit-timing in this firmware assumes SYSCLK is
     * 170 MHz -- the same 170-vs-80 MHz assumption that once produced total
     * bus silence. Restore the tree before touching any peripheral. */
    SystemClock_Config();
}

/* ==========================================================================
 * Watchdog
 * ========================================================================== */
void PMP_WatchdogKick(void)
{
#if (PM_IWDG_ENABLED == 1)
    (void)HAL_IWDG_Refresh(&hiwdg);
#endif
}
