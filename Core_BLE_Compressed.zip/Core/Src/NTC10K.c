/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : NTC10K.c
 * @brief          : NTC10K thermistor driver (dual-channel: NTC1 + NTC2)
 *
 * Implements:
 *   - Steinhart-Hart beta equation temperature conversion
 *   - Single-point B-coefficient calibration
 *   - Blocking ADC averaging for calibration
 *   - HAL_ADC_ConvCpltCallback  (ISR sample accumulation, dual-rank)
 *   - HAL_TIM_PeriodElapsedCallback  (TIM6 -> ADC trigger)
 ******************************************************************************
 */
/* USER CODE END Header */

#include "NTC10K.h"
#include "stm32g4xx_hal.h"
#include <math.h>

/* HAL peripheral handles defined in main.c */
extern ADC_HandleTypeDef hadc2;
extern TIM_HandleTypeDef htim6;

/* ---- NTC1 Module-level state (ADC2 Ch12, Rank 1) ------------------------ */
volatile uint32_t g_adc_raw = 0u;  /* Latest averaged ADC value          */
volatile uint8_t g_adc_ready = 0u; /* Flag: new averaged sample ready    */
static uint32_t g_adc_accum = 0u;  /* Running accumulator                */
static uint16_t g_sample_cnt = 0u; /* Samples counted since last average */
float g_calib_b = NTC_B_DEFAULT;   /* Active B coefficient               */

/* ---- NTC2 Module-level state (ADC2 Ch14, Rank 2) ------------------------ */
volatile uint32_t g_adc2_raw = 0u;  /* Latest averaged ADC2 value         */
volatile uint8_t g_adc2_ready = 0u; /* Flag: new averaged NTC2 sample     */
static uint32_t g_adc2_accum = 0u;  /* Running accumulator for NTC2       */
static uint16_t g_sample2_cnt = 0u; /* Samples counted since last average */
float g_calib2_b = NTC_B_DEFAULT;   /* Active B coefficient for NTC2      */

/* ---- Rank toggle for scan mode ------------------------------------------ */
static uint8_t g_adc2_rank = 0u; /* 0 = rank1 (NTC1), 1 = rank2 (NTC2) */

/* ---------------------------------------------------------------------------
 * NTC_ADC_To_Celsius  (NTC1)
 *   Convert a 12-bit ADC raw value to temperature in Celsius.
 *   Uses the simplified Steinhart-Hart (beta equation):
 *       1/T = 1/T0 + (1/B) * ln(R / R0)
 * ---------------------------------------------------------------------------*/
float NTC_ADC_To_Celsius(uint32_t adc_val) {
  float r_ntc, ln_ratio, inv_t;

  /* Guard: avoid division by zero at the rails */
  if (adc_val <= NTC_RAIL_PIN_MARGIN_COUNTS ||
      adc_val >= (4095u - NTC_RAIL_PIN_MARGIN_COUNTS)) {
    return -999.0f;
  }

  /* Voltage-divider: NTC at bottom (to GND) */
  r_ntc = SERIES_R * (float)adc_val / (ADC_MAX_VAL - (float)adc_val);

  /* Steinhart-Hart beta equation */
  ln_ratio = logf(r_ntc / NTC_NOMINAL_R);
  inv_t = (1.0f / NTC_NOMINAL_T_K) + (ln_ratio / g_calib_b);

  return (1.0f / inv_t) - KELVIN_OFFSET;
}

/* ---------------------------------------------------------------------------
 * NTC2_ADC_To_Celsius  (NTC2)
 *   Same as NTC_ADC_To_Celsius but uses g_calib2_b.
 * ---------------------------------------------------------------------------*/
float NTC2_ADC_To_Celsius(uint32_t adc_val) {
  float r_ntc, ln_ratio, inv_t;

  if (adc_val <= NTC_RAIL_PIN_MARGIN_COUNTS ||
      adc_val >= (4095u - NTC_RAIL_PIN_MARGIN_COUNTS)) {
    return -999.0f;
  }

  r_ntc = SERIES_R * (float)adc_val / (ADC_MAX_VAL - (float)adc_val);
  ln_ratio = logf(r_ntc / NTC_NOMINAL_R);
  inv_t = (1.0f / NTC_NOMINAL_T_K) + (ln_ratio / g_calib2_b);

  return (1.0f / inv_t) - KELVIN_OFFSET;
}

/* ---------------------------------------------------------------------------
 * NTC_Calibrate  (NTC1)
 *   Single-point calibration: compute the B coefficient from a known
 *   temperature and the corresponding averaged ADC reading.
 *
 *   B = ln(R / R0) / (1/T_cal - 1/T0)
 *
 *   Returns NTC_CALIB_OK on success; error code otherwise.
 *   The caller (main.c) is responsible for printing any error messages.
 * ---------------------------------------------------------------------------*/
NTC_CalibResult_t NTC_Calibrate(float known_temp_c, uint32_t adc_val) {
  float t_cal_k, r_ntc, ln_ratio, denom;

  if (adc_val <= NTC_RAIL_PIN_MARGIN_COUNTS ||
      adc_val >= (4095u - NTC_RAIL_PIN_MARGIN_COUNTS)) {
    return NTC_CALIB_ERR_ADC_RANGE;
  }

  t_cal_k = known_temp_c + KELVIN_OFFSET;
  r_ntc = SERIES_R * (float)adc_val / (ADC_MAX_VAL - (float)adc_val);
  ln_ratio = logf(r_ntc / NTC_NOMINAL_R);
  denom = (1.0f / t_cal_k) - (1.0f / NTC_NOMINAL_T_K);

  if (fabsf(denom) < 1e-9f) {
    return NTC_CALIB_ERR_TEMP_CLOSE;
  }

  /* Solve for B and update the active coefficient */
  g_calib_b = ln_ratio / denom;
  return NTC_CALIB_OK;
}

/* ---------------------------------------------------------------------------
 * NTC2_Calibrate  (NTC2)
 *   Same as NTC_Calibrate but updates g_calib2_b.
 * ---------------------------------------------------------------------------*/
NTC_CalibResult_t NTC2_Calibrate(float known_temp_c, uint32_t adc_val) {
  float t_cal_k, r_ntc, ln_ratio, denom;

  if (adc_val <= NTC_RAIL_PIN_MARGIN_COUNTS ||
      adc_val >= (4095u - NTC_RAIL_PIN_MARGIN_COUNTS)) {
    return NTC_CALIB_ERR_ADC_RANGE;
  }

  t_cal_k = known_temp_c + KELVIN_OFFSET;
  r_ntc = SERIES_R * (float)adc_val / (ADC_MAX_VAL - (float)adc_val);
  ln_ratio = logf(r_ntc / NTC_NOMINAL_R);
  denom = (1.0f / t_cal_k) - (1.0f / NTC_NOMINAL_T_K);

  if (fabsf(denom) < 1e-9f) {
    return NTC_CALIB_ERR_TEMP_CLOSE;
  }

  g_calib2_b = ln_ratio / denom;
  return NTC_CALIB_OK;
}

/* ---------------------------------------------------------------------------
 * NTC_GetCalibADC
 *   Blocking: take CALIB_ADC_SAMPLES ADC readings, return the average.
 *   Used only during the startup calibration phase.
 * ---------------------------------------------------------------------------*/
uint32_t NTC_GetCalibADC(void) {
  uint32_t sum = 0u;
  uint8_t i;

  for (i = 0u; i < CALIB_ADC_SAMPLES; i++) {
    HAL_ADC_Start(&hadc2);
    if (HAL_ADC_PollForConversion(&hadc2, 100u) == HAL_OK) {
      sum += HAL_ADC_GetValue(&hadc2);
    }
    HAL_ADC_Stop(&hadc2);
    HAL_Delay(5u);
  }

  return sum / CALIB_ADC_SAMPLES;
}

/* ---------------------------------------------------------------------------
 * HAL Callbacks
 * ---------------------------------------------------------------------------*/

/* Called from HAL_ADC_ConvCpltCallback dispatcher in stm32g4xx_it.c.
 * ADC2 is in scan mode with 2 ranks:
 *   Rank 1 = Channel 12 (NTC1)
 *   Rank 2 = Channel 14 (NTC2)
 * Each EOC fires this callback. We use a rank toggle to separate them. */
void NTC10K_ADC_Callback(ADC_HandleTypeDef *hadc) {
  if (hadc->Instance == ADC2) {
    uint32_t val = HAL_ADC_GetValue(hadc);

    if (g_adc2_rank == 0u) {
      /* Rank 1: NTC1 (Channel 12) */
      g_adc_accum += val;
      g_sample_cnt++;

      if (g_sample_cnt >= ADC_AVG_SAMPLES) {
        g_adc_raw = g_adc_accum / ADC_AVG_SAMPLES;
        g_adc_accum = 0u;
        g_sample_cnt = 0u;
        g_adc_ready = 1u;
      }
      g_adc2_rank = 1u; /* Next callback will be rank 2 */
    } else {
      /* Rank 2: NTC2 (Channel 14) */
      g_adc2_accum += val;
      g_sample2_cnt++;

      if (g_sample2_cnt >= ADC_AVG_SAMPLES) {
        g_adc2_raw = g_adc2_accum / ADC_AVG_SAMPLES;
        g_adc2_accum = 0u;
        g_sample2_cnt = 0u;
        g_adc2_ready = 1u;
      }
      g_adc2_rank = 0u; /* Next callback will be rank 1 */
    }
  }
}

/* Called from HAL_TIM_PeriodElapsedCallback dispatcher in stm32g4xx_it.c.
 * ADC2 is now hardware-triggered by TIM1 TRGO, so TIM6 no longer starts
 * ADC conversions. This callback is kept as a stub. */
void NTC10K_TIM_Callback(TIM_HandleTypeDef *htim) {
  (void)htim; /* No action needed — TIM1 TRGO drives ADC2 */
}
