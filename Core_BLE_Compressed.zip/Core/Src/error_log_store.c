/**
 * @file    error_log_store.c
 * @brief   Advanced error/event log storage implementation.
 *
 * ---------------------------------------------------------------------------
 * WHY THIS EXISTS (replacing the old "rewrite the whole struct" design)
 * ---------------------------------------------------------------------------
 * The old design kept ALL entries in one big struct (magic+head+count+
 * entries[100]+crc32, ~6.4KB) and on every single new log entry: erased
 * TWO 4KB sectors, then rewrote the ENTIRE 6.4KB structure. That has three
 * real problems:
 *   1. SLOW: a dual-sector-erase-plus-6.4KB-write is several hundred ms to
 *      ~1s, blocking, with no IWDG refresh of its own -- called from the
 *      same hot path as CAN telemetry, this stalled the whole system on
 *      every fault transition (see the CAN-hang bug this was fixed for).
 *   2. FLASH WEAR: rewriting 6.4KB to log 76 bytes of new data is ~85x more
 *      erase/write than necessary per entry -- on a part rated for maybe
 *      100,000 erase cycles per sector, that's needless wear.
 *   3. FRAGILE: a power loss at ANY point during that erase-then-rewrite
 *      corrupts the ENTIRE log (magic/CRC mismatch on next boot falls back
 *      to empty) -- one bad moment loses ALL history, not just the entry
 *      that was in flight.
 *
 * THIS design instead:
 *   - Reserves a ring of ERRLOG_SECTOR_COUNT 4KB sectors inside
 *     FLASH_PART_2 (flash_map.h) -- a small slice of that partition's
 *     2.66MB budget, leaving the rest free for later use.
 *   - Splits each sector into fixed-size records (ErrorLog_Record_t).
 *     A new entry is a single small WRITE into the next known-blank slot
 *     -- NOT an erase-then-rewrite of anything. NOR flash allows writing
 *     into already-erased (blank/0xFF) space without erasing first.
 *   - Each record carries its OWN magic + CRC16. A power loss mid-write
 *     corrupts at most that ONE record (it fails validation and is
 *     treated as blank/skipped on the next scan) -- every previously
 *     written record is completely untouched.
 *   - Rotates writes across all ERRLOG_SECTOR_COUNT sectors round-robin
 *     (wear leveling) instead of hammering one or two.
 *   - Sector erases -- the one genuinely slow operation here -- are done
 *     via W25Q64_EraseSectorStart() + polling W25Q64_IsBusy(), spread
 *     across many ErrorLog_ProcessPending() calls (one bus operation per
 *     call, ever), and scheduled PROACTIVELY during idle ticks well
 *     before the sector is actually needed -- so the hot append path
 *     essentially never has to wait on one. See the state machine below.
 * ---------------------------------------------------------------------------
 */

#include "error_log_store.h"
#include "flash_map.h"
#include "w25q64.h"
#include <string.h>
#include <stddef.h>

/* ========================================================================== */
/*                       Flash layout                                        */
/* ========================================================================== */

#define ERRLOG_RECORD_MAGIC 0xE10Au /* marks a fully, validly written record.
                                        Blank (erased) flash reads 0xFFFF,
                                        which can never collide with this. */

typedef struct __attribute__((packed)) {
  uint16_t         magic;
  ErrorLog_Entry_t entry;
  uint16_t         crc16;
} ErrorLog_Record_t;

/**
 * 16 sectors x 4KB = 64KB reserved out of FLASH_PART_2's 2.66MB budget.
 * RECORDS_PER_SECTOR is however many whole ErrorLog_Record_t fit in one
 * 4KB sector (a few bytes of tail padding per sector are simply unused).
 * >>> Bump ERRLOG_SECTOR_COUNT if you want more history; nothing else
 * needs to change -- everything below derives from these two constants. */
#define ERRLOG_SECTOR_COUNT   16U
#define ERRLOG_RECORDS_PER_SECTOR (W25Q64_SECTOR_SIZE / sizeof(ErrorLog_Record_t))
#define ERRLOG_TOTAL_SLOTS    (ERRLOG_SECTOR_COUNT * ERRLOG_RECORDS_PER_SECTOR)

const uint32_t ERROR_LOG_MAX_ENTRIES = ERRLOG_TOTAL_SLOTS;

static QSPI_HandleTypeDef *sQspiHandle = NULL;
extern RTC_HandleTypeDef hrtc;

/* ---- Runtime ring state (rebuilt from flash at boot, see ErrorLog_Init) -- */
static uint32_t sCursorAbsSlot = 0;   /* next slot to write, 0..TOTAL_SLOTS-1 */
static uint32_t sValidCount    = 0;   /* current entry count, capped at TOTAL_SLOTS */
static uint32_t sNextSeq       = 0;   /* next sequence number to assign */

/* ---- Non-blocking background erase-ahead state machine ------------------- */
typedef enum { ERRLOG_BG_IDLE = 0, ERRLOG_BG_ERASING } ErrLogBgState_t;
static ErrLogBgState_t sBgState        = ERRLOG_BG_IDLE;
static uint8_t         sNextSectorReady = 0; /* 1 = sector after the one we're
                                                 currently filling is confirmed
                                                 blank and ready to write into */

/* ========================================================================== */
/*                       Software CRC-16 (poly 0xA001, init 0x0000)          */
/* ========================================================================== */

static uint16_t ErrorLog_CRC16(const uint8_t *data, uint32_t length) {
  uint16_t crc = 0x0000U;
  for (uint32_t i = 0; i < length; i++) {
    crc ^= data[i];
    for (uint8_t j = 0; j < 8U; j++) {
      crc = (crc & 1U) ? (uint16_t)((crc >> 1) ^ 0xA001U) : (uint16_t)(crc >> 1);
    }
  }
  return crc;
}

/* ========================================================================== */
/*                       Address / slot helpers                              */
/* ========================================================================== */

static inline uint32_t ErrLog_SlotAddr(uint32_t abs_slot) {
  uint32_t sector_idx     = abs_slot / ERRLOG_RECORDS_PER_SECTOR;
  uint32_t slot_in_sector = abs_slot % ERRLOG_RECORDS_PER_SECTOR;
  return FLASH_PART_2_START + (sector_idx * W25Q64_SECTOR_SIZE) +
         (slot_in_sector * sizeof(ErrorLog_Record_t));
}

static inline uint32_t ErrLog_SectorAddr(uint32_t sector_idx) {
  return FLASH_PART_2_START + (sector_idx * W25Q64_SECTOR_SIZE);
}

/** @brief  Read + validate one record. Returns true only if magic AND
 *          CRC16 both check out -- a blank slot (0xFFFF) or a corrupted
 *          partial write (power loss mid-record) both correctly return
 *          false here, and affect only this one slot. */
static bool ErrLog_ReadValidRecord(uint32_t abs_slot, ErrorLog_Record_t *out) {
  if (W25Q64_Read(sQspiHandle, (uint8_t *)out, ErrLog_SlotAddr(abs_slot),
                  sizeof(*out)) != W25Q64_OK) {
    return false;
  }
  if (out->magic != ERRLOG_RECORD_MAGIC) {
    return false;
  }
  uint16_t computed = ErrorLog_CRC16(
      (const uint8_t *)out, offsetof(ErrorLog_Record_t, crc16));
  return computed == out->crc16;
}

/* ========================================================================== */
/*                       Boot recovery scan                                  */
/* ========================================================================== */

bool ErrorLog_Init(QSPI_HandleTypeDef *hqspi) {
  sQspiHandle = hqspi;

  if (W25Q64_Init(hqspi) != W25Q64_OK) {
    return false;
  }

  /* Single pass over every slot. For each valid record, track: how many
   * valid records exist total (capped at TOTAL_SLOTS -- this becomes
   * sValidCount), and which slot holds the globally HIGHEST sequence
   * number (its successor becomes the write cursor, and its seq+1
   * becomes sNextSeq). A record that fails validation -- blank, or a
   * partially-written one from a power loss mid-write -- is simply
   * skipped; it does not need to be contiguous with anything, and does
   * not invalidate any other record. */
  uint32_t valid_count   = 0;
  uint32_t highest_seq   = 0;
  uint32_t highest_slot  = 0;
  bool     found_any     = false;
  ErrorLog_Record_t rec;

  for (uint32_t slot = 0; slot < ERRLOG_TOTAL_SLOTS; slot++) {
    if (ErrLog_ReadValidRecord(slot, &rec)) {
      valid_count++;
      if (!found_any || rec.entry.seq >= highest_seq) {
        highest_seq  = rec.entry.seq;
        highest_slot = slot;
        found_any    = true;
      }
    }
  }

  sValidCount = valid_count;

  if (found_any) {
    sCursorAbsSlot = (highest_slot + 1U) % ERRLOG_TOTAL_SLOTS;
    sNextSeq       = highest_seq + 1U;
  } else {
    sCursorAbsSlot = 0U;
    sNextSeq       = 0U;
  }

  /* If the cursor's target slot isn't blank (leftover data from an old
   * lap that was never cleanly rotated through, or the tail-end remnant
   * of a corrupted in-flight record), erase that whole sector now --
   * once, at boot, before the main loop starts, so blocking briefly here
   * is fine. Every future crossing into a fresh sector is instead
   * handled by the non-blocking erase-ahead machinery below. */
  {
    uint16_t magic_check = 0xFFFFU;
    W25Q64_Read(sQspiHandle, (uint8_t *)&magic_check,
                ErrLog_SlotAddr(sCursorAbsSlot), sizeof(magic_check));
    if (magic_check != 0xFFFFU) {
      uint32_t sector_idx = sCursorAbsSlot / ERRLOG_RECORDS_PER_SECTOR;
      (void)W25Q64_EraseSector(sQspiHandle, ErrLog_SectorAddr(sector_idx));
    }
  }

  /* Opportunistically check whether the sector after the cursor's is
   * ALREADY blank (common on a fresh chip, or after a clean prior
   * rotation) -- if so, mark it ready now instead of spending one idle
   * tick re-erasing something that doesn't need it. */
  {
    uint32_t cur_sector  = sCursorAbsSlot / ERRLOG_RECORDS_PER_SECTOR;
    uint32_t next_sector = (cur_sector + 1U) % ERRLOG_SECTOR_COUNT;
    uint16_t magic_check = 0xFFFFU;
    W25Q64_Read(sQspiHandle, (uint8_t *)&magic_check,
                ErrLog_SectorAddr(next_sector), sizeof(magic_check));
    sNextSectorReady = (magic_check == 0xFFFFU) ? 1U : 0U;
  }

  return true;
}

/* ========================================================================== */
/*                       Deferred (non-blocking) queue                       */
/* ========================================================================== */

/**
 * Sized to the actual worst case, not a round guess: fault_detector.c has
 * FTIDX_COUNT (13) independently-debounced fault types, all evaluated in
 * every single Fault_Update() call -- a cascading failure can plausibly
 * cross several thresholds in the exact same tick, each queuing its own
 * message. Plus main.c's current-sensor health edge and PATH T's
 * block/resume edge (2 more independent hot-path sources) = 15 possible
 * simultaneous new entries in one tick, worst case. 16 gives one spare
 * slot. If you add more debounced fault types later, bump this to match. */
#define ERROR_LOG_PENDING_MAX 16U
static ErrorLog_Entry_t sPending[ERROR_LOG_PENDING_MAX];
static uint8_t sPendingHead  = 0U;
static uint8_t sPendingTail  = 0U;
static uint8_t sPendingCount = 0U;

bool ErrorLog_QueueDeferredEx(ErrorLog_Severity_t severity,
                               uint16_t fault_bits, const char *message) {
  if (sPendingCount >= ERROR_LOG_PENDING_MAX) {
    return false; /* full -- drop rather than block the real-time caller */
  }

  RTC_TimeTypeDef sTime = {0};
  RTC_DateTypeDef sDate = {0};
  HAL_RTC_GetTime(&hrtc, &sTime, RTC_FORMAT_BIN);
  HAL_RTC_GetDate(&hrtc, &sDate, RTC_FORMAT_BIN);

  ErrorLog_Entry_t *e = &sPending[sPendingHead];
  e->timestamp.year    = sDate.Year;
  e->timestamp.month   = sDate.Month;
  e->timestamp.date    = sDate.Date;
  e->timestamp.hours   = sTime.Hours;
  e->timestamp.minutes = sTime.Minutes;
  e->timestamp.seconds = sTime.Seconds;
  e->seq        = 0U;          /* assigned for real at commit time */
  e->fault_bits = fault_bits;
  e->severity   = (uint8_t)severity;
  e->reserved   = 0U;
  strncpy(e->message, message, ERROR_LOG_MSG_MAX_LEN - 1);
  e->message[ERROR_LOG_MSG_MAX_LEN - 1] = '\0';

  sPendingHead = (uint8_t)((sPendingHead + 1U) % ERROR_LOG_PENDING_MAX);
  sPendingCount++;
  return true;
}

bool ErrorLog_QueueDeferred(const char *message) {
  return ErrorLog_QueueDeferredEx(ERRLOG_SEV_INFO, 0U, message);
}

/* ========================================================================== */
/*                       Commit path (called from ErrorLog_ProcessPending)   */
/* ========================================================================== */

static void ErrLog_CommitOne(const ErrorLog_Entry_t *pending) {
  uint32_t abs_slot       = sCursorAbsSlot;
  uint32_t slot_in_sector = abs_slot % ERRLOG_RECORDS_PER_SECTOR;

  /* Safety net: about to write slot 0 of a sector that isn't confirmed
   * blank yet (the background erase-ahead didn't get a chance to finish
   * -- e.g. a burst of more than ERRLOG_RECORDS_PER_SECTOR simultaneous
   * entries with no idle tick in between). Erase it now, synchronously
   * -- bounded to ONE sector (tens to a few hundred ms), a small fraction
   * of the old design's two-sector-plus-6.4KB-write. This should be rare
   * in practice: FAULT_DEBOUNCE's own ~5s+ hysteresis already rate-limits
   * how fast any single fault can re-log. */
  if (slot_in_sector == 0U && !sNextSectorReady) {
    uint32_t sector_idx = abs_slot / ERRLOG_RECORDS_PER_SECTOR;
    (void)W25Q64_EraseSector(sQspiHandle, ErrLog_SectorAddr(sector_idx));
  }
  sNextSectorReady = 0U; /* consumed either way -- next crossing needs a fresh check */

  ErrorLog_Record_t rec;
  rec.magic = ERRLOG_RECORD_MAGIC;
  rec.entry = *pending;
  rec.entry.seq = sNextSeq++;
  rec.crc16 = ErrorLog_CRC16((const uint8_t *)&rec,
                             offsetof(ErrorLog_Record_t, crc16));

  (void)W25Q64_Write(sQspiHandle, (const uint8_t *)&rec,
                     ErrLog_SlotAddr(abs_slot), sizeof(rec));

  sValidCount = (sValidCount < ERRLOG_TOTAL_SLOTS) ? (sValidCount + 1U)
                                                    : ERRLOG_TOTAL_SLOTS;
  sCursorAbsSlot = (abs_slot + 1U) % ERRLOG_TOTAL_SLOTS;
}

static void ErrLog_MaybeStartEraseAhead(void) {
  if (sNextSectorReady) {
    return;
  }
  uint32_t cur_sector  = sCursorAbsSlot / ERRLOG_RECORDS_PER_SECTOR;
  uint32_t next_sector = (cur_sector + 1U) % ERRLOG_SECTOR_COUNT;
  if (W25Q64_EraseSectorStart(sQspiHandle, ErrLog_SectorAddr(next_sector)) ==
      W25Q64_OK) {
    sBgState = ERRLOG_BG_ERASING;
  }
}

void ErrorLog_ProcessPending(void) {
  if (sQspiHandle == NULL) {
    return;
  }

  /* At most ONE flash-bus operation happens below, ever, per call. */

  if (sBgState == ERRLOG_BG_ERASING) {
    if (!W25Q64_IsBusy(sQspiHandle)) {
      sBgState = ERRLOG_BG_IDLE;
      sNextSectorReady = 1U;
    }
    return; /* single fast status read this call -- microseconds */
  }

  if (sPendingCount > 0U) {
    ErrLog_CommitOne(&sPending[sPendingTail]);
    sPendingTail = (uint8_t)((sPendingTail + 1U) % ERROR_LOG_PENDING_MAX);
    sPendingCount--;
    return; /* single small record write this call -- a few ms at most */
  }

  /* Nothing pending -- idle tick. Spend it proactively erasing the
   * sector that will eventually be needed, so the hot append path above
   * essentially never has to (see ErrLog_CommitOne()'s safety-net branch
   * for the rare case where it still does). */
  ErrLog_MaybeStartEraseAhead();
}

/* ========================================================================== */
/*                       Synchronous (slow-path) API                        */
/* ========================================================================== */

bool ErrorLog_AddEx(ErrorLog_Severity_t severity, uint16_t fault_bits,
                    const char *message) {
  if (sQspiHandle == NULL) {
    return false;
  }
  if (!ErrorLog_QueueDeferredEx(severity, fault_bits, message)) {
    return false;
  }

  /* Drain synchronously until the whole pending queue empties (our entry
   * is always the last one in FIFO order, so this guarantees ours is
   * committed too, even if others were already ahead of it) -- fine to
   * block here, this is the explicitly-slow-path API. Time-bounded, not
   * iteration-bounded: each ProcessPending() call does at most one fast
   * status poll or one small write, so this is a tight poll loop, not a
   * fixed-count one. */
  uint32_t start_ms = HAL_GetTick();
  while (sPendingCount > 0U && (HAL_GetTick() - start_ms) < 2000U) {
    ErrorLog_ProcessPending();
  }
  return true;
}

bool ErrorLog_Add(const char *message) {
  return ErrorLog_AddEx(ERRLOG_SEV_INFO, 0U, message);
}

/* ========================================================================== */
/*                       Read API                                            */
/* ========================================================================== */

uint32_t ErrorLog_GetCount(void) { return sValidCount; }

bool ErrorLog_GetEntry(uint32_t index, ErrorLog_Entry_t *out_entry) {
  if (index >= sValidCount || out_entry == NULL) {
    return false;
  }

  /* General formula, valid whether the ring has never wrapped, has fully
   * wrapped, or (the case the old two-branch special-casing got WRONG)
   * sat through a logical ErrorLog_Clear() and is now being partially
   * refilled from a cursor position that ISN'T slot 0: the oldest
   * surviving entry is always exactly "cursor minus how many entries
   * currently exist", wrapped. This single formula subsumes both of the
   * simpler cases too (count < TOTAL_SLOTS and count == TOTAL_SLOTS),
   * so there's no need to special-case them separately. */
  uint32_t oldest_slot =
      (sCursorAbsSlot + ERRLOG_TOTAL_SLOTS - sValidCount) % ERRLOG_TOTAL_SLOTS;
  uint32_t abs_slot = (oldest_slot + index) % ERRLOG_TOTAL_SLOTS;

  ErrorLog_Record_t rec;
  if (!ErrLog_ReadValidRecord(abs_slot, &rec)) {
    return false; /* this one slot failed validation -- see file header */
  }

  *out_entry = rec.entry;
  return true;
}

bool ErrorLog_Clear(void) {
  /* Logical clear: reported count/entries go to zero immediately, with
   * NO flash operation at all -- ErrorLog_GetCount()/GetEntry() are
   * driven entirely by sValidCount/the cursor, not by re-scanning flash.
   * The sequence counter (sNextSeq) deliberately keeps counting rather
   * than resetting -- a "clear" shouldn't be able to hide that entries
   * existed before it (an intentional black-box-style property, not an
   * oversight). Physical space is recycled naturally by the normal
   * wear-leveled rotation as new entries get written going forward --
   * this is a diagnostic log, not a secure-erase target, so there's no
   * need to synchronously wipe ERRLOG_SECTOR_COUNT sectors just to
   * report "empty" (that would reintroduce exactly the kind of multi-
   * hundred-ms blocking stall this whole redesign exists to avoid). */
  if (sQspiHandle == NULL) {
    return false;
  }
  sValidCount = 0U;
  return true;
}
