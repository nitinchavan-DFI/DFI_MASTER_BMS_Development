/**
 * @file    can_gui_cmds.c
 * @brief   GUI -> BMS config-write commands over CAN: ISR-safe staging
 *          array + atomic main-loop consume. See can_gui_cmds.h for the
 *          protocol/payload description.
 *
 * Decode, validation (ValidateFaultThresholds()), and dispatch into
 * Fault_SetThresholds() / CurrentSensor_Start*Calibration() live in
 * main.c, not here -- same split as the charger RX path: this file only
 * ever touches raw bytes.
 */
#include "can_gui_cmds.h"
#include "main.h" /* __disable_irq/__enable_irq/__DMB (CMSIS) */
#include <string.h>

GuiCmdStage_t g_guiCmdStage[GUI_CMD_COUNT];

void GuiCmd_LatchRawFrame(GuiCmdIndex_t idx, const uint8_t *data, uint8_t len) {
  if ((uint32_t)idx >= (uint32_t)GUI_CMD_COUNT) {
    return; /* defensive -- should never happen, see header note */
  }

  GuiCmdStage_t *stage = &g_guiCmdStage[idx];

  if (stage->pending) {
    stage->overrun_count++;
  }
  uint8_t n = (len > 8U) ? 8U : len;
  for (uint8_t i = 0U; i < 8U; i++) {
    stage->raw[i] = (i < n) ? data[i] : 0U;
  }
  stage->len = n;
  /* Write pending LAST so main loop never sees partial data. */
  __DMB();
  stage->pending = 1U;
}

bool GuiCmd_TryConsume(GuiCmdIndex_t idx, uint8_t *out_raw, uint8_t *out_len) {
  if ((uint32_t)idx >= (uint32_t)GUI_CMD_COUNT) {
    return false;
  }

  GuiCmdStage_t *stage = &g_guiCmdStage[idx];
  uint8_t havePending;

  __disable_irq();
  havePending = stage->pending;
  if (havePending) {
    memcpy(out_raw, stage->raw, 8U);
    *out_len       = stage->len;
    stage->pending = 0U;
  }
  __enable_irq();

  return (havePending != 0U);
}

/**
 * @brief  ISR-context dispatch entry point -- see can_gui_cmds.h for the
 *         full contract. Maps the incoming extended CAN ID to its
 *         GuiCmdIndex_t slot and forwards the raw payload to
 *         GuiCmd_LatchRawFrame(); mirrors Process_Charger_Frame()'s role
 *         for the charger status ID (see can_frame_handlers.c). O(1),
 *         no floating-point, no calls out besides the latch -- safe to
 *         call from HAL_FDCAN_RxFifo0Callback().
 */
void Process_GuiCmd_Frame(uint32_t ext_id, uint8_t *data, uint8_t len) {
  GuiCmdIndex_t idx;

  switch (ext_id) {
    case GUI_CMD_ID_SET_THRESH_VOLT: idx = GUI_CMD_SET_THRESH_VOLT; break;
    case GUI_CMD_ID_SET_THRESH_CURR: idx = GUI_CMD_SET_THRESH_CURR; break;
    case GUI_CMD_ID_SET_THRESH_TEMP: idx = GUI_CMD_SET_THRESH_TEMP; break;
    case GUI_CMD_ID_SET_THRESH_CELL: idx = GUI_CMD_SET_THRESH_CELL; break;
    case GUI_CMD_ID_SET_THRESH_DIFF: idx = GUI_CMD_SET_THRESH_DIFF; break;
    case GUI_CMD_ID_ZERO_CAL:        idx = GUI_CMD_ZERO_CAL;        break;
    case GUI_CMD_ID_KNOWN_CAL:       idx = GUI_CMD_KNOWN_CAL;       break;
    default:
      /* Should not happen: fdcan.c's hardware filter bank is programmed
         to exactly [GUI_CMD_ID_RANGE_LOW, GUI_CMD_ID_RANGE_HIGH], and
         main.c only calls this function for IDs inside that range.
         Stays defensive against future drift between the #defines here
         and the filter/switch (see header note). */
      return;
  }

  GuiCmd_LatchRawFrame(idx, data, len);
}
