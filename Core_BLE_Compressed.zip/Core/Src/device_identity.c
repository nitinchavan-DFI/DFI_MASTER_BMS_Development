/**
 * @file    device_identity.c
 * @brief   BMS Serial Number / Pack Serial Number / Product ID -- live RAM
 *          copy + validation. See device_identity.h.
 */
#include "device_identity.h"
#include <string.h>

static CLI_DeviceIdentity_t s_identity;

void DeviceIdentity_LoadDefaults(CLI_DeviceIdentity_t *id) {
  memset(id, 0, sizeof(*id));
}

void DeviceIdentity_RestoreFromFlash(const CLI_DeviceIdentity_t *stored) {
  s_identity = *stored;
  /* Belt-and-suspenders even on a CRC-valid flash record -- a future
   * firmware image with a shorter/renamed field layout could still read
   * back plausible-looking but non-terminated bytes here. */
  s_identity.bmsSerialNumber[sizeof(s_identity.bmsSerialNumber) - 1] = '\0';
  s_identity.packSerialNumber[sizeof(s_identity.packSerialNumber) - 1] = '\0';
  s_identity.mfgDate[sizeof(s_identity.mfgDate) - 1] = '\0';
}

void DeviceIdentity_Get(CLI_DeviceIdentity_t *out) {
  *out = s_identity;
}

const CLI_DeviceIdentity_t *DeviceIdentity_GetPtr(void) {
  return &s_identity;
}

/** @brief  true if every byte up to the first NUL (or the whole field, if
 *          there's no NUL) is printable 7-bit ASCII. An all-zero field
 *          (cleared serial number) is accepted. */
static bool IsValidSerialField(const char *field, uint32_t len) {
  for (uint32_t i = 0; i < len; i++) {
    uint8_t c = (uint8_t)field[i];
    if (c == '\0') {
      return true; /* rest of the field is padding, don't care what it is */
    }
    if (c < 0x20U || c > 0x7EU) {
      return false;
    }
  }
  return true; /* ran off the end with no NUL -- every byte was printable */
}

bool DeviceIdentity_Set(const CLI_DeviceIdentity_t *in) {
  if (!IsValidSerialField(in->bmsSerialNumber, sizeof(in->bmsSerialNumber)) ||
      !IsValidSerialField(in->packSerialNumber, sizeof(in->packSerialNumber)) ||
      !IsValidSerialField(in->mfgDate, sizeof(in->mfgDate))) {
    return false;
  }

  s_identity = *in;
  /* Force-terminate regardless of what was sent -- see header comment. */
  s_identity.bmsSerialNumber[sizeof(s_identity.bmsSerialNumber) - 1] = '\0';
  s_identity.packSerialNumber[sizeof(s_identity.packSerialNumber) - 1] = '\0';
  s_identity.mfgDate[sizeof(s_identity.mfgDate) - 1] = '\0';
  return true;
}
