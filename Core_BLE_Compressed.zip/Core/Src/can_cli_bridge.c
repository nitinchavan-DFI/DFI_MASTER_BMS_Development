/**
 * @file    can_cli_bridge.c
 * @brief   CAN-CLI tunnel: ISR-context SF/FF/CF reassembly into a
 *          CLI_Frame_t-compatible queue, and the reverse (segmented send).
 *          See can_cli_bridge.h for the wire format and design rationale.
 */
#include "can_cli_bridge.h"
#include "fdcan.h" /* hfdcan1, Transmit_CanCli_Msg() */
#include "main.h"  /* __disable_irq/__enable_irq/__DMB (CMSIS) */
#include <string.h>

volatile CanCli_RxStats_t g_canCliRxStats;

/* ========================================================================
 * RX: ISR-context SF/FF/CF reassembly
 * ==================================================================== */

/** One fully-reassembled command, sized to CANCLI_MAX_PAYLOAD rather than
 *  reusing cli_frame.h's much larger CLI_Frame_t (512-byte data[]) -- this
 *  queue is 4 deep, no reason to spend 2 KB+ of RAM on headroom nothing on
 *  this tunnel will ever use (see can_cli_bridge.h payload-size note). */
typedef struct {
  uint8_t  cmd;
  uint8_t  data[CANCLI_MAX_PAYLOAD - 1U];
  uint16_t data_len;
} CanCli_Msg_t;

static CanCli_Msg_t s_rxQueue[CANCLI_RX_QUEUE_DEPTH];
static volatile uint8_t s_rxHead = 0U;
static volatile uint8_t s_rxTail = 0U;

/** Active reassembly session. Single session -- one CAN-side client at a
 *  time, which matches the intended use (one PEAK-CAN GUI). A new FF
 *  always starts a fresh session; an SF is always self-contained. */
static struct {
  bool     active;
  uint16_t total_len; /* total VP length (cmd + data), from the FF        */
  uint16_t got_len;   /* VP bytes received so far                         */
  uint8_t  expected_seq;
  uint8_t  buf[CANCLI_MAX_PAYLOAD];
} s_rx;

static volatile uint32_t s_lastClientTick = 0U;

static void EnqueueCompletedMessage(void) {
  uint8_t next_head = (uint8_t)((s_rxHead + 1U) % CANCLI_RX_QUEUE_DEPTH);
  if (next_head == s_rxTail) {
    g_canCliRxStats.queue_drops++;
    return; /* queue full -- drop, same policy as the UART CLI FIFO */
  }

  CanCli_Msg_t *slot = &s_rxQueue[s_rxHead];
  uint16_t dlen = (uint16_t)(s_rx.total_len - 1U); /* total_len includes cmd */
  if (dlen > (uint16_t)sizeof(slot->data)) {
    dlen = (uint16_t)sizeof(slot->data); /* defensive, can't happen given
                                             the length checks below */
  }
  slot->cmd = s_rx.buf[0];
  memcpy(slot->data, &s_rx.buf[1], dlen);
  slot->data_len = dlen;

  __DMB();
  s_rxHead = next_head;
  g_canCliRxStats.msgs_ok++;
}

void CanCli_RxFrame(const uint8_t *data, uint8_t len) {
  if (len == 0U) {
    return;
  }
  g_canCliRxStats.frames_rx++;
  s_lastClientTick = HAL_GetTick();

  uint8_t pci   = data[0];
  uint8_t ftype = (uint8_t)(pci >> 4);

  if (ftype == 0x0U) {
    /* Single Frame: byte0 = 0x0|L, bytes[1..L] = VP (cmd + data) */
    uint8_t l = (uint8_t)(pci & 0x0FU);
    if ((l == 0U) || (l > 7U) || (l > (uint8_t)(len - 1U))) {
      g_canCliRxStats.rej_len++;
      s_rx.active = false; /* abandon any in-progress FF/CF session too */
      return;
    }
    s_rx.total_len = l;
    memcpy(s_rx.buf, &data[1], l);
    s_rx.active = false;
    EnqueueCompletedMessage();

  } else if (ftype == 0x1U) {
    /* First Frame: byte0 = 0x1|(L>>8), byte1 = L&0xFF, bytes[2..7] = VP[0..5] */
    if (len < 3U) {
      g_canCliRxStats.rej_len++;
      s_rx.active = false;
      return;
    }
    uint16_t l = (uint16_t)(((uint16_t)(pci & 0x0FU) << 8) | data[1]);
    if ((l < 8U) || (l > (CANCLI_MAX_PAYLOAD - 1U))) {
      /* l < 8 should have been a Single Frame -- a well-formed sender
       * never does this, but don't trust the wire. */
      g_canCliRxStats.rej_len++;
      s_rx.active = false;
      return;
    }
    uint8_t n = (uint8_t)(len - 2U);
    if (n > 6U) {
      n = 6U;
    }
    memcpy(s_rx.buf, &data[2], n);
    s_rx.total_len     = l;
    s_rx.got_len        = n;
    s_rx.expected_seq   = 1U;
    s_rx.active          = true;

  } else if (ftype == 0x2U) {
    /* Consecutive Frame: byte0 = 0x2|seq, bytes[1..7] = next VP bytes */
    if (!s_rx.active) {
      g_canCliRxStats.rej_orphan_cf++;
      return;
    }
    uint8_t seq = (uint8_t)(pci & 0x0FU);
    if (seq != s_rx.expected_seq) {
      g_canCliRxStats.rej_seq++;
      s_rx.active = false;
      return;
    }

    uint16_t remain = (uint16_t)(s_rx.total_len - s_rx.got_len);
    uint8_t  n      = (uint8_t)(len - 1U);
    if (n > 7U) {
      n = 7U;
    }
    if (n > remain) {
      n = (uint8_t)remain;
    }
    memcpy(&s_rx.buf[s_rx.got_len], &data[1], n);
    s_rx.got_len      = (uint16_t)(s_rx.got_len + n);
    s_rx.expected_seq = (uint8_t)((s_rx.expected_seq + 1U) & 0x0FU);

    if (s_rx.got_len >= s_rx.total_len) {
      s_rx.active = false;
      EnqueueCompletedMessage();
    }
  }
  /* Any other top nibble (0x3-0xF, e.g. a real ISO-TP Flow-Control frame
   * this tunnel never sends) is not a frame type this protocol defines --
   * ignored, not counted as a rejection since it was never a request. */
}

bool CanCli_Process(CLI_Frame_t *frame) {
  bool     havePending;
  uint8_t  tail;

  __disable_irq();
  havePending = (s_rxHead != s_rxTail);
  tail        = s_rxTail;
  if (havePending) {
    s_rxTail = (uint8_t)((s_rxTail + 1U) % CANCLI_RX_QUEUE_DEPTH);
  }
  __enable_irq();

  if (!havePending) {
    return false;
  }

  const CanCli_Msg_t *slot = &s_rxQueue[tail];
  frame->cmd      = slot->cmd;
  frame->data_len = slot->data_len;
  memcpy(frame->data, slot->data, slot->data_len);
  return true;
}

bool CanCli_ClientActive(void) {
  if (s_lastClientTick == 0U) {
    return false; /* never heard from anyone since boot */
  }
  return (HAL_GetTick() - s_lastClientTick) < CANCLI_CLIENT_TIMEOUT_MS;
}

/* ========================================================================
 * TX: main-loop-context segmented send
 * ==================================================================== */

/** Bounded busy-wait on TX FIFO free level, then transmit one already-built
 *  CAN frame. Bounded (not HAL_MAX_DELAY-style) so a dead/saturated bus
 *  degrades a config write/telemetry tick, never hangs the main loop --
 *  same "must degrade, not hang" philosophy as FDCAN1_HealthCheck(). */
static HAL_StatusTypeDef CanCli_TransmitFrame(const uint8_t *frame, uint8_t len) {
  for (uint32_t spin = 0U; spin < 2000U; spin++) {
    if (HAL_FDCAN_GetTxFifoFreeLevel(&hfdcan1) > 0U) {
      return Transmit_CanCli_Msg(CANCLI_ID_RESP, (uint8_t *)frame, len)
                 ? HAL_OK
                 : HAL_ERROR;
    }
  }
  return HAL_ERROR;
}

HAL_StatusTypeDef CanCli_Send(uint8_t cmd, const uint8_t *data, uint16_t len) {
  if (!CanCli_ClientActive()) {
    return HAL_OK; /* nobody listening on CAN -- intentional no-op */
  }
  if (len > (CANCLI_MAX_PAYLOAD - 1U)) {
    return HAL_ERROR;
  }

  uint16_t total = (uint16_t)(len + 1U); /* + cmd byte */
  uint8_t  frame[8];

  if (total <= 7U) {
    /* Single Frame */
    frame[0] = (uint8_t)(0x00U | total);
    frame[1] = cmd;
    if (len != 0U) {
      memcpy(&frame[2], data, len);
    }
    return CanCli_TransmitFrame(frame, (uint8_t)(1U + total));
  }

  /* First Frame: VP[0..5] = cmd + first 5 data bytes */
  frame[0] = (uint8_t)(0x10U | ((total >> 8) & 0x0FU));
  frame[1] = (uint8_t)(total & 0xFFU);
  frame[2] = cmd;
  uint16_t sent      = 0U;
  uint8_t  firstDataN = (len < 5U) ? (uint8_t)len : 5U;
  if (firstDataN != 0U) {
    memcpy(&frame[3], data, firstDataN);
  }
  if (CanCli_TransmitFrame(frame, 8U) != HAL_OK) {
    return HAL_ERROR;
  }
  sent = firstDataN;

  uint8_t seq = 1U;
  while (sent < len) {
    uint8_t n = (uint8_t)(len - sent);
    if (n > 7U) {
      n = 7U;
    }
    frame[0] = (uint8_t)(0x20U | seq);
    memcpy(&frame[1], &data[sent], n);
    if (CanCli_TransmitFrame(frame, (uint8_t)(1U + n)) != HAL_OK) {
      return HAL_ERROR;
    }
    sent = (uint16_t)(sent + n);
    seq  = (uint8_t)((seq + 1U) & 0x0FU);
  }
  return HAL_OK;
}
