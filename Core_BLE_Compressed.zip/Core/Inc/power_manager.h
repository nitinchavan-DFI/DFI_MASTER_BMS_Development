/**
  ******************************************************************************
  * @file    power_manager.h
  * @brief   Automotive deep-sleep subsystem for the DFI Mosaic BMS.
  *          STM32G474RET6 / Stop 1 / Standby, RTC-ticked, with an escalating
  *          under-voltage indication ladder.
  *
  * Design intent
  * -------------
  * The BMS spends its life in Stop 1 with every mA-class load power-gated.
  * A single RTC wake-up tick does three jobs: kick the IWDG (which cannot be
  * stopped in Stop mode and would otherwise reset the MCU during a long
  * sleep), advance the software stage timer, and provide the sample point for
  * the duty-cycled voltage/current measurement.
  *
  * Wake sources
  * ------------
  *   CAN traffic     : transceiver in low-power mode, FDCAN1_RX re-mapped
  *                     from AF to EXTI falling edge. The waking frame is lost.
  *   Charge/discharge: duty-cycled current measurement, or an external
  *                     nanopower comparator on the shunt (preferred).
  *   Wake button     : EXTI in Stop 1, PWR WKUP pin in Standby.
  *   Under-voltage   : duty-cycled pack voltage measurement.
  *
  * Under-voltage ladder
  * --------------------
  * A near-flat pack must not be held awake by a continuously asserted fault,
  * because the act of indicating the fault is what finishes the pack off.
  * Instead the fault is indicated for 10 s, then re-checked after
  * 5 min / 30 min / 1 h / 12 h / 24 h, and finally the BMS hibernates with
  * fault-based wake disabled. Only the wake button brings it back, and doing
  * so restarts the ladder from stage 0.
  ******************************************************************************
  */

#ifndef POWER_MANAGER_H
#define POWER_MANAGER_H

#include <stdint.h>
#include <stdbool.h>
#include "power_manager_conf.h"

/* -------------------------------------------------------------------------- */
/* Types                                                                      */
/* -------------------------------------------------------------------------- */

typedef enum
{
    PM_STATE_ACTIVE       = 0U,  /*!< Normal operation, inactivity timer running   */
    PM_STATE_DEEP_SLEEP   = 1U,  /*!< Stop 1, no fault, all wake sources armed     */
    PM_STATE_UV_INDICATE  = 2U,  /*!< 10 s indication window, awake                */
    PM_STATE_UV_BACKOFF   = 3U,  /*!< Stop 1, counting down the current ladder step */
    PM_STATE_HIBERNATE    = 4U   /*!< Standby. Button only. Pack protection.       */
} PM_State_t;

typedef enum
{
    PM_WAKE_NONE          = 0U,
    PM_WAKE_RTC_TICK      = 1U,  /*!< Housekeeping tick, not a real wake     */
    PM_WAKE_CAN           = 2U,
    PM_WAKE_BUTTON        = 3U,
    PM_WAKE_CURRENT       = 4U,
    PM_WAKE_UNDERVOLTAGE  = 5U,
    PM_WAKE_STAGE_EXPIRY  = 6U,  /*!< Ladder interval elapsed, time to re-check */
    PM_WAKE_RESET         = 7U   /*!< Came up from Standby or a cold boot    */
} PM_WakeSource_t;

/** Runtime snapshot, suitable for publishing on the diagnostic CAN frame so
 *  the Tkinter tool can display why the BMS is asleep and how far up the
 *  ladder it has climbed. */
typedef struct
{
    PM_State_t      state;
    PM_WakeSource_t last_wake;
    uint8_t         uv_stage;             /*!< 0 = no fault, N = ladder index  */
    uint8_t         hibernate_latched;    /*!< 1 = fault wake permanently off  */
    uint32_t        stage_elapsed_s;      /*!< seconds inside the current step */
    uint32_t        cumulative_fault_s;   /*!< total time the UV fault has held */
    float           last_pack_v;
    float           last_current_a;
} PM_Status_t;

/* -------------------------------------------------------------------------- */
/* API                                                                        */
/* -------------------------------------------------------------------------- */

/**
  * @brief  Initialise the subsystem. Call once from main() AFTER
  *         SystemClock_Config(), HAL_Init() and MX_RTC_Init(), and BEFORE the
  *         main loop.
  *
  *         Detects whether this boot is a cold start or an exit from Standby,
  *         restores the ladder state from the RTC backup registers, and arms
  *         the RTC wake-up tick.
  */
void PM_Init(void);

/**
  * @brief  Service the state machine. Call on every pass of the main loop.
  *         Non-blocking except for the indication window and the sensor
  *         settling delay. This function is what actually enters Stop 1, so
  *         it will not return until the MCU has woken again.
  */
void PM_Task(void);

/**
  * @brief  Reset the inactivity timer. Call from anywhere that constitutes
  *         real activity: a received CAN frame, an operator command, a
  *         charging session starting, a fault being serviced.
  */
void PM_NotifyActivity(void);

/**
  * @brief  Veto sleep. While any caller holds a lock the BMS stays in
  *         PM_STATE_ACTIVE. Use around flash writes, an active charge
  *         session, or a firmware update. Reference counted -- every Acquire
  *         needs its Release.
  */
void PM_LockAcquire(void);
void PM_LockRelease(void);

/**
  * @brief  Request an immediate transition to deep sleep, skipping the
  *         remaining inactivity timeout. Ignored while a lock is held.
  */
void PM_RequestSleep(void);

/**
  * @brief  Hook to be called from the application's existing
  *         HAL_GPIO_EXTI_Callback(). Does NOT define its own callback, so it
  *         cannot collide with the one already in main.c.
  * @param  gpio_pin  the GPIO_PIN_x passed to the callback
  */
void PM_EXTI_Notify(uint16_t gpio_pin);

/**
  * @brief  Current subsystem status, for telemetry.
  */
void PM_GetStatus(PM_Status_t *out);

/**
  * @brief  Packed status byte for the diagnostic CAN frame.
  *         bits [2:0] state, bits [6:3] uv_stage, bit 7 hibernate_latched.
  */
uint8_t PM_GetPackedStatus(void);

/**
  * @brief  Clear the latched hibernate condition and reset the ladder.
  *         Called automatically on a button wake out of hibernate; also
  *         exposed for a service-tool override over CAN.
  */
void PM_ClearHibernateLatch(void);

#endif /* POWER_MANAGER_H */
