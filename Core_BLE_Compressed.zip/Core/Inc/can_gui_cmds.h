/**
 * @file    can_gui_cmds.h
 * @brief   GUI -> BMS config-write commands over CAN 2.0B Extended.
 *
 * Adds a CAN transport for writes that used to be UART-CLI-only:
 *   CLI_CMD_SET_FAULT_THRESH (0x20)  -> Fault_SetThresholds()
 *   CLI_CMD_ZERO_CAL         (0x10)  -> CurrentSensor_StartZeroCalibration()
 *   CLI_CMD_KNOWN_CAL        (0x11)  -> CurrentSensor_StartKnownCalibration()
 * (see cli_frame.h). The UART CLI path is UNCHANGED and still works --
 * this is an additional transport for the exact same underlying writes,
 * so e.g. BUSMASTER can drive them with no UART connection at all.
 *
 * FaultThresholds_t (fault_detector.h) is 9 floats / 36 bytes -- too big
 * for one Classic CAN frame (8-byte max payload) -- so the threshold SET
 * write is split into 5 domain-grouped frames below, matching the
 * project's existing convention of scaled-integer (never raw float32)
 * CAN payloads (see BMS_VIT / Charger_Cmd / Charger_Status in the DBC).
 * Each frame is a COMPLETE, independently valid write: the main-loop
 * handler in main.c reads the CURRENTLY active thresholds
 * (Fault_GetThresholds()), patches in just that frame's field(s),
 * re-validates the WHOLE struct with the exact same
 * ValidateFaultThresholds() the UART path uses, and only commits via
 * Fault_SetThresholds() if that whole-struct validation still passes.
 * That means: (a) you only need to send the one domain frame for
 * whatever you're changing -- no need to resend all 5 every time, and
 * (b) a bad value in one frame can never corrupt the other 7 thresholds,
 * same "reject the whole write, keep old config" guarantee the UART path
 * already gives (see ValidateFaultThresholds()'s comment in main.c).
 *
 * ---- Payload layouts (all little-endian) --------------------------------
 *   GUI_CMD_ID_SET_THRESH_VOLT (0x1FF900) DLC 4:
 *     [0:2) ovVoltage_V  u16, 0.01 V/count
 *     [2:4) uvVoltage_V  u16, 0.01 V/count
 *   GUI_CMD_ID_SET_THRESH_CURR (0x1FF901) DLC 4:
 *     [0:2) ocCurrent_A     u16, 0.1 A/count
 *     [2:4) chargeOCLimit_A u16, 0.1 A/count
 *   GUI_CMD_ID_SET_THRESH_TEMP (0x1FF902) DLC 4:
 *     [0:2) otTemp_C  i16, 0.01 degC/count
 *     [2:4) utTemp_C  i16, 0.01 degC/count
 *   GUI_CMD_ID_SET_THRESH_CELL (0x1FF903) DLC 4:
 *     [0:2) cellMax_V u16, 0.001 V/count
 *     [2:4) cellMin_V u16, 0.001 V/count
 *   GUI_CMD_ID_SET_THRESH_DIFF (0x1FF904) DLC 2:
 *     [0:2) cellDiff_mV u16, 1 mV/count
 *   GUI_CMD_ID_ZERO_CAL (0x1FF905) DLC 1:
 *     [0:1) trigger u8 -- ANY value triggers; presence of the frame is
 *           the command, same convention as the 0-byte UART
 *           CLI_CMD_ZERO_CAL. A real payload byte (rather than DLC=0) is
 *           used purely because some CAN tools make a true zero-length
 *           data frame awkward to send by hand.
 *   GUI_CMD_ID_KNOWN_CAL (0x1FF906) DLC 2:
 *     [0:2) known_current_mA i16, 1 mA/count
 *
 * See DFI_BMS_CAN_PacketMap.dbc for the matching signal definitions.
 *
 * ---------------------------------------------------------------------------
 * FIX (this revision): GUI_CMD_ID_RANGE_LOW/HIGH and the seven per-command
 * IDs above were previously only ever written down in this comment block --
 * there was no actual `#define`, fdcan.c had no hardware filter bank
 * covering 0x1FF900-0x1FF906, and HAL_FDCAN_RxFifo0Callback() in main.c
 * never called Process_GuiCmd_Frame() for anything. A frame sent to any of
 * these IDs was silently dropped by the FDCAN acceptance filter before it
 * ever reached software -- this entire feature was unreachable over the
 * bus despite compiling cleanly. All three pieces are fixed as of this
 * revision: the #defines are below, fdcan.c's CANFILT_IDX_GUICMD filter
 * bank now covers 0x1FF900-0x1FF908 (this range PLUS the two new
 * can_cli_bridge.h tunnel IDs immediately above it), and main.c's RX
 * callback dispatches into Process_GuiCmd_Frame() for IDs in this range.
 *
 * NEW in this revision: can_cli_bridge.h adds a generic multi-frame tunnel
 * (CANCLI_ID_REQ/RESP, 0x1FF907/0x1FF908) that carries the *exact same*
 * CLI_CMD_* command set UART2 uses, for every command -- not just fault
 * thresholds and current-sensor calibration. Prefer that for anything new;
 * the seven fixed-format IDs below are kept exactly as documented for
 * whatever already targets them (e.g. an existing BUSMASTER panel), but
 * nothing further will be added to this fixed-format set.
 * ---------------------------------------------------------------------------
 */
#ifndef CAN_GUI_CMDS_H
#define CAN_GUI_CMDS_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdbool.h>

/* ---- Actual per-command extended (29-bit) CAN IDs ---- */
#define GUI_CMD_ID_SET_THRESH_VOLT 0x1FF900UL
#define GUI_CMD_ID_SET_THRESH_CURR 0x1FF901UL
#define GUI_CMD_ID_SET_THRESH_TEMP 0x1FF902UL
#define GUI_CMD_ID_SET_THRESH_CELL 0x1FF903UL
#define GUI_CMD_ID_SET_THRESH_DIFF 0x1FF904UL
#define GUI_CMD_ID_ZERO_CAL        0x1FF905UL
#define GUI_CMD_ID_KNOWN_CAL       0x1FF906UL

/** @brief  Hardware-filter range for this fixed-format command set. Kept
 *          separate from CANCLI_ID_REQ/RESP (can_cli_bridge.h) even though
 *          fdcan.c programs ONE filter bank spanning both -- see
 *          CANFILT_IDX_GUICMD in fdcan.c. */
#define GUI_CMD_ID_RANGE_LOW  GUI_CMD_ID_SET_THRESH_VOLT /* 0x1FF900 */
#define GUI_CMD_ID_RANGE_HIGH GUI_CMD_ID_KNOWN_CAL        /* 0x1FF906 */

/** @brief  Index into g_guiCmdStage[] -- one slot per GUI command ID. */
typedef enum {
  GUI_CMD_SET_THRESH_VOLT = 0,
  GUI_CMD_SET_THRESH_CURR,
  GUI_CMD_SET_THRESH_TEMP,
  GUI_CMD_SET_THRESH_CELL,
  GUI_CMD_SET_THRESH_DIFF,
  GUI_CMD_ZERO_CAL,
  GUI_CMD_KNOWN_CAL,
  GUI_CMD_COUNT
} GuiCmdIndex_t;

/** @brief  ISR->main-loop handoff slot. Structurally identical to, but
 *          intentionally a distinct type from, charger_config.h's
 *          ChargerRxStage_t -- these are two unrelated protocols that
 *          happen to share the same "8 raw bytes + pending flag" Classic
 *          CAN handoff shape; keeping them separate types avoids ever
 *          mixing up which staging array a pointer belongs to. */
typedef struct {
  uint8_t  raw[8];
  uint8_t  len;
  volatile uint8_t pending;   /**< 1 = unread command waiting              */
  uint32_t overrun_count;     /**< ISR latched a new command of this type
                                    before the main loop consumed the
                                    previous one (diagnostic only -- these
                                    are one-shot config writes, not
                                    something you'd send faster than the
                                    main loop drains them)                 */
} GuiCmdStage_t;

extern GuiCmdStage_t g_guiCmdStage[GUI_CMD_COUNT];

/**
 * @brief  ISR-context latch: copies up to 8 raw bytes into
 *         g_guiCmdStage[idx] and sets its pending flag. O(1), no
 *         floating-point math, no function calls out -- safe to call
 *         from HAL_FDCAN_RxFifo0Callback(). If the previous command of
 *         this type was never consumed, it is silently overwritten and
 *         overrun_count is bumped (diagnostic only).
 */
void GuiCmd_LatchRawFrame(GuiCmdIndex_t idx, const uint8_t *data, uint8_t len);

/**
 * @brief  Main-loop-context atomic consume. If a command of this type is
 *         pending, copies its raw bytes/length out (clearing pending) and
 *         returns true; otherwise leaves *out_raw/*out_len untouched and
 *         returns false. Uses the same __disable_irq/__enable_irq minimal
 *         critical section as Charger_ProcessStatusFrame() for the same
 *         reason: a plain byte-array copy is NOT atomic on Cortex-M4.
 * @param  idx      Which command slot to check.
 * @param  out_raw  Destination for up to 8 raw payload bytes.
 * @param  out_len  Destination for the payload length actually received.
 */
bool GuiCmd_TryConsume(GuiCmdIndex_t idx, uint8_t *out_raw, uint8_t *out_len);

/**
 * @brief  ISR-context dispatch entry point -- maps an incoming extended
 *         CAN ID in [GUI_CMD_ID_RANGE_LOW, GUI_CMD_ID_RANGE_HIGH] (see
 *         fdcan.h) to a GuiCmdIndex_t and latches it. Call from
 *         HAL_FDCAN_RxFifo0Callback() for any ID in that range -- mirrors
 *         Process_Charger_Frame()'s role for the charger status ID.
 *         Unrecognized IDs inside the range are silently ignored (should
 *         not happen given the hardware filter is programmed to this
 *         exact range, but stays defensive against future drift between
 *         the #defines and this switch).
 */
void Process_GuiCmd_Frame(uint32_t ext_id, uint8_t *data, uint8_t len);

#ifdef __cplusplus
}
#endif

#endif /* CAN_GUI_CMDS_H */
