/**
 * @file    can_cli_bridge.h
 * @brief   Generic CAN 2.0B Extended tunnel for the UART2 CLI protocol.
 *
 * can_gui_cmds.h added a CAN transport for exactly two UART commands
 * (fault thresholds, current-sensor calibration), one fixed-format
 * extended CAN ID per field group. That doesn't scale to "every UART2 CLI
 * command" -- Solterra charger config, SOC config, RTC, error-log
 * readback, device identity, etc. -- without inventing a new fixed frame
 * layout (and burning a new hardware filter or ID) per command.
 *
 * This file instead tunnels the UART2 CLI protocol's actual unit of
 * transfer -- (cmd byte, data[0..N)) -- over Classic CAN's 8-byte payload
 * using a minimal ISO-15765-2-style Single/First/Consecutive-Frame
 * segmentation (no Flow-Control frame -- see "Deliberately no flow
 * control" below). Every existing and future CLI_CMD_* (cli_frame.h) is
 * automatically usable over CAN with zero protocol changes, because both
 * transports feed the exact same CLI_DispatchCommand() switch in main.c.
 *
 * UART2 is completely unaffected: this is an additional transport, not a
 * replacement. CLI_Frame_Send()/CLI_Frame_Process() and everything in
 * cli_frame.c are untouched.
 *
 * ---- Wire format (byte 0 = PCI, top nibble = frame type) ----------------
 *   Virtual payload (VP) = [cmd (1 byte)] + [data (0..CANCLI_MAX_PAYLOAD-1)]
 *
 *   Single Frame   (0x0_): byte0 = 0x00 | L        (L = VP length, 1..7)
 *                           bytes[1..L] = VP
 *   First Frame     (0x1_): byte0 = 0x10 | (L>>8)&0xF, byte1 = L & 0xFF
 *                           (L = total VP length, 8..CANCLI_MAX_PAYLOAD)
 *                           bytes[2..7] = first 6 bytes of VP
 *   Consecutive Frame(0x2_): byte0 = 0x20 | seq (seq: 1..15,0,1,... wrapping)
 *                            bytes[1..7] = next up to 7 bytes of VP
 *
 * ---- Deliberately no flow-control frame ----------------------------------
 * Real ISO-TP adds a Flow-Control frame so a slow receiver can pace a fast
 * sender. Every message on this tunnel is a short, one-shot config
 * read/write or a single telemetry sample (worst case: CLI_CMD_SET_SOC_
 * CONFIG at 101 bytes -> 1 FF + 15 CF = 16 CAN frames, well under 1 ms of
 * bus time even at 250 kbps) -- there is no sustained streaming use case
 * that could ever outrun the receiver's O(1)-per-frame reassembly. Adding
 * FC frames would only add a round-trip and a second hardware filter ID
 * for no real benefit here.
 *
 * ---- Bus-load discipline --------------------------------------------------
 * CanCli_Send() is a no-op unless a CAN-side client has been heard from
 * within CANCLI_CLIENT_TIMEOUT_MS. main.c's 100 ms telemetry block calls it
 * unconditionally alongside every CLI_Frame_Send(); with no CAN GUI
 * attached this costs one cheap tick check and zero bus traffic --
 * DroneCAN, the Solterra charger link, and the Display never see any of
 * this unless a PC is actually connected via PEAK-CAN and talking.
 */
#ifndef CAN_CLI_BRIDGE_H
#define CAN_CLI_BRIDGE_H

#ifdef __cplusplus
extern "C" {
#endif

#include "cli_frame.h" /* CLI_Frame_t, CLI_CMD_* */
#include "stm32g4xx_hal.h"
#include <stdbool.h>
#include <stdint.h>

/* Extended CAN IDs for this tunnel. Chosen immediately after the legacy
 * fixed-format GUI_CMD_ID_* range (can_gui_cmds.h, 0x1FF900-0x1FF906) so
 * ONE hardware filter bank (fdcan.c, CANFILT_IDX_GUICMD) covers both. */
#define CANCLI_ID_REQ  0x1FF907UL /* PC  -> BMS: request/write, any CLI_CMD_* */
#define CANCLI_ID_RESP 0x1FF908UL /* BMS -> PC : reply/telemetry, any CLI_CMD_* */

/** Largest (cmd + data) virtual payload this tunnel will reassemble or
 *  send. Covers every existing CLI command with headroom -- the largest
 *  today is CLI_CMD_SET_SOC_CONFIG at 1 + sizeof(CLI_SOC_Config_Payload_t)
 *  = 101 bytes. */
#define CANCLI_MAX_PAYLOAD 200U

/** How recently a valid request must have arrived on CANCLI_ID_REQ for
 *  CanCli_Send() to treat a CAN-side GUI as attached and actually put
 *  frames on the bus (see "Bus-load discipline" above). The PC GUI simply
 *  needs to poll or ping at least this often while connected. */
#define CANCLI_CLIENT_TIMEOUT_MS 3000U

/** Depth of the reassembled-command queue -- ISR producer, main-loop
 *  consumer. Same rationale as CLI_RX_QUEUE_DEPTH (cli_frame.h): absorbs a
 *  back-to-back multi-command burst from the GUI without dropping the
 *  second command while the first is still being handled. */
#define CANCLI_RX_QUEUE_DEPTH 4U

/**
 * @brief  Diagnostics -- same role as CLI_RxStats_t for the UART path. Add
 *         g_canCliRxStats to Live Expressions while exercising the CAN GUI.
 */
typedef struct {
  uint32_t frames_rx;       /**< Every SF/FF/CF the filter let through     */
  uint32_t msgs_ok;         /**< Fully reassembled messages queued         */
  uint32_t rej_seq;         /**< CF sequence-number mismatch -> dropped    */
  uint32_t rej_len;         /**< SF/FF length field out of range           */
  uint32_t rej_orphan_cf;   /**< CF with no FF session in progress         */
  uint32_t queue_drops;     /**< Reassembled message lost, RX queue full   */
} CanCli_RxStats_t;

extern volatile CanCli_RxStats_t g_canCliRxStats;

/**
 * @brief  ISR-context entry point. Call for every RX FIFO0 frame whose
 *         Identifier == CANCLI_ID_REQ (see HAL_FDCAN_RxFifo0Callback in
 *         main.c). Reassembles SF/FF/CF; on a fully-reassembled message,
 *         pushes it onto the RX queue for CanCli_Process(). O(1), no
 *         floating point, no calls out -- ISR-safe like every other CAN
 *         latch in this project (GuiCmd_LatchRawFrame(),
 *         Charger_LatchRawFrame()).
 * @param  data  Raw CAN payload bytes (RxHeader.DataLength of them).
 * @param  len   Number of valid bytes in data (0..8).
 */
void CanCli_RxFrame(const uint8_t *data, uint8_t len);

/**
 * @brief  Main-loop pop -- same contract as CLI_Frame_Process(): copies the
 *         oldest queued reassembled command into *frame and returns true,
 *         or leaves *frame untouched and returns false if the queue is
 *         empty. Drain in a loop up to CANCLI_RX_QUEUE_DEPTH times per
 *         main-loop iteration, same reasoning as the UART path.
 */
bool CanCli_Process(CLI_Frame_t *frame);

/**
 * @brief  Segment and transmit (cmd, data, len) over CANCLI_ID_RESP.
 *         No-op (returns HAL_OK immediately) if CanCli_ClientActive() is
 *         false -- see "Bus-load discipline" in the file header comment.
 *         Each CAN segment is sent with a bounded busy-wait on TX FIFO
 *         free level (a few hundred iterations, not HAL_MAX_DELAY) -- this
 *         is the CAN-side equivalent of CLI_Frame_Send()'s "blocking TX"
 *         on UART, capped so a dead/saturated bus can never hang the main
 *         loop.
 * @retval HAL_OK     sent (or intentionally skipped -- no client attached)
 * @retval HAL_ERROR  len too large for CANCLI_MAX_PAYLOAD, or the TX FIFO
 *                    never freed up within the bounded wait
 */
HAL_StatusTypeDef CanCli_Send(uint8_t cmd, const uint8_t *data, uint16_t len);

/**
 * @brief  true if a CAN-side client has sent a valid request within the
 *         last CANCLI_CLIENT_TIMEOUT_MS.
 */
bool CanCli_ClientActive(void);

#ifdef __cplusplus
}
#endif

#endif /* CAN_CLI_BRIDGE_H */
