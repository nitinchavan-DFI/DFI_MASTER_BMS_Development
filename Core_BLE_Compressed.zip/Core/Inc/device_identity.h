/**
 * @file    device_identity.h
 * @brief   BMS Serial Number / Pack Serial Number / Product ID.
 *
 * Small standalone module, same shape as every other "one live RAM copy,
 * loaded from CalibStore_Data_t at boot, written back on
 * SaveSystemStateToFlash()" subsystem in this project (compare
 * g_charger_config in charger_config.h). Kept out of main.c on purpose --
 * this has no periodic tick, no ISR, nothing but get/set/validate, so it
 * doesn't need to live in the giant file.
 *
 * Reachable from BOTH transports (UART2 CLI and the CAN 2.0B Extended
 * tunnel, can_cli_bridge.h) because CLI_CMD_SET_DEVICE_IDS /
 * CLI_CMD_GET_DEVICE_IDS are handled in main.c's shared
 * CLI_DispatchCommand(), which both transports call into.
 */
#ifndef DEVICE_IDENTITY_H
#define DEVICE_IDENTITY_H

#ifdef __cplusplus
extern "C" {
#endif

#include "cli_frame.h" /* CLI_DeviceIdentity_t */
#include <stdbool.h>

/**
 * @brief  Populate id with the factory-default identity (empty serials,
 *         productId = 0). Call once at boot when flash has no valid
 *         record yet (mirrors ChargerConfig_LoadDefaults()).
 */
void DeviceIdentity_LoadDefaults(CLI_DeviceIdentity_t *id);

/**
 * @brief  Overwrite the live in-RAM copy from a freshly-loaded
 *         CalibStore_Data_t at boot. Does no validation -- flash already
 *         passed CRC by the time this is called; call
 *         DeviceIdentity_LoadDefaults() instead if that load failed.
 */
void DeviceIdentity_RestoreFromFlash(const CLI_DeviceIdentity_t *stored);

/**
 * @brief  Copy the current live identity out.
 */
void DeviceIdentity_Get(CLI_DeviceIdentity_t *out);

/**
 * @brief  Validate and apply a new identity to the live RAM copy.
 *         RAM only -- same convention as every other config write on this
 *         bus (fault thresholds, SOC config, charger config): persist
 *         explicitly with CLI_CMD_SAVE_CAL / SaveSystemStateToFlash().
 *
 *         Validation: all three string fields (bmsSerialNumber,
 *         packSerialNumber, mfgDate) must each be either all-zero
 *         (cleared) or printable 7-bit ASCII (0x20-0x7E), and the last
 *         byte of each is force-set to '\0' regardless of what was sent,
 *         so a non-terminated write can never propagate into a string
 *         later code treats as NUL-terminated (e.g. an ErrorLog_Add()
 *         message built from it). mfgDate is free-form ASCII (e.g.
 *         "06-08-2026"), not a parsed/validated date. productId has no
 *         range restriction -- it's an opaque numeric identifier.
 *
 * @retval true   applied
 * @retval false  rejected (non-printable byte found); live copy unchanged
 */
bool DeviceIdentity_Set(const CLI_DeviceIdentity_t *in);

/**
 * @brief  Direct pointer to the live copy, for SaveSystemStateToFlash() to
 *         read without an extra struct copy -- same pattern as
 *         Fault_GetThresholds() / CurrentSensor_GetData().
 */
const CLI_DeviceIdentity_t *DeviceIdentity_GetPtr(void);

#ifdef __cplusplus
}
#endif

#endif /* DEVICE_IDENTITY_H */
