/**
 * @file    cli_frame.h
 * @brief   CLI frame protocol – interrupt-driven UART frame decoder/encoder
 *
 * Frame format (little-endian length):
 *   [0xAA][0x55][LEN_L][LEN_H][CMD][DATA...][CHECKSUM][0x0D][0x0A]
 *
 *   - LEN  = total frame length (header + len + cmd + data + checksum + end)
 *   - CHECKSUM = sum(bytes from LEN_L to last DATA byte) & 0xFF
 *   - Min frame = 8 bytes (no data), Max data = 512 bytes
 */

#ifndef CLI_FRAME_H
#define CLI_FRAME_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32g4xx_hal.h"
#include <stdbool.h>
#include <stdint.h>

/* Exported defines ----------------------------------------------------------*/
#define CLI_HEADER_BYTE_1 0xAA
#define CLI_HEADER_BYTE_2 0x55
#define CLI_END_BYTE_1 0x0D
#define CLI_END_BYTE_2 0x0A

#define CLI_MIN_FRAME_LENGTH 8U
#define CLI_MAX_DATA_LENGTH 512U
#define CLI_MAX_FRAME_LENGTH                                                   \
  (CLI_MIN_FRAME_LENGTH + CLI_MAX_DATA_LENGTH) /* 520 */

/* Overhead = header(2) + length(2) + cmd(1) + checksum(1) + end(2) = 8 */
#define CLI_FRAME_OVERHEAD 8U

/**
 * @brief  Depth of the decoded-frame RX queue (ISR producer, main consumer).
 *
 * Was effectively 1: the ISR held a single decoded frame and dropped every
 * further frame until the main loop consumed it.  Because the 100 ms
 * telemetry block issues a dozen *blocking* CLI_Frame_Send() calls, a host
 * burst — "Set Thresholds" immediately followed by "Save to Flash" is the
 * common one — routinely lost the second frame.  From the GUI that is
 * indistinguishable from "the write did not take" / "save does not work".
 * 4 frames ≈ 2 KB of RAM on a 128 KB part.
 *
 * NOTE: the "Set Thresholds then Save to Flash" scenario above described
 * a GUI talking CLI over UART2 -- that no longer happens at all (UART2's
 * old-CLI dispatch is blocked, see main()'s "8. UART2 old-CLI RX"; all
 * config/threshold traffic is CAN-only now, with its own separate
 * CANCLI_RX_QUEUE_DEPTH). This queue is still drained every loop
 * iteration so the ISR-side ring never sits full, but nothing dispatches
 * what comes out of it on UART2 anymore -- kept at this depth regardless
 * since there's no reason to shrink it and no cost to leaving it.
 */
#define CLI_RX_QUEUE_DEPTH 4U

/* ---- Application Command IDs ---- */
#define CLI_CMD_SOC_DATA 0x01 /* STM32 → PC: SOC%, Ah, I, V  (16B) */
#define CLI_CMD_BMS_DATA 0x02 /* STM32 → PC: BMS summary     (32B) */
#define CLI_CMD_TEMP_DATA                                                      \
  0x03 /* STM32 → PC: temperature °C   (4B float)               */
#define CLI_CMD_FAULT_STATUS                                                   \
  0x04 /* STM32 → PC: fault bitmask (uint16,2B) + 9×f32 thresholds (36B) LE */
#define CLI_CMD_RTC_DATA                                                       \
  0x05 /* STM32 -> PC: date/time (6B: YY MM DD hh mm ss) */
#define CLI_CMD_TEMP2_DATA                                                     \
  0x07 /* STM32 → PC: NTC2 temperature °C (4B float)     */
#define CLI_CMD_CELL_EXTREMA 0x08 /* STM32 → PC: min_cell_idx(u8), min_V(f32), max_cell_idx(u8), max_V(f32) (10B) */
#define CLI_CMD_CELL_VOLT_ALL 0x0C /* STM32 → PC: nCells(u8) + n×float32 LE cellV (1-16 cells) */
#define CLI_CMD_ZERO_CAL                                                       \
  0x10 /* PC → STM32: zero calibration                    (0B)   */
#define CLI_CMD_SET_FAULT_THRESH                                               \
  0x20 /* PC → STM32: set fault thresholds.                                */
     /* PAYLOAD SIZE — this comment used to say "24B = 6×float", which is   */
     /* what the GUI was written against, while FaultThresholds_t grew to   */
     /* 9 floats (36 B) when cell OV / cell UV / charge OC were added.  The */
     /* handler demanded >= 36 B, so a 24 B write was dropped in silence.   */
     /* Both are now accepted:                                             */
     /*   24 B = 6×f32 LE: ov_V, uv_V, oc_A, cellDiff_mV, ot_C, ut_C        */
     /*   36 B = the above + cellMax_V, cellMin_V, chargeOC_A               */
     /* In the 36 B form a trailing field that is 0.0f or non-finite means  */
     /* "not supplied — keep the value the BMS is already using", so a GUI  */
     /* that only exposes the original six fields no longer has its whole   */
     /* write rejected.  On success the BMS immediately pushes an unsolicited*/
     /* CLI_CMD_FAULT_STATUS (0x04) frame containing the thresholds now in  */
     /* force, so "Set" can be confirmed by read-back with no extra poll.   */
     /* A rejected or short write is recorded in the error log (0x31).      */
#define CLI_CMD_KNOWN_CAL 0x11     /* PC → STM32: known-I cal    (4B float) */
#define CLI_CMD_SOC_SET_FULL 0x12  /* PC → STM32: SOC = 100%       (0B) */
#define CLI_CMD_SOC_SET_EMPTY 0x13 /* PC → STM32: SOC = 0%         (0B) */
#define CLI_CMD_SAVE_CAL 0x14      /* PC → STM32: save cal to flash (0B) */
#define CLI_CMD_SET_SOC_CONFIG 0x21 /* PC → STM32: configure SOC    (100B) */
     /* This was write-only for a long time -- no GET/readback existed at   */
     /* all, unlike every other config surface on this bus (fault          */
     /* thresholds, charger config, device identity all have a GET +       */
     /* unsolicited echo-after-write). CLI_CMD_GET_SOC_CONFIG /             */
     /* CLI_CMD_SOC_CONFIG_DATA below fix that: a write now always gets an  */
     /* unsolicited SOC_CONFIG_DATA reply too (success -> the new values;   */
     /* rejected by ValidateSocConfig() -> the unchanged old ones), so a    */
     /* GUI can confirm a Set the same way it already can for thresholds.  */
#define CLI_CMD_GET_SOC_CONFIG                                                 \
  0x27 /* PC -> STM32: request current SOC config              (0B)      */
#define CLI_CMD_SOC_CONFIG_DATA                                               \
  0x28 /* STM32 -> PC: SOC config reply (100B, CLI_SOC_Config_Payload_t)  */
#define CLI_CMD_SET_TEMP_CAL 0x15   /* PC → STM32: set temp offset  (4B)   */
#define CLI_CMD_SET_TEMP2_CAL 0x16  /* PC → STM32: set NTC2 temp cal (4B)  */
#define CLI_CMD_SET_RTC 0x30        /* PC -> STM32: set time         (6B) */
#define CLI_CMD_READ_ERROR_LOGS 0x31 /* PC -> STM32: request error logs (0B) */
#define CLI_CMD_FAULT_STATUS 0x04
#define CLI_CMD_RTC_DATA 0x05
#define CLI_CMD_ERROR_LOG_DATA 0x06
#define CLI_CMD_TEMP2_DATA 0x07
#define CLI_CMD_CELL_EXTREMA 0x08
#define CLI_CMD_LC_DATA 0x50 /* STM32 → PC: LC Wh/sec/conf (12B) */
#define CLI_CMD_SET_LC_ZERO 0x51 /* PC → STM32: force LC=0 (0B) */
#define CLI_CMD_SET_SOH 0x52 /* PC → STM32: set SOH% (4B float) */

/* ── System reset / fault clear commands ───────────────────────────────── */
#define CLI_CMD_CLEAR_FAULTS    0x54 /* PC → STM32: clear all latched faults (0B) */
#define CLI_CMD_RESET_STATE     0x55 /* PC → STM32: reset lastDriveState to IDLE (0B) */

/* ── Device identity (BMS serial / pack serial / product ID) ─────────────
 * New in this revision. Persisted in CalibStore_Data_t (calib_store.h) and
 * reachable over BOTH transports — UART2 CLI and the CAN 2.0B Extended
 * tunnel (can_cli_bridge.h) — because both run through the same
 * CLI_DispatchCommand() switch in main.c. Not auto-broadcast on the 100 ms
 * telemetry tick (it doesn't change at runtime); request it explicitly
 * with CLI_CMD_GET_DEVICE_IDS. A SET is RAM-only, same convention as every
 * other config write on this bus — persist explicitly with
 * CLI_CMD_SAVE_CAL (0x14). */
#define CLI_CMD_SET_DEVICE_IDS  0x60 /* PC → STM32: set identity   (48B, CLI_DeviceIdentity_t) */
#define CLI_CMD_GET_DEVICE_IDS  0x61 /* PC → STM32: request identity            (0B)          */
#define CLI_CMD_DEVICE_IDS_DATA 0x62 /* STM32 → PC: identity reply (48B, CLI_DeviceIdentity_t) */

/* ── Manual charger stop/resume override ──────────────────────────────────
 * Neither UART2 nor CAN previously had a way to force the Solterra charger
 * to stop independent of Charger_ComputeCommand()'s automatic CC/CV /
 * thermal-gate / pack-fault logic — CLI_ChargerConfig_t.chargeEnable is
 * documented DEPRECATED, always 1. This adds exactly one thing: a
 * host-settable STOP latch, checked in main.c right before the charger
 * command frame is built.
 *
 * SAFETY: this can only ever force the command to STOP. It can NEVER force
 * a START that bypasses PATH T (thermal gate) or PATH A (pack OV/OT fault)
 * in Charger_ComputeCommand() — clearing the override (mode=0) just hands
 * control back to that same automatic logic. No CAN or UART command can
 * charge a pack through an active safety trip. */
#define CLI_CMD_SET_CHARGER_OVERRIDE  0x63 /* PC → STM32: 1B, 0=AUTO 1=FORCE_STOP        */
#define CLI_CMD_GET_CHARGER_OVERRIDE  0x64 /* PC → STM32: request override state   (0B) */
#define CLI_CMD_CHARGER_OVERRIDE_DATA 0x65 /* STM32 → PC: 1B, 0=AUTO 1=FORCE_STOP        */

/* ── CAN-tunnel keepalive / echo ───────────────────────────────────────────
 * Handler just echoes the payload back on whatever transport it arrived
 * on. Exists so the CAN GUI has an explicit round-trip liveness check
 * independent of the telemetry-mirror timeout (CANCLI_CLIENT_TIMEOUT_MS,
 * can_cli_bridge.h). Harmless over UART2 too. */
#define CLI_CMD_CAN_PING              0x66 /* PC <-> STM32: echo (0-8B)                  */

/* ── UART2 BLE bridge telemetry (dedicated, NOT mirrored to CAN) ──────────
 * UART2 is physically wired to a BLE module for a mobile-app-facing
 * telemetry stream.
 *
 * REVISION 2: the original 6-packet design (0x70-0x75, all float32
 * fields, 71 bytes total across 6 frames -- verified against a
 * "TestBench Transmitter" tool for the first 4 of them) has been
 * RETIRED and replaced with 2 compact packets using scaled integers,
 * mirroring the exact technique the reference payload-structure
 * documents for other tracker products on this platform already use
 * (e.g. cell voltage as a 1-byte value scaled x20, date as 3 raw
 * day/month/year bytes instead of an ASCII string) -- 0x70-0x75 are
 * fully retired, not just deprecated: nothing sends or expects them
 * anymore, and they're free for reuse if a future revision needs new
 * IDs. Total payload dropped from 71 bytes/6 frames to 34 bytes/2
 * frames (~52% smaller) with EQUAL OR BETTER precision than before on
 * every field -- see each packet's field-level comments for the exact
 * scaling used and the real firmware limits it was checked against
 * (fault thresholds, temperature plausibility bounds) to confirm no
 * field can overflow its wire type.
 *
 * Deliberately NEW IDs (0x76/0x77), not a reuse of 0x70-0x75 or of this
 * codebase's existing CLI_CMD_SOC_DATA(0x01)/BMS_DATA(0x02)/TEMP_DATA
 * (0x03)/FAULT_STATUS(0x04) -- avoids ANY chance of the same numeric ID
 * meaning two different byte layouts at different points in this
 * project's history, which is exactly the class of confusion the whole
 * 0x70-0x75 block existed to avoid on the CAN-CLI collision in the
 * first place.
 *
 * As of this revision, the OLD CLI protocol (0x01-0x08, 0x10-0x31, 0x50-
 * 0x66, ...) is CAN-ONLY -- CLI_SendToCan() (main.c, renamed from
 * CLI_SendToAllPorts()) no longer touches UART2 at all, and incoming
 * UART2 frames are drained and discarded rather than dispatched (see "8.
 * UART2 old-CLI RX" in main()). UART2 is now exclusively the BLE bridge:
 * these 2 IDs outbound (via CLI_Frame_Send() directly, 1-second cadence,
 * see the BLE block in main()), and nothing else in either direction.
 * Every existing CAN consumer (bms_can_gui.py) needed zero changes --
 * the full old-CLI command set, including SOC configuration
 * (CLI_CMD_GET_SOC_CONFIG/SET_SOC_CONFIG/SOC_CONFIG_DATA), is completely
 * unaffected on CAN.
 *
 * The BLE-side receiver needs a full rewrite of its decode logic for
 * both IDs -- this is a breaking wire-format change, not an additive
 * one; there is no field-for-field carryover from the old 0x70-0x75
 * layouts to reuse. See BLE_Payload_Structure.docx (Revision 2) for the
 * complete byte-level spec. */
#define CLI_CMD_BLE_LIVE         0x76 /* STM32 → BLE: SOC%(u8), PackV_cV(u16,x100), Current_dA(i16,x10,signed), Temp_C(u8,offset+40), MaxCellV(u8,x20), MaxCellIdx(u8), MinCellV(u8,x20), MinCellIdx(u8), FaultMask(u8: bit0=UV,bit1=OV,bit2=OT1), Status(u8: 0=Idle,1=Charging,2=Discharging), CycleCount(u16), SOH%(u8)   (15B) */
#define CLI_CMD_BLE_BATTERY_INFO 0x77 /* STM32 → BLE: BmsSerialNumber(16B ASCII NUL-padded), MfgDay(u8,1-31), MfgMonth(u8,1-12), MfgYearSince2000(u8,0-99) -- best-effort parse of the free-form DeviceIdentity.mfgDate string, all-zero if it doesn't parse as DD-MM-YYYY (19B) */

#define CLI_CMD_BMS_LIFE 0x0A     /* STM32 → PC: BMS life data (16B) */
#define CLI_CMD_RESET_LIFE 0x53   /* PC → STM32: reset SOH counters (0B) */

/* ---- PC->STM32 ---- */
#define CLI_CMD_ZERO_CAL 0x10
#define CLI_CMD_KNOWN_CAL 0x11
#define CLI_CMD_SOC_SET_FULL 0x12
#define CLI_CMD_SOC_SET_EMPTY 0x13
#define CLI_CMD_SAVE_CAL 0x14
#define CLI_CMD_SET_TEMP_CAL 0x15
#define CLI_CMD_SET_TEMP2_CAL 0x16
#define CLI_CMD_SET_FAULT_THRESH 0x20
#define CLI_CMD_SET_SOC_CONFIG 0x21
#define CLI_CMD_SET_RTC 0x30
#define CLI_CMD_READ_ERROR_LOGS 0x31

/* ---- Solterra charger charge-profile config ---- */
#define CLI_CMD_SET_CHARGER_CONFIG                                            \
  0x22 /* PC -> STM32: set charge profile (20B, see CLI_ChargerConfig_t) */
#define CLI_CMD_GET_CHARGER_CONFIG                                            \
  0x23 /* PC -> STM32: request current charge profile        (0B)       */
#define CLI_CMD_CHARGER_CONFIG_DATA                                           \
  0x24 /* STM32 -> PC: charge profile reply (20B, CLI_ChargerConfig_t)  */
#define CLI_CMD_CHARGER_STATUS_DATA                                           \
  0x25 /* STM32 -> PC: live charger status (20B), sent every 100 ms.       */
      /* Byte map (all little-endian):                                    */
      /*   [0] state u8   0 DISCONNECTED 1 READY 2 CHARGING               */
      /*                  3 FAULT 4 INHIBITED 5 TIMEOUT                   */
      /*   [1] comm_ok u8                                                 */
      /*   [2] last_valid_flags u8 (raw Solterra status flags byte)       */
      /*   [3] reserved u8                                                */
      /*   [4:8)  actual_V f32   (from charger)                           */
      /*   [8:12) actual_I f32   (from charger)                           */
      /*   [12:16) cmd_V_setpoint f32 (what the BMS is commanding)        */
      /*   [16:20) cmd_I_setpoint f32                                     */
      /* Python: struct.unpack('<4Bffff', data)                           */
#define CLI_CMD_CAN_HEALTH_DATA                                               \
  0x26 /* STM32 -> PC: CAN bus health (8B), sent every 100 ms.           */
      /* Added alongside the FDCAN1_HealthCheck() fix for "CAN hangs,    */
      /* only a manual BMS reset fixes it" — that turned out to be       */
      /* sustained Error_Passive with no formal Bus_Off, which the old   */
      /* recovery logic never caught (see fdcan.c). This makes both the  */
      /* cumulative recovery count and live Error_Passive dwell time     */
      /* visible in the GUI, not just after the fact in the Error Logs.  */
      /*   [0:4) bus_off_recovery_count u32 LE                           */
      /*   [4:8) error_passive_seconds  u32 LE (0 = currently healthy)   */
      /* Python: struct.unpack('<2I', data)                              */

/* Exported types ------------------------------------------------------------*/

#pragma pack(push, 1)

typedef struct {
  float pack_uv_limit;
  float battery_capacity_ah;
  float pack_full_voltage;
  float soc_ref[11];
  float pack_ocv[11];
} CLI_SOC_Config_Payload_t;

typedef struct {
  uint8_t year;    // Years since 2000 (0-99)
  uint8_t month;   // 1-12
  uint8_t date;    // 1-31
  uint8_t hours;   // 0-23
  uint8_t minutes; // 0-59
  uint8_t seconds; // 0-59
} RTC_DateTime_t;
#pragma pack(pop)

/**
 * @brief  Solterra charger charge-profile config (PC <-> STM32 <-> Flash).
 *
 * Wire layout (packed, 24 bytes):
 *   float cellVoltageSetpoint_V  4
 *   float chargeCurrentFull_A    4
 *   float cvCutoffCurrent_A      4   NEW — CV phase ends when charger-reported
 *                                        I drops below this value; 0 = disabled
 *   float socTaperStart_pct      4   kept for flash compat, unused in pure CC/CV
 *   uint8_t cellCount            1
 *   uint8_t chargeEnable         1   DEPRECATED, always send 1
 *   uint8_t[2] reserved          2   padding
 * Total = 24 bytes. PC side: struct.pack('<4f2B2x', ...)
 *
 * CC/CV logic (Charger_ComputeCommand):
 *   CC phase : send chargeCurrentFull_A until charger-reported V >= pack target
 *   CV phase : charger holds V at target; BMS sends chargeCurrentFull_A still
 *              (charger self-limits); charging stops when charger-reported I
 *              drops below cvCutoffCurrent_A (CV cutoff / termination current).
 */
#pragma pack(push, 1)
typedef struct {
  float    cellVoltageSetpoint_V; /**< Target per-cell voltage (V/cell)        */
  float    chargeCurrentFull_A;   /**< CC phase current ceiling (A)            */
  float    cvCutoffCurrent_A;     /**< CV termination current (A); 0=disabled  */
  float    socTaperStart_pct;     /**< Reserved / flash compat                 */
  uint8_t  cellCount;             /**< Series cell count (S)                   */
  uint8_t  chargeEnable;          /**< DEPRECATED — ignored, always send 1     */
  uint8_t  reserved[2];           /**< Padding                                 */
} CLI_ChargerConfig_t;
#pragma pack(pop)

/**
 * @brief  BMS/Pack identity (PC <-> STM32 <-> Flash). See CLI_CMD_SET_DEVICE_IDS
 *         / CLI_CMD_GET_DEVICE_IDS / CLI_CMD_DEVICE_IDS_DATA above.
 *
 * Wire layout (packed, 48 bytes): Python side struct.pack('<16s16sI12s', ...).
 * The two serial-number fields are ASCII, NUL-padded if shorter than 15
 * characters; DeviceIdentity_Set() (device_identity.c) force-terminates
 * byte [15] so a malformed write can never produce an unterminated string
 * that later code walks off the end of. mfgDate is the same convention,
 * force-terminated at byte [11] -- free-form ASCII (e.g. "06-08-2026"),
 * not a parsed/validated date, same as the two serial fields. Added after
 * bmsSerialNumber/packSerialNumber/productId already shipped -- see
 * CALIB_STORE_MAGIC's bump in calib_store.h for why old flash records
 * with the smaller 36-byte layout correctly fail validation and fall
 * back to defaults instead of reading garbage into this field.
 */
#pragma pack(push, 1)
typedef struct {
  char     bmsSerialNumber[16];  /**< ASCII, NUL-terminated/padded  */
  char     packSerialNumber[16]; /**< ASCII, NUL-terminated/padded  */
  uint32_t productId;            /**< Numeric product/model ID      */
  char     mfgDate[12];          /**< ASCII, NUL-terminated/padded, free-form (e.g. "06-08-2026") */
} CLI_DeviceIdentity_t;
#pragma pack(pop)


/**
 * @brief  CLI RX diagnostics.
 *
 * Add "g_cliRxStats" to STM32CubeIDE Live Expressions with the GUI connected
 * and clicking "Set Thresholds". It splits the fault in one glance:
 *
 *   bytes == 0                  -> nothing is reaching PB4 at all. Wiring /
 *                                  TX-RX swap / adapter, not firmware.
 *   bytes rises, frames_ok == 0,
 *     rej_checksum rises        -> the host's checksum window does not match
 *                                  this protocol. Compare last_ck_expected
 *                                  with last_ck_received; the BMS sums
 *                                  LEN_L..last DATA byte, i.e. bytes [2..n-4],
 *                                  excluding the 0xAA 0x55 header.
 *   rej_len rises               -> host is sending payload length in the LEN
 *                                  field instead of TOTAL frame length.
 *   rej_header / rej_end rise   -> framing/baud mismatch or partial writes.
 *   frames_ok rises but nothing
 *     changes on the BMS        -> decode is fine; the command handler is
 *                                  rejecting it (check the Error Logs tab).
 *   overrun_events rises        -> bytes are being lost to a starved ISR.
 *   rearm_events != 0           -> the receiver had been disarmed and was
 *                                  recovered (the original failure mode).
 */
typedef struct {
  uint32_t bytes;              /**< Total bytes pulled out of RDR          */
  uint32_t frames_ok;          /**< Complete valid frames queued           */
  uint32_t rej_header;         /**< Bad byte where 0x55 was expected       */
  uint32_t rej_len;            /**< LEN field outside 8..520               */
  uint32_t rej_checksum;       /**< Checksum mismatch                      */
  uint32_t rej_end;            /**< Bad 0x0D / 0x0A terminator             */
  uint32_t overrun_events;     /**< ORE seen (a byte was lost)             */
  uint32_t frame_noise_events; /**< FE / NE / PE seen                      */
  uint32_t rearm_events;       /**< Times the receiver had to be revived   */
  uint32_t queue_drops;        /**< Frames lost to a full RX FIFO          */
  uint8_t  last_good_cmd;      /**< cmd byte of the last accepted frame    */
  uint16_t last_good_len;      /**< payload length of that frame           */
  uint8_t  last_bad_cmd;       /**< cmd byte of the last checksum reject   */
  uint8_t  last_ck_expected;   /**< checksum the BMS computed              */
  uint8_t  last_ck_received;   /**< checksum the host actually sent        */
} CLI_RxStats_t;

extern volatile CLI_RxStats_t g_cliRxStats;

/** @brief  Receiver state machine states */
typedef enum {
  CLI_STATE_WAIT_HEADER1 = 0,
  CLI_STATE_WAIT_HEADER2,
  CLI_STATE_WAIT_LEN_LOW,
  CLI_STATE_WAIT_LEN_HIGH,
  CLI_STATE_RECV_PAYLOAD,
  CLI_STATE_WAIT_END1,
  CLI_STATE_WAIT_END2
} CLI_RxState_t;

/** @brief  Decoded frame ready for application consumption */
typedef struct {
  uint8_t cmd;                       /**< Command byte          */
  uint8_t data[CLI_MAX_DATA_LENGTH]; /**< Payload data          */
  uint16_t data_len;                 /**< Length of payload data */
} CLI_Frame_t;

/* Exported functions --------------------------------------------------------*/

/**
 * @brief  Initialise the CLI frame receiver (starts UART interrupt reception).
 * @param  huart  Pointer to the UART handle (e.g. &huart2)
 */
void CLI_Frame_Init(UART_HandleTypeDef *huart);

/**
 * @brief  Call from the main loop.  Pops the oldest queued frame, if any.
 *
 * @note   Backed by a CLI_RX_QUEUE_DEPTH-deep FIFO, so the caller should
 *         drain in a loop (up to CLI_RX_QUEUE_DEPTH iterations) rather than
 *         handling a single frame per pass — otherwise the queue can only
 *         ever grow shallower than the bursts it exists to absorb.
 *
 * @param  frame  Pointer to a CLI_Frame_t that receives the decoded frame
 * @retval true   A valid frame was available and has been copied
 * @retval false  Queue empty
 */
bool CLI_Frame_Process(CLI_Frame_t *frame);

/**
 * @brief  Number of decoded frames discarded because the RX queue was full.
 *         Non-zero means the main loop is not draining fast enough — host
 *         commands are being lost.  Zero is the healthy value.
 */
uint32_t CLI_Frame_GetDropCount(void);

/**
 * @brief  Encode and transmit a CLI frame (blocking TX).
 * @param  cmd   Command byte
 * @param  data  Pointer to payload data (may be NULL if len == 0)
 * @param  len   Length of payload data (0 – CLI_MAX_DATA_LENGTH)
 * @retval HAL_StatusTypeDef  HAL_OK on success
 */
HAL_StatusTypeDef CLI_Frame_Send(uint8_t cmd, const uint8_t *data,
                                 uint16_t len);

/**
 * @brief  CLI UART receive ISR. Call FIRST from USART2_IRQHandler(), before
 *         HAL_UART_IRQHandler(&huart2).
 *
 * Pulls every pending byte straight out of RDR and clears RX error flags
 * itself, so the HAL never manages CLI reception and can never leave the
 * receiver disarmed. By the time HAL_UART_IRQHandler() runs there is nothing
 * left for it to see, so it becomes a no-op for RX and continues to behave
 * exactly as before for TX.
 */
void CLI_Frame_IRQHandler(void);

/**
 * @brief  Re-enable the CLI receiver without disturbing the decoded-frame
 *         FIFO. Safe to call from ISR or main context, and safe to call
 *         before CLI_Frame_Init().
 *
 * @note   Use this — not CLI_Frame_Init() — from HAL_UART_ErrorCallback().
 *         CLI_Frame_Init() zeroes the RX FIFO, which threw away decoded but
 *         not-yet-consumed host commands on an unrelated line glitch.
 */
void CLI_Frame_Rearm(void);

/**
 * @brief  Retained for source compatibility; now a no-op.
 *
 * CLI reception no longer runs through HAL_UART_Receive_IT(), so the HAL
 * RX-complete callback never fires for USART2. The existing call in
 * HAL_UART_RxCpltCallback() can stay where it is.
 */
void CLI_Frame_RxCallback(UART_HandleTypeDef *huart);

#ifdef __cplusplus
}
#endif

#endif /* CLI_FRAME_H */
