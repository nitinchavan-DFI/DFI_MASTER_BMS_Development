/**
 * @file soh_estimator.h
 * @brief Automotive-grade SOH (State of Health) estimator for STM32G474 BMS
 * 
 * ISO 26262/IEC 62133 compliant. Three-method fusion with validity gates.
 * Single-instance OOP design: SOH_Handle_t holds all state.
 */

#ifndef SOH_ESTIMATOR_H
#define SOH_ESTIMATOR_H

#ifdef __cplusplus
extern "C" {
#endif

#include "soh_config.h"
#include "fault_detector.h"
#include "soc.h"
#include <stdint.h>
#include <stdbool.h>

/* ----- Public Types ----- */

/**
 * @brief BMS_LifeData_t - EXACTLY matches UART CLI frame CMD 0x0A (16B)
 *        Packed, little-endian. Padding ensures sizeof==16.
 */
typedef struct __attribute__((packed)) {
    float    soh_percent;       /* 0-100% fused SOH */
    uint16_t cycles;            /* Full cycle count */
    float    life_years;        /* Remaining calendar life (years) */
    uint32_t total_ah_cycled;   /* Cumulative Ah throughput */
    uint8_t  pad[2];            /* Padding to 16 bytes */
} BMS_LifeData_t;

/**
 * @brief SOH_FlashData_t - Persistent state (~72B, CRC16 protected)
 */
typedef struct __attribute__((packed)) {
    uint32_t  magic;                /* SOH_FLASH_MAGIC */
    uint16_t  version;              /* SOH_FLASH_VERSION */
    uint16_t  cycles;
    float     soh_percent;
    float     soh_cap;              /* Capacity method */
    float     soh_r;                /* Resistance method */
    float     q_nominal_ah;
    float     q_last_full_ah;
    float     r_int_new_ohm;
    float     r_int_now_ohm;
    uint32_t  total_ah_cycled;
    float     cumulative_ah_partial;
    uint32_t  rtc_first_use;        /* Unix timestamp first cycle */
    uint32_t  rtc_last_save;
    float     life_years;
    uint8_t   meas_validity;        /* Last SOH_MeasValidity_t */
    uint8_t   config_s;             /* CELL_COUNT */
    uint8_t   pad[1];
    uint16_t  crc16;
} SOH_FlashData_t;

/* Enums */
typedef enum {
    SOH_MEAS_OK       = 0,
    SOH_MEAS_TEMP     = 1,
    SOH_MEAS_CURRENT  = 2,
    SOH_MEAS_SOC      = 3,
    SOH_MEAS_FAULT    = 4,
    SOH_MEAS_SHORT    = 5,
    SOH_MEAS_VOLTAGE  = 6
} SOH_MeasValidity_t;

typedef enum {
    SOH_STATE_IDLE     = 0,
    SOH_STATE_DISCHARGE = 1,
    SOH_STATE_MEAS_VALID = 2,
    SOH_STATE_CHARGE   = 3,
    SOH_STATE_FAULT    = 4,
    SOH_STATE_COLD     = 5
} SOH_State_t;

/* ----- SOH Handle (all state - no globals) ----- */
typedef struct SOH_Handle {
    /* Config */
    float q_nominal_ah;
    float r_int_new_ohm;
    uint8_t series_cells;
    
    /* Persisted state */
    SOH_FlashData_t data;
    bool flash_valid;
    
    /* Runtime state */
    SOH_State_t state;
    float soh_fused;
    float soh_cap;
    float soh_r;
    float soh_cyc;
    SOH_MeasValidity_t last_validity;
    
    /* Cycle tracking */
    float cum_ah_discharged;
    uint32_t meas_start_time;
    float meas_start_soc;
    float avg_temp_meas;
    float meas_ah;
    
    /* Rint rolling buffer */
    float rint_samples[SOH_RINT_WINDOW_SIZE];
    uint8_t rint_idx;
    uint8_t rint_count;
    float rint_now;
    
    /* Life */
    float avg_cycles_year;
    uint32_t flash_last_write;
    
    /* Timestamps */
    uint32_t tick_count;
    uint32_t last_curr_step_time;
    float last_pack_v;
    float last_current_a;
    
} SOH_Handle_t;

/* ----- Public API ----- */
void SOH_Init(SOH_Handle_t *h, float q_nominal_ah, float r_int_new_ohm, uint8_t series_cells);
void SOH_Tick100ms(SOH_Handle_t *h, float current_a, float pack_voltage, float soc_percent, float temp_c, uint16_t fault_mask);
BMS_LifeData_t SOH_GetLifeData(const SOH_Handle_t *h);
void SOH_ResetLifeCounters(SOH_Handle_t *h);
void SOH_SetQNominal(SOH_Handle_t *h, float q_ah);
void SOH_SetRintNew(SOH_Handle_t *h, float r_ohm);
void SOH_SetPercent(SOH_Handle_t *h, float soh_pct);
float SOH_GetPercent(const SOH_Handle_t *h);
SOH_State_t SOH_GetState(const SOH_Handle_t *h);
SOH_MeasValidity_t SOH_GetLastValidity(const SOH_Handle_t *h);

#ifdef __cplusplus
}
#endif

#endif /* SOH_ESTIMATOR_H */

