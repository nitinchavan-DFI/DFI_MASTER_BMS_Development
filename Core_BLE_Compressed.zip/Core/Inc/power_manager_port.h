/**
  ******************************************************************************
  * @file    power_manager_port.h
  * @brief   Board porting layer for the deep-sleep subsystem.
  *
  * Everything the state machine needs from the hardware sits behind this
  * interface. power_manager.c contains no board knowledge; power_manager_port.c
  * contains all of it. Port that one file and the state machine is untouched.
  ******************************************************************************
  */

#ifndef POWER_MANAGER_PORT_H
#define POWER_MANAGER_PORT_H

#include <stdint.h>
#include <stdbool.h>

/* --- Power rails ---------------------------------------------------------- */

/** Enable/disable the ACS37610 current sensor rail. */
void PMP_SenseRail(bool on);

/** Enable/disable the gated pack-voltage divider. */
void PMP_VDivRail(bool on);

/** Enable/disable the Daly slave / AFE rail. */
void PMP_DalyRail(bool on);

/** Drive every mA-class rail off in one call, in a safe order. */
void PMP_AllRailsOff(void);

/** Bring every rail back up and allow settling. Blocking. */
void PMP_AllRailsOn(void);

/* --- CAN ------------------------------------------------------------------ */

/** Put FDCAN1 and the transceiver into their low-power states and re-map
  * FDCAN1_RX from alternate function to EXTI falling edge so bus activity
  * wakes the MCU from Stop 1. */
void PMP_CanEnterSleep(void);

/** Restore FDCAN1_RX to alternate function, wake the transceiver, and re-init
  * FDCAN1. Must be called only after the 170 MHz clock tree is restored,
  * because the bit timing depends on it. */
void PMP_CanExitSleep(void);

/** True if the CAN bus is currently dominant. Entering Stop while the bus is
  * dominant produces an immediate wake and a busy loop. */
bool PMP_CanBusIsDominant(void);

/* --- Serial flash --------------------------------------------------------- */

void PMP_FlashEnterDeepPowerDown(void);
void PMP_FlashExitDeepPowerDown(void);

/* --- Measurement --------------------------------------------------------- */

/** Take one pack-voltage reading. Assumes the divider rail is already up and
  * settled. Returns false if the reading is not trustworthy, in which case
  * the state machine treats it as "no new information" rather than as a
  * fault -- a stalled Daly link must never be able to fake a UV trip. */
bool PMP_MeasurePackVoltage(float *volts);

/** Take one pack-current reading, signed. Same trust contract as above. */
bool PMP_MeasureCurrent(float *amps);

/** Power up the sense rails, wait out the settling time, take both readings,
  * power the rails back down. This is the duty-cycled measurement that keeps
  * the 10 mA sensor out of the average current budget. Blocking for roughly
  * PM_SENSE_SETTLE_MS. */
bool PMP_SampleOnce(float *volts, float *amps);

/* --- Indication ---------------------------------------------------------- */

void PMP_FaultLed(bool on);

/** Publish the UV fault on CAN during an indication window. Wakes the
  * transceiver, sends, and returns it to low power. */
void PMP_IndicateOnCan(uint8_t uv_stage, float pack_v);

/* --- Wake button --------------------------------------------------------- */

/** True while the wake button is physically pressed, polarity-corrected. */
bool PMP_WakeButtonPressed(void);

/* --- Contactors / FETs --------------------------------------------------- */

/** Force charge and discharge paths open before sleeping. The state machine
  * will not sleep with the pack live under software control. */
void PMP_OpenPowerPath(void);

/* --- Peripheral suspend / resume ---------------------------------------- */

/** Stop the UARTs, ADC, timers, QSPI and anything else that must not be left
  * clocked or driving a pin across Stop 1. */
void PMP_PeripheralsSuspend(void);

/** Re-initialise everything PMP_PeripheralsSuspend() tore down. Called after
  * the clock tree is back to 170 MHz. */
void PMP_PeripheralsResume(void);

/** Park unused GPIO in analog mode. Preserves wake pins, rail-enable pins,
  * the LSE pins and (optionally) SWD. */
void PMP_ParkGpio(void);
void PMP_RestoreGpio(void);

/* --- Clock tree ---------------------------------------------------------- */

/** Restore the 170 MHz PLL clock tree. Stop-mode exit always lands on HSI16
  * with the PLL off, so this must run before any peripheral whose timing was
  * calculated against 170 MHz is used -- FDCAN bit timing above all. Getting
  * this wrong is exactly the failure that produced complete bus silence when
  * the kernel clock was assumed to be 80 MHz. */
void PMP_RestoreClocks(void);

/* --- Watchdog ------------------------------------------------------------ */

void PMP_WatchdogKick(void);

#endif /* POWER_MANAGER_PORT_H */
