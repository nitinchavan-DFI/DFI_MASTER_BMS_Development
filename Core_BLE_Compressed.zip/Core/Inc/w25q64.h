/**
 * @file    w25q64.h
 * @brief   W25Q64FVSSIG QSPI NOR Flash Driver for STM32G4
 * @author  Auto-generated
 *
 * Driver for Winbond W25Q64FV 64-Mbit (8 MB) serial NOR flash
 * connected via the STM32 QUADSPI peripheral.
 */

#ifndef W25Q64_H
#define W25Q64_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ----------------------------------------------------------------- */
#include "stm32g4xx_hal.h"
#include <stdbool.h>
#include <stdint.h>

/* ========================================================================== */
/*                          Flash Geometry */
/* ========================================================================== */

#define W25Q64_FLASH_SIZE (8U * 1024U * 1024U) /**< 8 MB total          */
#define W25Q64_PAGE_SIZE 256U                  /**< 256 B per page      */
#define W25Q64_SECTOR_SIZE (4U * 1024U)        /**< 4 KB per sector     */
#define W25Q64_BLOCK_32K_SIZE (32U * 1024U)    /**< 32 KB block         */
#define W25Q64_BLOCK_64K_SIZE (64U * 1024U)    /**< 64 KB block         */
#define W25Q64_SECTOR_COUNT 2048U              /**< Total sectors       */
#define W25Q64_PAGE_COUNT (W25Q64_FLASH_SIZE / W25Q64_PAGE_SIZE)

/* ========================================================================== */
/*                       W25Q64 Command Opcodes */
/* ========================================================================== */

/* --- Identification ------------------------------------------------------- */
#define W25Q64_CMD_JEDEC_ID 0x9FU  /**< Read JEDEC ID (MFR + DevID)  */
#define W25Q64_CMD_UNIQUE_ID 0x4BU /**< Read 64-bit Unique ID        */

/* --- Status Registers ----------------------------------------------------- */
#define W25Q64_CMD_READ_SR1 0x05U  /**< Read Status Register-1       */
#define W25Q64_CMD_READ_SR2 0x35U  /**< Read Status Register-2       */
#define W25Q64_CMD_READ_SR3 0x15U  /**< Read Status Register-3       */
#define W25Q64_CMD_WRITE_SR1 0x01U /**< Write Status Register-1      */
#define W25Q64_CMD_WRITE_SR2 0x31U /**< Write Status Register-2      */
#define W25Q64_CMD_WRITE_SR3 0x11U /**< Write Status Register-3      */

/* --- Write Control -------------------------------------------------------- */
#define W25Q64_CMD_WRITE_ENABLE 0x06U   /**< Write Enable                 */
#define W25Q64_CMD_WRITE_DISABLE 0x04U  /**< Write Disable                */
#define W25Q64_CMD_VOLATILE_SR_WE 0x50U /**< Volatile SR Write Enable     */

/* --- Read Data ------------------------------------------------------------ */
#define W25Q64_CMD_READ 0x03U               /**< Read Data (SPI, up to 50 MHz)*/
#define W25Q64_CMD_FAST_READ 0x0BU          /**< Fast Read (1-1-1)            */
#define W25Q64_CMD_FAST_READ_QUAD_OUT 0x6BU /**< Fast Read Quad Output         \
                                               (1-1-4)*/
#define W25Q64_CMD_FAST_READ_QUAD_IO 0xEBU  /**< Fast Read Quad I/O  (1-4-4)  */

/* --- Page Program --------------------------------------------------------- */
#define W25Q64_CMD_PAGE_PROGRAM 0x02U      /**< Page Program (1-1-1)         */
#define W25Q64_CMD_QUAD_PAGE_PROGRAM 0x32U /**< Quad Page Program (1-1-4) */

/* --- Erase ---------------------------------------------------------------- */
#define W25Q64_CMD_SECTOR_ERASE 0x20U    /**< Sector Erase   (4 KB)        */
#define W25Q64_CMD_BLOCK_ERASE_32K 0x52U /**< Block Erase    (32 KB)       */
#define W25Q64_CMD_BLOCK_ERASE_64K 0xD8U /**< Block Erase    (64 KB)       */
#define W25Q64_CMD_CHIP_ERASE 0xC7U      /**< Chip Erase                   */

/* --- Reset ---------------------------------------------------------------- */
#define W25Q64_CMD_ENABLE_RESET 0x66U /**< Enable Reset                 */
#define W25Q64_CMD_RESET_DEVICE 0x99U /**< Reset Device                 */

/* --- Power ---------------------------------------------------------------- */
#define W25Q64_CMD_POWER_DOWN 0xB9U         /**< Power Down                   */
#define W25Q64_CMD_RELEASE_POWER_DOWN 0xABU /**< Release Power Down / Dev ID   \
                                             */

/* ========================================================================== */
/*                       Status Register Bit Masks */
/* ========================================================================== */

#define W25Q64_SR1_BUSY 0x01U /**< Erase/Write In Progress      */
#define W25Q64_SR1_WEL 0x02U  /**< Write Enable Latch           */
#define W25Q64_SR2_QE 0x02U   /**< Quad Enable bit (SR2 bit 1)  */

/* ========================================================================== */
/*                       JEDEC ID Expected Values */
/* ========================================================================== */

#define W25Q64_MANUFACTURER_ID 0xEFU /**< Winbond                      */
#define W25Q64_DEVICE_ID 0x4017U     /**< W25Q64FV                     */

/* ========================================================================== */
/*                        Timeout Values (ms) */
/* ========================================================================== */

#define W25Q64_TIMEOUT_DEFAULT 1000U      /**< General command timeout      */
#define W25Q64_TIMEOUT_SECTOR_ERASE 400U  /**< Sector erase typ. 45 ms      */
#define W25Q64_TIMEOUT_BLOCK_ERASE 2000U  /**< Block erase typ. 120-150 ms  */
#define W25Q64_TIMEOUT_CHIP_ERASE 100000U /**< Chip erase typ. 20-40 s      */
#define W25Q64_TIMEOUT_PAGE_PROGRAM 10U   /**< Page program typ. 0.7 ms     */

/* ========================================================================== */
/*                          Return Type */
/* ========================================================================== */

/**
 * @brief Driver return status codes.
 */
typedef enum {
  W25Q64_OK = 0x00U,      /**< Operation completed successfully */
  W25Q64_ERROR = 0x01U,   /**< Generic error                    */
  W25Q64_BUSY = 0x02U,    /**< Device is busy                   */
  W25Q64_TIMEOUT = 0x03U, /**< Operation timed out              */
} W25Q64_StatusTypeDef;

/* ========================================================================== */
/*                          Public API */
/* ========================================================================== */

/**
 * @brief  Initialise the W25Q64 flash device.
 *         Performs a software reset, verifies the JEDEC ID, and enables
 *         Quad SPI mode (sets QE bit in Status Register 2).
 * @param  hqspi  Pointer to an initialised QSPI_HandleTypeDef.
 * @retval W25Q64_OK on success.
 */
W25Q64_StatusTypeDef W25Q64_Init(QSPI_HandleTypeDef *hqspi);

/**
 * @brief  Read the JEDEC Manufacturer + Device ID.
 * @param  hqspi  QSPI handle.
 * @param  pID    Pointer to a uint32_t that receives the 3-byte ID
 *                (Manufacturer[23:16] | MemType[15:8] | Capacity[7:0]).
 * @retval W25Q64_OK on success.
 */
W25Q64_StatusTypeDef W25Q64_ReadID(QSPI_HandleTypeDef *hqspi, uint32_t *pID);

/* ----- Read --------------------------------------------------------------- */

/**
 * @brief  Standard SPI Read (1-1-1 mode, command 0x03).
 * @param  hqspi    QSPI handle.
 * @param  pData    Destination buffer.
 * @param  address  24-bit start address in flash.
 * @param  size     Number of bytes to read.
 * @retval W25Q64_OK on success.
 */
W25Q64_StatusTypeDef W25Q64_Read(QSPI_HandleTypeDef *hqspi, uint8_t *pData,
                                 uint32_t address, uint32_t size);

/**
 * @brief  Quad Output Fast Read (1-1-4 mode, command 0x6B).
 *         Requires Quad Enable (QE) bit to be set.
 * @param  hqspi    QSPI handle.
 * @param  pData    Destination buffer.
 * @param  address  24-bit start address in flash.
 * @param  size     Number of bytes to read.
 * @retval W25Q64_OK on success.
 */
W25Q64_StatusTypeDef W25Q64_FastReadQuad(QSPI_HandleTypeDef *hqspi,
                                         uint8_t *pData, uint32_t address,
                                         uint32_t size);

/* ----- Write -------------------------------------------------------------- */

/**
 * @brief  Program a single page (up to 256 bytes).
 *         The caller MUST ensure `address` and `address + size - 1` lie
 *         within the same 256-byte page boundary.
 * @param  hqspi    QSPI handle.
 * @param  pData    Source data buffer.
 * @param  address  24-bit start address (must be page-aligned for full page).
 * @param  size     Number of bytes to write (1..256).
 * @retval W25Q64_OK on success.
 */
W25Q64_StatusTypeDef W25Q64_WritePage(QSPI_HandleTypeDef *hqspi,
                                      const uint8_t *pData, uint32_t address,
                                      uint32_t size);

/**
 * @brief  Write an arbitrary amount of data across page boundaries.
 *         Internally splits the write into page-sized chunks.
 * @param  hqspi    QSPI handle.
 * @param  pData    Source data buffer.
 * @param  address  24-bit start address.
 * @param  size     Number of bytes to write.
 * @retval W25Q64_OK on success.
 */
W25Q64_StatusTypeDef W25Q64_Write(QSPI_HandleTypeDef *hqspi,
                                  const uint8_t *pData, uint32_t address,
                                  uint32_t size);

/* ----- Erase -------------------------------------------------------------- */

/**
 * @brief  Erase a 4 KB sector.
 * @param  hqspi    QSPI handle.
 * @param  address  Any address within the target sector.
 * @retval W25Q64_OK on success.
 */
W25Q64_StatusTypeDef W25Q64_EraseSector(QSPI_HandleTypeDef *hqspi,
                                        uint32_t address);

/**
 * @brief  Start a 4 KB sector erase and return WITHOUT waiting for it to
 *         complete -- unlike W25Q64_EraseSector(), which blocks for the
 *         full erase time (tens to hundreds of ms per datasheet). The
 *         WREN + erase-command bytes clock out (a few µs) and this
 *         returns; the flash chip then erases autonomously in the
 *         background. Poll W25Q64_IsBusy() (a single fast status-register
 *         read) from your own loop/state machine to find out when it's
 *         actually done -- do NOT start any other flash operation on this
 *         chip until W25Q64_IsBusy() returns false.
 * @param  hqspi    QSPI handle.
 * @param  address  Any address within the target sector.
 * @retval W25Q64_OK if the erase command was accepted, W25Q64_ERROR
 *         otherwise. Says nothing about whether the erase itself has
 *         finished -- that's what W25Q64_IsBusy() is for.
 */
W25Q64_StatusTypeDef W25Q64_EraseSectorStart(QSPI_HandleTypeDef *hqspi,
                                             uint32_t address);

/**
 * @brief  Erase a 32 KB block.
 * @param  hqspi    QSPI handle.
 * @param  address  Any address within the target block.
 * @retval W25Q64_OK on success.
 */
W25Q64_StatusTypeDef W25Q64_EraseBlock32(QSPI_HandleTypeDef *hqspi,
                                         uint32_t address);

/**
 * @brief  Erase a 64 KB block.
 * @param  hqspi    QSPI handle.
 * @param  address  Any address within the target block.
 * @retval W25Q64_OK on success.
 */
W25Q64_StatusTypeDef W25Q64_EraseBlock64(QSPI_HandleTypeDef *hqspi,
                                         uint32_t address);

/**
 * @brief  Erase the entire chip.  This can take up to 100 seconds.
 * @param  hqspi    QSPI handle.
 * @retval W25Q64_OK on success.
 */
W25Q64_StatusTypeDef W25Q64_EraseChip(QSPI_HandleTypeDef *hqspi);

/* ----- Status ------------------------------------------------------------- */

/**
 * @brief  Check if the flash is currently busy.
 * @param  hqspi  QSPI handle.
 * @retval true if BUSY bit is set, false otherwise.
 */
bool W25Q64_IsBusy(QSPI_HandleTypeDef *hqspi);

/**
 * @brief  Blocking wait until the device is ready (BUSY == 0).
 * @param  hqspi      QSPI handle.
 * @param  timeout_ms Maximum wait time in milliseconds.
 * @retval W25Q64_OK on success, W25Q64_TIMEOUT if timed out.
 */
W25Q64_StatusTypeDef W25Q64_WaitForReady(QSPI_HandleTypeDef *hqspi,
                                         uint32_t timeout_ms);

/* ----- Power -------------------------------------------------------------- */

/**
 * @brief  Put the flash into deep power-down mode.
 * @param  hqspi  QSPI handle.
 * @retval W25Q64_OK on success.
 */
W25Q64_StatusTypeDef W25Q64_PowerDown(QSPI_HandleTypeDef *hqspi);

/**
 * @brief  Release the flash from deep power-down mode.
 * @param  hqspi  QSPI handle.
 * @retval W25Q64_OK on success.
 */
W25Q64_StatusTypeDef W25Q64_ReleasePowerDown(QSPI_HandleTypeDef *hqspi);

#ifdef __cplusplus
}
#endif

#endif /* W25Q64_H */
