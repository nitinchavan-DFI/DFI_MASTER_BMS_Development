/**
  ******************************************************************************
  * @file    power_manager_conf.h
  * @brief   Board and policy configuration for the automotive deep-sleep
  *          subsystem on the DFI Mosaic BMS (STM32G474RET6).
  *
  * Board section filled from the actual tree:
  *   main.h            wakeButton PB9 / STB_CAN PC9 / CAN_EN PA8 / LEDs
  *   stm32g4xx_hal_msp.c  FDCAN1 PA11-PA12, QSPI PA2/3/6/7 + PB0/PB1,
  *                        UART5 PC12/PD2, USART2 PB3/PB4, ADC PA0/PB2/PB11
  *   main.c            IWDG presc 64 / reload 2000, RTC on LSI
  *   fault_detector.h  FAULT_UV_DEFAULT 42.0 V
  *
  * Items still marked  >>> HW <<<  depend on parts/rework, not on the source.
  ******************************************************************************
  */

#ifndef POWER_MANAGER_CONF_H
#define POWER_MANAGER_CONF_H

#include "main.h"

/* ==========================================================================
 * 1. UV THRESHOLDS AND THE "NEAR-UV" BAND
 * ==========================================================================
 * PM_UV_TRIP_V matches FAULT_UV_DEFAULT (42.0 V) = 2.625 V/cell on the 16S
 * LiFePO4 pack this build is configured for (DalyBMS_SetCellCount(...,16)).
 *
 * "UV - 1V" in the requirement is read as the band the pack passes through on
 * its way DOWN to the trip, i.e. 1 V ABOVE it, so the ladder starts before
 * the hard trip rather than after. Negate PM_UV_NEAR_MARGIN_V if the literal
 * (UV - 1 V) was meant; the state machine does not care about the sign.
 *
 * PM_UV_CLEAR_V is the recovery threshold and must sit above PM_UV_NEAR_V by
 * a real band, or surface-charge recovery after a load is removed will make
 * the ladder chatter. 0.8 V here is below FAULT_HYST_UV_V (1.0 V) on purpose:
 * the power manager must not declare recovery before fault_detector does.
 * -------------------------------------------------------------------------- */
#define PM_UV_TRIP_V                    (42.0f)     /* = FAULT_UV_DEFAULT     */
#define PM_UV_NEAR_MARGIN_V             (1.0f)
#define PM_UV_NEAR_V                    (PM_UV_TRIP_V + PM_UV_NEAR_MARGIN_V)
#define PM_UV_CLEAR_V                   (PM_UV_NEAR_V + 0.8f)

/* Track fault_detector.h at compile time rather than by hand. */
#define PM_UV_TRACK_FAULT_DETECTOR      (1)

/* ==========================================================================
 * 2. WAKE THRESHOLDS
 * ========================================================================== */
/* Magnitude of pack current that counts as "charge or discharge detected".
 * Must sit above the residual noise of the ACS37610 pipeline after the
 * deadband stage, or sensor noise alone holds the BMS awake and flattens the
 * pack. Measure the sleeping noise floor and set ~5x above it.
 * >>> HW <<< the 37610 is single-ended where the 37612 was differential, so
 * the old noise figure does not carry over. Re-measure after the rework. */
#define PM_WAKE_CURRENT_A               (0.5f)

/* Consecutive qualifying samples before a current wake is accepted. Single-
 * sample wake on a duty-cycled sensor is a false-wake generator. */
#define PM_WAKE_CURRENT_CONFIRM_CNT     (2U)

/* ==========================================================================
 * 3. TIMING POLICY
 * ==========================================================================
 * PM_TICK_SECONDS is the master heartbeat of the sleeping BMS. Three jobs:
 *   (a) kick the IWDG. The IWDG runs in Stop on STM32G4 and cannot be
 *       disabled once started. THIS BUILD: prescaler 64, reload 2000, LSI
 *       32 kHz -> period = 64 * 2001 / 32000 = 4.002 s. Any RTC sleep longer
 *       than that resets the MCU.
 *   (b) advance the software stage counter, which sidesteps the RTC wake-up
 *       timer's 18.2 h ceiling in CK_SPRE_16BITS mode entirely.
 *   (c) provide the sample point for the duty-cycled V/I measurement.
 *
 * BUDGET: the RTC on this board is clocked from LSI with AsynchPrediv 127 /
 * SynchPrediv 255 = 32768 divisions, but LSI is 32 000 Hz, so ck_spre is
 * 0.9766 Hz and one "RTC second" is really 1.024 s. 3 ticks = 3.07 s, which
 * leaves 23 % margin under the 4.002 s IWDG. 4 would leave 2 %. Do not raise
 * this above 3 without also lengthening the IWDG period.
 *
 * Sensor-rail cost at 10 mA, once the rework lands:
 *      tick = 1 s -> ~36 uA average, 1 s current-detect latency
 *      tick = 3 s -> ~12 uA average, 3 s latency          (default)
 * -------------------------------------------------------------------------- */
#define PM_TICK_SECONDS                 (3U)        /* < 4.002 s IWDG period  */

/* Compile-time assertion input: measured IWDG period in ms. */
#define PM_IWDG_PERIOD_MS               (4002U)

/* Measure V/I on every Nth tick. 1 = every tick. */
#define PM_MEASURE_EVERY_N_TICKS        (1U)
#define PM_MEASURE_EVERY_N_TICKS_BACKOFF (20U)      /* 20 x 3 s = ~60 s       */

/* Time the sensor rail must be powered before its output is trustworthy:
 * ACS37610 power-on time plus the external RC filter settling time. The RC
 * dominates. >>> HW <<< measure on the bench after the rework. */
#define PM_SENSE_SETTLE_MS              (3U)

/* Inactivity required in ACTIVE before dropping to deep sleep. */
#define PM_INACTIVITY_TIMEOUT_MS        (30000U)

/* Duration of the fault indication window. Requirement: 10 s. */
#define PM_INDICATE_MS                  (10000U)

/* Indication blink profile. A steady LED for 10 s on a near-flat pack is
 * wasted charge; a 10 % duty blink is equally visible for a tenth of it. */
#define PM_INDICATE_LED_ON_MS           (100U)
#define PM_INDICATE_LED_PERIOD_MS       (1000U)

/* Emit fault telemetry on CAN during the indication window as well as
 * blinking. Costs transceiver active current for the window only. */
#define PM_INDICATE_ON_CAN              (1)

/* ==========================================================================
 * 4. THE UV BACKOFF LADDER
 * ==========================================================================
 *   stage 1 ->   5 min      cumulative  5 min
 *   stage 2 ->  30 min      cumulative 35 min
 *   stage 3 ->   1 h        cumulative  1 h 35 min
 *   stage 4 ->  12 h        cumulative 13 h 35 min
 *   stage 5 ->  24 h        cumulative 37 h 35 min  -> HIBERNATE
 *
 * These are counted in PM_TICK_SECONDS units, so the LSI/prediv error above
 * applies: nominal 24 h elapses in ~24.6 h, and up to ~25.9 h with LSI at
 * -5 %. Acceptable for a protection backoff. If it is not, see section 8.
 * -------------------------------------------------------------------------- */
#define PM_UV_LADDER_SECONDS  {          \
            (5UL   * 60UL),              \
            (30UL  * 60UL),              \
            (60UL  * 60UL),              \
            (12UL  * 60UL * 60UL),       \
            (24UL  * 60UL * 60UL)        \
        }

/* Absolute-time guard. The ladder reaches hibernate at ~37.6 h cumulative,
 * not at 24 h. "If the fault stays more than 1 day, protect the battery" is
 * ambiguous between:
 *   0 = LADDER TERMINAL (default). Hibernate after the 24 h stage re-checks
 *       true. Follows the literal stage sequence as specified.
 *   1 = HARD WALL CLOCK. Hibernate as soon as cumulative fault time exceeds
 *       PM_UV_ABS_TIMEOUT_S, cutting the ladder short mid-sequence. */
#define PM_UV_ABS_TIMEOUT_ENABLE        (0)
#define PM_UV_ABS_TIMEOUT_S             (24UL * 60UL * 60UL)

/* A CAN or button wake while the ladder is running does NOT reset it; only a
 * genuine recovery above PM_UV_CLEAR_V does. Set 1 only if any bus traffic
 * should restart from stage 0 -- on a chatty bus that defeats the mechanism.
 * The Solterra charger broadcasts continuously, so leave this at 0. */
#define PM_UV_RESET_LADDER_ON_COMMS     (0)

/* ==========================================================================
 * 5. PIN MAP  (from main.h / stm32g4xx_hal_msp.c -- verified against tree)
 * ========================================================================== */

/* ---- Wake button: PB9, EXTI9_5 ------------------------------------------
 * PB9 is NOT one of the five STM32G474 PWR WKUP pins
 *   WKUP1=PA0  WKUP2=PC13  WKUP3=PE6  WKUP4=PA2  WKUP5=PC5
 * so Standby and Shutdown cannot be woken by it. PM_HIBERNATE_USE_STOP1 is
 * therefore forced to 1 below. Stop 1 costs ~4 uA more than Standby, which
 * is irrelevant against a 100-300 uA budget -- no rework needed for this.
 *
 * POLARITY NOTE: MX_GPIO_Init configures PB9 as GPIO_MODE_IT_RISING with
 * GPIO_PULLUP. Those disagree -- an internal pull-up holds the line high, so
 * a button to GND produces a FALLING edge and the existing rising-edge
 * config only fires on release. Kept as RISING here to preserve the current
 * LedStatus_Wake() behaviour exactly. >>> HW <<< if the button is wired to
 * GND, set PM_WAKE_BTN_ACTIVE_LOW to 1 and PM_WAKE_BTN_EDGE_RISING to 0. */
#define PM_WAKE_BTN_PORT                wakeButton_GPIO_Port    /* GPIOB     */
#define PM_WAKE_BTN_PIN                 wakeButton_Pin          /* GPIO_PIN_9*/
#define PM_WAKE_BTN_EXTI_IRQn           wakeButton_EXTI_IRQn    /* EXTI9_5   */
#define PM_WAKE_BTN_ACTIVE_LOW          (0)
#define PM_WAKE_BTN_EDGE_RISING         (1)
#define PM_WAKE_BTN_DEBOUNCE_MS         (50U)
#define PM_WAKE_BTN_HOLD_MS             (200U)

/* Only meaningful if PM_HIBERNATE_USE_STOP1 is set to 0, which requires
 * physically moving the button to a WKUP pin first. Left defined so that
 * branch still compiles; the value below assumes a move to PC13 = WKUP2. */
#define PM_WAKE_BTN_PWR_WKUP            PWR_WAKEUP_PIN2

/* Forced to 1: PB9 is not a WKUP pin. Do not set 0 without moving the button
 * to PA0, PC13, PE6, PA2 or PC5 -- hibernate would become unwakeable and the
 * pack would need a physical disconnect to recover. */
#define PM_HIBERNATE_USE_STOP1          (1)

/* ---- FDCAN1 RX (PA11), re-purposed as an EXTI wake line while asleep ----
 * FDCAN cannot receive in Stop mode on STM32G4. PA11 is switched from AF9 to
 * EXTI falling edge so the first dominant bit wakes the MCU. THE FRAME THAT
 * CAUSED THE WAKE IS LOST -- the peer must retry. */
#define PM_CAN_RX_PORT                  GPIOA
#define PM_CAN_RX_PIN                   GPIO_PIN_11
#define PM_CAN_RX_AF                    GPIO_AF9_FDCAN1
#define PM_CAN_RX_EXTI_IRQn             EXTI15_10_IRQn

/* ---- CAN transceiver: STB on PC9, EN on PA8 -----------------------------
 * MX_GPIO_Init leaves STB_CAN low and CAN_EN high, so low STB = normal mode
 * and standby is STB high. EN is left asserted through sleep so the receiver
 * stays biased and can flag a bus wake on RXD.
 * >>> HW <<< confirm the fitted part has a low-power mode WITH bus wake-up.
 * TJA1042/1043/1145 and TCAN1042/1043 do (~10-20 uA). A bare TJA1050 or
 * SN65HVD230 does not, and leaves ~10 mA on the rail no matter what the
 * firmware does -- that alone breaks the target. */
#define PM_CAN_STB_PORT                 STB_CAN_GPIO_Port       /* GPIOC     */
#define PM_CAN_STB_PIN                  STB_CAN_Pin             /* GPIO_PIN_9*/
#define PM_CAN_STB_STANDBY_LEVEL        GPIO_PIN_SET
#define PM_CAN_STB_NORMAL_LEVEL         GPIO_PIN_RESET

#define PM_CAN_EN_PORT                  CAN_EN_GPIO_Port        /* GPIOA     */
#define PM_CAN_EN_PIN                   CAN_EN_Pin              /* GPIO_PIN_8*/
#define PM_CAN_EN_SLEEP_LEVEL           GPIO_PIN_SET   /* keep biased        */
#define PM_CAN_EN_NORMAL_LEVEL          GPIO_PIN_SET

/* ==========================================================================
 * 5b. RAILS THAT DO NOT EXIST ON THIS BOARD YET
 * ==========================================================================
 * There is no load switch on the current-sensor rail, no gated pack-voltage
 * divider, and no Daly/AFE rail switch anywhere in MX_GPIO_Init or the MSP.
 * Every port pin the schematic assigns is accounted for:
 *
 *   PA0        ADC1_IN1  (ACS37610 output)
 *   PA1        LED1_D8
 *   PA2/3/6/7  QUADSPI   (W25Q64)
 *   PA8        CAN_EN
 *   PA9/PA10   GREEN_LED / RED_LED
 *   PA11/PA12  FDCAN1_RX / FDCAN1_TX
 *   PA13/PA14  SWD
 *   PB0/PB1    QUADSPI
 *   PB2/PB11   ADC2 (NTC10K x2)
 *   PB3/PB4    USART2 (CLI)
 *   PB9        wakeButton
 *   PC1/2/3    LED4_D11 / LED3_D10 / LED2_D9
 *   PC8/PC9    BLUE_LED / STB_CAN
 *   PC12/PD2   UART5 (Daly)
 *
 * So the three PM_HAS_* flags below are 0 and the corresponding PMP_*Rail()
 * calls compile to nothing. The firmware is correct and safe like this -- it
 * just cannot reach 100-300 uA, because the ACS37610 holds ~10 mA on the rail
 * continuously. See the design document, section "Hardware gap".
 *
 * Free pins on the LQFP64 suitable for the rework: PC0, PC4, PC5, PC6, PC7,
 * PC10, PC11, PC13, PA5, PA15, PB5, PB6, PB7, PB8, PB10, PB12..PB15.
 * Suggested: PC6 = SENSE_EN, PC7 = VDIV_EN, PC10 = DALY_EN.
 * -------------------------------------------------------------------------- */
#define PM_HAS_SENSE_RAIL               (0)     /* set 1 after rework */
#define PM_SENSE_EN_PORT                GPIOC
#define PM_SENSE_EN_PIN                 GPIO_PIN_6
#define PM_SENSE_EN_ON_LEVEL            GPIO_PIN_SET

#define PM_HAS_VDIV_RAIL                (0)     /* no MCU-side divider exists */
#define PM_VDIV_EN_PORT                 GPIOC
#define PM_VDIV_EN_PIN                  GPIO_PIN_7
#define PM_VDIV_EN_ON_LEVEL             GPIO_PIN_SET

#define PM_HAS_DALY_RAIL                (0)     /* set 1 after rework */
#define PM_DALY_EN_PORT                 GPIOC
#define PM_DALY_EN_PIN                  GPIO_PIN_10
#define PM_DALY_EN_ON_LEVEL             GPIO_PIN_SET

/* Optional nanopower comparator across the shunt (TS881-class) driving an
 * EXTI. This is the correct automotive answer for current-based wake: it is
 * instantaneous instead of up to PM_TICK_SECONDS late, and it removes the
 * duty-cycled sensor cost from the budget entirely. Suggested pin PC4. */
#define PM_HAS_CURRENT_COMPARATOR       (0)
#define PM_ICOMP_PORT                   GPIOC
#define PM_ICOMP_PIN                    GPIO_PIN_4
#define PM_ICOMP_EXTI_IRQn              EXTI4_IRQn

/* ---- Fault indication LED: RED_LED on PA10 ------------------------------ */
#define PM_FAULT_LED_PORT               RED_LED_GPIO_Port       /* GPIOA     */
#define PM_FAULT_LED_PIN                RED_LED_Pin             /* GPIO_PIN_10*/
#define PM_FAULT_LED_ON_LEVEL           GPIO_PIN_SET

/* ==========================================================================
 * 6. LOW-POWER HOUSEKEEPING SWITCHES
 * ========================================================================== */
/* Park GPIOs not needed during sleep in analog mode. A floating digital input
 * sitting at mid-rail draws crowbar current through its input buffer; analog
 * mode disconnects the buffer entirely. Worth tens of microamps. */
#define PM_PARK_UNUSED_GPIO             (1)

/* Park PA13/PA14 (SWDIO/SWCLK). Their pull-ups leak, but parking them makes
 * the target undebuggable while asleep. Keep 0 during bring-up. */
#define PM_DISABLE_SWD_IN_SLEEP         (0)

/* Send the W25Q64 a Deep Power-Down (0xB9) before sleeping: standby ~15 uA ->
 * DPD ~1 uA. W25Q64_PowerDown() / W25Q64_ReleasePowerDown() already exist in
 * w25q64.h; the release path needs tRES1 (~3 us) before the first access. */
#define PM_FLASH_DEEP_POWER_DOWN        (1)

/* IWDG is enabled in this build (MX_IWDG_Init is called unconditionally). */
#define PM_IWDG_ENABLED                 (1)

/* ==========================================================================
 * 7. BACKUP REGISTER ALLOCATION
 * ==========================================================================
 * Ladder state must survive an unexpected reset (IWDG, BOR) so a brownout on
 * a dying pack cannot silently restart protection from stage 0. STM32G4 keeps
 * these in the TAMP block. Checked against the tree: nothing else in this
 * firmware writes RTC_BKP_DRx -- CalibStore, ChargerConfig and ErrorLog all
 * persist to the external W25Q64, not to backup registers. DR8..DR12 are free.
 * -------------------------------------------------------------------------- */
#define PM_BKP_MAGIC_REG                RTC_BKP_DR8
#define PM_BKP_PACKED_REG               RTC_BKP_DR9
#define PM_BKP_STAGE_ELAPSED_REG        RTC_BKP_DR10
#define PM_BKP_CUMULATIVE_REG           RTC_BKP_DR11
#define PM_BKP_CHECKSUM_REG             RTC_BKP_DR12

#define PM_BKP_MAGIC_VALUE              (0x424D5301UL)      /* "BMS", rev 1 */

/* ==========================================================================
 * 8. RTC ACCURACY (informational -- fix lives in MX_RTC_Init)
 * ==========================================================================
 * MX_RTC_Init uses AsynchPrediv 127 / SynchPrediv 255 = 32768 divisions.
 * That is correct for a 32.768 kHz LSE. This board runs the RTC from LSI,
 * which is 32 000 Hz on STM32G4, so ck_spre is 32000/32768 = 0.9766 Hz and
 * every RTC second is 1.024 s long -- the clock runs 2.4 % slow. That affects
 * the existing CLI_CMD_RTC_DATA timestamps and the error log, not just this
 * module.
 *
 * To correct it, in MX_RTC_Init:
 *     hrtc.Init.AsynchPrediv = 124;   // (124+1) * (255+1) = 32000
 *     hrtc.Init.SynchPrediv  = 255;
 * LSI's own +/-5 % tolerance remains and cannot be trimmed away; only an LSE
 * crystal fixes that. PM_RTC_LSI_COMPENSATE below scales the ladder in
 * software so the stages land on real time even with the 32768 prediv left
 * as-is. Set 0 if you apply the prediv fix above.
 * -------------------------------------------------------------------------- */
#define PM_RTC_USES_LSE                 (0)     /* this board: LSI */
#define PM_RTC_LSI_COMPENSATE           (1)
#define PM_RTC_LSI_HZ                   (32000UL)
#define PM_RTC_PREDIV_TOTAL             (32768UL)

#endif /* POWER_MANAGER_CONF_H */
