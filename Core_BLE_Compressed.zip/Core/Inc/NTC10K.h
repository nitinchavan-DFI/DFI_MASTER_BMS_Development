/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : NTC10K.h
 * @brief          : NTC10K thermistor driver — public API
 *
 * Circuit assumption:
 *   VCC (3.3V)
 *     |
 *   [SERIES_R = 10K]
 *     |
 *     +----> ADC pin (PB2 / ADC2_CH12)
 *     |
 *   [NTC 10K]
 *     |
 *    GND
 *
 *   R_ntc = SERIES_R * adc_raw / (ADC_MAX_VAL - adc_raw)
 ******************************************************************************
 */
/* USER CODE END Header */

#ifndef NTC10K_H
#define NTC10K_H

#include "stm32g4xx_hal.h"
#include <stdint.h>

/* ---- Sensor & circuit constants ----------------------------------------- */
#define NTC_NOMINAL_R 10000.0f  /* NTC resistance at 25 C (ohm)      */
#define NTC_NOMINAL_T_K 298.15f /* Nominal temperature in Kelvin      */
#define NTC_B_DEFAULT 3950.0f   /* Default Steinhart-Hart B constant  */
#define SERIES_R 10000.0f       /* Pull-up series resistor (ohm)      */
#define ADC_MAX_VAL 4095.0f     /* 12-bit ADC full scale              */
#define KELVIN_OFFSET 273.15f   /* Celsius to Kelvin offset           */

/**
 * A disconnected NTC (open circuit) pulls the ADC pin toward VCC through
 * SERIES_R with no load, i.e. adc_val -> ADC_MAX_VAL, R_ntc -> very large,
 * computed temperature -> very cold (this is exactly the -50..-100 C
 * "disconnected" symptom -- an NTC's resistance INCREASES as it gets
 * colder, so a huge apparent resistance maps to a huge apparent cold).
 * A shorted NTC pulls the opposite way (adc_val -> 0, R_ntc -> 0, computed
 * temperature -> very hot).
 *
 * The old guard only caught adc_val EXACTLY 0 or EXACTLY 4095. Real
 * hardware never lands exactly there: g_adc_raw is an 8-sample average
 * (ADC_AVG_SAMPLES), so a genuinely disconnected sensor's average settles
 * a few counts off the rail (leakage/noise) and sails right past an
 * exact-equality check, "successfully" computing the bogus cold/hot value
 * instead of hitting the -999.0f sentinel that FAULT_BIT_THERM_MISSING /
 * FAULT_BIT_THERM2_MISSING (fault_detector.c) are specifically watching
 * for -- i.e. that fault existed and was correctly wired, but essentially
 * never actually fired for a real disconnect. Widen to a margin. */
#define NTC_RAIL_PIN_MARGIN_COUNTS 20u

/**
 * Set to 0 if this hardware variant does not physically populate this
 * thermistor -- e.g. a single-NTC pack design, or a bench/debug build
 * with no temperature sensors at all. This is a DELIBERATE "not present"
 * declaration, distinct from CS_Health_t-style fault detection above: a
 * channel that's absent by design floats to the exact same rail-pinned
 * ADC signature as one that failed after working, and there is no
 * hardware-only way to tell those apart -- so the firmware has to be
 * TOLD which case it is. When 0:
 *   - fault_detector.c's thermistor(2)NotConnectedError never latches for
 *     this channel (main.c feeds it the same 0.0f sentinel already used
 *     for "ADC not ready yet" instead of the real reading -- see the
 *     safe_temp1/safe_temp2 block in main.c),
 *   - Charger_GetGateTemperature() (main.c, PATH T) excludes this channel
 *     from its hottest-of-N-thermistors decision instead of treating a
 *     permanently-absent sensor as a permanently-latched CHARGER_TEMP_
 *     SENSOR_FAIL_C block,
 *   - SOH/LC simply never receive a plausible reading from this channel,
 *     which they already handle gracefully for any implausible input.
 * Both default to 1 (present) so existing single/dual-NTC hardware is
 * completely unaffected until you deliberately flip one.
 * >>> ADJUST FOR YOUR HARDWARE VARIANT <<< */
#define NTC1_SENSOR_PRESENT 1
#define NTC2_SENSOR_PRESENT 1

/* ---- Sampling / timing --------------------------------------------------
 *   TIM6 fires at 170 MHz / ((11+1) * (59999+1)) = ~236 Hz
 *   ADC_AVG_SAMPLES averaged readings  -> ready at ~236/8  = ~29.5 Hz
 *   PRINT_EVERY ready-events           -> print at ~29.5/29 = ~1 Hz
 * -------------------------------------------------------------------------*/
#define ADC_AVG_SAMPLES 8u    /* ISR samples to average per reading */
#define PRINT_EVERY 29u       /* Averaged readings between prints   */
#define CALIB_ADC_SAMPLES 64u /* Blocking samples for calibration   */

/* ---- Calibration result codes ------------------------------------------- */
typedef enum {
  NTC_CALIB_OK = 0,        /* Calibration successful, g_calib_b updated  */
  NTC_CALIB_ERR_ADC_RANGE, /* ADC value at rail (0 or 4095)              */
  NTC_CALIB_ERR_TEMP_CLOSE /* Reference temp too close to 25 C           */
} NTC_CalibResult_t;

/* ---- Shared state (written in ISR, read in main loop) ------------------- */
/* NTC1 (ADC2 Channel 12 - Rank 1) */
extern volatile uint32_t g_adc_raw;  /* Latest averaged ADC value           */
extern volatile uint8_t g_adc_ready; /* Flag: new averaged sample ready     */
extern float g_calib_b; /* Active B coefficient (printed by main) */

/* NTC2 (ADC2 Channel 14 - Rank 2) */
extern volatile uint32_t g_adc2_raw;  /* Latest averaged ADC2 value          */
extern volatile uint8_t g_adc2_ready; /* Flag: new averaged NTC2 sample ready */
extern float g_calib2_b; /* Active B coefficient for NTC2         */

/* ---- Public API --------------------------------------------------------- */
/* NTC1 */
float NTC_ADC_To_Celsius(uint32_t adc_val);
NTC_CalibResult_t NTC_Calibrate(float known_temp_c, uint32_t adc_val);
uint32_t NTC_GetCalibADC(void);

/* NTC2 */
float NTC2_ADC_To_Celsius(uint32_t adc_val);
NTC_CalibResult_t NTC2_Calibrate(float known_temp_c, uint32_t adc_val);

/* ---- ISR dispatch functions (called from stm32g4xx_it.c) --------------- */
void NTC10K_ADC_Callback(ADC_HandleTypeDef *hadc);
void NTC10K_TIM_Callback(TIM_HandleTypeDef *htim);

#endif /* NTC10K_H */
