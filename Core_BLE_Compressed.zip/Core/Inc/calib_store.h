/**
 * @file    calib_store.h
 * @brief   Non-volatile calibration storage on W25Q64 QSPI flash
 *
 * Stores current-sensor calibration (zero offset, coupling factor)
 * and SOC state (soc_percent, remaining_ah) in sector 0 of the
 * external flash so they survive power cycles.
 */

#ifndef CALIB_STORE_H
#define CALIB_STORE_H

#ifdef __cplusplus
extern "C" {
#endif

#include "bmsNode.h"
#include "cli_frame.h" /* CLI_ChargerConfig_t */
#include "soc.h"
#include "stm32g4xx_hal.h"
#include "soc.h" // FIXED
#include <stdbool.h>
#include <stdint.h>

/* ========================================================================== */
/*                          Data Layout */
/* ========================================================================== */

/** Magic number to validate stored data.
 *  Bumped to 0xCA1B000C after adding CLI_DeviceIdentity_t.mfgDate (12
 *  bytes -- see device_identity.h/cli_frame.h). Struct size changed
 *  again, so old (pre-0xCA1B000C) flash records correctly fail
 *  CalibStore_IsValid() and the BMS falls back to defaults + a re-run of
 *  zero calibration on first boot after this update, same as every
 *  other magic bump on this project -- not a silent data-corruption
 *  risk. (Previously bumped to 0xCA1B000B for deviceIdentity itself.) */
#define CALIB_STORE_MAGIC 0xCA1B000CU

/**
 * @brief  Calibration data structure written to flash.
 *         CalibStore_Save()/Load() use W25Q64_Write()/Read() with
 *         sizeof(CalibStore_Data_t) directly (same as error_log_store.c's
 *         much larger ~6.4KB struct) -- multi-page writes are handled
 *         internally by the flash driver, so this struct growing past a
 *         single 256-byte page (as it already had, well before this
 *         field, once soc_config/dronecan_settings/charger_config/
 *         deviceIdentity were all added) is not a correctness concern.
 */
typedef struct {
  uint32_t magic; /**< Must equal CALIB_STORE_MAGIC  */

  /* Current-sensor and Temperature calibration */
  int32_t zeroOffset_Q16; /**< Zero-current offset (Q16) */
  float couplingFactor;   /**< mA per mV deviation       */
  float ntc_calib_b;      /**< Steinhart-Hart B constant (NTC1) */
  float ntc2_calib_b;     /**< Steinhart-Hart B constant (NTC2) */

  /* SOC state and Config */
  SOC_Config_t soc_config; /**< User-tunable SOC parameters */
  float soc_percent;       /**< Last known SOC %          */
  float remaining_ah;      /**< Last known remaining Ah   */

  /* Fault detection thresholds (9 floats total) */
  float fault_ov_v;           /**< Pack OV threshold (V)              */
  float fault_uv_v;           /**< Pack UV threshold (V)              */
  float fault_oc_a;           /**< Discharge OC threshold (A)         */
  float fault_cell_diff_mv;   /**< Cell imbalance threshold (mV)      */
  float fault_ot_c;           /**< Over-temperature threshold (°C)    */
  float fault_ut_c;           /**< Under-temperature threshold (°C)   */
  float fault_cell_max_v;     /**< Individual cell OV threshold (V)   */
  float fault_cell_min_v;     /**< Individual cell UV threshold (V)   */
  float fault_charge_oc_a;    /**< Charge OC threshold (A)            */

/* DroneCAN Node Settings */
  settings_t dronecan_settings; /**< CAN node ID, battery index, rate */

  /* Solterra charger charge profile (20 bytes) — carved out of what was
   * reserved[36], so total struct size is unchanged. */
  CLI_ChargerConfig_t charger_config;

  /* BMS serial / pack serial / product ID / mfg date (48 bytes) — see
   * device_identity.h. mfgDate added on top of the original 36-byte
   * layout, hence the CALIB_STORE_MAGIC bump above. */
  CLI_DeviceIdentity_t deviceIdentity;

  /* No extended SOC buffer (keep legacy size) */
  uint8_t reserved[16];
  bool reserved_valid;

  uint32_t crc32; /**< CRC-32 of all fields above */
} CalibStore_Data_t;

#include "soc_extended.h"

/* ========================================================================== */
/*                          Public API */
/* ========================================================================== */

/**
 * @brief  Initialise the flash chip (reset, JEDEC check, enable quad).
 * @param  hqspi  Pointer to the QSPI handle.
 * @retval true on success, false on failure.
 */
bool CalibStore_Init(QSPI_HandleTypeDef *hqspi);

/**
 * @brief  Save calibration data to flash sector 0.
 *         Erases the sector, then writes the struct (with CRC).
 * @param  data  Pointer to the data to save.
 * @retval true on success, false on failure.
 */
bool CalibStore_Save(const CalibStore_Data_t *data);

/**
 * @brief  Load calibration data from flash sector 0.
 *         Validates magic number and CRC32 before returning.
 * @param  data  Pointer to receive the loaded data.
 * @retval true if valid data was read, false otherwise.
 */
bool CalibStore_Load(CalibStore_Data_t *data);

/**
 * @brief  Check whether a loaded data struct is valid (magic + CRC).
 * @param  data  Pointer to the data to validate.
 * @retval true if valid, false otherwise.
 */
bool CalibStore_IsValid(const CalibStore_Data_t *data);

#ifdef __cplusplus
}
#endif

#endif /* CALIB_STORE_H */
