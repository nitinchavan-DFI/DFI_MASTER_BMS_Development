/**
 * @file    error_log_store.h
 * @brief   Advanced error/event log storage on W25Q64 QSPI flash.
 *
 * Design goals (see error_log_store.c for the full write-up):
 *   - NEVER blocks the caller for more than a single small flash write
 *     (a handful of ms) -- sector erases, the genuinely slow operation
 *     (tens to hundreds of ms), are done via a non-blocking start/poll
 *     state machine spread across many main-loop iterations, and are
 *     scheduled proactively ahead of when they're actually needed so the
 *     hot append path almost never has to wait on one at all.
 *   - Wear-leveled: rotates writes across many sectors instead of
 *     hammering the same one or two on every single log entry.
 *   - Power-loss safe at the RECORD level: each entry is a small,
 *     independently checksummed record written into blank space (no
 *     erase-then-rewrite of history). Losing power mid-write can corrupt
 *     at most the ONE record in flight -- every previously-written record
 *     is completely unaffected and still readable.
 *   - Richer entries: severity + a FAULT_BIT_* snapshot + a monotonic
 *     sequence number, not just a timestamp and a free-text string --
 *     so tooling can filter/aggregate without string-matching, and can
 *     tell exactly how many older entries were overwritten by ring wrap.
 */

#ifndef ERROR_LOG_STORE_H
#define ERROR_LOG_STORE_H

#ifdef __cplusplus
extern "C" {
#endif

#include "cli_frame.h"
#include "stm32g4xx_hal.h"
#include <stdbool.h>
#include <stdint.h>

#define ERROR_LOG_MSG_MAX_LEN 58

/**
 * @brief  Total number of entries the ring can hold before it starts
 *         overwriting the oldest. See error_log_store.c's layout
 *         constants (ERRLOG_SECTOR_COUNT / RECORDS_PER_SECTOR) if you
 *         want to change this -- it's derived from those, not
 *         independently adjustable here.
 */
extern const uint32_t ERROR_LOG_MAX_ENTRIES;

/**
 * @brief  Severity of a logged event -- lets the GUI/tooling filter or
 *         color-code without string-matching the message text.
 */
typedef enum {
  ERRLOG_SEV_INFO     = 0, /**< Informational -- connects, config changes, etc. */
  ERRLOG_SEV_WARNING  = 1, /**< Advisory -- e.g. charger thermal-gate block/resume */
  ERRLOG_SEV_CRITICAL = 2, /**< A FaultThresholds_t-driven fault latched or cleared */
} ErrorLog_Severity_t;

/**
 * @brief  A single logged event, as delivered over CLI_CMD_ERROR_LOG_DATA
 *         and returned by ErrorLog_GetEntry(). Grew from the original
 *         (timestamp + message only) to add fault-code context, a
 *         severity, and a monotonic sequence number.
 */
typedef struct __attribute__((packed)) {
  RTC_DateTime_t timestamp;   /**< Real wall-clock time (see main.c: RTC is
                                    synced to the host PC on every GUI connect) */
  uint32_t       seq;         /**< Monotonic, never reused -- a gap between two
                                    consecutive entries' seq values tells you
                                    exactly how many older entries were
                                    overwritten by ring wrap in between */
  uint16_t       fault_bits;  /**< FAULT_BIT_* snapshot at log time, 0 if n/a */
  uint8_t        severity;    /**< ErrorLog_Severity_t */
  uint8_t        reserved;    /**< pad to 4-byte alignment; future use */
  char           message[ERROR_LOG_MSG_MAX_LEN]; /**< NUL-terminated, truncated */
} ErrorLog_Entry_t;

/**
 * @brief  Initialize the error log storage mechanism. Scans flash to
 *         rebuild the write cursor and highest sequence number -- see
 *         error_log_store.c's "boot recovery scan" section. One-time
 *         cost at boot (before the main loop starts, so blocking here is
 *         fine); typically a few tens of ms for a full-region scan.
 * @param hqspi Pointer to the QSPI handle.
 * @retval true on success, false otherwise.
 */
bool ErrorLog_Init(QSPI_HandleTypeDef *hqspi);

/**
 * @brief  Log a message immediately, severity defaults to
 *         ERRLOG_SEV_INFO, fault_bits to 0. Internally just queues +
 *         immediately drains one entry (see ErrorLog_AddEx()) -- safe to
 *         call from a slow-path context (e.g. responding to an explicit
 *         CLI command); do NOT call from anything sharing a cadence with
 *         CAN telemetry -- use ErrorLog_QueueDeferred() there.
 * @param message The error message string (truncated to fit).
 * @retval true on success, false if the flash write failed.
 */
bool ErrorLog_Add(const char *message);

/**
 * @brief  Same as ErrorLog_Add(), with explicit severity and a
 *         FAULT_BIT_* snapshot to store alongside the message.
 */
bool ErrorLog_AddEx(ErrorLog_Severity_t severity, uint16_t fault_bits,
                     const char *message);

/**
 * @brief  Fast, non-blocking alternative to ErrorLog_Add() for hot-path
 *         callers (e.g. fault_detector.c's per-tick debounce, evaluated
 *         every main-loop iteration alongside CAN telemetry). Captures
 *         the RTC timestamp immediately (cheap register reads) and
 *         copies the message into a small in-RAM pending queue -- NO
 *         flash access happens here, so this cannot stall the caller.
 *         The actual flash write happens later via ErrorLog_ProcessPending().
 *         Severity defaults to ERRLOG_SEV_INFO, fault_bits to 0 -- use
 *         ErrorLog_QueueDeferredEx() to set them.
 * @retval true if queued; false if the pending queue is full (message
 *         dropped -- the alternative would be blocking exactly the
 *         real-time caller this function exists to protect).
 */
bool ErrorLog_QueueDeferred(const char *message);

/**
 * @brief  Same as ErrorLog_QueueDeferred(), with explicit severity and a
 *         FAULT_BIT_* snapshot to store alongside the message.
 */
bool ErrorLog_QueueDeferredEx(ErrorLog_Severity_t severity,
                               uint16_t fault_bits, const char *message);

/**
 * @brief  Call ONCE per main-loop iteration, AFTER any time-critical CAN
 *         telemetry has already been sent for that iteration. Does AT
 *         MOST ONE of the following per call, never more, and never
 *         blocks longer than a single fast flash operation (a few ms for
 *         a record write, a few µs for a busy-poll check):
 *           - commit one pending deferred entry as a small record write
 *             into flash space that's already known to be blank, or
 *           - advance an in-progress background sector erase by one poll
 *             check (see error_log_store.c's non-blocking erase-ahead
 *             state machine), or
 *           - start erasing the next sector that will eventually be
 *             needed, if none is in progress and one will be needed soon.
 *         A burst of several simultaneous fault transitions therefore
 *         spreads its cost across that many loop iterations instead of
 *         one iteration paying for all of them at once.
 */
void ErrorLog_ProcessPending(void);

/**
 * @brief Get the current number of stored log entries (0 to
 *        ERROR_LOG_MAX_ENTRIES).
 */
uint32_t ErrorLog_GetCount(void);

/**
 * @brief Retrieve a specific error log entry.
 *
 * @param index Index of the entry to retrieve. 0 is the oldest, (count-1) is
 * the newest.
 * @param out_entry Pointer to the struct where the entry will be copied.
 * @retval true on success, false if index is out of bounds or the record
 *         at that slot failed its integrity check (e.g. a record that was
 *         only partially written when power was lost mid-write -- this
 *         affects only that one entry, never the rest of the log).
 */
bool ErrorLog_GetEntry(uint32_t index, ErrorLog_Entry_t *out_entry);

/**
 * @brief Clear all error logs from flash and RAM.
 * @retval true on success, false otherwise.
 */
bool ErrorLog_Clear(void);

#ifdef __cplusplus
}
#endif

#endif /* ERROR_LOG_STORE_H */
