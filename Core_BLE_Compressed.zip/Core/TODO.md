# DeepSleep & UV Sleep Ladder Implementation — TODO

## Phase 1: Power Manager Module
- [ ] Create `Core/Inc/power_manager.h` — API declarations, wake source enums, deep-sleep state machine
- [ ] Create `Core/Src/power_manager.c` — Stop 2 mode entry, RTC wakeup, IWDG refresh, peripheral shutdown, CAN transceiver standby, W25Q64 deep power-down

## Phase 2: UV Sleep Ladder Module
- [ ] Create `Core/Inc/uv_sleep.h` — UV ladder state machine API, stage enum, persisted state struct
- [ ] Create `Core/Src/uv_sleep.c` — UV ladder state machine (10s/30min/1hr/12hr/24hr/hibernate), near-UV detection, RTC backup register persistence

## Phase 3: Integrate into main.c
- [ ] Add power manager init + UV sleep init in main()
- [ ] Add deep sleep evaluation in main loop (idle detection, UV detection)
- [ ] Add UV ladder evaluation hook
- [ ] Add RTC wakeup handler for periodic current sampling

## Phase 4: CAN Standby / Wake-on-CAN
- [ ] Modify `Core/Inc/fdcan.h` — add CAN standby/wake API
- [ ] Modify `Core/Src/fdcan.c` — transceiver standby control, wake-on-CAN EXTI config

## Phase 5: Current Sensor Low-Power API
- [ ] Modify `Core/Inc/current_sensor.h` — add low-power sampling API
- [ ] Modify `Core/Src/current_sensor.c` — implement low-power current sample (single-shot, no TIM1 trigger)

## Phase 6: Interrupt Handlers
- [ ] Modify `Core/Src/stm32g4xx_it.c` — wake-up handlers (CAN EXTI, RTC alarm, button), deep sleep entry

## Phase 7: Build & Test
- [ ] Verify CMake build
- [ ] Test wake sources individually
- [ ] Measure actual current consumption
