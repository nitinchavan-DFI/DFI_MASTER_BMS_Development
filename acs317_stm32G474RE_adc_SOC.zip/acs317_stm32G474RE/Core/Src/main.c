/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2025 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "arm_math.h"
#include <math.h>
#include "dalyBalancer.h"
#include "ntc10k.h"
uint16_t AD_RES = 0;
//volatile uint8_t curruntFlag = 1;
//volatile float peackCurrent = 0.0;
//#include "acs37612.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */


/*****************************************BATTERY SOC VARIABLE**********************************************************/
typedef struct
{
	float soc;
	float coulomb_Ah;
	uint32_t restCounter;
} SOC_Runtime_t;

SOC_Runtime_t socRun = {.soc = 50.0f};

#define BATTERY_CAPACITY_AH   30.0f   // change to your pack
#define PACK_MIN_VOLT         37.2f   // 0% SOC pack voltage
#define PACK_MAX_VOLT         50.5f   // 100% SOC pack voltage

#define DT_SEC               0.1f    // 100 ms timer



/* ===== BATTERY CONFIG ===== */

#define REST_CURRENT_A          1.0f        // C/50 for 50Ah
#define REST_TIME_SEC           20           // Voltage must be stable

#define PACK_FULL_VOLT          54.6f
#define PACK_EMPTY_VOLT         42.1f

#define OCV_POINTS              11

const float soc_ref[OCV_POINTS] =
{
		0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100
};

const float pack_ocv[OCV_POINTS] =
{
		42.0, 44.5, 46.2, 47.4, 48.2,
		48.8, 49.2, 49.8, 50.4, 51.5, 54.6
};

float coulomb_soc = 50.0f;   // %
float coulomb_ah  = 0.0f;

static uint32_t rest_timer = 0;



/***********************************************************************************************************************/


#define ADC_MAX        4095.0f
#define VREF           3.32f
#define SENS_V_PER_G   0.010f
#define CF_G_PER_A     0.74f

#define A_PER_COUNT   (VREF / (ADC_MAX * SENS_V_PER_G * CF_G_PER_A))

#define MA_LENGTH       1000
#define LPF_CUTOFF_HZ   30.0f
#define LPF_SAMPLE_HZ   1000.0f

volatile uint8_t my_txBuffer[13];
volatile uint8_t my_rxBuffer[XFER_BUFFER_LENGTH];
volatile  get_ get;
alarm_ alarm;
uint16_t timer;
volatile uint32_t bmsFaultRegister = BMS_FAULT_NONE;


/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
ADC_HandleTypeDef hadc2;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim6;
TIM_HandleTypeDef htim7;

UART_HandleTypeDef huart5;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
float firStateF32[MA_LENGTH + 1];
float firCoeffsF32[MA_LENGTH];
arm_fir_instance_f32 FIR_MA;

float lpf_alpha = 0.0f;
float lpf_state = 0.0f;

volatile float current_filtered = 0.0f;
volatile float adc_zero = 1987.56348;

volatile uint16_t counter = 0;


NTC10K_Handle_t ntc1;
NTC10K_Handle_t ntc2;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM2_Init(void);
static void MX_UART5_Init(void);
static void MX_TIM3_Init(void);
static void MX_ADC2_Init(void);
static void MX_TIM6_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM7_Init(void);
/* USER CODE BEGIN PFP */
float current;
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */


//void Build_Pack_OCV_Table(void)
//{
//	float vmin = PACK_MIN_VOLT;
//	float vmax = PACK_MAX_VOLT;
//
//	for(int i=0;i<OCV_POINTS;i++)
//	{
//		pack_ocv[i] = vmin +
//				(soc_ref[i] / 100.0f) * (vmax - vmin);
//	}
//}

void ACS_InitFilter(void)
{
	for(int i=0;i<MA_LENGTH;i++)
		firCoeffsF32[i] = 1.0f / MA_LENGTH;

	arm_fir_init_f32(&FIR_MA, MA_LENGTH, firCoeffsF32, firStateF32, 1);

	float dt = 1.0f / LPF_SAMPLE_HZ;
	float RC = 1.0f / (2.0f * 3.1415926f * LPF_CUTOFF_HZ);
	lpf_alpha = dt / (RC + dt);
}
//
//void ACS_CalibrateZero(void)
//{
//	float sum = 0;
//
//	for(int i=0;i<800;i++)
//	{
//		while(!__HAL_ADC_GET_FLAG(&hadc1, ADC_FLAG_EOC));
//		sum += HAL_ADC_GetValue(&hadc1);
//	}
//
//	adc_zero = sum / 800.0f;
//	lpf_state = (float)adc_zero;
//}

//float adc_zero = 0.0f;
float adc_per_amp = 0.0f;   // <-- replaces A_PER_COUNT

void ACS_CalibrateZero(void)
{
	float sum = 0;

	for(int i = 0; i < 800; i++)
	{
		while(!__HAL_ADC_GET_FLAG(&hadc1, ADC_FLAG_EOC));
		sum += HAL_ADC_GetValue(&hadc1);
	}

	adc_zero = sum / 800.0f;
	lpf_state = adc_zero;   // keep LPF aligned
}

void ACS_CalibrateGain(float known_current_A)
{
	float sum = 0;

	for(int i = 0; i < 800; i++)
	{
		while(!__HAL_ADC_GET_FLAG(&hadc1, ADC_FLAG_EOC));
		sum += HAL_ADC_GetValue(&hadc1);
	}

	float adc_known = sum / 800.0f;

	adc_per_amp = (adc_known - adc_zero) / known_current_A;
}

void delay_us(uint32_t us)
{
	__HAL_TIM_SET_COUNTER(&htim2, 0);  // Set the counter value to 0, replace htimX with your timer handle (e.g., htim2)
	while ((uint32_t)__HAL_TIM_GET_COUNTER(&htim2) < us); // Wait for the counter to reach the desired microsecond value
}

float currentGain = 0;
uint8_t curruntGainTune = 0;
uint8_t curruntZeroTune = 0;
#include "ntc_table.h"
uint16_t adcValue[3];
uint8_t Sch_100ms = 255;
float Ntc_Tmp_Raw[2];
float Ntc_Tmp[2];
float voltage;
#include <stdio.h>
#include <stdio.h>
/* USER CODE END 0 */

/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void)
{

	/* USER CODE BEGIN 1 */

	/* USER CODE END 1 */

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_ADC1_Init();
	MX_TIM1_Init();
	MX_TIM2_Init();
	MX_UART5_Init();
	MX_TIM3_Init();
	MX_ADC2_Init();
	MX_TIM6_Init();
	MX_USART2_UART_Init();
	MX_TIM7_Init();
	/* USER CODE BEGIN 2 */

	//  ACS37612_InitFilter();
	//  ACS37612_Start();
	HAL_TIM_Base_Start(&htim2); // Start the configured timer (e.g., htim2)

	ACS_InitFilter();

	HAL_TIM_Base_Start(&htim1); // Start Timer3 (Trigger Source For ADC1)
	HAL_ADC_Start_IT(&hadc1); // Start ADC Conversion

	//  HAL_Delay(2);
	delay_us(200*1000);
	//  ACS_CalibrateZero();
	//
	//  HAL_Delay(200);
	ACS_CalibrateZero();
	dalyInit();
	//	Build_Pack_OCV_Table();

	HAL_TIM_Base_Start_IT(&htim3);

	NTC10K_Init(&ntc1);
	NTC10K_Init(&ntc2);

	HAL_TIM_Base_Start(&htim6); // Start Timer3 (Trigger Source For ADC1)
	HAL_ADC_Start_IT(&hadc2); // Start ADC Conversion

	HAL_TIM_Base_Start_IT(&htim7);
	/* USER CODE END 2 */

	/* Infinite loop */
	/* USER CODE BEGIN WHILE */
	while (1)
	{
		/* USER CODE END WHILE */

		/* USER CODE BEGIN 3 */
		if(curruntGainTune == 1)
		{
			ACS_CalibrateGain(currentGain);
			curruntGainTune = 0;
		}

		if(curruntZeroTune == 1)
		{
			ACS_CalibrateZero();
			curruntZeroTune = 0;
		}
		//	  current = ACS37612_ReadCurrent();
		BMS_ServiceTask();
		//	    HAL_UART_Transmit(&huart2, "hello semeen", 12, 100);


		HAL_Delay(1);
	}
	/* USER CODE END 3 */
}

/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void)
{
	RCC_OscInitTypeDef RCC_OscInitStruct = {0};
	RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

	/** Configure the main internal regulator output voltage
	 */
	HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);

	/** Initializes the RCC Oscillators according to the specified parameters
	 * in the RCC_OscInitTypeDef structure.
	 */
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
	RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
	RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV4;
	RCC_OscInitStruct.PLL.PLLN = 85;
	RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
	RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
	RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
	{
		Error_Handler();
	}

	/** Initializes the CPU, AHB and APB buses clocks
	 */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
			|RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
	{
		Error_Handler();
	}
}

/**
 * @brief ADC1 Initialization Function
 * @param None
 * @retval None
 */
static void MX_ADC1_Init(void)
{

	/* USER CODE BEGIN ADC1_Init 0 */

	/* USER CODE END ADC1_Init 0 */

	ADC_MultiModeTypeDef multimode = {0};
	ADC_ChannelConfTypeDef sConfig = {0};

	/* USER CODE BEGIN ADC1_Init 1 */

	/* USER CODE END ADC1_Init 1 */

	/** Common config
	 */
	hadc1.Instance = ADC1;
	hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
	hadc1.Init.Resolution = ADC_RESOLUTION_12B;
	hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
	hadc1.Init.GainCompensation = 0;
	hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
	hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
	hadc1.Init.LowPowerAutoWait = DISABLE;
	hadc1.Init.ContinuousConvMode = DISABLE;
	hadc1.Init.NbrOfConversion = 1;
	hadc1.Init.DiscontinuousConvMode = DISABLE;
	hadc1.Init.ExternalTrigConv = ADC_EXTERNALTRIG_T1_TRGO;
	hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_RISING;
	hadc1.Init.DMAContinuousRequests = DISABLE;
	hadc1.Init.Overrun = ADC_OVR_DATA_PRESERVED;
	hadc1.Init.OversamplingMode = DISABLE;
	if (HAL_ADC_Init(&hadc1) != HAL_OK)
	{
		Error_Handler();
	}

	/** Configure the ADC multi-mode
	 */
	multimode.Mode = ADC_MODE_INDEPENDENT;
	if (HAL_ADCEx_MultiModeConfigChannel(&hadc1, &multimode) != HAL_OK)
	{
		Error_Handler();
	}

	/** Configure Regular Channel
	 */
	sConfig.Channel = ADC_CHANNEL_1;
	sConfig.Rank = ADC_REGULAR_RANK_1;
	sConfig.SamplingTime = ADC_SAMPLETIME_2CYCLES_5;
	sConfig.SingleDiff = ADC_SINGLE_ENDED;
	sConfig.OffsetNumber = ADC_OFFSET_NONE;
	sConfig.Offset = 0;
	if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN ADC1_Init 2 */

	/* USER CODE END ADC1_Init 2 */

}

/**
 * @brief ADC2 Initialization Function
 * @param None
 * @retval None
 */
static void MX_ADC2_Init(void)
{

	/* USER CODE BEGIN ADC2_Init 0 */

	/* USER CODE END ADC2_Init 0 */

	ADC_ChannelConfTypeDef sConfig = {0};

	/* USER CODE BEGIN ADC2_Init 1 */

	/* USER CODE END ADC2_Init 1 */

	/** Common config
	 */
	hadc2.Instance = ADC2;
	hadc2.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
	hadc2.Init.Resolution = ADC_RESOLUTION_12B;
	hadc2.Init.DataAlign = ADC_DATAALIGN_RIGHT;
	hadc2.Init.GainCompensation = 0;
	hadc2.Init.ScanConvMode = ADC_SCAN_ENABLE;
	hadc2.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
	hadc2.Init.LowPowerAutoWait = DISABLE;
	hadc2.Init.ContinuousConvMode = DISABLE;
	hadc2.Init.NbrOfConversion = 2;
	hadc2.Init.DiscontinuousConvMode = DISABLE;
	hadc2.Init.ExternalTrigConv = ADC_EXTERNALTRIG_T6_TRGO;
	hadc2.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_RISING;
	hadc2.Init.DMAContinuousRequests = DISABLE;
	hadc2.Init.Overrun = ADC_OVR_DATA_PRESERVED;
	hadc2.Init.OversamplingMode = DISABLE;
	if (HAL_ADC_Init(&hadc2) != HAL_OK)
	{
		Error_Handler();
	}

	/** Configure Regular Channel
	 */
	sConfig.Channel = ADC_CHANNEL_12;
	sConfig.Rank = ADC_REGULAR_RANK_1;
	sConfig.SamplingTime = ADC_SAMPLETIME_92CYCLES_5;
	sConfig.SingleDiff = ADC_SINGLE_ENDED;
	sConfig.OffsetNumber = ADC_OFFSET_NONE;
	sConfig.Offset = 0;
	if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK)
	{
		Error_Handler();
	}

	/** Configure Regular Channel
	 */
	sConfig.Channel = ADC_CHANNEL_14;
	sConfig.Rank = ADC_REGULAR_RANK_2;
	if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN ADC2_Init 2 */

	/* USER CODE END ADC2_Init 2 */

}

/**
 * @brief TIM1 Initialization Function
 * @param None
 * @retval None
 */
static void MX_TIM1_Init(void)
{

	/* USER CODE BEGIN TIM1_Init 0 */

	/* USER CODE END TIM1_Init 0 */

	TIM_ClockConfigTypeDef sClockSourceConfig = {0};
	TIM_MasterConfigTypeDef sMasterConfig = {0};

	/* USER CODE BEGIN TIM1_Init 1 */

	/* USER CODE END TIM1_Init 1 */
	htim1.Instance = TIM1;
	htim1.Init.Prescaler = 0;
	htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim1.Init.Period = 33999;
	htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim1.Init.RepetitionCounter = 0;
	htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
	if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
	{
		Error_Handler();
	}
	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
	{
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
	sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN TIM1_Init 2 */

	/* USER CODE END TIM1_Init 2 */

}

/**
 * @brief TIM2 Initialization Function
 * @param None
 * @retval None
 */
static void MX_TIM2_Init(void)
{

	/* USER CODE BEGIN TIM2_Init 0 */

	/* USER CODE END TIM2_Init 0 */

	TIM_ClockConfigTypeDef sClockSourceConfig = {0};
	TIM_MasterConfigTypeDef sMasterConfig = {0};

	/* USER CODE BEGIN TIM2_Init 1 */

	/* USER CODE END TIM2_Init 1 */
	htim2.Instance = TIM2;
	htim2.Init.Prescaler = 170-1;
	htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim2.Init.Period = 4294967295;
	htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
	{
		Error_Handler();
	}
	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
	{
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN TIM2_Init 2 */

	/* USER CODE END TIM2_Init 2 */

}

/**
 * @brief TIM3 Initialization Function
 * @param None
 * @retval None
 */
static void MX_TIM3_Init(void)
{

	/* USER CODE BEGIN TIM3_Init 0 */

	/* USER CODE END TIM3_Init 0 */

	TIM_ClockConfigTypeDef sClockSourceConfig = {0};
	TIM_MasterConfigTypeDef sMasterConfig = {0};

	/* USER CODE BEGIN TIM3_Init 1 */

	/* USER CODE END TIM3_Init 1 */
	htim3.Instance = TIM3;
	htim3.Init.Prescaler = 339;
	htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim3.Init.Period = 49999;
	htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
	{
		Error_Handler();
	}
	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
	{
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN TIM3_Init 2 */

	/* USER CODE END TIM3_Init 2 */

}

/**
 * @brief TIM6 Initialization Function
 * @param None
 * @retval None
 */
static void MX_TIM6_Init(void)
{

	/* USER CODE BEGIN TIM6_Init 0 */

	/* USER CODE END TIM6_Init 0 */

	TIM_MasterConfigTypeDef sMasterConfig = {0};

	/* USER CODE BEGIN TIM6_Init 1 */

	/* USER CODE END TIM6_Init 1 */
	htim6.Instance = TIM6;
	htim6.Init.Prescaler = 11;
	htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim6.Init.Period = 59999;
	htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
	if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
	{
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN TIM6_Init 2 */

	/* USER CODE END TIM6_Init 2 */

}

/**
 * @brief TIM7 Initialization Function
 * @param None
 * @retval None
 */
static void MX_TIM7_Init(void)
{

	/* USER CODE BEGIN TIM7_Init 0 */

	/* USER CODE END TIM7_Init 0 */

	TIM_MasterConfigTypeDef sMasterConfig = {0};

	/* USER CODE BEGIN TIM7_Init 1 */

	/* USER CODE END TIM7_Init 1 */
	htim7.Instance = TIM7;
	htim7.Init.Prescaler = 143;
	htim7.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim7.Init.Period = 49999;
	htim7.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_Base_Init(&htim7) != HAL_OK)
	{
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim7, &sMasterConfig) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN TIM7_Init 2 */

	/* USER CODE END TIM7_Init 2 */

}

/**
 * @brief UART5 Initialization Function
 * @param None
 * @retval None
 */
static void MX_UART5_Init(void)
{

	/* USER CODE BEGIN UART5_Init 0 */

	/* USER CODE END UART5_Init 0 */

	/* USER CODE BEGIN UART5_Init 1 */

	/* USER CODE END UART5_Init 1 */
	huart5.Instance = UART5;
	huart5.Init.BaudRate = 9600;
	huart5.Init.WordLength = UART_WORDLENGTH_8B;
	huart5.Init.StopBits = UART_STOPBITS_1;
	huart5.Init.Parity = UART_PARITY_NONE;
	huart5.Init.Mode = UART_MODE_TX_RX;
	huart5.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart5.Init.OverSampling = UART_OVERSAMPLING_16;
	huart5.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
	huart5.Init.ClockPrescaler = UART_PRESCALER_DIV1;
	huart5.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
	if (HAL_UART_Init(&huart5) != HAL_OK)
	{
		Error_Handler();
	}
	if (HAL_UARTEx_SetTxFifoThreshold(&huart5, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
	{
		Error_Handler();
	}
	if (HAL_UARTEx_SetRxFifoThreshold(&huart5, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
	{
		Error_Handler();
	}
	if (HAL_UARTEx_EnableFifoMode(&huart5) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN UART5_Init 2 */

	/* USER CODE END UART5_Init 2 */

}

/**
 * @brief USART2 Initialization Function
 * @param None
 * @retval None
 */
static void MX_USART2_UART_Init(void)
{

	/* USER CODE BEGIN USART2_Init 0 */

	/* USER CODE END USART2_Init 0 */

	/* USER CODE BEGIN USART2_Init 1 */

	/* USER CODE END USART2_Init 1 */
	huart2.Instance = USART2;
	huart2.Init.BaudRate = 115200;
	huart2.Init.WordLength = UART_WORDLENGTH_8B;
	huart2.Init.StopBits = UART_STOPBITS_1;
	huart2.Init.Parity = UART_PARITY_NONE;
	huart2.Init.Mode = UART_MODE_TX_RX;
	huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart2.Init.OverSampling = UART_OVERSAMPLING_16;
	huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
	huart2.Init.ClockPrescaler = UART_PRESCALER_DIV1;
	huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
	if (HAL_UART_Init(&huart2) != HAL_OK)
	{
		Error_Handler();
	}
	if (HAL_UARTEx_SetTxFifoThreshold(&huart2, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
	{
		Error_Handler();
	}
	if (HAL_UARTEx_SetRxFifoThreshold(&huart2, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
	{
		Error_Handler();
	}
	if (HAL_UARTEx_DisableFifoMode(&huart2) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN USART2_Init 2 */

	/* USER CODE END USART2_Init 2 */

}

/**
 * @brief GPIO Initialization Function
 * @param None
 * @retval None
 */
static void MX_GPIO_Init(void)
{
	/* USER CODE BEGIN MX_GPIO_Init_1 */

	/* USER CODE END MX_GPIO_Init_1 */

	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOF_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOD_CLK_ENABLE();

	/* USER CODE BEGIN MX_GPIO_Init_2 */

	/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
//void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
//{
//    AD_RES = HAL_ADC_GetValue(&hadc1); // Read & Update The ADC Result
////    HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_0); // Toggle Interrupt Rate Indicator Pin
//}


//void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
//{
//	if(hadc->Instance == ADC1)
//	{
//		float ma_out;
//		float input = (float)HAL_ADC_GetValue(hadc);
//
//		arm_fir_f32(&FIR_MA, &input, &ma_out, 1);
//
//		lpf_state = lpf_state + lpf_alpha * (ma_out - lpf_state);
//
//		current_filtered = (lpf_state - adc_zero) * A_PER_COUNT;
//
//		if(curruntFlag == 1)
//		{
//			if(/*current_filtered > 0.1*/1)
//			{
//				peackCurrent = current_filtered;
//			}else
//			{
//				peackCurrent = 0.0f;
//			}
//			curruntFlag = 0;
//		}
//	}
//
//	if(hadc->Instance == ADC2)
//	{
//		adcValue[0]= HAL_ADC_GetValue(&hadc2);
//		adcValue[1]= HAL_ADC_GetValue(&hadc2);
//		voltage = (float)(adcValue[0] * 3.52f/ 4096);
//
//		Ntc_Tmp_Raw[0] = calc_temperature(adcValue[0]);
//		Ntc_Tmp[0] = 0.1*Ntc_Tmp_Raw[0];
//
//		Ntc_Tmp_Raw[1] = calc_temperature(adcValue[1]);
//		Ntc_Tmp[1] = 0.1*Ntc_Tmp_Raw[1];
//	}
//}

//void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
//{
//    AD_RES = HAL_ADC_GetValue(&hadc1); // Read & Update The ADC Result
////    HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_0); // Toggle Interrupt Rate Indicator Pin
//}

volatile uint8_t curruntFlag = 1;
volatile float peackCurrent = 0.0;

float temperature[2];

uint8_t tempratureCalibrationFlag = 0;

float tempratureCalibration[2];

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
	if(hadc->Instance == ADC1)
	{
		float ma_out;
		float input = (float)HAL_ADC_GetValue(hadc);

		arm_fir_f32(&FIR_MA, &input, &ma_out, 1);

		lpf_state = lpf_state + lpf_alpha * (ma_out - lpf_state);

		current_filtered = (lpf_state - adc_zero) / adc_per_amp;

		//		if(curruntFlag == 1)
		{
			if(current_filtered > 0.1)
			{
				peackCurrent = current_filtered;
			}else
			{
				peackCurrent = 0.0f;
			}
			curruntFlag = 0;
		}
	}

	if(hadc->Instance == ADC2)
	{
		adcValue[0]= HAL_ADC_GetValue(&hadc2);
		adcValue[1]= HAL_ADC_GetValue(&hadc2);

		temperature[0] = NTC10K_GetTemperature(&ntc1, adcValue[0]);
		temperature[1] = NTC10K_GetTemperature(&ntc2, adcValue[1]);

		if(tempratureCalibrationFlag == 1)
		{
			NTC10K_Calibrate(&ntc1, adcValue[0], tempratureCalibration[0]);
			NTC10K_Calibrate(&ntc2, adcValue[1], tempratureCalibration[1]);
			tempratureCalibrationFlag = 0;
		}
		/* NTC is adcValue[0] */
		//		voltage = (float)(adcValue[0] * 3.52f/ 4096);
		//
		//		Ntc_Tmp_Raw[0] = calc_temperature(adcValue[0]);
		//		Ntc_Tmp[0] = 0.1*Ntc_Tmp_Raw[0];
		//
		//		Ntc_Tmp_Raw[1] = calc_temperature(adcValue[1]);
		//		Ntc_Tmp[1] = 0.1*Ntc_Tmp_Raw[1];
	}
}

//static float pack_ocv[] = {
//		41.6,44.9,46.1,47.5,48.5,49.1,49.7,
//		50.3,51.0,51.7,53.0,53.6,54.6
//};

//static float pack_soc[] = {
//		0,  5, 10, 20, 30, 40, 50,
//		60, 70, 80, 90, 95,100
//};

//float SOC_From_PackOCV(float packV)
//{
//	if(packV <= pack_ocv[0]) return 0;
//	if(packV >= pack_ocv[12]) return 100;
//
//	for(int i=0;i<12;i++)
//	{
//		if(packV >= pack_ocv[i] && packV <= pack_ocv[i+1])
//		{
//			return soc_ref[i] +
//					(packV-pack_ocv[i]) *
//					(soc_ref[i+1]-soc_ref[i]) /
//					(pack_ocv[i+1]-pack_ocv[i]);
//		}
//	}
//	return 0;
//}
//
//void SOC_Coulomb_Update(float packCurrent)
//{
//	float dAh = (packCurrent * DT_SEC) / 3600.0f;
//	float dSOC = (dAh / BATTERY_CAPACITY_AH) * 100.0f;
//
//	coulomb_soc += dSOC;
//	coulomb_ah  += dAh;
//
//	if(coulomb_soc > 100.0f) coulomb_soc = 100.0f;
//	if(coulomb_soc <   0.0f) coulomb_soc =   0.0f;
//}

float SOC_From_PackOCV(float packV)
{
	if (packV <= pack_ocv[1])
		return coulomb_soc;//soc_ref[0];

	if (packV >= pack_ocv[OCV_POINTS - 1])
		return soc_ref[OCV_POINTS - 1];

	for (int i = 0; i < OCV_POINTS - 1; i++)
	{
		if (packV >= pack_ocv[i] && packV <= pack_ocv[i + 1])
		{
			return soc_ref[i] +
					(packV - pack_ocv[i]) *
					(soc_ref[i + 1] - soc_ref[i]) /
					(pack_ocv[i + 1] - pack_ocv[i]);
		}
	}
	return coulomb_soc;
}

void SOC_Coulomb_Update(float packCurrent_A)
{
	float dAh  = (packCurrent_A * DT_SEC) / 3600.0f;
	float dSOC = (dAh / BATTERY_CAPACITY_AH) * 100.0f;

	coulomb_ah  += dAh;
	coulomb_soc += dSOC;

	if (coulomb_soc > 100.0f) coulomb_soc = 100.0f;
	if (coulomb_soc <   0.0f) coulomb_soc =   0.0f;
}

void SOC_OCV_Correction(float packVoltage, float packCurrent)
{
	if (fabsf(packCurrent) < REST_CURRENT_A)
	{
		rest_timer++;

		if (rest_timer >= REST_TIME_SEC)
		{
			float soc_ocv = SOC_From_PackOCV(packVoltage);

			/* Gentle correction (no jump) */
			coulomb_soc = 0.95f * coulomb_soc + 0.05f * soc_ocv;
		}
	}
	else
	{
		rest_timer = 0;
	}
}

void SOC_Boundary_Check(float packVoltage, float packCurrent)
{
	/* Full charge detection */
	if (packVoltage >= PACK_FULL_VOLT && packCurrent < REST_CURRENT_A)
	{
		coulomb_soc = 100.0f;
		coulomb_ah  = BATTERY_CAPACITY_AH;
	}

	/* Empty detection */
	if (packVoltage <= PACK_EMPTY_VOLT)
	{
		coulomb_soc = 0.0f;
		coulomb_ah  = 0.0f;
	}
}

static uint8_t empty_latched = 0;
#define CHARGE_DETECT_CURRENT 1
void SOC_Empty_Latch(float packVoltage, float packCurrent)
{
	if (packVoltage <= PACK_EMPTY_VOLT)
	{
		coulomb_soc = 0.0f;
		empty_latched = 1;
	}

	if (empty_latched)
	{
		if (packCurrent > CHARGE_DETECT_CURRENT)
		{
			empty_latched = 0;  // charging started
		}
		else
		{
			coulomb_soc = 0.0f;
		}
	}
}

float packVoltage = 43.5;
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if (htim->Instance == TIM3)
	{
		if(curruntFlag == 0)
		{
			packVoltage = get.packVoltage;
			SOC_Coulomb_Update(peackCurrent);
			SOC_OCV_Correction(packVoltage, peackCurrent);
			SOC_Boundary_Check(packVoltage, peackCurrent);
			SOC_Empty_Latch(packVoltage, peackCurrent);
			curruntFlag = 1;
		}
		socRun.soc = coulomb_soc;
	}
	if(htim->Instance == TIM7){
		char tx_buffer[100];
		//peackCurrent = -50;
		int len = sprintf(tx_buffer, "%.2f, %.4f, %.2f, %.2f, %.2f\r\n",get.packVoltage, peackCurrent, socRun.soc,temperature[0],temperature[1]);

		HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, len, 100);
	}
}
//
//volatile float packvoltaeg=44;
//void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef* htim)
//{
//	if (htim->Instance == TIM3) {
//		{
//			if(curruntFlag==0)
//			{
//				packvoltaeg = get.packVoltage;
//				SOC_Coulomb_Update(peackCurrent);
//				curruntFlag = 1;
//				{
//					coulomb_soc = 0.9f * coulomb_soc + 0.1f * SOC_From_PackOCV(packvoltaeg);
//					socRun.soc = coulomb_soc;
//					//					counter = 0;
//				}
//			}
//		}
//		counter++;
//	}
//
//	if(htim->Instance == TIM7){
//		char tx_buffer[100];
//		int len = sprintf(tx_buffer, "%.2f, %.4f, %.2f, %.2f, %.2f\r\n",get.packVoltage, peackCurrent, socRun.soc,Ntc_Tmp[0],Ntc_Tmp[1]);
//
//		HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, len, 100);
//	}
//}
/* USER CODE END 4 */

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void)
{
	/* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1)
	{
	}
	/* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
 * @brief  Reports the name of the source file and the source line number
 *         where the assert_param error has occurred.
 * @param  file: pointer to the source file name
 * @param  line: assert_param error line source number
 * @retval None
 */
void assert_failed(uint8_t *file, uint32_t line)
{
	/* USER CODE BEGIN 6 */
	/* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
	/* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
