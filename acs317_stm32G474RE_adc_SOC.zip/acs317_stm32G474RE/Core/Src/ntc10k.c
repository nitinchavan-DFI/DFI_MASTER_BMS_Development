/*
 * ntc10k.c
 *
 *  Created on: Feb 5, 2026
 *      Author: semeen
 */

#include "ntc10k.h"
#include <math.h>

/* ================= INTERNAL FUNCTIONS ================= */

static float adc_to_voltage(uint32_t adc)
{
    return (adc * NTC_VREF) / NTC_ADC_MAX;
}

static float voltage_to_resistance(float voltage)
{
    /* NTC at bottom, pull-up resistor at VREF */
    return NTC_SERIES_RES * (voltage / (NTC_VREF - voltage));
}

/* ================= API IMPLEMENTATION ================= */

void NTC10K_Init(NTC10K_Handle_t *ntc)
{
    ntc->R0    = 10000.0f;          // Default 10k
    ntc->T0    = 298.15f;           // 25°C in Kelvin
    ntc->Beta  = NTC_DEFAULT_BETA;
    ntc->valid = 0;
}

void NTC10K_Calibrate(NTC10K_Handle_t *ntc,
                      uint32_t adc_raw,
                      float known_temp_c)
{
    float voltage;
    float resistance;

    voltage = adc_to_voltage(adc_raw);
    resistance = voltage_to_resistance(voltage);

    ntc->R0 = resistance;
    ntc->T0 = known_temp_c + 273.15f; // Convert °C to Kelvin
    ntc->valid = 1;
}

float NTC10K_GetTemperature(NTC10K_Handle_t *ntc,
                            uint32_t adc_raw)
{
    float voltage;
    float resistance;
    float tempK;

    voltage = adc_to_voltage(adc_raw);
    resistance = voltage_to_resistance(voltage);

    tempK = 1.0f / (
                (1.0f / ntc->T0) +
                (1.0f / ntc->Beta) *
                log(resistance / ntc->R0)
            );

    return tempK - 273.15f; // Kelvin → Celsius
}

