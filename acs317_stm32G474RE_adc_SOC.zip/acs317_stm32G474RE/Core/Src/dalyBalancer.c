/*
 * dalyBalancer.c
 *
 *  Created on: Oct 14, 2025
 *      Author: Kachh
 */

#include "dalyBalancer.h"


int bitRead(int x, int n) {
	return (x >> n) & 1;
}

void dalyInit(void)
{
	my_txBuffer[0] = 0xA5;
	my_txBuffer[1] = 0x40;
	my_txBuffer[3] = 0x08;

	for (uint8_t i = 4; i < 12; i++)
	{
		my_txBuffer[i] = 0x00;
	}
}

void dalysendCommand(COMMAND cmdID)
{
//	dalysReceiveBytes();
	uint8_t checksum = 0;
	my_txBuffer[2] = cmdID;
	for (uint8_t i = 0; i <= 11; i++)
	{
		checksum += my_txBuffer[i];
	}
	// put it on the frame
	my_txBuffer[12] = checksum;
	HAL_UART_Transmit(&huart5, my_txBuffer, 13, HAL_MAX_DELAY);

}
bool dalysReceiveBytes()
{
	//	 memset(my_rxBuffer, 0, XFER_BUFFER_LENGTH);
	if(HAL_UART_Receive(&huart5, my_rxBuffer, XFER_BUFFER_LENGTH, 1000) == HAL_OK)
	{
		return true;
	}else
	{
		return false;
	}
}

/*
void dalysendCommand(COMMAND cmdID)
{
    uint8_t checksum = 0;
    my_txBuffer[2] = cmdID;

    // Calculate checksum
    for (uint8_t i = 0; i <= 11; i++)
    {
        checksum += my_txBuffer[i];
    }
    my_txBuffer[12] = checksum;

    // Start DMA transmission. The function returns immediately.
    HAL_UART_Transmit_DMA(&huart2, my_txBuffer, 13);
}

// This function should be called once, typically in main() or during initialization.
void dalysReceiveBytes(void)
{
    HAL_UART_Receive_DMA(&huart2, my_rxBuffer, XFER_BUFFER_LENGTH);
}*/
bool getPackMeasurements()
{
	__HAL_UART_CLEAR_FLAG(&huart5, USART_ICR_RTOCF);
	memset(my_rxBuffer, 0, sizeof(my_rxBuffer));
	dalysendCommand(VOUT_IOUT_SOC);
	if(dalysReceiveBytes() & validateChecksum()){
		get.packVoltage = ((float)((my_rxBuffer[4] << 8) | my_rxBuffer[5]) / 10.0f);
		// The current measurement is given with a 30000 unit offset (see /docs/)
		get.packCurrent = ((float)(((my_rxBuffer[8] << 8) | my_rxBuffer[9]) - 30000) / 10.0f);
		get.packSOC = ((float)((my_rxBuffer[10] << 8) | my_rxBuffer[11]) / 10.0f);
		return true;
	}
	return false;
}

bool getMinMaxCellVoltage()
{
	dalysendCommand(MIN_MAX_CELL_VOLTAGE);
	dalysReceiveBytes();
	get.maxCellmV = (float)((my_rxBuffer[4] << 8) | my_rxBuffer[5]);
	get.maxCellVNum = my_rxBuffer[6];
	get.minCellmV = (float)((my_rxBuffer[7] << 8) | my_rxBuffer[8]);
	get.minCellVNum = my_rxBuffer[9];
	get.cellDiff = (get.maxCellmV - get.minCellmV);
}

bool getPackTemp()
{
	dalysendCommand(MIN_MAX_TEMPERATURE);
	dalysReceiveBytes();

	get.tempMax = (my_rxBuffer[4] - 40);
	get.tempMin = (my_rxBuffer[6] - 40);
	get.tempAverage = (get.tempMax + get.tempMin) / 2;
}

bool getDischargeChargeMosStatus()
{

	dalysendCommand(DISCHARGE_CHARGE_MOS_STATUS);
	if(dalysReceiveBytes() & validateChecksum()){

		switch (my_rxBuffer[4])
		{
		case 0:
			get.chargeDischargeStatus = "Stationary";
			break;
		case 1:
			get.chargeDischargeStatus = "Charge";
			break;
		case 2:
			get.chargeDischargeStatus = "Discharge";
			break;
		}

		get.chargeFetState = my_rxBuffer[5];
		get.disChargeFetState = my_rxBuffer[6];
		get.bmsHeartBeat = my_rxBuffer[7];
		get.resCapacitymAh = ((uint32_t)my_rxBuffer[8] << 0x18) | ((uint32_t)my_rxBuffer[9] << 0x10) | ((uint32_t)my_rxBuffer[10] << 0x08) | (uint32_t)my_rxBuffer[11];
		memset(my_rxBuffer, 0, sizeof(my_rxBuffer));
		return true;
	}
	return false;
}

bool getStatusInfo() // 0x94
{
	dalysendCommand(STATUS_INFO);
	dalysReceiveBytes();

	get.numberOfCells = my_rxBuffer[4];
	get.numOfTempSensors = my_rxBuffer[5];
	get.chargeState = my_rxBuffer[6];
	get.loadState = my_rxBuffer[7];

	// Parse the 8 bits into 8 booleans that represent the states of the Digital IO
	for (size_t i = 0; i < 8; i++)
	{
		get.dIO[i] = bitRead(my_rxBuffer[8], i);
	}

	get.bmsCycles = ((uint16_t)my_rxBuffer[9] << 0x08) | (uint16_t)my_rxBuffer[10];

	return true;
}

bool getCellVoltages() // 0x95
{
	__HAL_UART_CLEAR_FLAG(&huart5, USART_ICR_RTOCF);
	memset(my_rxBuffer, 0, sizeof(my_rxBuffer));
	int cellNo = 0;
	// Check to make sure we have a valid number of cells
	if (get.numberOfCells < MIN_NUMBER_CELLS && get.numberOfCells >= MAX_NUMBER_CELLS)
	{
		return false;
	}

	dalysendCommand(CELL_VOLTAGES);

	for (size_t i = 0; i < 4; i++)
	{
		if(dalysReceiveBytes() & validateChecksum())
			//		HAL_UART_Receive(&huart5, my_rxBuffer, 13, HAL_MAX_DELAY);
		{

			for (size_t i = 0; i < 3; i++)
			{

				get.cellVmV[cellNo] = (my_rxBuffer[5 + i + i] << 8) | my_rxBuffer[6 + i + i];
				cellNo++;
				//				if (cellNo >= get.numberOfCells)
				//					break;
			}
		}

	}
	return true;
}

bool getCellTemperature() // 0x96
{
	int sensorNo = 0;

	// Check to make sure we have a valid number of temp sensors
	if ((get.numOfTempSensors < MIN_NUMBER_TEMP_SENSORS) && (get.numOfTempSensors >= MAX_NUMBER_TEMP_SENSORS))
	{
		return false;
	}

	dalysendCommand(CELL_TEMPERATURE);
	//	dalysReceiveBytes();

	for (size_t i = 0; i <= (get.numOfTempSensors / 7); i++)
	{

		if(dalysReceiveBytes() & validateChecksum())
		{
			for (size_t i = 0; i < 7; i++)
			{
				get.cellTemperature[sensorNo] = (my_rxBuffer[5 + i] - 40);
				sensorNo++;
				if (sensorNo + 1 >= get.numOfTempSensors)
					break;
			}
		}
	}
	return true;
}

bool getCellBalanceState() // 0x97
{
	int cellBalance = 0;
	int cellBit = 0;

	// Check to make sure we have a valid number of cells
	if (get.numberOfCells < MIN_NUMBER_CELLS && get.numberOfCells >= MAX_NUMBER_CELLS)
	{
		return false;
	}

	dalysendCommand(CELL_BALANCE_STATE);
	dalysReceiveBytes();


	// We expect 6 bytes response for this command
	for (size_t i = 0; i < 6; i++)
	{
		// For each bit in the byte, pull out the cell balance state boolean
		for (size_t j = 0; j < 8; j++)
		{
			get.cellBalanceState[cellBit] = bitRead(my_rxBuffer[i + 4], j);
			cellBit++;
			if (bitRead(my_rxBuffer[i + 4], j))
			{
				cellBalance++;
			}
			if (cellBit >= 47)
			{
				break;
			}
		}
	}

	if (cellBalance > 0)
	{
		get.cellBalanceActive = true;
	}
	else
	{
		get.cellBalanceActive = false;
	}

	return true;
}

bool getFailureCodes() // 0x98
{
	dalysendCommand(FAILURE_CODES);
	dalysReceiveBytes();

	/* 0x00 */
	alarm.levelOneCellVoltageTooHigh = bitRead(my_rxBuffer[4], 0);
	alarm.levelTwoCellVoltageTooHigh = bitRead(my_rxBuffer[4], 1);
	alarm.levelOneCellVoltageTooLow = bitRead(my_rxBuffer[4], 2);
	alarm.levelTwoCellVoltageTooLow = bitRead(my_rxBuffer[4], 3);
	alarm.levelOnePackVoltageTooHigh = bitRead(my_rxBuffer[4], 4);
	alarm.levelTwoPackVoltageTooHigh = bitRead(my_rxBuffer[4], 5);
	alarm.levelOnePackVoltageTooLow = bitRead(my_rxBuffer[4], 6);
	alarm.levelTwoPackVoltageTooLow = bitRead(my_rxBuffer[4], 7);

	/* 0x01 */
	alarm.levelOneChargeTempTooHigh = bitRead(my_rxBuffer[5], 1);
	alarm.levelTwoChargeTempTooHigh = bitRead(my_rxBuffer[5], 1);
	alarm.levelOneChargeTempTooLow = bitRead(my_rxBuffer[5], 1);
	alarm.levelTwoChargeTempTooLow = bitRead(my_rxBuffer[5], 1);
	alarm.levelOneDischargeTempTooHigh = bitRead(my_rxBuffer[5], 1);
	alarm.levelTwoDischargeTempTooHigh = bitRead(my_rxBuffer[5], 1);
	alarm.levelOneDischargeTempTooLow = bitRead(my_rxBuffer[5], 1);
	alarm.levelTwoDischargeTempTooLow = bitRead(my_rxBuffer[5], 1);

	/* 0x02 */
	alarm.levelOneChargeCurrentTooHigh = bitRead(my_rxBuffer[6], 0);
	alarm.levelTwoChargeCurrentTooHigh = bitRead(my_rxBuffer[6], 1);
	alarm.levelOneDischargeCurrentTooHigh = bitRead(my_rxBuffer[6], 2);
	alarm.levelTwoDischargeCurrentTooHigh = bitRead(my_rxBuffer[6], 3);
	alarm.levelOneStateOfChargeTooHigh = bitRead(my_rxBuffer[6], 4);
	alarm.levelTwoStateOfChargeTooHigh = bitRead(my_rxBuffer[6], 5);
	alarm.levelOneStateOfChargeTooLow = bitRead(my_rxBuffer[6], 6);
	alarm.levelTwoStateOfChargeTooLow = bitRead(my_rxBuffer[6], 7);

	/* 0x03 */
	alarm.levelOneCellVoltageDifferenceTooHigh = bitRead(my_rxBuffer[7], 0);
	alarm.levelTwoCellVoltageDifferenceTooHigh = bitRead(my_rxBuffer[7], 1);
	alarm.levelOneTempSensorDifferenceTooHigh = bitRead(my_rxBuffer[7], 2);
	alarm.levelTwoTempSensorDifferenceTooHigh = bitRead(my_rxBuffer[7], 3);

	/* 0x04 */
	alarm.chargeFETTemperatureTooHigh = bitRead(my_rxBuffer[8], 0);
	alarm.dischargeFETTemperatureTooHigh = bitRead(my_rxBuffer[8], 1);
	alarm.failureOfChargeFETTemperatureSensor = bitRead(my_rxBuffer[8], 2);
	alarm.failureOfDischargeFETTemperatureSensor = bitRead(my_rxBuffer[8], 3);
	alarm.failureOfChargeFETAdhesion = bitRead(my_rxBuffer[8], 4);
	alarm.failureOfDischargeFETAdhesion = bitRead(my_rxBuffer[8], 5);
	alarm.failureOfChargeFETTBreaker = bitRead(my_rxBuffer[8], 6);
	alarm.failureOfDischargeFETBreaker = bitRead(my_rxBuffer[8], 7);

	/* 0x05 */
	alarm.failureOfAFEAcquisitionModule = bitRead(my_rxBuffer[9], 0);
	alarm.failureOfVoltageSensorModule = bitRead(my_rxBuffer[9], 1);
	alarm.failureOfTemperatureSensorModule = bitRead(my_rxBuffer[9], 2);
	alarm.failureOfEEPROMStorageModule = bitRead(my_rxBuffer[9], 3);
	alarm.failureOfRealtimeClockModule = bitRead(my_rxBuffer[9], 4);
	alarm.failureOfPrechargeModule = bitRead(my_rxBuffer[9], 5);
	alarm.failureOfVehicleCommunicationModule = bitRead(my_rxBuffer[9], 6);
	alarm.failureOfIntranetCommunicationModule = bitRead(my_rxBuffer[9], 7);

	/* 0x06 */
	alarm.failureOfCurrentSensorModule = bitRead(my_rxBuffer[10], 0);
	alarm.failureOfMainVoltageSensorModule = bitRead(my_rxBuffer[10], 1);
	alarm.failureOfShortCircuitProtection = bitRead(my_rxBuffer[10], 2);
	alarm.failureOfLowVoltageNoCharging = bitRead(my_rxBuffer[10], 3);

	return true;
}

bool validateChecksum()
{
	uint8_t checksum = 0x00;

	for (int i = 0; i < XFER_BUFFER_LENGTH - 1; i++)
	{
		checksum += my_rxBuffer[i];
	}

	if(checksum == my_rxBuffer[XFER_BUFFER_LENGTH - 1]){
		return true;
	}
	return false;
}

static inline void BMS_UpdateFault(bool status, BMS_Fault_t fault)
{
    if(status == false)
        bmsFaultRegister |= fault;      // set fault bit
    else
        bmsFaultRegister &= ~fault;     // clear fault bit
}


void BMS_ServiceTask(void)
{
    bool ret;

    ret = getStatusInfo();
    BMS_UpdateFault(ret, BMS_FAULT_STATUS_INFO);
    HAL_Delay(10);

    ret = getCellVoltages();
    BMS_UpdateFault(ret, BMS_FAULT_CELL_VOLTAGE);
    HAL_Delay(10);

    ret = getDischargeChargeMosStatus();
    BMS_UpdateFault(ret, BMS_FAULT_CHG_DSG_MOS);
    HAL_Delay(10);

    ret = getPackMeasurements();
    BMS_UpdateFault(ret, BMS_FAULT_PACK_MEASUREMENT);
    HAL_Delay(10);

    ret = getFailureCodes();
    BMS_UpdateFault(ret, BMS_FAULT_FAILURE_CODE);
    HAL_Delay(10);

    ret = getCellTemperature();
    BMS_UpdateFault(ret, BMS_FAULT_CELL_TEMPERATURE);
    HAL_Delay(10);

    ret = getPackTemp();
    BMS_UpdateFault(ret, BMS_FAULT_PACK_TEMPERATURE);
    HAL_Delay(10);

    ret = getMinMaxCellVoltage();
    BMS_UpdateFault(ret, BMS_FAULT_MIN_MAX_CELL_VOLTAGE);
    HAL_Delay(10);

    ret = getCellBalanceState();
    BMS_UpdateFault(ret, BMS_FAULT_CELL_BALANCE);
    HAL_Delay(10);
}

