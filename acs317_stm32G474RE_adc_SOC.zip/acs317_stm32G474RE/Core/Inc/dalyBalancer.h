/*
 * dalyBalancer.h
 *
 *  Created on: Oct 14, 2025
 *      Author: Kachh
 */

#ifndef INC_DALYBALANCER_H_
#define INC_DALYBALANCER_H_
#include "main.h"

#include <stdbool.h>
#define XFER_BUFFER_LENGTH 13
#define MIN_NUMBER_CELLS 1
#define MAX_NUMBER_CELLS 48
#define MIN_NUMBER_TEMP_SENSORS 1
#define MAX_NUMBER_TEMP_SENSORS 16

typedef enum
{
    VOUT_IOUT_SOC = 0x90,
    MIN_MAX_CELL_VOLTAGE = 0x91,
    MIN_MAX_TEMPERATURE = 0x92,
    DISCHARGE_CHARGE_MOS_STATUS = 0x93,
    STATUS_INFO = 0x94,
    CELL_VOLTAGES = 0x95,
    CELL_TEMPERATURE = 0x96,
    CELL_BALANCE_STATE = 0x97,
    FAILURE_CODES = 0x98,
    DISCHRG_FET = 0xD9,
    CHRG_FET = 0xDA,
    BMS_RESET = 0x00,
}COMMAND;

typedef struct
{
    // data from 0x90
    float packVoltage; // Total pack voltage (0.1 V)
    float packCurrent; // Current in (+) or out (-) of pack (0.1 A)
    float packSOC;     // State Of Charge

    // data from 0x91
    float maxCellmV; // Maximum cell voltage (mV)
    int maxCellVNum; // Number of cell with highest voltage
    float minCellmV; // Minimum cell voltage (mV)
    int minCellVNum; // Number of cell with lowest voltage
    float cellDiff;  // Difference between min and max cell voltages

    // data from 0x92
    int tempMax;       // Maximum temperature sensor reading (°C)
    int tempMin;       // Minimum temperature sensor reading (°C)
    float tempAverage; // Average of temp sensors

    // data from 0x93
    char* chargeDischargeStatus; // charge/discharge status (0 stationary, 1 charge, 2 discharge)
    bool chargeFetState;          // charging MOSFET status
    bool disChargeFetState;       // discharge MOSFET state
    int bmsHeartBeat;             // BMS life (0~255 cycles)?
    int resCapacitymAh;           // residual capacity mAH

    // data from 0x94
    int numberOfCells;    // Cell count
    int numOfTempSensors; // Temp sensor count
    bool chargeState;     // charger status 0 = disconnected 1 = connected
    bool loadState;       // Load Status 0=disconnected 1=connected
    bool dIO[8];          // No information about this
    int bmsCycles;        // charge / discharge cycles

    // data from 0x95
    float cellVmV[48]; // Store Cell Voltages (mV)

    // data from 0x96
    int cellTemperature[16]; // array of cell Temperature sensors

    // data from 0x97
    bool cellBalanceState[48]; // bool array of cell balance states
    bool cellBalanceActive;    // bool is cell balance active

    // debug data string
    char* aDebug;
} get_;



typedef struct
{
    // data from 0x98
    /* 0x00 */
    bool levelOneCellVoltageTooHigh;
    bool levelTwoCellVoltageTooHigh;
    bool levelOneCellVoltageTooLow;
    bool levelTwoCellVoltageTooLow;
    bool levelOnePackVoltageTooHigh;
    bool levelTwoPackVoltageTooHigh;
    bool levelOnePackVoltageTooLow;
    bool levelTwoPackVoltageTooLow;

    /* 0x01 */
    bool levelOneChargeTempTooHigh;
    bool levelTwoChargeTempTooHigh;
    bool levelOneChargeTempTooLow;
    bool levelTwoChargeTempTooLow;
    bool levelOneDischargeTempTooHigh;
    bool levelTwoDischargeTempTooHigh;
    bool levelOneDischargeTempTooLow;
    bool levelTwoDischargeTempTooLow;

    /* 0x02 */
    bool levelOneChargeCurrentTooHigh;
    bool levelTwoChargeCurrentTooHigh;
    bool levelOneDischargeCurrentTooHigh;
    bool levelTwoDischargeCurrentTooHigh;
    bool levelOneStateOfChargeTooHigh;
    bool levelTwoStateOfChargeTooHigh;
    bool levelOneStateOfChargeTooLow;
    bool levelTwoStateOfChargeTooLow;

    /* 0x03 */
    bool levelOneCellVoltageDifferenceTooHigh;
    bool levelTwoCellVoltageDifferenceTooHigh;
    bool levelOneTempSensorDifferenceTooHigh;
    bool levelTwoTempSensorDifferenceTooHigh;

    /* 0x04 */
    bool chargeFETTemperatureTooHigh;
    bool dischargeFETTemperatureTooHigh;
    bool failureOfChargeFETTemperatureSensor;
    bool failureOfDischargeFETTemperatureSensor;
    bool failureOfChargeFETAdhesion;
    bool failureOfDischargeFETAdhesion;
    bool failureOfChargeFETTBreaker;
    bool failureOfDischargeFETBreaker;

    /* 0x05 */
    bool failureOfAFEAcquisitionModule;
    bool failureOfVoltageSensorModule;
    bool failureOfTemperatureSensorModule;
    bool failureOfEEPROMStorageModule;
    bool failureOfRealtimeClockModule;
    bool failureOfPrechargeModule;
    bool failureOfVehicleCommunicationModule;
    bool failureOfIntranetCommunicationModule;

    /* 0x06 */
    bool failureOfCurrentSensorModule;
    bool failureOfMainVoltageSensorModule;
    bool failureOfShortCircuitProtection;
    bool failureOfLowVoltageNoCharging;
} alarm_;

typedef enum
{
    BMS_FAULT_NONE                     = 0x00000000,

    BMS_FAULT_STATUS_INFO              = 0x00000001,
    BMS_FAULT_CELL_VOLTAGE             = 0x00000002,
    BMS_FAULT_CHG_DSG_MOS              = 0x00000004,
    BMS_FAULT_PACK_MEASUREMENT         = 0x00000008,
    BMS_FAULT_FAILURE_CODE             = 0x00000010,
    BMS_FAULT_CELL_TEMPERATURE         = 0x00000020,
    BMS_FAULT_PACK_TEMPERATURE         = 0x00000040,
    BMS_FAULT_MIN_MAX_CELL_VOLTAGE     = 0x00000080,
    BMS_FAULT_CELL_BALANCE             = 0x00000100,
}BMS_Fault_t;


extern volatile uint8_t my_txBuffer[13];
extern volatile uint8_t my_rxBuffer[XFER_BUFFER_LENGTH];
extern volatile get_ get;
extern alarm_ alarm;
extern volatile uint32_t bmsFaultRegister;

void dalyInit(void);
void dalysendCommand(COMMAND cmdID);
bool dalysReceiveBytes(void);
bool getPackMeasurements();
bool getPackTemp();
bool getMinMaxCellVoltage();
bool getStatusInfo();
bool getCellVoltages();
bool getCellTemperature();
bool getCellBalanceState();
bool getFailureCodes();
bool setDischargeMOS(bool sw);
bool setChargeMOS(bool sw);
bool getDischargeChargeMosStatus();
bool setBmsReset();
bool validateChecksum();
void BMS_ServiceTask(void);


#endif /* INC_DALYBALANCER_H_ */
