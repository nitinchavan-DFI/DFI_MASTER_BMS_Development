/*
 * ntc10k.h
 *
 *  Created on: Feb 5, 2026
 *      Author: semeen
 */

#ifndef INC_NTC10K_H_
#define INC_NTC10K_H_

#include <stdint.h>

/* ================= USER CONFIG ================= */

#define NTC_ADC_MAX        4095.0f   // 12-bit ADC
#define NTC_VREF           3.3f      // ADC reference voltage

#define NTC_SERIES_RES     10000.0f  // Fixed resistor value (ohms)

/* Default Beta (used if not calibrated) */
#define NTC_DEFAULT_BETA   3950.0f

/* ================= DATA STRUCT ================= */

typedef struct
{
    float R0;       // Resistance at reference temperature
    float T0;       // Reference temperature (Kelvin)
    float Beta;     // Beta value
    uint8_t valid;  // Calibration valid flag
} NTC10K_Handle_t;

/* ================= API ================= */

/* Initialize NTC handle with default values */
void NTC10K_Init(NTC10K_Handle_t *ntc);

/* One-point calibration (pass known temperature in °C) */
void NTC10K_Calibrate(NTC10K_Handle_t *ntc,
                      uint32_t adc_raw,
                      float known_temp_c);

/* Convert ADC raw value to temperature (°C) */
float NTC10K_GetTemperature(NTC10K_Handle_t *ntc,
                            uint32_t adc_raw);


#endif /* INC_NTC10K_H_ */
