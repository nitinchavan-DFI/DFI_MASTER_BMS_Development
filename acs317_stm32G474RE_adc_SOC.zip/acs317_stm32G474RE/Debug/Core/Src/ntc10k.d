Core/Src/ntc10k.o: ../Core/Src/ntc10k.c ../Core/Inc/ntc10k.h
../Core/Inc/ntc10k.h:
